
import { io } from 'socket.io-client';
//import { getUnSyncedCustomer } from '../service/customerService';
import { syncOrderDataResult, syncOrderRetunResult } from "../service/orderService";
import { getUnSynOrder, getUnSynReturnOrder } from "../controller/orderController";
import * as productController from "../controller/productController";
import { getUnSyncedCustomer, syncCustomerDataResult } from "../service/customerService";
import * as discountController from '../controller/discountController'
import { itemDataSetup } from '../controller/itemDataSetup';
import { getInverntorySync, getUnSyncedStockTransfer } from '../controller/stockTransferController';
import { syncStockTransferDataResult } from '../service/stockTransferService';
import { getposid } from '../service/storeService';
import * as userController from '../controller/userController'
import { getUnSyncedSaleCreditNote, getUnSyncedSaleDelivery, getUnSyncedSaleInvoice, getUnSyncedSaleReturn, getUnSyncedSalesOrder } from '../controller/salesOrderController';
import * as salesOrderService from '../service/salesOrderService'
import * as purchaseOrderService from '../service/purchaseOrderService'
import { getUnPurchaseCreditNote, getUnPurchaseInvoice, getUnPurchaseReturn, getUnSyncedGRN, getUnSyncPurchaseOrder, getUnSyncPurchaseOrderIncompany, grnSync, InvoiceSYNC } from '../controller/purchaseOrderController';
import { accountDataSetup, getUnSyncCustomerGLAccount, getUnSyncjournEntry } from '../controller/accountDataSetup';
import { asyncJouranlEntryDataResult, customerGLSyncDataResult } from '../service/accountSyncService';
import { getposId } from '../service/storeService';
//const url = 'http://120.138.10.236:8001'
let url 
 const geturl = await getposId()
 
 console.log(geturl.rows)
 url = `http://${geturl.rows[0].cpos_ip_address}:8001`
//url =  'http://localhost:8001'
 
console.log(url)

let socket = io(url, {
    transports: ['websocket'],
    auth: {
        token: 'CPOSSYNID', // Replace with your custom token
      },
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    randomizationFactor: 0.5
});

 socket.on('connect', () => {
    console.log('Connected to CPOS server', socket.id);
// // //     // socket.emit('sync', { message: 'POS data to sync' });

// // //     // getposid()
// // //     // getUnSyncedCustomer();
// // //     // getUnSynOrder();
// // //     // getUnSyncedStockTransfer()
// // //     // getInverntorySync()
// // //     // getUnSyncedSalesOrder()
// // //     // getUnSyncPurchaseOrder()
// // //     // getUnSyncedSaleDelivery()
// // //     // getUnSyncedSaleInvoice()
// // //     // getUnSyncedSaleReturn()
// // //     // getUnSyncedSaleCreditNote()
// // //     // getUnSyncedGRN()
// // //     // getUnPurchaseInvoice()
// // //     // getUnPurchaseReturn()
// // //     // getUnPurchaseCreditNote()
    
 });

 socket.on('connect_error', (err) => {
    console.error('Connection failed:', err.message);
    if (err.message === 'Token is missing') {
      console.error('Please provide a valid token.');
    } else if (err.message === 'Invalid or expired token') {
      console.error('Your token is invalid or has expired.');
    }
  });

socket.on('itemSync', (data: any) => {
    //   console.log('Received update item ifo from CPOS:', data);
    productController.itemInfoSync(data.body)

});

socket.on('disconnect', () => {
    console.log('Disconnected from CPOS server');
});



socket.on('itemDataSetUp', (data: any) => {
    // console.log('synced from CPOS server', data);
    let orderData = {

        itemData: data.body.itemData
    };
    itemDataSetup(orderData);
});
socket.on('discountSettingSync', (data: any) => {
    // console.log('synced from CPOS server', data);
    let discountrData = {

        discountData: data.body.discountData
    };
     discountController.discountDataSetupSync(discountrData);
});

socket.on('userauth', (data: any) => {
     console.log('synced  auth from CPOS server', data);

    userController.asyncUserAuth(data.body.itemData.users_table)
    //  let authData = {

    //      discountData: data.body.discountData
    //  };
    //  discountController.discountDataSetupSync(discountrData);

});

socket.on('GRNSYNC', (data: any) => {
    console.log('synced  auth from grn CPOS server', data);
    grnSync(data,socket.id)
 

});


socket.on('InvoiceYNC', (data: any) => {
    console.log('synced  auth from grn CPOS server', data);

    InvoiceSYNC(data,socket.id)
 

});


socket.on('sync-acknowledgment', (data: any) => {
    //   console.log('synced from CPOS server', data);
    let customerData = {
        cmr_id: data.cmr_id,
        data_synced: data.sync
    };
    syncCustomerDataResult(customerData.cmr_id, customerData);
});

socket.on('biiling_order_sync-acknowledgment', (data: any) => {
    //  console.log('synced from CPOS server', data);
    let orderData = {
        sot_id: data.sot_id,
        data_synced: data.sync
    };
    syncOrderDataResult(orderData, orderData.sot_id);
});

socket.on('return_order_sync-acknowledgment', (data: any) => {
    //  console.log('synced from CPOS server', data);
    let orderData = {
        icn_id: data.icn,
        data_synced: data.sync
    };
console.log(data,"return" ,orderData)
    syncOrderRetunResult(orderData, data.icn);
});

socket.on('stock_transfer_sync-acknowledgment', (data: any) => {
    //     console.log('synced from CPOS server', data);
    let orderData = {
        itt_id: data.itt_id,
        data_synced: data.sync
    }

    syncStockTransferDataResult(orderData, orderData.itt_id);
});

socket.on('sales_order_sync-acknowledgment', (data: any) => {
    console.log('synced from CPOS server', data);
    let orderData = {
        sott_id: data.sott_id,
        data_synced: data.sync
    }

    salesOrderService.syncSalesOrderDataResult(orderData, orderData.sott_id);
});


socket.on('sales_delivery_sync-acknowledgment', (data: any) => {
    console.log('synced  sales_delivery_sync-acknowledgmentfrom CPOS server', data);
    let orderData = {
        sodtt_id: data.sodtt_id,
        data_synced: data.sync
    }

    salesOrderService.syncSalesDeliveryDataResult(orderData, orderData.sodtt_id);
});

socket.on('sales_invoice_sync-acknowledgment', (data: any) => {
    console.log('synced  sales_invoice_sync-acknowledgmentfrom CPOS server', data);
    let orderData = {
        soit_id: data.soit_id,
        data_synced: data.sync
    }

    salesOrderService.syncSalesInoviceDataResult(orderData, orderData.soit_id);
});

socket.on('sales_return_sync-acknowledgment', (data: any) => {
    console.log('synced  sales_invoice_sync-acknowledgmentfrom CPOS server', data);
    let orderData = {
        srt_id: data.srt_id,
        data_synced: data.sync
    }

    salesOrderService.syncSalesReturneDataResult(orderData, orderData.srt_id);
});

socket.on('sales_credit_note_sync-acknowledgment', (data: any) => {
  //  console.log('synced  sales_invoice_sync-acknowledgmentfrom CPOS server', data);
    let orderData = {
        sct_id: data.sct_id,
        data_synced: data.sync
    }

    salesOrderService.syncSalesCreditNoteDataResult(orderData, orderData.sct_id);
});

socket.on('purchase_order_sync-acknowledgment', (data: any) => {
   // console.log('synced from CPOS server', data);
    let orderData = {
        pot_id: data.pot_id,
        data_synced: data.sync
    }

    purchaseOrderService.syncPurchaseOrderDataResult(orderData, orderData.pot_id);
});



socket.on('purchase_grn_sync-acknowledgment', (data: any) => {
    console.log('synced from CPOS server', data);
    let orderData = {
        gort_id: data.gort_id,
        data_synced: data.sync
    }

    purchaseOrderService.syncGRNDataResult(orderData, orderData.gort_id);
});



socket.on('purchase_invoice_sync-acknowledgment', (data: any) => {
    console.log('synced from CPOS server', data);
    let orderData = {
        poit_id: data.poit_id,
        data_synced: data.sync
    }

    purchaseOrderService.syncPurchaseInvoiceDataResult(orderData, orderData.poit_id);
});

socket.on('purchase_return_sync-acknowledgment', (data: any) => {
    console.log('synced from CPOS server', data);
    let orderData = {
        prt_id: data.prt_id,
        data_synced: data.sync
    }

    purchaseOrderService.syncPurchaseReturnDataResult(orderData, orderData.prt_id);
});


socket.on('purchase_credit_note_sync-acknowledgment', (data: any) => {
    console.log('synced from CPOS server', data);
    let orderData = {
        pct_id: data.pct_id,
        data_synced: data.sync
    }

    purchaseOrderService.syncPurchaseCreditNoteDataResult(orderData, orderData.pct_id);
});


socket.on('journal_entry_sync-acknowledgment', (data: any) => {
    console.log('synced from CPOS server', data);
    let orderData = {
        transcation_id: data.transcation_id,
        data_synced: data.sync
    }
    
asyncJouranlEntryDataResult(orderData, orderData.transcation_id);
});

socket.on('customer_gl_account_sync-acknowledgment', (data: any) => {
    console.log('synced from CPOS server', data);
    let orderData = {
        account_id: data.account_id,
        data_synced: data.sync
    }
    
customerGLSyncDataResult(orderData, orderData.account_id);
});


socket.on('purhcaseOrderSyncInterCompanyStatus', (data: any) => {
    console.log('synced from CPOS server', data);
    const orderData = {
        pot_order_status:data.pot_order_status,
    }
    purchaseOrderService.poupdateOrderDataStatus(orderData,data.pot_id,data.pos_id)
    
          
});


socket.on('accountSync', (data: any) => {
    // console.log('synced from CPOS server', data);
    let accountData = {

        accountData: data.body.accountData
    };

    accountDataSetup(accountData);
});

export function sync(){setInterval(async () => {
    try {
        console.log("sync calll")
        getposid()
        getUnSyncPurchaseOrderIncompany()
        getUnSyncedCustomer();
        getUnSynOrder();
        getUnSyncedStockTransfer()
      //  getInverntorySync()
        getUnSyncedSalesOrder()
        getUnSyncPurchaseOrder()
        getUnSyncedSaleDelivery()
        getUnSyncedSaleInvoice()
        getUnSyncedSaleReturn()
        getUnSyncedSaleCreditNote()
        getUnSyncedGRN()
        getUnPurchaseInvoice()
        getUnPurchaseReturn()
        getUnPurchaseCreditNote()
        getUnSyncjournEntry()
        getUnSyncCustomerGLAccount()
        getUnSynReturnOrder()
     

      
    } catch (error) {
        console.error('Error making API call:', error);
    }
}, 600000);  

setInterval(() => {
    const now = new Date();
    const targetHour = 23; // 11 PM
    const targetMinute = 0; // 00 minutes

    if (now.getHours() === targetHour && now.getMinutes() === targetMinute) {
      console.log("Running getInverntorySync at scheduled time");
      getInverntorySync();
    }
  }, 600000);
}

export default socket

