import { Router } from 'express';
import * as orderController from '../../controller/orderController';
import * as  authService from '../../middleware/authService'
const orderRouter = Router();





orderRouter.post('/api/order/add',authService.authenticate, orderController.addOrder)

orderRouter.post('/api/order/draft/create',authService.authenticate,orderController.addDrafOrder)

orderRouter.post('/api/order/draft/update',authService.authenticate, orderController.updateDrafOrder)

orderRouter.post('/api/order/payment',authService.authenticate,  orderController.payment)

orderRouter.get('/api/order/get',authService.authenticate, orderController.getOrderList)

orderRouter.get('/api/order/get/repeatPastOrder',authService.authenticate, orderController.repeatPastOrder)

orderRouter.get("/api/order/getOrderById",authService.authenticate,orderController.getOrderById)

orderRouter.get('/api/order/app/getOrderById',authService.authenticate,orderController.getOrderByIdApp)

orderRouter.post('/api/order/draft/delete', authService.authenticate,orderController.deleteDraftOrder)

orderRouter.get('/api/order/pastorder/get',authService.authenticate, orderController.getPastOrder)

orderRouter.get('/api/doctor/get',authService.authenticate,orderController.getDoctor )

orderRouter.get('/api/order/dashboard/graph1/get',authService.authenticate,orderController.getDashboardGraph1 )


orderRouter.get('/api/order/getInvoiceItemsList',authService.authenticate, orderController.getInvoiceitemsList)

orderRouter.post('/api/order/creditNote/add',authService.authenticate, orderController.addInvoiceCreditNote)

orderRouter.get('/api/order/creditNote/getall',authService.authenticate, orderController.getCreditNoteOrderList)

orderRouter.get('/api/order/creditNote/getById',authService.authenticate, orderController.getCreditNoteOrderById)

orderRouter.post('/api/order/invoice/share', orderController.invoiceShare)

orderRouter.get("/api/order/getOrderByIdAsPdf",authService.authenticate,orderController.getOrderByIdAsPdf)

orderRouter.get("/api/order/invoice_credit_note/getOrderByIdHTML",authService.authenticate,orderController.getSalesReturnInvoiceByIdHTML)

export default orderRouter;