import { Router } from 'express';
import * as paymentTypeController from '../../controller/paymentTypeController';
import * as  authService from '../../middleware/authService'
const paymentTypeRoutes = Router();


paymentTypeRoutes.post('/api/paymentType/add', authService.authenticate,paymentTypeController.addPymentType)
paymentTypeRoutes.post('/api/paymentType/edit', authService.authenticate,paymentTypeController.editPymentType)
paymentTypeRoutes.get('/api/paymentType/getById', authService.authenticate,paymentTypeController.getPymentTypeById)



export default paymentTypeRoutes;