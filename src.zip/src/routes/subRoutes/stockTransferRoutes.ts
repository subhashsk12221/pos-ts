import { Router } from 'express';
import * as stockTransferController from '../../controller/stockTransferController';
import * as  authService from '../../middleware/authService'
const stockTransferRouter = Router();

stockTransferRouter.post('/api/stock/transfer/create',authService.authenticate, stockTransferController.createStockTransfer)

stockTransferRouter.get('/api/stock/transfer/list', authService.authenticate,stockTransferController.getStockTransferList)

stockTransferRouter.get('/api/stock/transfer/getById',authService.authenticate, stockTransferController.getStockTransferById)

stockTransferRouter.post('/api/stock/transfer/void',authService.authenticate, stockTransferController.voidStockTranferRocordLevel)

stockTransferRouter.post('/api/stock/transfer/void/item',authService.authenticate, stockTransferController.voidStockTranferSubRocordLevel)

stockTransferRouter.post('/api/stock/transfer/warehouse/add', authService.authenticate,stockTransferController.addWareHouse)

stockTransferRouter.get('/api/stock/transfer/warehouselist', authService.authenticate,stockTransferController.getWareHouseList)






export default stockTransferRouter;