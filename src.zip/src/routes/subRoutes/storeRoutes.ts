import { Router } from 'express';
import * as storeController from '../../controller/storeController';
import * as  authService from '../../middleware/authService'
import * as uploadService from '../../util/uploadService';
const storeRoutes = Router();




storeRoutes.post('/api/store/address/add',authService.authenticate,storeController.addStoreAddress)

storeRoutes.post('/api/store/personalDetails/add',authService.authenticate,storeController.addStorePersonalDetails)

storeRoutes.post('/api/store/firmDetails/add', authService.authenticate,storeController.addStoreFirmDetails)

storeRoutes.post('/api/store/storeAgreement/add',authService.authenticate,storeController.addStoreAgreementDetails)

storeRoutes.post('/api/store/paymentDetails/add',authService.authenticate,storeController.addStorePaymentDetails)

storeRoutes.post('/api/store/drugLicenseDetails/add', authService.authenticate,storeController.addStoreDrugLicenseDetails)

storeRoutes.post('/api/image/upload',authService.authenticate, uploadService.addfiles )

storeRoutes.get('/api/store/getById',authService.authenticate,storeController.getById)

storeRoutes.get('/api/storelist/get', authService.authenticate,storeController.getStoreList)

storeRoutes.get('/api/store/details/getById', authService.authenticate, storeController.getStoreByIdService )

storeRoutes.post('/api/store/details/add',authService.authenticate, storeController.addStoreService )

storeRoutes.post('/api/store/details/update',authService.authenticate, storeController.updateStoreService )


export default storeRoutes;