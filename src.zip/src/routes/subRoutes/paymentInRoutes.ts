
import { Router } from 'express';
import * as paymentInController from '../../controller/paymentInController';
import * as  authService from '../../middleware/authService'
const paymentInRoutes = Router();

paymentInRoutes.post('/api/paymentIn/add', paymentInController.addPaymentIN )

paymentInRoutes.post('/api/paymentOut/add', paymentInController.addPaymentOut )

paymentInRoutes.get('/api/payment/glaccount/getAll',paymentInController.getGlAccount)

paymentInRoutes.get('/api/paymentIn/getAll',paymentInController.getAllPaymentIn)

paymentInRoutes.get('/api/paymentIn/getbyId', paymentInController.paymentInGetbyId)

paymentInRoutes.get('/api/paymentOut/getbyId', paymentInController.paymentOutGetbyId)

paymentInRoutes.get('/api/paymentOut/getAll', paymentInController.getAllPaymentOut)


export default paymentInRoutes;