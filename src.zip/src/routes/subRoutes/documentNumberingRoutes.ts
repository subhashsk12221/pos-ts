import { Router } from 'express';
import * as documentNumberingSeriesController from '../../controller/documentNumbering';
import * as  authService from '../../middleware/authService'
const documentNumneringRoutes = Router();


documentNumneringRoutes.post('/api/document/numbering/add', authService.authenticate, documentNumberingSeriesController.addDocument)

documentNumneringRoutes.post('/api/document/numbering/series/add',authService.authenticate, documentNumberingSeriesController.addSeriesToDocument)

documentNumneringRoutes.get('/api/document/numbering/series/get', authService.authenticate,documentNumberingSeriesController.getSeriesToDocument)

documentNumneringRoutes.post('/api/document/numbering/series/update',authService.authenticate,documentNumberingSeriesController.updateDocumentSeries)

documentNumneringRoutes.get('/api/document/numbering/document/getAll',authService.authenticate,documentNumberingSeriesController.getAllDocument)



export default documentNumneringRoutes;