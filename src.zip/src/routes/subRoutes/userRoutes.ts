import { Router } from 'express';
import * as userController from '../../controller/userController';
import * as  authService from '../../middleware/authService'
const userRoutes = Router();




userRoutes.post('/api/user/create',userController.signup)

userRoutes.post('/api/user/login',userController.login)

userRoutes.post('/api/create/role',userController.createRole)

userRoutes.post('/api/create/department',userController.createDepartment)

userRoutes.get('/api/roles/get',userController.getRoles)

userRoutes.get('/api/department/get',userController.getDeparmment)

userRoutes.get('/api/user/getAll', userController.getAllUser)

userRoutes.get('/api/user/getById', userController.getUserById)

userRoutes.post('/api/user/update',userController.updateUser)

//app.post('/api/store/address/update', authService.authenticate,storeController.updateStoreAddress)

userRoutes.post('/api/user/permission/add',authService.authenticate,userController.addUserPermission)

userRoutes.post('/api/user/permission/update', authService.authenticate,userController.updatePermission)

userRoutes.get('/api/user/permission/get', authService.authenticate, userController.getPermission)

userRoutes.get('/api/user/permission/getById', userController.getUserPermissionById)

userRoutes.get('/api/user/getUsers', userController.getAllUserWithoutPagination)

userRoutes.post('/api/submodule/add',userController.addModule)

userRoutes.get('/api/submodule/get',userController.getModule)

userRoutes.post('/api/submodule/update',userController.addUpdateUpdateModule)

userRoutes.post('/api/main/module/add',userController.addMainModule)

userRoutes.post('/api/user/forgot/password', userController.forgotPassword)

userRoutes.post('/api/user/reset/password', userController.resetPassword)

export default userRoutes;