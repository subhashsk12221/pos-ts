

import { Router } from 'express';
import * as financialLedgerController from '../../controller/financialLedgerController';
import * as  authService from '../../middleware/authService'
const financialLedgerRoutes = Router();



financialLedgerRoutes.post('/api/financialLedger/account/add', financialLedgerController.addChartsOfAccounts)

financialLedgerRoutes.post('/api/financialLedger/account/update', financialLedgerController.updateChartsOfAccounts)

financialLedgerRoutes.post('/api/financialLedger/account/delete', financialLedgerController.deletChartsAccount)

financialLedgerRoutes.get('/api/financialLedger/account/get',financialLedgerController.getChartsOfAccounts)

financialLedgerRoutes.post('/api/financialLedger/generalAccount/update',financialLedgerController.updateGeneralAccountAllocation)

financialLedgerRoutes.post('/api/financialLedger/generalAccount/financialYear/add', financialLedgerController.addFinancialYear)

financialLedgerRoutes.get('/api/financialLedger/searchGeneralAccount/get',financialLedgerController.getGeneralAccount)

financialLedgerRoutes.get('/api/financialLedger/columnsNames/get', financialLedgerController.getColumnofAccountType)

financialLedgerRoutes.get('/api/financialLedger/generalAccountsOfYears/get', financialLedgerController.getGeneralAccountsOfYears)

financialLedgerRoutes.get('/api/financialLedger/journEntry/get', financialLedgerController.getjournEntry)

financialLedgerRoutes.get('/api/financialLedger/journEntry/search',financialLedgerController.searchJournalEntry)

financialLedgerRoutes.get('/api/financialLedger/yearList',financialLedgerController.getYearList)


export default financialLedgerRoutes;