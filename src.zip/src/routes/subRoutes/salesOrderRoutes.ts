import { Router } from 'express';
import * as salesOrderController from '../../controller/salesOrderController';
import * as  authService from '../../middleware/authService'
const salesOrderRoutes = Router();



salesOrderRoutes.post('/api/salesorder/add', salesOrderController.addSalesOrder)

salesOrderRoutes.post('/api/salesorder/update', salesOrderController.updateSalesOrder)

salesOrderRoutes.get('/api/saleorder/products/get', salesOrderController.getSalesProduct)

salesOrderRoutes.get('/api/saleorder/orderList/getAll', salesOrderController.getSalesOrderList)

salesOrderRoutes.get('/api/saleorder/getOrderById', salesOrderController.getSalesOrderById)

salesOrderRoutes.get('/api/saleorder/getSalesitemsList', salesOrderController.getSalesitemsList)

salesOrderRoutes.post('/api/saleorder/delivery/add', salesOrderController.addSaleDelivery)

salesOrderRoutes.post('/api/saleorder/delivery/update', salesOrderController.updateDeliveryOrder)

salesOrderRoutes.post('/api/saleorder/delivery/void', salesOrderController.voidDeliveryOrder)

salesOrderRoutes.get('/api/saleorder/delivery/getAll', salesOrderController.getSaleDelivery)

salesOrderRoutes.get('/api/saleorder/delivery/getOrderById', salesOrderController.getDeliveryOrderById)

salesOrderRoutes.get('/api/saleorder/delivery/getDeliveryitemsList', salesOrderController.getDeliveryitemsList)

salesOrderRoutes.post('/api/saleorder/invoice/add', salesOrderController.addSalesOrderInvoice)

salesOrderRoutes.post('/api/saleorder/invoice/void', salesOrderController.voidInvoice)

salesOrderRoutes.post('/api/saleorder/invoice/update', salesOrderController.updateSalesOrderInvoice)

salesOrderRoutes.get('/api/saleorder/invoice/getAll', salesOrderController.getSalesOrderInvoiceList)

salesOrderRoutes.get('/api/saleorder/invoice/getById', salesOrderController.getSalesOrderInvoiceById)

salesOrderRoutes.get('/api/saleorder/invoice/orderList', salesOrderController.getSalesInvoiceList)

salesOrderRoutes.get('/api/saleorder/invoice/orderList/search', salesOrderController.getSalesInvoiceListSearch)

salesOrderRoutes.get('/api/saleorder/invoice/getInvoiceitemsList', salesOrderController.getInvoiceitemsList)

salesOrderRoutes.post('/api/saleorder/returnInvoice/add', salesOrderController.addSalesReturnInvoice)

salesOrderRoutes.post('/api/saleorder/returnInvoice/void', salesOrderController.voidSalesReturnInvoice)

salesOrderRoutes.post('/api/saleorder/returnInvoice/update', salesOrderController.updateSalesReturnInvoice)

salesOrderRoutes.get('/api/saleorder/returnInvoice/getAll', salesOrderController.getSalesReturnInvoiceList)

salesOrderRoutes.get('/api/saleorder/returnInvoice/getById', salesOrderController.getSalesReturnInvoiceById)

salesOrderRoutes.get('/api/saleorder/returnInvoice/getSaleReturnitemsList', salesOrderController.getSaleReturnitemsList)

salesOrderRoutes.post('/api/saleorder/creditNote/add', salesOrderController.addSalesCreditNote)

salesOrderRoutes.post('/api/saleorder/creditNote/void', salesOrderController.voidsalesCreditNote)

salesOrderRoutes.post('/api/saleorder/creditNote/update', salesOrderController.updateSalesCreditInvoice)

salesOrderRoutes.get('/api/saleorder/creditNote/getAll', salesOrderController.getSalesCreditNoteList)

salesOrderRoutes.get('/api/saleorder/creditNote/getById', salesOrderController.getSalesCreditNoteById)

salesOrderRoutes.get('/api/saleorder/creditNote/getByIdHTML', salesOrderController.getSalesCreditNoteByIdHTML)

salesOrderRoutes.post('/api/salesorder/void', salesOrderController.voidSaleOrder)

salesOrderRoutes.get('/api/products/search',salesOrderController.getSalesProduct)

salesOrderRoutes.get('/api/saleorder/delivery/getOrderByIdHTML', salesOrderController.getDeliveryOrderByIdHTML)

salesOrderRoutes.get('/api/saleorder/invoice/getByIdHTML', salesOrderController.getSalesOrderInvoiceByIdHTML)

salesOrderRoutes.get('/api/saleorder/returnInvoice/getByIdHTML', salesOrderController.getSalesReturnInvoiceByIdHTML)

export default salesOrderRoutes;