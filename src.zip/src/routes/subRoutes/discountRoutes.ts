import { Router } from 'express';
import * as discountController from '../../controller/discountController';
import * as  authService from '../../middleware/authService'
const discountRoutes = Router();




discountRoutes.post('/api/discount/pricelist/add',authService.authenticate, discountController.addPricelist)

discountRoutes.get('/api/discount/pricelist/getById',authService.authenticate, discountController.getByIdPricelist)

discountRoutes.get('/api/discount/pricelist/getall',authService.authenticate, discountController.getAllPricelist)

discountRoutes.post('/api/discount/priclist/items/add',authService.authenticate, discountController.addItems)

discountRoutes.get('/api/discount/pricelist/items/get',authService.authenticate, discountController.getSelectedItems)

discountRoutes.post('/api/discount/pricelist/update',authService.authenticate, discountController.updatePricelist)

discountRoutes.get('/api/discount/select/items',authService.authenticate, discountController.getSelectedItems)

discountRoutes.post('/api/discount/pricelist/items/update',authService.authenticate, discountController.updateItemsofPricelist)

discountRoutes.get('/api/discount/pricelist/get',authService.authenticate, discountController.getpricelistWithoutPageniation)

discountRoutes.post('/api/discountGroup/itemsGroup/add',authService.authenticate, discountController.addItemsGroup)

discountRoutes.get('/api/discountGroup/getByCustomer', discountController.getDiscountGroupByCustomer)

discountRoutes.post('/api/discountGroup/manufactureGroup/add',authService.authenticate, discountController.addDiscountManufactureGroup)

discountRoutes.post('/api/discountGroup/items/add',authService.authenticate, discountController.addDiscountGroupItems)

discountRoutes.post('/api/itemsGroup/add',authService.authenticate, discountController.addItemGroupTable)

discountRoutes.get('/api/itemsGroup/get',authService.authenticate, discountController.getItemsGroupTable)

discountRoutes.post('/api/manufacturesGroup/add',authService.authenticate, discountController.addManufacturesGroup)

discountRoutes.get('/api/manufacturesGroup/get',authService.authenticate, discountController.getManufacturesGroup),

discountRoutes.post('/api/customerGroup/add',authService.authenticate, discountController.addCustomerGroup)

discountRoutes.get('/api/customerGroup/get',authService.authenticate, discountController.getCustomerGroup)

discountRoutes.post('/api/discountType/add',authService.authenticate, discountController.addDiscountType)

discountRoutes.get('/api/discountType/get',authService.authenticate, discountController.getDiscountType)

discountRoutes.get('/api/discountGroup/getSelectedItems', discountController.getDiscountGroupSelectedItems)

discountRoutes.post('/api/discount/periodAndVolume/items/add',authService.authenticate, discountController.addPeriodAndVolumeItems)

discountRoutes.get('/api/discount/periodAndVolume/pricelist/selecteditems/get',authService.authenticate, discountController.getPeriodAndVolumeselecteditems)

discountRoutes.get('/api/discount/periodAndVolume/pricelist/items/get', authService.authenticate,discountController.getPeriodAndVolumePricelistItems)

discountRoutes.post('/api/discount/periodAndVolume/item/period/add', authService.authenticate,discountController.addItemPeriodAndVolume)

discountRoutes.post('/api/discount/periodAndVolume/item/period/addBulk', authService.authenticate,discountController.addBulkDiscount)
 
discountRoutes.post('/api/discount/periodAndVolume/item/volume/add',authService.authenticate, discountController.addItemVolume)

discountRoutes.get('/api/discount/periodAndVolume/item/period/get',authService.authenticate, discountController.getItemPeriod)

discountRoutes.get('/api/discount/periodAndVolume/item/volume/get',authService.authenticate, discountController.getItemVolume)

discountRoutes.get('/api/discount/get',authService.authenticate, discountController.getItemDiscount)

discountRoutes.get('/api/discount/sales/get',authService.authenticate, discountController.getSalesItemDiscount)

discountRoutes.post('/api/discount/add',authService.authenticate,discountController.addDiscount)

discountRoutes.post('/api/discount/pricelist/delete',authService.authenticate, discountController.deletePricelist)

export default discountRoutes;