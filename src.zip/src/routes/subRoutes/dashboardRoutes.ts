import * as dashboardController from "../../controller/dashboardController";
import * as authService from "../../middleware/authService";
import { Router } from "express";
const dashboardRouter = Router();
dashboardRouter.get(
  "/api/sales-dashboard/get",
  authService.authenticate,
  dashboardController.getSalesReport
);

dashboardRouter.get(
  "/api/top-selling-products",
  authService.authenticate,
  dashboardController.getTopSellingProducts
);
dashboardRouter.get(
  "/api/low-stock-products",
  authService.authenticate,
  dashboardController.getLowStockProducts
);
dashboardRouter.get(
  "/api/expiring-soon-products",
  authService.authenticate,
  dashboardController.getExpiringSoonProducts
);

dashboardRouter.get(
  "/api/new-customers-graph",
  authService.authenticate,
  dashboardController.getNewCustomersReport
);

export default dashboardRouter;
