import { Router } from 'express';
import * as reportController from '../../controller/reportController';
import * as  authService from '../../middleware/authService'
const reportRoutes = Router();


reportRoutes.post('/api/report/sales-summary', reportController.generateSalesSummaryReport)


/**Updated */
reportRoutes.post('/api/report/over-all-sales', reportController.generateOverallSalesReportv1)

reportRoutes.post('/api/report/gst/gstr-1', reportController.getGstr1)

reportRoutes.post('/api/report/gst/gstr-2', reportController.getGstr2)

reportRoutes.post('/api/report/gst/gstr-3B', reportController.getGstr3B)

reportRoutes.post('/api/report/branch-wise-sales', reportController.branchWiseSalesReport)

reportRoutes.post('/api/report/product-wise-sales', reportController.productWiseSalesReport)

reportRoutes.post('/api/report/doctor-wise-sales', reportController.doctorWiseSalesReport)

reportRoutes.post('/api/report/payment-mode-wise-sales', reportController.paymentModeWiseSalesReport)

reportRoutes.post('/api/report/party-wise-sales', reportController.partyWiseSalesReport)

reportRoutes.post('/api/report/discount-analysis', reportController.discountAnalysisReport)

reportRoutes.post('/api/report/sales-return', reportController.salesReturnReport)

reportRoutes.post('/api/report/customer-purchase-frequency', reportController.getCustomerPurchaseFreqReport)

reportRoutes.post('/api/report/customer-purchase-behavior', reportController.customerPurchaseBehaviorReport)

reportRoutes.post('/api/report/bounce', reportController.getBounceReport)

reportRoutes.post('/api/report/sales-inventory', reportController.getSalesInventoryReport)

reportRoutes.post('/api/report/inventory', reportController.inventoryReport)

reportRoutes.post('/api/report/scheduled-hdrug-reg', reportController.scheduledHDrugReport)

reportRoutes.post('/api/report/expiry-loss', reportController.expiryLossReport)

reportRoutes.post('/api/report/slow-fast-moving-products', reportController.getFastAndSlowMovingProductsReport)

reportRoutes.post('/api/report/daily-sales', reportController.dailySalesReport)

reportRoutes.post('/api/report/stock-sales-report', reportController.stockSalesReport)

reportRoutes.post('/api/report/product-purchase-return',reportController.productPurchaseReturn)

reportRoutes.post('/api/report/get-saved-reports',reportController.GetSavedReports)

reportRoutes.post('/api/report/get-saved-report-data',reportController.GetSavedReportData)

export default reportRoutes;