import { Router } from 'express';
import * as taxController from '../../controller/taxController';
import * as  authService from '../../middleware/authService'
const  taxRoutes = Router();




taxRoutes.post('/api/tax/add',authService.authenticate, taxController.addTax)

taxRoutes.get('/api/tax/get',authService.authenticate, taxController.gettaxAmount)

taxRoutes.get('/api/storeId/get', taxController.getStoreId)

taxRoutes.get('/api/paymentsModes/get',authService.authenticate, taxController.getPaymentMode)

taxRoutes.get('/api/itemcategory/get' ,authService.authenticate, taxController.itemCategory)

taxRoutes.get('/api/uom/get',authService.authenticate, taxController.getUom)

taxRoutes.get('/api/pricelist/get',authService.authenticate, taxController.getPricelist)

taxRoutes.get('/api/itemgroup/get',authService.authenticate, taxController.itemgroup)

taxRoutes.get('/api/taxcategory/get',authService.authenticate,taxController.taxCategory)

taxRoutes.get('/api/manufacturers/get',authService.authenticate, taxController.getManufacturers)

taxRoutes.get('/api/shippingtype/get',authService.authenticate,taxController.getshippingtype)

taxRoutes.get('/api/sector/get',authService.authenticate, taxController.getSector)

taxRoutes.get('/api/preferred_vendor/get',authService.authenticate,taxController.getVendors)

taxRoutes.get('/api/valuationMethod/get',authService.authenticate,taxController.getValuationMethod)

taxRoutes.post('/api/uomgroup/add', authService.authenticate,taxController.addUomGroup)

taxRoutes.post('/api/uom/add',authService.authenticate,taxController.addUom)

taxRoutes.get('/api/uomgroup/get',authService.authenticate,taxController.getUomGroupList)

taxRoutes.get('/api/uomlist/get',authService.authenticate,taxController.getUomList)

taxRoutes.get('/api/id/get',authService.authenticate,taxController.getId)

taxRoutes.post('/api/bank/add',authService.authenticate,taxController.addbank)

taxRoutes.get('/api/bank/list',authService.authenticate,taxController.getbanklist)

taxRoutes.get('/api/store/details/get',authService.authenticate,taxController.getStoreDetails )

//taxRoutes.get('/api/sector/get',authService.authenticate, taxController.getSector)


export default taxRoutes;