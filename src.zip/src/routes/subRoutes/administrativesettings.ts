import * as uomController from '../../administrativesettings/src/controller/uomSetupController'
import * as itemController from '../../administrativesettings/src/controller/itemSetupController'
import * as taxController from '../../administrativesettings/src/controller/taxSetupController'
import * as manufacturerController from '../../administrativesettings/src/controller/manufacturerController'
import * as shippingController from '../../administrativesettings/src/controller/shippingSetupController'
import * as documentNumberingController from '../../administrativesettings/src/controller/documentNumberingController'
import * as testController from '../../administrativesettings/src/controller/testController';
import * as communicationController from '../../administrativesettings/src/controller/communicationController';
import * as paymentConfigController from '../../administrativesettings/src/controller/paymentConfigController';
import * as printPreferenceController from '../../administrativesettings/src/controller/printPreferenceController';
import * as documentNumberingSeriesController from '../../controller/documentNumbering';
import { Router } from 'express';
const adminRouter = Router();
    /**UOM Setup */
    /**Unit of Measures */
    adminRouter.post('/api/settings/uom/add', uomController.addUom)
    adminRouter.get('/api/settings/uom/list', uomController.getUomList)
    adminRouter.get('/api/settings/uom/view', uomController.getUomById)
    adminRouter.post('/api/settings/uom/update', uomController.updateUom)
    adminRouter.get('/api/settings/uoms', uomController.listUom)

    /**UOM Groups */
    adminRouter.post('/api/settings/uom-group/add', uomController.addUomGroup)
    adminRouter.get('/api/settings/uom-group/list', uomController.getUomGroupList)
    adminRouter.post('/api/settings/uom-group/update', uomController.updateUomGroup)
    adminRouter.post('/api/settings/uom-group/delete', uomController.deleteUomGroup)
    adminRouter.post('/api/settings/uom-group/item-delete', uomController.deleteUomGroupItem)
    adminRouter.get('/api/settings/uom-group/uom-list', uomController.listUom)
    adminRouter.get('/api/settings/uom-groups', uomController.listUomGroup)
    adminRouter.get('/api/settings/uom-group-items', uomController.listUomGroupItems)

    /**Item Setup */
    /**Item Types */
    adminRouter.post('/api/settings/item-type/add', itemController.addItemType)
    adminRouter.post('/api/settings/item-type/update', itemController.updateItemType)
    adminRouter.post('/api/settings/item-type/delete', itemController.deleteItemType)
    adminRouter.get('/api/settings/item-type/list', itemController.getItemTypeList)

    /**Item Category */
    adminRouter.post('/api/settings/item-category/add', itemController.addItemCategory)
    adminRouter.post('/api/settings/item-category/update', itemController.updateItemCategory)
    adminRouter.post('/api/settings/item-category/delete', itemController.deleteItemCategory)
    adminRouter.get('/api/settings/item-category/list', itemController.getItemCategoryList)

    /**Item Group */
    adminRouter.post('/api/settings/item-group/add', itemController.addItemGroup)
    adminRouter.post('/api/settings/item-group/update', itemController.updateItemGroup)
    adminRouter.post('/api/settings/item-group/delete', itemController.deleteItemGroup)
    adminRouter.get('/api/settings/item-group/list', itemController.getItemGroupList)
    adminRouter.get('/api/settings/itemgroup/dropdown', itemController.getAllitemgroup)
    adminRouter.get('/api/settings/itemgtype/dropdown', itemController.findAllitemType)
    adminRouter.get('/api/settings/itemgcategory/dropdown', itemController.getAllitemcategory)





    
    /**Tax Types */
    adminRouter.post('/api/settings/tax-type/add', taxController.addTaxType)
    adminRouter.post('/api/settings/tax-type/update', taxController.updateTaxType)
    adminRouter.post('/api/settings/tax-type/delete', taxController.deleteTaxType)
    adminRouter.get('/api/settings/tax-type/list', taxController.getTaxTypeList)
    adminRouter.get('/api/settings/tax-types', taxController.taxTypeList)


    /**Tax Combinations */
    adminRouter.post('/api/settings/tax-combination/add', taxController.addTaxCombination)
    adminRouter.post('/api/settings/tax-combination/update', taxController.updateTaxCombination)
    adminRouter.get('/api/settings/tax-combination/list', taxController.getTaxCombinationList)
    adminRouter.get('/api/settings/tax-combination/tax-types', taxController.taxTypeList)
    adminRouter.post('/api/settings/tax-combination/delete', taxController.deleteTaxCombination)
    adminRouter.post('/api/settings/tax-combination-item/delete', taxController.deleteTaxCombinationItem)
    adminRouter.get('/api/settings/tax-combination-item/dropdown', taxController.findAllTaxCombination)

    /**Manufacturer */
    adminRouter.post('/api/settings/manufacturer/add', manufacturerController.addManufacturer)
    adminRouter.post('/api/settings/manufacturer/update', manufacturerController.updateManufacturer)
    adminRouter.post('/api/settings/manufacturer/delete', manufacturerController.deleteManufacturer)
    adminRouter.get('/api/settings/manufacturer/list', manufacturerController.getManufacturerList)
    adminRouter.get('/api/settings/manufacturers', manufacturerController.manufacturerList)


    /**Shipping Type */
    adminRouter.post('/api/settings/shipping-type/add', shippingController.addShippingType)
    adminRouter.post('/api/settings/shipping-type/update', shippingController.updateShippingType)
    adminRouter.get('/api/settings/shipping-type/list', shippingController.getShippingTypeList)
    adminRouter.post('/api/settings/shipping-type/delete', shippingController.deleteShippingType)
    adminRouter.get('/api/settings/shipping-types', shippingController.shippingTypeList)

    /**Document numbering */
   adminRouter.post('/api/settings/document-numbering/add', documentNumberingController.addDocument)
   adminRouter.post('/api/settings/document-numbering/update', documentNumberingController.updateDocument)
   adminRouter.get('/api/settings/document-numbering/list', documentNumberingController.getDocumentList)
   adminRouter.post('/api/settings/document-numbering/delete', documentNumberingController.deleteDoc)

   adminRouter.post('/api/settings/document-numbering-series/add', documentNumberingController.addDocumentSeries)
  adminRouter.post('/api/settings/document-numbering-series/update', documentNumberingSeriesController.updateDocumentSeries)
   adminRouter.get('/api/settings/document-numbering-series/list', documentNumberingController.getDocumentSeriesList)

    /**Test Routes */
   adminRouter.post('/api/test/sms', testController.testSms)
   adminRouter.post('/api/test/mail', testController.testMail)
   adminRouter.post('/api/test/whatsapp-message', testController.sendWhatsappMessage)

    /**Communication */
    /**SMTP */
   adminRouter.get('/api/settings/smtp/view', communicationController.findSmtpConfig)
   adminRouter.post('/api/settings/smtp/add', communicationController.addSmtpConfig)
   adminRouter.post('/api/settings/smtp/update', communicationController.updateSmtpConfig)

    /**Whatsapp */
   adminRouter.get('/api/settings/whatsapp/view', communicationController.findWhatsappConfig)
   adminRouter.post('/api/settings/whatsapp/add', communicationController.addWhatsappConfig)
   adminRouter.post('/api/settings/whatsapp/update', communicationController.updateWhatsappConfig)

    /**SMS */
   adminRouter.get('/api/settings/sms/view', communicationController.findSmsConfig)
   adminRouter.post('/api/settings/sms/add', communicationController.addSmsConfig)
   adminRouter.post('/api/settings/sms/update', communicationController.updateSmsConfig)

    /**Payment Config */
    /**Razorpay */
   adminRouter.get('/api/settings/razorpay/view', paymentConfigController.findRazorPayConfig)
   adminRouter.post('/api/settings/razorpay/add', paymentConfigController.addRazorPayConfig)
   adminRouter.post('/api/settings/razorpay/update', paymentConfigController.updateRazorPayConfig)

    /**Stripe */
   adminRouter.get('/api/settings/stripe/view', paymentConfigController.findStripeConfig)
   adminRouter.post('/api/settings/stripe/add', paymentConfigController.addStripeConfig)
   adminRouter.post('/api/settings/stripe/update', paymentConfigController.updateStripeConfig)

    /**Phonepe */
   adminRouter.get('/api/settings/phonepe/view', paymentConfigController.findPhonepeConfig)
   adminRouter.post('/api/settings/phonepe/add', paymentConfigController.addPhonepeConfig)
   adminRouter.post('/api/settings/phonepe/update', paymentConfigController.updatePhonepeConfig)

    /**Paytm */
   adminRouter.get('/api/settings/paytm/view', paymentConfigController.findPaytmConfig)
   adminRouter.post('/api/settings/paytm/add', paymentConfigController.addPaytmConfig)
   adminRouter.post('/api/settings/paytm/update', paymentConfigController.updatePaytmConfig)

    /**Paytm */
   adminRouter.get('/api/settings/pine-labs/view', paymentConfigController.findPineLabsConfig)
   adminRouter.post('/api/settings/pine-labs/add', paymentConfigController.addPineLabsonfig)
   adminRouter.post('/api/settings/pine-labs/update', paymentConfigController.updatePineLabsConfig)

    /**Print Preferences */
   adminRouter.get('/api/settings/print-preference/list', printPreferenceController.printPreferenceList)
   adminRouter.post('/api/settings/print-preference/add', printPreferenceController.addPrintPreference)
   adminRouter.post('/api/settings/print-preference/update', printPreferenceController.updatePrintPreference)
   adminRouter.get('/api/settings/print-preference/current', printPreferenceController.currentPrintPreference)

   
export default adminRouter;