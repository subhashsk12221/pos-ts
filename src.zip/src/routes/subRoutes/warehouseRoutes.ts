import { Router } from 'express';
import * as inventoryManagementController from '../../controller/inventoryManagementController';
import * as  authService from '../../middleware/authService'
const warehouseRoutes = Router();




warehouseRoutes.post('/api/warehouse/create', inventoryManagementController.createWarehouse)

warehouseRoutes.post('/api/warehouse/addBinLocation', inventoryManagementController.addBinLocation)

warehouseRoutes.post('/api/warehouse/binLocation/addSubLevel', inventoryManagementController.generateWareHouseBinLocation)

warehouseRoutes.get('/api/warehouse/get',inventoryManagementController.getWarehouse)

warehouseRoutes.get('/api/warehouse/nextSublevel/get',inventoryManagementController.getNextSublevel)

warehouseRoutes.get('/api/warehouse/getByWareHouseCode',inventoryManagementController.getByWareHouseCode)

warehouseRoutes.get('/api/warehouse/getAllBinLocation', inventoryManagementController.getAllBinLocation)


export default warehouseRoutes