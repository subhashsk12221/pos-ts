import { Router } from 'express';
import * as customerController from '../../controller/customerController';
import * as  authService from '../../middleware/authService'
const customerRouter = Router();


customerRouter.post('/api/customer/add', authService.authenticate,customerController.addStoreCustomer)

customerRouter.get('/api/customer/get/customerlist',authService.authenticate, customerController.getCustomerList)

customerRouter.get('/api/customer/getCustomerById',authService.authenticate, customerController.getCustomerById)

customerRouter.post('/api/customer/update',authService.authenticate, customerController.updateStoreCustomer)

customerRouter.get('/api/customer/get',authService.authenticate, customerController.getStoreCustomerById)

customerRouter.post('/api/customer/delete',authService.authenticate, customerController.deleteStoreCustomer)

customerRouter.get('/api/customer/getByPhoneNumber',authService.authenticate, customerController.searchCustomerByPhoneNumber)

customerRouter.get('/api/customer/getByType',authService.authenticate, customerController.getCustomerByType)

export default customerRouter;
