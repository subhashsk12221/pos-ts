
import { Router } from 'express';
import * as purchaseOrderController from '../../controller/purchaseOrderController';
import * as  authService from '../../middleware/authService'
const purchaseOrderRoutes = Router();






purchaseOrderRoutes.post('/api/purchaseorder/add', purchaseOrderController.addPurchaseorder)

purchaseOrderRoutes.post('/api/purchaseorder/void', purchaseOrderController.voidPurchaseOrder)

purchaseOrderRoutes.post('/api/purchaseorder/update', purchaseOrderController.updatePurchaseOrder)

purchaseOrderRoutes.get('/api/purchaseorder/products/get', purchaseOrderController.getPurchaseorderProduct)

purchaseOrderRoutes.get('/api/purchaseorder/orderList/getAll', purchaseOrderController.getPurchaseorderOrderList)

purchaseOrderRoutes.get('/api/purchaseorder/getPurchaseitemsList', purchaseOrderController.getPurchaseitemsList)

purchaseOrderRoutes.get('/api/purchaseorder/getOrderById', purchaseOrderController.getPurchaseOrderById)

purchaseOrderRoutes.get('/api/vendor/get', purchaseOrderController.getVendor)

purchaseOrderRoutes.get('/api/purchaseorder/invoice/orderList/search', purchaseOrderController.getPurchaseInvoiceListSearch)

purchaseOrderRoutes.post('/api/purchaseorder/gop/add', purchaseOrderController.addGOp)

purchaseOrderRoutes.post('/api/purchaseorder/gop/void', purchaseOrderController.voidGOPOrder)

purchaseOrderRoutes.post('/api/purchaseorder/gop/update', purchaseOrderController.updateGop)

purchaseOrderRoutes.get('/api/purchaseorder/gop/getAll', purchaseOrderController.getGopOrderList)

purchaseOrderRoutes.get('/api/purchaseorder/gop/getGopitemsList', purchaseOrderController.getGopitemsList)

purchaseOrderRoutes.get('/api/purchaseorder/gop/getOrderById', purchaseOrderController.getGopOrderById)

purchaseOrderRoutes.get('/api/purchaseorder/gop/getOrderByIdHTML', purchaseOrderController.getGopOrderByIdHTML)

purchaseOrderRoutes.post('/api/purchaseorder/invoice/add', purchaseOrderController.addPurchaseOrderInvoice)

purchaseOrderRoutes.post('/api/purchaseorder/invoice/void', purchaseOrderController.voidInvoice)

purchaseOrderRoutes.post('/api/purchaseorder/invoice/update', purchaseOrderController.updatePurchaseOrderInvoice)

purchaseOrderRoutes.get('/api/purchaseorder/invoice/getAll', purchaseOrderController.getPurchaseOrderInvoiceList)

purchaseOrderRoutes.get('/api/purchaseorder/invoice/getinvoiceitemsList', purchaseOrderController.getPurchaseOrderInvoiceitemsList)

purchaseOrderRoutes.get('/api/purchaseorder/invoice/getOrderById', purchaseOrderController.getPurchaseOrderInvoiceById)

purchaseOrderRoutes.get('/api/purchaseorder/invoice/getOrderByIdHTML', purchaseOrderController.getPurchaseOrderInvoiceByIdHTML)

purchaseOrderRoutes.post('/api/purchaseorder/return/add', purchaseOrderController.addPurhcaseReturnInvoice)

purchaseOrderRoutes.post('/api/purchaseorder/return/void', purchaseOrderController.voidPurhcaseReturnInvoice)

purchaseOrderRoutes.post('/api/purchaseorder/return/update', purchaseOrderController.updatePurchaseReturnInvoice)

purchaseOrderRoutes.get('/api/purchaseorder/return/getAll', purchaseOrderController.getPurchaseReturnInvoiceList)

purchaseOrderRoutes.get('/api/purchaseorder/return/getreturnitemsList', purchaseOrderController.getPurchaseReturnitemsList)

purchaseOrderRoutes.get('/api/purchaseorder/return/getOrderById', purchaseOrderController.getPurchaseReturnInvoiceById)

purchaseOrderRoutes.post('/api/purchaseorder/creditNote/add', purchaseOrderController.addPurchaseCreditNote)

purchaseOrderRoutes.post('/api/purchaseorder/creditNote/void', purchaseOrderController.voidPurchaseCreditNote)

purchaseOrderRoutes.post('/api/purchaseorder/creditNote/update', purchaseOrderController.updatePurchaseCreditNote)

purchaseOrderRoutes.get('/api/purchaseorder/creditNote/getOrderById', purchaseOrderController.getPurchaseCreditNoteById)

purchaseOrderRoutes.get('/api/purchaseorder/creditNote/getAll', purchaseOrderController.getPurchaseCreditNoteList)

purchaseOrderRoutes.post('/api/purchaseorder/bulkOrder/add', purchaseOrderController.addPurchasebulkOrder)

purchaseOrderRoutes.post('/api/purchaseorder/import/items', purchaseOrderController.importpurchasecsv)

purchaseOrderRoutes.get('/api/purchaseorder/tax/get',authService.authenticate, purchaseOrderController.getItemtaxForPurchase)

purchaseOrderRoutes.get('/api/purchaseorder/creditNote/getOrderByIdHTML', purchaseOrderController.getPurchaseCreditNoteByIdHTML)

export default purchaseOrderRoutes;