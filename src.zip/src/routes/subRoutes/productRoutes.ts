import { Router } from 'express';
import * as productController from '../../controller/productController';
import * as  authService from '../../middleware/authService'
const  productRoutes = Router();



productRoutes.post('/api/product/add',authService.authenticate,productController.addProduct)

productRoutes.post('/api/product/update',authService.authenticate,productController.updateProduct)

productRoutes.get('/api/product/get',authService.authenticate,productController.getProduct)

productRoutes.get("/api/inventory/stock/items",authService.authenticate, productController.getStockItems)

productRoutes.get('/api/v1/inventory/stock/items',authService.authenticate,productController.getStockItemsV1)

productRoutes.get('/api/v1/inventory/stock/sales/items',authService.authenticate,productController.getSalesStockItemsV1)

productRoutes.get('/api/productScheduleList/get',authService.authenticate,productController.getProductScheduleList)
   
productRoutes.post('/api/product/alternative/add',authService.authenticate,productController.addAlternativeItem)

productRoutes.get('/api/product/alternative/get',authService.authenticate,productController.getAlternativeItem)

productRoutes.post('/api/item/generalDetails/add',authService.authenticate,productController.addGeneralDetails)

productRoutes.get('/api/itemsList/get',authService.authenticate, productController.getproductlist)
    
productRoutes.post('/api/itemBatchNumber/add',authService.authenticate,productController.additemBatchNumber)
    
productRoutes.post('/api/item/generalDetails/update',authService.authenticate,productController.updateGeneralDetails)
   
productRoutes.post('/api/item/purchasingDetails/update', authService.authenticate,productController.updatePurchasingDetails)

productRoutes.post('/api/item/salesDetails/update',authService.authenticate,productController.updateSalesDetails)

productRoutes.post('/api/item/inventoryDetails/update', authService.authenticate,productController.updateInventoryDetails)

productRoutes.post('/api/item/planningDetails/update', authService.authenticate,productController.updatePlanningDetails)

productRoutes.post('/api/item/restrictionDetails/update' ,authService.authenticate,productController.updateRestrictionDetails)

productRoutes.post('/api/item/remarks/update',authService.authenticate,productController.updateItemRemarks)

productRoutes.get('/api/item/getItemById',authService.authenticate,productController.getItemById)

productRoutes.post('/api/item/delete',authService.authenticate,authService.authenticate, productController.deleteItem)

productRoutes.post('/api/item/barcode/update',authService.authenticate,productController.updateBarcode)

productRoutes.get('/api/product/barcode/get',authService.authenticate,authService.authenticate,productController.getProductByBarcode)

productRoutes.get('/api/product/batchnumber/get',authService.authenticate, productController.getProductBatchNumberAndLocation)

productRoutes.get('/api/product/geuombarcode/get',authService.authenticate,productController.getitemsUombarcode)

productRoutes.get('/api/product/minimumstockquntity/get',authService.authenticate,productController.getMinimumstockquntity)

productRoutes.get('/api/product/alternative/getList',authService.authenticate,productController.listofAlternativeItem)

productRoutes.post('/api/product/alternative/delete',authService.authenticate,authService.authenticate, productController.deleteAlternativeItem)




export default productRoutes