import { Router } from 'express';
import * as doctorController from '../../controller/doctorController';
import * as  authService from '../../middleware/authService'
const doctorRoutes = Router();


doctorRoutes.post('/api/doctor/add', authService.authenticate, doctorController.addDoctor )

doctorRoutes.post('/api/doctor/update',authService.authenticate, doctorController.updateDoctor)

doctorRoutes.get('/api/doctor/get/doctorlist',authService.authenticate, doctorController.getDoctorList)

doctorRoutes.get('/api/doctor/getDoctorById',authService.authenticate, doctorController.getDoctorById)

doctorRoutes.post('/api/doctor/delete',authService.authenticate, doctorController.deleteDoctor)


export default doctorRoutes;
