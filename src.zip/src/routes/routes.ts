
import customerRoutes from './subRoutes/customerRoutes';
import userRoutes from './subRoutes/userRoutes';
import orderRoutes from './subRoutes/orderRoutes';
import productRoutes from './subRoutes/productRoutes';
import storeRoutes from './subRoutes/storeRoutes';
import taxRoutes from './subRoutes/taxRoutes'
import discountRoutes from './subRoutes/discountRoutes';
import warehouseRoutes from './subRoutes/warehouseRoutes';
import salesOrderRoutes from './subRoutes/salesOrderRoutes';
import purchaseOrderRoutes from './subRoutes/purchaseOrderRoutes';
import financialLedgerRoutes from './subRoutes/financialLedgerRoutes';
import documentNumberingRoutes from './subRoutes/documentNumberingRoutes';
import paymentInRoutes from './subRoutes/paymentInRoutes'
import doctorRoutes from './subRoutes/doctorRoutes'
import reportRoutes from './subRoutes/reportRoutes';
import stocktransferRoutes from './subRoutes/stockTransferRoutes';
import dashboardRoutes from './subRoutes/dashboardRoutes';
import adminRouter from './subRoutes/administrativesettings';
import paymentTypeRoutes from './subRoutes/paymentTypeRoutes';
// import  { routes as submoduleRoutes }  from '../administrativesettings/src/routes/routes'

export function routes(app: any) {
    app.use(customerRoutes);
    app.use(userRoutes);
    app.use(orderRoutes);
    app.use(productRoutes);
    app.use(taxRoutes);
    app.use(storeRoutes);
    app.use(discountRoutes);
    app.use(warehouseRoutes);
    app.use(salesOrderRoutes);
    app.use(purchaseOrderRoutes);
    app.use(financialLedgerRoutes);
    app.use(documentNumberingRoutes);
    app.use(paymentInRoutes);
    app.use(doctorRoutes);
    app.use(reportRoutes);
    app.use(stocktransferRoutes);
    app.use(dashboardRoutes);
    app.use(adminRouter);
    app.use(paymentTypeRoutes);
    app.get('/health', (req: any, res: any) => {
        res.send('ok');
    });

}
