import { readFileSync } from 'fs';
import { create } from 'pdf-creator-node';

// Define the function to generate a PDF
async function generatePDF() {
    // Example data for items
    const items = [
        {
            mfgHsn: 'Zota 411963',
            productName: 'CRISTMAS COOKIES',
            batchNo: 'dfssf1552',
            exp: '01/25',
            uom: 'each',
            qty: 1,
            mrp: 150,
            taxableAmt: 150,
            gst: 18,
            sgstAmt: 11.44,
            cgstAmt: 11.44
        },
        {
            mfgHsn: 'Med 234567',
            productName: 'Vitamin D',
            batchNo: 'AB12345',
            exp: '06/24',
            uom: 'bottle',
            qty: 2,
            mrp: 300,
            taxableAmt: 600,
            gst: 12,
            sgstAmt: 36,
            cgstAmt: 36
        }
    ];

    // Define the HTML template file path
    const html = readFileSync('./invoice.html', 'utf-8');

    // Define the document options
    const document = {
        html: html,
        data: {
            items: items  // Provide the data for the template
        },
        path: './invoice.pdf',  // Output PDF file path
        type: 'pdf',  // Type of the output
    };

    try {
        const pdf = await create(document);  // Generate the PDF
        console.log('PDF generated successfully!', pdf);
    } catch (error) {
        console.error('Error generating PDF:', error);
    }
}

// Call the function to generate the PDF
generatePDF();
