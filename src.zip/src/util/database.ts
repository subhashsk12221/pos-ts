import pkg from "pg";
const { Pool } = pkg;

// Create pool connection using env variables
const pool = new Pool({
  user: "postgres",
 host: "103.241.144.228",
 //host:"localhost",
  database: "customer",
  password: "1234567890",
  port: 5432,
  max: 40, // Maximum number of clients in the pool
  idleTimeoutMillis: 30,
  
  connectionTimeoutMillis: 8000,
});
//console.log('Connecting to database', pool);
// pool.on('connect', () => {
//   console.log('Connected to the database');
// });

// pool.on('error', (err) => {
//   console.error('Error connecting to the database:', err);
// });



const client = await pool.connect();

export default client;
