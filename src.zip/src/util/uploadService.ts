import path from 'path';
import { generateResponse } from './genRes';
import { fileURLToPath } from 'url';
export async function   addfiles (req:any,res:any){

    try{

        console.log(req.files)
        if (req.files) {
            const file = req.files.image
            var uploadPathForPicture
              
            if (file) {
                const currentFileUrl = import.meta.url;
                // Convert the file URL to a file path
                const currentFilePath = fileURLToPath(currentFileUrl);
                // Use path.dirname to get the directory name
                const currentDir = path.dirname(currentFilePath);


                 uploadPathForPicture = path.join(currentDir, "..", "uploads") + "/" + file.name;
               await  file.mv(uploadPathForPicture)
            }

            console.log(uploadPathForPicture)
         if(uploadPathForPicture){
        let   imageurl = `https://dev.zotanextech.com/api/image/${file.name}`

            return res.status(200).send(
                generateResponse(true, "file uploaded  successfully", 200,imageurl )
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "file uploaded  unsuccessful", 400, null)
            );
        }
         }
        }

    catch(error){
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}