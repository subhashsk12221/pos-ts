import Joi from 'joi';

const paymentDataSchema = Joi.object({
  payment_mode_name: Joi.string().required(),
  payment_amount: Joi.number().required()
});

const itemDataSchema = Joi.object({
  item_batch_number: Joi.string().required(),
  item_code: Joi.string().optional(),
  item_discount_amount: Joi.number().optional(),
  item_discount_percentage: Joi.number().optional(),
  item_exp_date: Joi.string().optional(),
  item_generic_name: Joi.string().allow('').required(),
  item_id: Joi.string().required(),
  item_name: Joi.string().optional(),
  item_uom:Joi.string().allow('').optional(),
  item_total_tax_percentage:Joi.number().optional(),
  item_price_wiithout_tax:Joi.number().allow('').optional(),
  item_pack_size:Joi.string().optional(),
  item_quantity: Joi.number().positive().required().messages({
    'number.base': '"item_quantity" should be a valid number',       // For invalid number input
    'number.positive': '"item_quantity" must be a positive number',  // For negative numbers
    'any.required': '"item_quantity" is required',                   // When field is missing
}),
  item_rack_location: Joi.string().allow('').optional(),
  item_schedule: Joi.string().allow('').optional(),
  item_tax_amount: Joi.number().required(),
  item_total_amount: Joi.number().required(),
  item_unit_price: Joi.number().required(),
  item_gst: Joi.number().required(),
  item_sgst: Joi.number().required(),
  item_cgst: Joi.number().required(),
  item_igst: Joi.number().optional(),
  item_free_quantity:Joi.number().optional(),
  item_manufacturer_id:Joi.string().allow('').optional(),
  item_manufacturer_name:Joi.string().allow('').optional(),
  item_hsn: Joi.string().allow(null, 'null','').optional()
});

const orderDataSchema = Joi.object({
  store_id: Joi.string().optional(),
  cmr_phone_number: Joi.number().required(),
  cmr_id: Joi.string().optional(),
  sot_total_gst: Joi.number().required(),
  sot_total_discount: Joi.number().required(),
  sot_payment_status: Joi.string().optional(),
  sot_transaction_id: Joi.string().allow('').optional(),
  is_draft_order: Joi.boolean().optional(),
  sot_sub_total: Joi.number().optional(),
  sot_payment_method: Joi.string().optional(),
  sot_billing_address: Joi.string().allow('').optional(),
  sot_total_amount: Joi.number().required(),
  doctor_name: Joi.string().optional(),
  sot_remarks:Joi.string().optional()
});

const orderValidation = Joi.object({
  orderData: orderDataSchema,
  paymentData: Joi.array().items(paymentDataSchema).optional(),
  itemData: Joi.array().items(itemDataSchema).required()
});

export default orderValidation