import Joi from "joi";

// Define the TypeScript interface
export interface DocumentSeries {
    series_name: string;
    series_prefix: string;
    series_suffix: string;
    series_first_digit: number;
    series_last_digit: number;
    series_separator: string;
    series_default: boolean;
    series_increment: number;
    series_include_year: boolean;
    series_include_month: boolean;
    series_include_date: boolean;
    series_leading_spaces: number;
    series_fyi_year: string;
    transaction_doc_id: string;
}

// Define the Joi validation schema
export const addDocumentSeries = Joi.object<DocumentSeries>({
    series_name: Joi.string().required(),
    series_prefix: Joi.string().required(),
    series_suffix: Joi.string().required(),
    series_first_digit: Joi.number().integer().required(),
    series_last_digit: Joi.number().integer().required(),
    series_separator: Joi.string().required(),
    series_default: Joi.boolean().required(),
    series_increment: Joi.number().integer().required(),
    series_include_year: Joi.boolean().required(),
    series_include_month: Joi.boolean().required(),
    series_include_date: Joi.boolean().required(),
    series_leading_spaces: Joi.number().integer().required(),
    series_fyi_year: Joi.string().required(),
    transaction_doc_id: Joi.string().required()
});