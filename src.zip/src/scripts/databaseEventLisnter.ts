
import AWS from 'aws-sdk';
import pgListen from 'pg-listen';
AWS.config.update({
    accessKeyId: 'AKIA5FTZAKUNFPO2ILFS',     // Your AWS access key ID
    secretAccessKey: 'Wu8EdpMb1DA2+ImE7dgrb4Fd0tpfXziB5J6ql3Fs', // Your AWS secret access key
    region: "us-east-1"                   // The AWS region where your resources are located
  });

  import * as discountServive from '../service/discountService'
// Initialize AWS SDK for EventBridge
const eventbridge = new AWS.EventBridge();

const sqs = new AWS.SQS();


// Database connection URL
const dbUrl = 'postgresql://postgres:1234567890@103.241.144.228:5432/customer';

export async function trigger() {
    const listener = pgListen({ connectionString: dbUrl });
 
      
    listener.notifications.on('customer_details_event', async (msg) => {
        console.log('Received notification:', msg);
        try {
            const payload = msg;
            const params = {
                Entries: [
                    {
                        Source: 'your.custom.source',
                        DetailType: 'CustomerDetailsChange',
                        Detail: JSON.stringify(payload),
                        EventBusName: 'default',
                    }
                ]
            };

       const pg =      await eventbridge.putEvents(params).promise();
            console.log('Event sent to EventBridge',pg);
        } catch (error) {
            console.error('Error processing notification:', error);
        }
    });

    listener.events.on('error', (error) => {
        console.error('Fatal database connection error:', error);
        process.exit(1);
    });

    listener.events.on('reconnect', () => {
        console.log('Reconnecting to the database...');
    });

    await listener.connect();
    await listener.listenTo('customer_details_event');

    console.log('Listening for database changes...');
}

export async function updateItemSellingOfPriceList(){
    try{
    const listener = pgListen({ connectionString: dbUrl });
    

    console.log(listener, "eeee")
      
    listener.notifications.on('price_change_event', async (msg) => {
       

      discountServive.updateTriggerofItemPRicelist(msg)
    });

    listener.events.on('error', (error) => {
        console.error('Fatal database connection error:', error);
        process.exit(1);
    });

    listener.events.on('reconnect', () => {
        console.log('Reconnecting to the database...');
    });

    await listener.connect();
    await listener.listenTo('price_change_event');

    console.log('Listening for database of itemselling price changes...');
}catch(error){
    console.log(error)
}
}



export async function billingInvoiceEvent(){
    try{
    const listener = pgListen({ connectionString: dbUrl });
    

    console.log(listener, "eeee")
      
    listener.notifications.on('sales_order_insert', async (msg) => {
        console.log(msg, "order")
        try {
            const payload = msg;
            const params = {
                Entries: [
                    {
                        Source: 'your.custom.source',
                        DetailType: 'salesDetailsChange',
                        Detail: JSON.stringify(payload),
                        EventBusName: 'default',
                    }
                ]
            };

       const pg =      await eventbridge.putEvents(params).promise();
            console.log('Event sent to EventBridge',pg);
        } catch (error) {
            console.error('Error processing notification:', error);
        }
       
    });

    listener.events.on('error', (error) => {
        console.error('order error:', error);

    });

    listener.events.on('reconnect', () => {
        console.log('Reconnecting to the database...');
    });

    await listener.connect();
    await listener.listenTo('sales_order_insert');

    console.log('Listening for database of itemselling price changes...');
}catch(error){
    console.log(error)
}
}



export async function billingInvoiceItemsEvent(){
    try{
    const listener = pgListen({ connectionString: dbUrl });
    

    console.log(listener, "eeee")
      
    listener.notifications.on('order_items_list_insert', async (msg) => {
        console.log(msg,"items")
        try {
            const payload = msg;
            const params = {
                Entries: [
                    {
                        Source: 'your.custom.source',
                        DetailType: 'salesDetailsChange',
                        Detail: JSON.stringify(payload),
                        EventBusName: 'default',
                    }
                ]
            };

       const pg =      await eventbridge.putEvents(params).promise();
            console.log('Event sent to EventBridge',pg);
        } catch (error) {
            console.error('Error processing notification:', error);
        }
       
    });

    listener.events.on('error', (error) => {
        console.error('items erorr:', error);
       
    });

    listener.events.on('reconnect', () => {
        console.log('Reconnecting to the database...');
    });

    await listener.connect();
    await listener.listenTo('order_items_list_insert');

    console.log('Listening for database of itemselling price changes...');
}catch(error){
    console.log(error)
}
}



// Call the trigger function


