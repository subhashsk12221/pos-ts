import axios from 'axios';

export const sendLoginOtp = async (mobile: any, otp: any) => {
    const response = await axios.get(`https://smsnotify.one/SMSApi/send?userid=davaindia&password=Dava@123&sendMethod=quick&mobile=${mobile}&msg=Thank%20you,%20for%20connecting%20with%20Davaindia%20Generic%20Pharmacy,%20your%20login%20One%20Time%20Password%20(OTP)%20is%20${otp}.%20davaindia%20generic%20pharmacy.&senderid=DAVAIN&msgType=text&format=text`)
    console.log(response.data);
    console.log("responmse", response);

    return response.data
}