import { findSmtpData } from "../service/communicationService";
import * as nodemailer from 'nodemailer';

export const sendMail = async function (mailData: any) {

    const mailConfig = await findSmtpData();
    if (mailConfig.rows.length === 0) {
        return false
    }
    const configData = mailConfig.rows[0];

    const transporter = nodemailer.createTransport({
        host: configData.host,
        port: Number(configData.port),
        auth: {
            user: configData.user_name.trim(),
            pass: configData.password.trim()
        },
        tls: {
            rejectUnauthorized: false
        }
    });
    mailData.from = `"${configData.from_name}" <${configData.email}>`;
    
    const res = await transporter.sendMail(mailData);
    console.log(res);
    return true;
};