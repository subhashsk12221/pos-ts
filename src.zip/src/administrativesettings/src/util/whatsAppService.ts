import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const whatsappApiUrl = "https://theultimate.io/WAApi/send";
const whatsappApiKey = "6b3971f0c1109d1271c484b03ce8d75294218904";

if (!whatsappApiUrl || !whatsappApiKey) {
    throw new Error('WhatsApp API URL or API Key is not set in the environment variables');
}

interface WhatsAppMessageData {
    to: string;
    body: string;
}

export const sendWhatsAppMessage = async (messageData: WhatsAppMessageData): Promise<boolean> => {
    try {
        const response = await axios.post(
            whatsappApiUrl,
            {
                recipient_type: "individual",
                to: messageData.to,
                type: "text",
                text: {
                    body: messageData.body
                }
            },
            {
                headers: {
                    'Authorization': `Bearer ${whatsappApiKey}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        console.log('Message sent:', response.data);
        return true;
    } catch (error) {
        console.error('Error sending message:', error.response ? error.response.data : error.message);
        return false;
    }
};


interface WhatsAppMediaMessageData {
    to: string;
    body?: string;
    mediaUrl: string;
    mediaType: 'image' | 'video' | 'document' | 'audio';
}

export const sendWhatsAppMediaMessage = async (messageData: WhatsAppMediaMessageData): Promise<boolean> => {
    try {
        const response = await axios.post(
            whatsappApiUrl,
            {
                recipient_type: "individual",
                to: messageData.to,
                type: messageData.mediaType,
                [messageData.mediaType]: {
                    link: messageData.mediaUrl,
                    caption: messageData.body,
                }
            },
            {
                headers: {
                    'Authorization': `Bearer ${whatsappApiKey}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        console.log('Media message sent:', response.data);
        return true;
    } catch (error) {
        console.error('Error sending media message:', error.response ? error.response.data : error.message);
        return false;
    }
};