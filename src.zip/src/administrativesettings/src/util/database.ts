import pkg from 'pg';
const { Pool } = pkg;
const pool = new Pool({
  user: 'postgres',
  host: '103.241.144.228',
 //host:"localhost",
  database: 'customer',
  password: '1234567890',
  port: 5432,
  max: 30, // Maximum number of clients in the pool
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 4000,
});

const client = await pool.connect();

export default client;



