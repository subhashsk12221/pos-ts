import client from '../util/database';

// export const createTables = async () => {
//     const createTableQueries: any = [
//         `CREATE TABLE IF NOT EXISTS unit_of_measure (
//             uom_id VARCHAR(255) PRIMARY KEY,
//             code VARCHAR(50) NOT NULL,
//             name VARCHAR(100) NOT NULL,
//             ewb_unit VARCHAR(50),
//             length DECIMAL(10, 2),
//             width DECIMAL(10, 2),
//             height DECIMAL(10, 2),
//             volume DECIMAL(15, 3),
//             volume_uom VARCHAR(50),
//             weight DECIMAL(15, 3),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );
//         `,
//         `CREATE TABLE IF NOT EXISTS uom_group (
//             group_id VARCHAR(255) PRIMARY KEY,
//             name VARCHAR(255),
//             description TEXT,
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );
//         `,
//         `CREATE TABLE IF NOT EXISTS uom_group_item (
//             item_id VARCHAR(255) PRIMARY KEY,
//             group_id VARCHAR(255),
//             alt_quantity DECIMAL(10,2),
//             alt_uom VARCHAR(255),
//             base_quantity DECIMAL(10,2),
//             base_uom_id VARCHAR(255),
//             FOREIGN KEY (group_id) REFERENCES uom_group(group_id),
//             FOREIGN KEY (base_uom_id) REFERENCES unit_of_measure(uom_id),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,

//         `CREATE TABLE IF NOT EXISTS item_type (
//             id VARCHAR(255) PRIMARY KEY,
//             code VARCHAR(255),
//             name VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );
//         `,
//         `CREATE TABLE IF NOT EXISTS item_category (
//             id VARCHAR(255) PRIMARY KEY,
//             code VARCHAR(255),
//             name VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );
//         `,
//         `CREATE TABLE IF NOT EXISTS item_group (
//             id VARCHAR(255) PRIMARY KEY,
//             code VARCHAR(255),
//             name VARCHAR(255),
//             default_uom_id VARCHAR(255),
//             FOREIGN KEY (default_uom_id) REFERENCES unit_of_measure(uom_id),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );
//         `,
//         `CREATE TABLE IF NOT EXISTS tax_type (
//             id VARCHAR(255) PRIMARY KEY,
//             name VARCHAR(255),
//             description TEXT,
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS tax_combination (
//             id VARCHAR(255) PRIMARY KEY,
//             code VARCHAR(255),
//             rate BIGINT,
//             effective_from DATE,
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS tax_combination_item (
//             id VARCHAR(255) PRIMARY KEY,
//             tax_combination_id VARCHAR(255),
//             tax_type_id VARCHAR(255),
//             percentage DECIMAL(10,2),
//             sales_tax_acc VARCHAR(255),
//             purchase_tax_acc VARCHAR(255),
//             FOREIGN KEY (tax_type_id) REFERENCES tax_type(id),
//             FOREIGN KEY (tax_combination_id) REFERENCES tax_combination(id),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS manufacturer (
//             id VARCHAR(255) PRIMARY KEY,
//             code VARCHAR(255),
//             name VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS shipping_type (
//             id VARCHAR(255) PRIMARY KEY,
//             name VARCHAR(255),
//             carrier VARCHAR(255),
//             field_1 VARCHAR(255),
//             field_2 VARCHAR(255),
//             field_3 VARCHAR(255),
//             status BOOLEAN DEFAULT FALSE,
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,

//         `CREATE TABLE IF NOT EXISTS smtp_config (
//             id VARCHAR(255) PRIMARY KEY,
//             email VARCHAR(255),
//             from_name VARCHAR(255),
//             user_name VARCHAR(255),
//             host VARCHAR(255),
//             password VARCHAR(255),
//             port VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS razorpay_config (
//             id VARCHAR(255) PRIMARY KEY,
//             key_id VARCHAR(255),
//             key_secret VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS stripe_config (
//             id VARCHAR(255) PRIMARY KEY,
//             key_id VARCHAR(255),
//             key_secret VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS phonepe_config (
//             id VARCHAR(255) PRIMARY KEY,
//             host_url VARCHAR(255),
//             merchant_id VARCHAR(255),
//             secret_key VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS paytm_config (
//             id VARCHAR(255) PRIMARY KEY,
//             merchant_id VARCHAR(255),
//             secret_key VARCHAR(255),
//             paytm_website VARCHAR(255),
//             channel VARCHAR(255),
//             industry_type VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS pine_labs_config (
//             id VARCHAR(255) PRIMARY KEY,
//             host_url VARCHAR(255),
//             merchant_id VARCHAR(255),
//             secret_key VARCHAR(255),
//             access_code VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS print_preference (
//             id VARCHAR(255) PRIMARY KEY,
//             type VARCHAR(255),
//             image_url VARCHAR(255),
//             pdf_url VARCHAR(255),
//             is_current BOOLEAN DEFAULT FALSE,
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS whatsapp_config (
//             id VARCHAR(255) PRIMARY KEY,
//             api_key VARCHAR(255),
//             api_url VARCHAR(255),
//             user_name VARCHAR(255),
//             password VARCHAR(255),
//             number VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//         `CREATE TABLE IF NOT EXISTS sms_config (
//             id VARCHAR(255) PRIMARY KEY,
//             api_key VARCHAR(255),
//             api_url VARCHAR(255),
//             user_name VARCHAR(255),
//             password VARCHAR(255),
//             update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
//             created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
//         );`,
//     ];
//     try {
//         for (const query of createTableQueries) {
//             client.query(query);
//         }

//         console.log('Tables created successfully');
//         return true
//     } catch (error) {
//         console.log("Error while creating tables", error);
//     }
// }