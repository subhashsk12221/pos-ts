import { generateResponse } from "../util/genRes";
import { sendLoginOtp } from "../util/smsService";
import * as mail from "../util/mail"
import { sendWhatsAppMessage } from "../util/whatsAppService";

export const testSms = async (req: any, res: any) => {
    try {
        const { mobile, otp } = req.body;
        const msgResponse = await sendLoginOtp(mobile, otp);
        return res.status(200).send(
            generateResponse(true, "Message successfully", 200, msgResponse)
        );
    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const testMail = async (req: any, res: any) => {
    try {
        const mailOptions = {
            to: req.body.email,
            subject: "Testing Subject",
            text: "Testing...",
        };
        await mail.sendMail(mailOptions);
        return res.status(200).send(
            generateResponse(true, "Mail sent successfully", 200, null)
        );
    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function sendWhatsappMessage(req: any, res: any) {
    try {
        const { number, message } = req.body;

        const messageData = {
            to: number, 
            body: message
        };

        sendWhatsAppMessage(messageData).then(success => {
            if (success) {
                console.log('WhatsApp message sent successfully!');
            } else {
                console.log('Failed to send WhatsApp message.');
            }
        });

        return res.status(200).send(
            generateResponse(true, "Message sent successfully", 200, null)
        );
    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}