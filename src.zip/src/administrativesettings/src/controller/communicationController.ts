import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as communicationService from '../service/communicationService'

/**SMTP Config */
export const addSmtpConfig = async (req: any, res: any) => {
    try {
        const smptData = req.body;
        smptData.id = ulid();
        const response = await communicationService.addSmtpConfig(smptData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateSmtpConfig = async (req: any, res: any) => {
    try {



        const { id, ...smptData } = req.body;
        const getSmptpConfig = await communicationService.getSmtpConfigById(id);
        if (getSmptpConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Smptp config not found", 400, null)
            );
        }
        await communicationService.updateSmtpConfig(id, smptData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findSmtpConfig(req: any, res: any) {
    try {

        const getSmptpConfig = await communicationService.findSmtpData()

        if (getSmptpConfig.rows.length > 0) {
            return res.send(generateResponse(true, "Smtp fetched successfully", 200, getSmptpConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No smtp found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

/**Whatsapp Config */
export const addWhatsappConfig = async (req: any, res: any) => {
    try {
        const whatsappData = req.body;
        whatsappData.id = ulid();
        const response = await communicationService.addWhatsappConfig(whatsappData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateWhatsappConfig = async (req: any, res: any) => {
    try {
        const { id, ...whatsappData } = req.body;
        const getWhatsappConfig = await communicationService.getWhatsappConfigById(id);
        if (getWhatsappConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Config not found", 400, null)
            );
        }
        await communicationService.updateWhatsappConfig(id, whatsappData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findWhatsappConfig(req: any, res: any) {
    try {

        const getWhatsappConfig = await communicationService.findWhatsappData()

        if (getWhatsappConfig.rows.length > 0) {
            return res.send(generateResponse(true, "Data fetched successfully", 200, getWhatsappConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No data found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

/**Sms Config */
export const addSmsConfig = async (req: any, res: any) => {
    try {
        const smsData = req.body;
        smsData.id = ulid();
        const response = await communicationService.addSmsConfig(smsData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateSmsConfig = async (req: any, res: any) => {
    try {
        const { id, ...smsData } = req.body;
        const getSmsConfig = await communicationService.getSmsConfigById(id);
        if (getSmsConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Config not found", 400, null)
            );
        }
        await communicationService.updateSmsConfig(id, smsData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findSmsConfig(req: any, res: any) {
    try {

        const getSmptpConfig = await communicationService.findSmsData()

        if (getSmptpConfig.rows.length > 0) {
            return res.send(generateResponse(true, "Sms data fetched successfully", 200, getSmptpConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No Sms data found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}
