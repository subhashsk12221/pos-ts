import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as manufacturerService from '../service/manufacturerService'

export const addManufacturer = async (req: any, res: any) => {
    try {
        const manufacturerData = req.body;
        const checCodeExiists = await manufacturerService.findByManufacturerColoumn('code', manufacturerData.code);
        if (checCodeExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, "Code is already used", 400, null)
            );
        }
        manufacturerData.id = ulid();
        const response = await manufacturerService.addManufacturerData(manufacturerData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Manufacturer added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Manufacturer adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateManufacturer = async (req: any, res: any) => {
    try {

        const { updatingData } = req.body;

        for (let index = 0; index < updatingData.length; index++) {
            const element = updatingData[index];
            const { id, ...manufacturerData } = element;
            const checCodeExiists = await manufacturerService.findByManufacturerColoumn('code', manufacturerData.code);
            if (checCodeExiists.rows.length > 0 && checCodeExiists.rows[0].id !== id) {
                return res.status(400).send(
                    generateResponse(false, `Code ${manufacturerData.code} is already used`, 400, null)
                );
            }
        }

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...manufacturerData } = item;
            const getManufacturer = await manufacturerService.getManufacturerById(id);
            if (getManufacturer.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Manufacturer not found", 400, null)
                );
            }
            return (await manufacturerService.updateManufacturerData(id, manufacturerData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Manufacturer updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getManufacturerList(req: any, res: any) {
    try {

        const getManufacturerList = await manufacturerService.getManufacturerList(req.query)

        if (getManufacturerList.manufacturerList.length > 0) {
            return res.send(generateResponse(true, "Manufacturer list fetched successfully", 200, {
                totalCount: getManufacturerList.totalRowsCount,
                manufacturerList: getManufacturerList.manufacturerList
            }));
        } else {
            return res.send(generateResponse(true, "No Manufacturers found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const deleteManufacturer = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getTaxType = await manufacturerService.getManufacturerById(id);

        if (getTaxType.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Manufacturer not found", 400, null));
        }

        await manufacturerService.deleteManufacturer(id);

        return res.status(200).json(generateResponse(true, "Manufacturer Deleted Successfully", 200, null));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

export async function manufacturerList(req: any, res: any) {
    try {

        const getManufacturerList = await manufacturerService.findAllManufacturer()

        if (getManufacturerList.rows.length > 0) {
            return res.send(generateResponse(true, "Manufacturer list fetched successfully", 200, getManufacturerList.rows));
        } else {
            return res.send(generateResponse(true, "No Manufacturers found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}