import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as documentNumService from '../service/documentNumService'


/**Document Numbering */
export const addDocument = async (req: any, res: any) => {
    try {
        const docData = req.body;
        docData.id = ulid();
        const response = await documentNumService.addDocumentData(docData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateDocument = async (req: any, res: any) => {
    try {
        const { updatingData } = req.body;

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...itemTypeData } = item;
            const getItemType = await documentNumService.getDocumentById(id);
            if (getItemType.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Document numbering series not found", 400, null)
                );
            }
            return (await documentNumService.updateDocument(id, itemTypeData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Document numbering series updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const deleteDoc = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getDocument = await documentNumService.getDocumentById(id);
        if (getDocument.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Document numbering not found", 400, null)
            );
        }

        await documentNumService.deleteDocumentById(id)
        return res.status(200).send(
            generateResponse(true, "Document numbering Deleted successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getDocumentList(req: any, res: any) {
    try {
        const getDocList = await documentNumService.getDocumentList(req.query)

        if (getDocList.documentList.length > 0) {

            return res.send(generateResponse(true, "Document numbering list fetched successfully", 200, {
                totalCount: getDocList.totalRowsCount,
                documentList: getDocList.documentList
            }));
        } else {
            return res.send(generateResponse(true, "No Document numbering found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

/**Document Numbering */
export const addDocumentSeries = async (req: any, res: any) => {
    try {
        const docData = req.body;
        docData.id = ulid();
        const response = await documentNumService.addDocumentNumberingSeriesData(docData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateDocumentSeries = async (req: any, res: any) => {
    try {
        const { updatingData } = req.body;

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...itemTypeData } = item;
            const getItemType = await documentNumService.getDocumentNumberingSeriesById(id);
            if (getItemType.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Document numbering series not found", 400, null)
                );
            }
            return (await documentNumService.updateDocumentNumberingSeries(id, itemTypeData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Document numbering series updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getDocumentSeriesList(req: any, res: any) {
    try {
        const getDocList = await documentNumService.getDocumentNumberingSeriesList(req.query)

        if (getDocList.documentList.length > 0) {
            return res.send(generateResponse(true, "Document numbering list fetched successfully", 200, {
                totalCount: getDocList.totalRowsCount,
                documentList: getDocList.documentList
            }));
        } else {
            return res.send(generateResponse(true, "No Document numbering found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}


