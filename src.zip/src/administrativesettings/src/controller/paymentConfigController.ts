import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as paymentService from '../service/paymentService'

/**Razorpay */
export const addRazorPayConfig = async (req: any, res: any) => {
    try {
        const razorPayData = req.body;
        razorPayData.id = ulid();
        const response = await paymentService.addRazorpayConfig(razorPayData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateRazorPayConfig = async (req: any, res: any) => {
    try {
        const { id, ...razorPayData } = req.body;
        const getRazorPayConfig = await paymentService.getRazorpayConfigById(id);
        if (getRazorPayConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Razorpay config not found", 400, null)
            );
        }
        await paymentService.updateRazorpayConfig(id, razorPayData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findRazorPayConfig(req: any, res: any) {
    try {

        const getRazorPayConfig = await paymentService.findRazorPayData()

        if (getRazorPayConfig.rows.length > 0) {
            return res.send(generateResponse(true, "RazorPay fetched successfully", 200, getRazorPayConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No Razorpay data found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

/**Stripe */
export const addStripeConfig = async (req: any, res: any) => {
    try {
        const stripeData = req.body;
        stripeData.id = ulid();
        const response = await paymentService.addStripeConfig(stripeData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateStripeConfig = async (req: any, res: any) => {
    try {
        const { id, ...stripeData } = req.body;
        const getStripeConfig = await paymentService.getStripeConfigById(id);
        if (getStripeConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Stripe config not found", 400, null)
            );
        }
        await paymentService.updateStripeConfig(id, stripeData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findStripeConfig(req: any, res: any) {
    try {

        const getStripeConfig = await paymentService.findStripeData()

        if (getStripeConfig.rows.length > 0) {
            return res.send(generateResponse(true, "Stripe fetched successfully", 200, getStripeConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No Stripe data found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

/**Phonepe */
export const addPhonepeConfig = async (req: any, res: any) => {
    try {
        const phonepeData = req.body;
        phonepeData.id = ulid();
        const response = await paymentService.addPhonepeConfig(phonepeData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updatePhonepeConfig = async (req: any, res: any) => {
    try {
        const { id, ...phonepeData } = req.body;
        const getPhonepeConfig = await paymentService.getPhonepeConfigById(id);
        if (getPhonepeConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Phonepe config not found", 400, null)
            );
        }
        await paymentService.updatePhonepeConfig(id, phonepeData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findPhonepeConfig(req: any, res: any) {
    try {

        const getPhonepeConfig = await paymentService.findPhonepeData()

        if (getPhonepeConfig.rows.length > 0) {
            return res.send(generateResponse(true, "Phonepe fetched successfully", 200, getPhonepeConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No Phonepe data found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

/**Paytm */
export const addPaytmConfig = async (req: any, res: any) => {
    try {
        const paytmData = req.body;
        paytmData.id = ulid();
        const response = await paymentService.addPaytmConfig(paytmData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updatePaytmConfig = async (req: any, res: any) => {
    try {
        const { id, ...paytmData } = req.body;
        const getPaytmConfig = await paymentService.getPaytmConfigById(id);
        if (getPaytmConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Paytm config not found", 400, null)
            );
        }
        await paymentService.updatePaytmConfig(id, paytmData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findPaytmConfig(req: any, res: any) {
    try {

        const getPaytmConfig = await paymentService.findPaytmData()

        if (getPaytmConfig.rows.length > 0) {
            return res.send(generateResponse(true, "Paytm data fetched successfully", 200, getPaytmConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No Paytm data found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const addPineLabsonfig = async (req: any, res: any) => {
    try {
        const pineLabsData = req.body;
        pineLabsData.id = ulid();
        const response = await paymentService.addPineLabsConfig(pineLabsData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updatePineLabsConfig = async (req: any, res: any) => {
    try {
        const { id, ...pineLabsData } = req.body;
        const getPineLabsConfig = await paymentService.getPineLabsConfigById(id);
        if (getPineLabsConfig.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Pine Labs config not found", 400, null)
            );
        }
        await paymentService.updatePineLabsConfig(id, pineLabsData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function findPineLabsConfig(req: any, res: any) {
    try {

        const getPineLabsConfig = await paymentService.findPineLabsData()

        if (getPineLabsConfig.rows.length > 0) {
            return res.send(generateResponse(true, "Pine Labs data fetched successfully", 200, getPineLabsConfig.rows[0]));
        } else {
            return res.send(generateResponse(false, "No Pine Labs data found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}