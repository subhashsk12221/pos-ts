import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as printPreferenceService from '../service/printPreferenceService';

export const addPrintPreference = async (req: any, res: any) => {
    try {
        const printPrefData = req.body;
        printPrefData.id = ulid();
        const response = await printPreferenceService.addPrintPreference(printPrefData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updatePrintPreference = async (req: any, res: any) => {
    try {
        const { id, ...printPrefData } = req.body;
        const getPrintPref = await printPreferenceService.getPrintPreferenceById(id);
        if (getPrintPref.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Print Preference not found", 400, null)
            );
        }
        const currentPrintPreference = await printPreferenceService.getCurrentPrintPreferenceByType(getPrintPref.rows[0].type);
        if (currentPrintPreference.rows.length > 0) {
            await printPreferenceService.updatePrintPreference(currentPrintPreference.rows[0].id, { is_current: false })

        }
        const updatedData = await printPreferenceService.updatePrintPreference(id, printPrefData)

        return res.status(200).send(
            generateResponse(true, "Updated successfully", 200, updatedData.rows[0])
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function printPreferenceList(req: any, res: any) {
    try {
        const { type } = req.query;

        const getPrintPreferences = await printPreferenceService.getPrintPreferenceByType(type)

        if (getPrintPreferences.rows.length > 0) {
            return res.send(generateResponse(true, "Print Preference list fetched successfully", 200, getPrintPreferences.rows));
        } else {
            return res.send(generateResponse(true, `No Print Preferences found for ${type}`, 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export async function currentPrintPreference(req: any, res: any) {
    try {
        const { type } = req.query;

        const getPrintPreferences = await printPreferenceService.getCurrentPrintPreferenceByType(type)

        if (getPrintPreferences.rows.length > 0) {
            return res.send(generateResponse(true, "Print Preference fetched successfully", 200, getPrintPreferences.rows[0]));
        } else {
            return res.send(generateResponse(true, `No Print Preferences found`, 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}