import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as uomService from '../service/uomService'

/**Unit of measures */
export const addUom = async (req: any, res: any) => {
    try {
        const uomData = req.body;
        const checCodeExiists = await uomService.findByUomColoumn('code', uomData.code);
        if (checCodeExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, "Code is already used", 400, null)
            );
        }
        uomData.uom_id = ulid();
        const response = await uomService.addUomData(uomData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Uom added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Uom adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const listUom = async (req: any, res: any) => {
    try {

        const response = await uomService.findAllUom()
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Uom listed successfully", 200, response.rows)
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Uom listing unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getUomList(req: any, res: any) {
    try {
        const getUomList = await uomService.getUomList(req.query)

        if (getUomList.uomList.length > 0) {

            return res.send(generateResponse(true, "Uom list fetched successfully", 200, {
                totalCount: getUomList.totalRowsCount,
                uomList: getUomList.uomList
            }));
        } else {
            return res.send(generateResponse(true, "no uoms found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export async function getUomById(req: any, res: any) {
    try {
        const { uom_id } = req.query;

        const getUom = await uomService.getUomById(uom_id)
        if (getUom.rows.length > 0) {
            return res.send(generateResponse(true, "Uom fetched successfully", 200, getUom.rows[0]));
        } else {
            return res.send(generateResponse(true, "no uom found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const updateUom = async (req: any, res: any) => {
    try {
        const { updatingData } = req.body;

        for (let index = 0; index < updatingData.length; index++) {
            const element = updatingData[index];
            const { uom_id, ...uomData } = element;
            const checCodeExiists = await uomService.findByUomColoumn('code', uomData.code);
            if (checCodeExiists.rows.length > 0 && checCodeExiists.rows[0].uom_id !== uom_id) {
                return res.status(400).send(
                    generateResponse(false, `Code ${uomData.code} is already used`, 400, null)
                );
            }
        }

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { uom_id, ...uomData } = item;
            const getUom = await uomService.getUomById(uom_id);
            if (getUom.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Uom not found", 400, null)
                );
            }
            return (await uomService.updateUom(uom_id, uomData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Uom updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

/**UOM Groups */
export const addUomGroup = async (req: any, res: any) => {
    try {
        const { group_items, ...uomGroupData } = req.body;
        const checNameExiists = await uomService.findByUomGroupColoumn('name', uomGroupData.name);
        if (checNameExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, "Name is already used", 400, null)
            );
        }
        uomGroupData.group_id = ulid();

        const groupData = await uomService.addUomGroupData(uomGroupData);
        if (groupData.rows.length > 0) {
            const groupItemsPromises = group_items.map(async (item: any) => {
                item.item_id = ulid();
                item.group_id = groupData.rows[0].group_id;
                return uomService.addUomGroupItem(item);
            });

            await Promise.all(groupItemsPromises);

            return res.status(200).send(
                generateResponse(true, "Uom Group added successfully", 200, groupData.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Uom Group adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getUomGroupList(req: any, res: any) {
    try {

        const getUomList = await uomService.getUomGroupList(req.query)

        if (getUomList.uomGroupList.length > 0) {

            return res.send(generateResponse(true, "Uom Group list fetched successfully", 200, {
                totalCount: getUomList.totalRowsCount,
                uomList: getUomList.uomGroupList
            }));
        } else {
            return res.send(generateResponse(true, "no uom groups found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const updateUomGroup = async (req: any, res: any) => {
    try {
        const { group_id, group_items, ...uomGroupData } = req.body;

        const getUomGroup = await uomService.getUomGroupById(group_id);
        if (getUomGroup.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Uom Group not found", 400, null));
        }

        const checNameExiists = await uomService.findByUomGroupColoumn('name', uomGroupData.name);
        if (checNameExiists.rows.length > 0 && checNameExiists.rows[0].group_id !== group_id) {
            return res.status(400).send(
                generateResponse(false, "Name is already used", 400, null)
            );
        }

        const groupData = await uomService.updateUomGroupData(group_id, uomGroupData);
        if (groupData.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Uom Group updating unsuccessful", 400, null));
        }

        const groupItemsPromises = group_items.map(async (item: any) => {
            if (!item.item_id) {
                item.item_id = ulid();
                item.group_id = groupData.rows[0].group_id;
                return uomService.addUomGroupItem(item);
            } else {
                return uomService.updateUomGroupItem(item.item_id, item);
            }
        });

        await Promise.all(groupItemsPromises);

        return res.status(200).json(generateResponse(true, "Uom Group Updated Successfully", 200, groupData.rows[0]));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

export const deleteUomGroup = async (req: any, res: any) => {
    try {
        const { group_id } = req.body;
        const checNameExiists = await uomService.getUomGroupById(group_id);
        if (checNameExiists.rows.length < 0) {
            return res.status(400).send(
                generateResponse(false, "UOM Group not found", 400, null)
            );
        }
        await uomService.deleteUomGroupItem(group_id);
        await uomService.deleteUomGroupById(group_id)
        return res.status(200).send(
            generateResponse(true, "Uom Group deleted successfully", 200, null)
        );


    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const deleteUomGroupItem = async (req: any, res: any) => {
    try {
        const { item_id } = req.body;
        const checkExists = await uomService.getUomGroupItemById(item_id);
        if (checkExists.rows.length < 0) {
            return res.status(400).send(
                generateResponse(false, "UOM Group Item not found", 400, null)
            );
        }
        await uomService.deleteUomGroupItemById(item_id);

        return res.status(200).send(
            generateResponse(true, "Uom Group Item deleted successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const listUomGroup = async (req: any, res: any) => {
    try {

        const response = await uomService.uomGroupList()
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Uom group listed successfully", 200, response.rows)
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Uom group listing unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const listUomGroupItems = async (req: any, res: any) => {
    try {
        const { group_id } = req.query;
        const groupItems = await uomService.getUomGroupItems(group_id);
        if (groupItems.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Uom group items listed successfully", 200, groupItems)
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Uom group items listing unsuccessful", 400, null)
            );
        }
    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}