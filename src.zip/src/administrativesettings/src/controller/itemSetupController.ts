import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as itemService from '../service/itemService'


/**Item Types */
export const addItemType = async (req: any, res: any) => {
    try {
        const itemTypeData = req.body;
        const checCodeExiists = await itemService.findByItemTypeColoumn('code', itemTypeData.code);
        if (checCodeExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, "Code is already used", 400, null)
            );
        }
        itemTypeData.id = ulid();
        const response = await itemService.addItemTypeData(itemTypeData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Item Type added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Item Type adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateItemType = async (req: any, res: any) => {
    try {
        const { updatingData } = req.body;

        for (let index = 0; index < updatingData.length; index++) {
            const element = updatingData[index];
            const { id, ...itemTypeData } = element;
            const checCodeExiists = await itemService.findByItemTypeColoumn('code', itemTypeData.code);
            if (checCodeExiists.rows.length > 0 && checCodeExiists.rows[0].id !== id) {
                return res.status(400).send(
                    generateResponse(false, `Code ${itemTypeData.code} is already used`, 400, null)
                );
            }
        }

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...itemTypeData } = item;
            const getItemType = await itemService.getItemTypeById(id);
            if (getItemType.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Item Type not found", 400, null)
                );
            }
            return (await itemService.updateItemType(id, itemTypeData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Item Type updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const deleteItemType = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getItemType = await itemService.getItemTypeById(id);
        if (getItemType.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Item Type not found", 400, null)
            );
        }

        await itemService.deleteItemTypeById(id)
        return res.status(200).send(
            generateResponse(true, "Item Type Deleted successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getItemTypeList(req: any, res: any) {
    try {
        const getItemTypeList = await itemService.getItemTypeList(req.query)

        if (getItemTypeList.itemTypeList.length > 0) {

            return res.send(generateResponse(true, "Item type list fetched successfully", 200, {
                totalCount: getItemTypeList.totalRowsCount,
                itemTypeList: getItemTypeList.itemTypeList
            }));
        } else {
            return res.send(generateResponse(true, "No Item types found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

/**Item Categories */
export const addItemCategory = async (req: any, res: any) => {
    try {
        const itemCategoryData = req.body;
        const checCodeExiists = await itemService.findByItemCategoryColoumn('code', itemCategoryData.code);
        if (checCodeExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, "Code is already used", 400, null)
            );
        }
        itemCategoryData.id = ulid();
        const response = await itemService.addItemCategoryData(itemCategoryData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Item Category added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Item Category adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateItemCategory = async (req: any, res: any) => {
    try {
        const { updatingData } = req.body;

        for (let index = 0; index < updatingData.length; index++) {
            const element = updatingData[index];
            const { id, ...itemCategoryData } = element;
            const checCodeExiists = await itemService.findByItemCategoryColoumn('code', itemCategoryData.code);
            if (checCodeExiists.rows.length > 0 && checCodeExiists.rows[0].id !== id) {
                return res.status(400).send(
                    generateResponse(false, `Code ${itemCategoryData.code} is already used`, 400, null)
                );
            }
        }

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...itemCategoryData } = item;
            const getItemCategory = await itemService.getItemCategoryById(id);
            if (getItemCategory.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Item Category not found", 400, null)
                );
            }
            return (await itemService.updateItemCategory(id, itemCategoryData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Item Category updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getItemCategoryList(req: any, res: any) {
    try {
        const getItemCategoryList = await itemService.getItemCategoryList(req.query)

        if (getItemCategoryList.itemCategoryList.length > 0) {

            return res.send(generateResponse(true, "Item categories list fetched successfully", 200, {
                totalCount: getItemCategoryList.totalRowsCount,
                itemCategoryList: getItemCategoryList.itemCategoryList
            }));
        } else {
            return res.send(generateResponse(true, "Item categories not found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const deleteItemCategory = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getItemCategory = await itemService.getItemCategoryById(id);
        if (getItemCategory.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Item Category not found", 400, null)
            );
        }

        await itemService.deleteItemCategoryById(id)
        return res.status(200).send(
            generateResponse(true, "Item Category Deleted successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

/**Item Groups */
export const addItemGroup = async (req: any, res: any) => {
    try {
        const itemGroupData = req.body;
        const checCodeExiists = await itemService.findByItemGroupColoumn('code', itemGroupData.code);
        if (checCodeExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, `Code ${itemGroupData.code} is already used`, 400, null)
            );
        }
        itemGroupData.id = ulid();
        const response = await itemService.addItemGroupData(itemGroupData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Item Group added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Item Group adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateItemGroup = async (req: any, res: any) => {
    try {

        const { updatingData } = req.body;

        for (let index = 0; index < updatingData.length; index++) {
            const element = updatingData[index];
            const { id, ...itemGroupData } = element;
            const checCodeExiists = await itemService.findByItemGroupColoumn('code', itemGroupData.code);
            if (checCodeExiists.rows.length > 0 && checCodeExiists.rows[0].id !== id) {
                return res.status(400).send(
                    generateResponse(false, `Code ${itemGroupData.code} is already used`, 400, null)
                );
            }
        }

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...itemGroupData } = item;
            const getItemGroup = await itemService.getItemGroupById(id);
            if (getItemGroup.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Item Group not found", 400, null)
                );
            }
            return (await itemService.updateItemGroup(id, itemGroupData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Item Group updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const deleteItemGroup = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getItemGroup = await itemService.getItemGroupById(id);
        if (getItemGroup.rows.length === 0) {
            return res.status(400).send(
                generateResponse(false, "Item Group not found", 400, null)
            );
        }

        await itemService.deleteItemGroupById(id)
        return res.status(200).send(
            generateResponse(true, "Item Group Deleted successfully", 200, null)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getItemGroupList(req: any, res: any) {
    try {

        const getItemGroupList = await itemService.getItemGroupList(req.query)

        if (getItemGroupList.itemGroupList.length > 0) {

            return res.send(generateResponse(true, "Item groups list fetched successfully", 200, {
                totalCount: getItemGroupList.totalRowsCount,
                itemGroupList: getItemGroupList.itemGroupList
            }));
        } else {
            return res.send(generateResponse(true, "Item groups not found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export async function findAllitemType(req: any, res: any) {
    try {

        const getManufacturerList = await itemService.findAllitemType()

        if (getManufacturerList.rows.length > 0) {
            return res.send(generateResponse(true, "item type list fetched successfully", 200, getManufacturerList.rows));
        } else {
            return res.send(generateResponse(true, "No item type  found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export async function getAllitemgroup(req: any, res: any) {
    try {

        const getManufacturerList = await itemService.getAllitemgroup()

        if (getManufacturerList.rows.length > 0) {
            return res.send(generateResponse(true, "item group list fetched successfully", 200, getManufacturerList.rows));
        } else {
            return res.send(generateResponse(true, "No item group found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export async function getAllitemcategory(req: any, res: any) {
    try {

        const getManufacturerList = await itemService.getAllitemcategory()

        if (getManufacturerList.rows.length > 0) {
            return res.send(generateResponse(true, "item type category fetched successfully", 200, getManufacturerList.rows));
        } else {
            return res.send(generateResponse(true, "No item category found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}
