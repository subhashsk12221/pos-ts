import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as shippingService from '../service/shippingService'

export const addShippingType = async (req: any, res: any) => {
    try {
        const shippingTypeData = req.body;
        shippingTypeData.id = ulid();
        const response = await shippingService.addShippingtype(shippingTypeData)
        if (response.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Shipping Type added successfully", 200, response.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Shipping Type adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const updateShippingType = async (req: any, res: any) => {
    try {

        const { updatingData } = req.body;

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...shippingData } = item;
            const getShippingType = await shippingService.getShippingTypeById(id);
            if (getShippingType.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Shipping Type not found", 400, null)
                );
            }
            return (await shippingService.updateShippingType(id, shippingData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).send(
            generateResponse(true, "Shipping Type updated successfully", 200, updatedData)
        );

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getShippingTypeList(req: any, res: any) {
    try {

        const getShippingTypes = await shippingService.getShippingTypeList(req.query)

        if (getShippingTypes.shippingTypeList.length > 0) {
            return res.send(generateResponse(true, "Shipping Type list fetched successfully", 200, {
                totalCount: getShippingTypes.totalRowsCount,
                shippingTypeList: getShippingTypes.shippingTypeList
            }));
        } else {
            return res.send(generateResponse(true, "No Shipping Type found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const deleteShippingType = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getTaxType = await shippingService.getShippingTypeById(id);

        if (getTaxType.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Shipping type not found", 400, null));
        }

        await shippingService.deleteShippingTypeById(id);

        return res.status(200).json(generateResponse(true, "Shipping type Deleted Successfully", 200, null));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

export const shippingTypeList = async (req: any, res: any) => {
    try {

        const getShippingTypes = await shippingService.findAllShippingType()

        if (getShippingTypes.rows.length > 0) {
            return res.send(generateResponse(true, "Shipping Type list fetched successfully", 200, getShippingTypes.rows));
        } else {
            return res.send(generateResponse(true, "No Shipping Type found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}