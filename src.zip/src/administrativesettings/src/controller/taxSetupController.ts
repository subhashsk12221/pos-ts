import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as taxService from '../service/taxService'

/**Tax Types */
export const addTaxType = async (req: any, res: any) => {
    try {
        const taxTypeData = req.body;
        const checkNameExiists = await taxService.findByTaxTypeColoumn('name', taxTypeData.name);
        if (checkNameExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, `Name ${taxTypeData.name} is already used`, 400, null)
            );
        }
        taxTypeData.id = ulid();

        const taxType = await taxService.addTaxTypeData(taxTypeData);
        if (taxType.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Tax Type added successfully", 200, taxType.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Tax Type adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getTaxTypeList(req: any, res: any) {
    try {

        const getTaxTypeList = await taxService.getTaxTypeList(req.query)

        if (getTaxTypeList.taxTypeList.length > 0) {

            return res.send(generateResponse(true, "Tax Type list fetched successfully", 200, {
                totalCount: getTaxTypeList.totalRowsCount,
                taxTypeList: getTaxTypeList.taxTypeList
            }));
        } else {
            return res.send(generateResponse(true, "No Tax Types found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const updateTaxType = async (req: any, res: any) => {
    try {
        const { updatingData } = req.body;

        for (let index = 0; index < updatingData.length; index++) {
            const element = updatingData[index];
            const { id, ...taxTypeData } = element;
            const checkNameExiists = await taxService.findByTaxTypeColoumn('name', taxTypeData.name);
            if (checkNameExiists.rows.length > 0 && checkNameExiists.rows[0].id !== id) {
                return res.status(400).send(
                    generateResponse(false, `Name ${taxTypeData.name} is already used`, 400, null)
                );
            }
        }

        const updatingDataPromises = updatingData.map(async (item: any) => {
            const { id, ...taxTypeData } = item;
            const getManufacturer = await taxService.getTaxTypeById(id);
            if (getManufacturer.rows.length === 0) {
                return res.status(400).send(
                    generateResponse(false, "Tax Type not found", 400, null)
                );
            }
            return (await taxService.updateTaxType(id, taxTypeData)).rows[0];
        });

        const updatedData = await Promise.all(updatingDataPromises);

        return res.status(200).json(generateResponse(true, "Tax Type Updated Successfully", 200, updatedData));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

export const taxTypeList = async (req: any, res: any) => {
    try {
        const taxTypes = await taxService.findAllTaxType();
        if (taxTypes.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "Tax type listed successfully", 200, taxTypes.rows)
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Tax Type listing unsuccessful", 400, null)
            );
        }
    } catch (error) {
        console.log(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export const deleteTaxType = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getTaxType = await taxService.getTaxTypeById(id);

        if (getTaxType.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Tax type not found", 400, null));
        }

        const existsInTaxComb = await taxService.findTaxCombinationItemByTaxType(id);
        
        if (existsInTaxComb.rows.length > 0) {
            return res.status(400).json(generateResponse(false, "Tax type is in use unable to delete", 400, null));
        }

        await taxService.deleteTaxTypeById(id);

        return res.status(200).json(generateResponse(true, "Tax type Deleted Successfully", 200, null));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

/**Tax Combinations */
export const addTaxCombination = async (req: any, res: any) => {
    try {
        const { combinationItems, ...taxCombinationData } = req.body;
        const checCodeExiists = await taxService.findByTaxCombinationColoumn('code', taxCombinationData.code);
        if (checCodeExiists.rows.length > 0) {
            return res.status(400).send(
                generateResponse(false, `Code ${taxCombinationData.code} is already used`, 400, null)
            );
        }
        taxCombinationData.id = ulid();
        taxCombinationData.effective_from = taxCombinationData.effective_from || null
        let combinationRate = 0;
        for (let index = 0; index < combinationItems.length; index++) {
            const element = combinationItems[index];
            combinationRate += parseFloat(element.percentage);
        }
        taxCombinationData.rate = combinationRate;
        console.log("taxCombinationData", taxCombinationData);

        const taxCombination = await taxService.addTaxCombinationData(taxCombinationData);
        if (taxCombination.rows.length > 0) {

            const combinationItemsPromises = combinationItems.map(async (item: any) => {
                item.id = ulid();
                item.tax_combination_id = taxCombination.rows[0].id;
                return (await taxService.addTaxCombinationItems(item)).rows[0];
            });

            await Promise.all(combinationItemsPromises);

            return res.status(200).send(
                generateResponse(true, "Tax Combination added successfully", 200, taxCombination.rows[0])
            );
        } else {
            return res.status(400).send(
                generateResponse(false, "Tax Combination adding unsuccessful", 400, null)
            );
        }

    } catch (error) {
        console.error(error);
        return res.status(500).send(
            generateResponse(false, "Something went wrong", 500, error)
        );
    }
}

export async function getTaxCombinationList(req: any, res: any) {
    try {

        const getTaxCombinationList = await taxService.getTaxCombinationList(req.query)

        if (getTaxCombinationList.taxCombinationList.length > 0) {

            return res.send(generateResponse(true, "Tax Combination list fetched successfully", 200, {
                totalCount: getTaxCombinationList.totalRowsCount,
                taxCombinationList: getTaxCombinationList.taxCombinationList
            }));
        } else {
            return res.send(generateResponse(true, "No Tax Combination found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}

export const updateTaxCombination = async (req: any, res: any) => {
    try {
        const { id, combinationItems, ...taxCombinationData } = req.body;

        const checCodeExiists = await taxService.findByTaxCombinationColoumn('code', taxCombinationData.code);
        if (checCodeExiists.rows.length > 0 && checCodeExiists.rows[0].id !== id) {
            return res.status(400).send(
                generateResponse(false, `Code ${taxCombinationData.code} is already used`, 400, null)
            );
        }
        taxCombinationData.effective_from = taxCombinationData.effective_from || null
        const getTaxCombination = await taxService.getTaxCombinationById(id);
        let combinationRate = 0;
        for (let index = 0; index < combinationItems.length; index++) {
            const element = combinationItems[index];
            combinationRate += parseFloat(element.percentage);
        }
        taxCombinationData.rate = combinationRate;
        if (getTaxCombination.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Tax Combination not found", 400, null));
        }

        const taxCombination = await taxService.updateTaxCombination(id, taxCombinationData);
        if (taxCombination.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Tax Combination updating unsuccessful", 400, null));
        }

        const combinationItemsPromises = combinationItems.map(async (item: any) => {
            if (!item.id) {
                item.id = ulid();
                item.tax_combination_id = taxCombination.rows[0].id;
                return taxService.addTaxCombinationItems(item);
            } else {
                return taxService.updateTaxCombinationItems(item.item_id, item);
            }
        });

        await Promise.all(combinationItemsPromises);

        return res.status(200).json(generateResponse(true, "Tax Combination Updated Successfully", 200, taxCombination.rows[0]));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

export const deleteTaxCombination = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const getTaxCombination = await taxService.getTaxCombinationById(id);

        if (getTaxCombination.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Tax Combination not found", 400, null));
        }

        await taxService.deleteTaxCombinationItem(id)
        await taxService.deleteTaxCombinationById(id);

        return res.status(200).json(generateResponse(true, "Tax Combination deleted Successfully", 200, null));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

export const deleteTaxCombinationItem = async (req: any, res: any) => {
    try {
        const { id } = req.body;

        const taxCombinationItem = await taxService.findTaxCombinationItemById(id);
        if (taxCombinationItem.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Tax Combination Item not found", 400, null));
        }
        const taxCombination = await taxService.getTaxCombinationById(taxCombinationItem.rows[0].tax_combination_id);
        if (taxCombination.rows.length === 0) {
            return res.status(400).json(generateResponse(false, "Tax Combination not found", 400, null));
        }
        const taxCombObject = {
            rate: parseFloat(taxCombination.rows[0].rate) - parseFloat(taxCombinationItem.rows[0].percentage)
        }

        await taxService.updateTaxCombination(taxCombinationItem.rows[0].tax_combination_id, taxCombObject)

        await taxService.deleteTaxCombinationItemById(id)
        return res.status(200).json(generateResponse(true, "Tax Combination deleted Successfully", 200, null));

    } catch (error) {
        console.error(error);
        return res.status(500).json(generateResponse(false, "Something went wrong", 500, error));
    }
}

export async function findAllTaxCombination(req: any, res: any) {
    try {

        const getManufacturerList = await taxService.findAllTaxCombination()

        if (getManufacturerList.rows.length > 0) {
            return res.send(generateResponse(true, "tax type category fetched successfully", 200, getManufacturerList.rows));
        } else {
            return res.send(generateResponse(true, "No item category found", 400, null));
        }

    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, "Something went wrong", 400, error));
    }
}