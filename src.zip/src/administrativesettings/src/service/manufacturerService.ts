import client from '../util/database';

/**Manufacturer */
export async function findAllManufacturer() {
    try {

        const query = 'SELECT id, name, code FROM manufacturer';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getManufacturerList(query: any) {
    try {
        const { searchValue } = query;

        let whereClause = '';
        let orderByClause = '';

        orderByClause = 'ORDER BY m.created_date ASC';

        // Add search condition for the specified column
        if (searchValue) {
            whereClause += ` AND (m.code ILIKE $1 OR m.name ILIKE $1)`;
        }
        const values = searchValue ? [`%${searchValue}%`] : []

        const manufacturerListQuery = `
            SELECT
                m.*
            FROM
                manufacturer m
            WHERE
                1=1 ${whereClause}
            GROUP BY
                m.id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM manufacturer m 
            WHERE 1=1 ${whereClause};
        `;

        const totalCount = await client.query(queryCount, values);
        const getManufacturerList = await client.query(manufacturerListQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const manufacturerList = getManufacturerList.rows;
        return { totalRowsCount, manufacturerList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addManufacturerData(manufacturerData: any) {
    try {

        const columns = Object.keys(manufacturerData);
        const values = Object.values(manufacturerData);

        const insertQuery = `INSERT INTO manufacturer (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getManufacturerById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "manufacturer" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateManufacturerData(id: any, manufacturerData: any) {
    try {

        const columnValuePairs = Object.entries(manufacturerData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(manufacturerData);

        const query = `UPDATE manufacturer SET ${columnValuePairs} WHERE id = $${Object.keys(manufacturerData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteManufacturer(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "manufacturer" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByManufacturerColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "manufacturer" m
        WHERE
          m.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}