import client from '../util/database';

export async function addPrintPreference(printPrefData: any) {
    try {

        const columns = Object.keys(printPrefData);
        const values = Object.values(printPrefData);

        const insertQuery = `INSERT INTO print_preference (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updatePrintPreference(id: any, printPrefData: any) {
    try {
        const columnValuePairs = Object.entries(printPrefData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(printPrefData);

        const query = `UPDATE print_preference SET ${columnValuePairs} WHERE id = $${Object.keys(printPrefData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPrintPreferenceById(id: any) {
    try {
        const query = `
        SELECT *
        FROM
          "print_preference" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getCurrentPrintPreferenceByType(type: any) {
    try {
        const query = `
        SELECT *
        FROM
          "print_preference" m
        WHERE
          m.is_current = true AND
          m.type = $1;`;

        const result = await client.query(query, [type]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPrintPreferenceByType(type: any) {
    try {
        const query = `
        SELECT *
        FROM
          "print_preference" m
        WHERE
          m.type = $1
        ORDER BY m.created_date ASC;`;

        const result = await client.query(query, [type]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}