import client from '../util/database';

/**Document Numbering Queries */

export async function getDocumentList(query: any) {
    try {
        const { searchValue } = query;

        let whereClause = '';
        let orderByClause = 'ORDER BY i.created_date ASC';

        // Add search condition for the name and code
        if (searchValue) {
            whereClause += ` AND (i.code ILIKE $1 OR i.name ILIKE $1)`;
        }

        const totalOrderValueQuery = `
            SELECT
                i.*,
                json_build_object(
                    'id', s.id,
                    'document_numbering_id', s.document_numbering_id,
                    'name', s.name,
                    'first_no', s.first_no,
                    'next_no', s.next_no,
                    'last_no', s.last_no,
                    'prefix', s.prefix,
                    'suffix', s.suffix,
                    'period', s.period,
                    'cancellation', s.cancellation,
                    'lock', s.lock,
                    'digital_series', s.digital_series,
                    'update_date', s.update_date,
                    'created_date', s.created_date
                ) AS default_series,
                json_agg(
                    json_build_object(
                        'value',opt.id,
                        'label', opt.name
                    )
                ) AS default_options
            FROM
                document_numbering i
            LEFT JOIN
                document_numbering_series s ON i.default_series = s.id
            LEFT JOIN
                document_numbering_series opt ON i.id = opt.document_numbering_id
            WHERE
                1=1 ${whereClause}
            GROUP BY
                i.id, s.id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM document_numbering i 
            WHERE 1=1 ${whereClause};
        `;

        const values = searchValue ? [`%${searchValue}%`] : [];

        const totalCount = await client.query(queryCount, values);
        const documentLists = await client.query(totalOrderValueQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const documentList = documentLists.rows;
        return { totalRowsCount, documentList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addDocumentData(docData: any) {
    try {

        const columns = Object.keys(docData);
        const values = Object.values(docData);

        const insertQuery = `INSERT INTO document_numbering (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getDocumentById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "document_numbering" it
        WHERE
          it.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateDocument(id: any, itemTypeData: any) {
    try {

        const columnValuePairs = Object.entries(itemTypeData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(itemTypeData);

        const query = `UPDATE document_numbering SET ${columnValuePairs} WHERE id = $${Object.keys(itemTypeData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByDocumentColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "document_numbering" it
        WHERE
          it.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteDocumentById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "document_numbering" i
        WHERE
          i.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Document Numbering Series */

export async function getDocumentNumberingSeriesList(query: any) {
    try {
        const { searchValue, id } = query;

        let whereClause = '';
        let orderByClause = '';

        orderByClause = 'ORDER BY i.created_date ASC';

        // Add search condition for the name and code
        if (searchValue) {
            whereClause += ` AND (i.code ILIKE $1 OR i.name ILIKE $1)`;
        }
        const values = searchValue ? [`%${searchValue}%`] : [];
        // Add condition for document_numbering_id
        whereClause += ` AND i.document_numbering_id = $${values.length + 1}`; // Append to existing clause

        const totalOrderValueQuery = `
        SELECT
          i.*
        FROM
          document_numbering_series i
        WHERE
          1=1 ${whereClause}
        GROUP BY
          i.id
        ${orderByClause};
      `;

        const queryCount = `
        SELECT COUNT(*)
        FROM document_numbering_series i
        WHERE 1=1 ${whereClause};
      `;

        values.push(id); // Add id to the values array

        const totalCount = await client.query(queryCount, values);
        const documentLists = await client.query(totalOrderValueQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const documentList = documentLists.rows;

        return { totalRowsCount, documentList };
    } catch (error) {
        throw new Error(error);
    }
}

export async function addDocumentNumberingSeriesData(docData: any) {
    try {

        const columns = Object.keys(docData);
        const values = Object.values(docData);

        const insertQuery = `INSERT INTO document_numbering_series (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getDocumentNumberingSeriesById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "document_numbering_series" it
        WHERE
          it.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateDocumentNumberingSeries(id: any, itemTypeData: any) {
    try {

        const columnValuePairs = Object.entries(itemTypeData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(itemTypeData);

        const query = `UPDATE document_numbering_series SET ${columnValuePairs} WHERE id = $${Object.keys(itemTypeData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByDocumentNumberingSeriesColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "document_numbering_series" it
        WHERE
          it.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteDocumentNumberingSeriesById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "document_numbering_series" i
        WHERE
          i.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}
