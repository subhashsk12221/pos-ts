import client from '../util/database';

/**Item Type Queries */
export async function getItemTypeList(query: any) {
    try {
        const { searchValue } = query;

        let whereClause = '';
        let orderByClause = '';

        orderByClause = 'ORDER BY i.created_date ASC';

        // Add search condition for the name and code

        if (searchValue) {
            whereClause += ` AND (i.code ILIKE $1 OR i.name ILIKE $1)`;
        }

        const totalOrderValueQuery = `
            SELECT
                i.*
            FROM
                item_type i
            WHERE
                1=1 ${whereClause}
            GROUP BY
                i.id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM item_type i 
            WHERE 1=1 ${whereClause};
        `;

        const values = searchValue ? [`%${searchValue}%`] : [];

        const totalCount = await client.query(queryCount, values);
        const getItemTypeList = await client.query(totalOrderValueQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const itemTypeList = getItemTypeList.rows;
        return { totalRowsCount, itemTypeList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function itemTypeList() {
    try {

        const query = 'SELECT id, name, code FROM item_type';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addItemTypeData(itemTypeData: any) {
    try {

        const columns = Object.keys(itemTypeData);
        const values = Object.values(itemTypeData);

        const insertQuery = `INSERT INTO item_type (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getItemTypeById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "item_type" it
        WHERE
          it.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateItemType(id: any, itemTypeData: any) {
    try {

        const columnValuePairs = Object.entries(itemTypeData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(itemTypeData);

        const query = `UPDATE item_type SET ${columnValuePairs} WHERE id = $${Object.keys(itemTypeData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByItemTypeColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "item_type" it
        WHERE
          it.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteItemTypeById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "item_type" i
        WHERE
          i.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Item category Queries */
export async function itemCategoryList() {
    try {

        const query = 'SELECT id, name, code FROM item_category';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getItemCategoryList(query: any) {
    try {
        const { searchValue } = query;

        let whereClause = '';
        let orderByClause = '';

        orderByClause = 'ORDER BY i.created_date ASC';

        // Add search condition for the specified column
        if (searchValue) {
            whereClause += ` AND (i.code ILIKE $1 OR i.name ILIKE $1)`;
        }

        const totalOrderValueQuery = `
            SELECT
                i.*
            FROM
                item_category i
            WHERE
                1=1 ${whereClause}
            GROUP BY
                i.id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM item_category i 
            WHERE 1=1 ${whereClause};
        `;

        const values = searchValue ? [`%${searchValue}%`] : [];
        const totalCount = await client.query(queryCount, values);
        const getItemCategoryList = await client.query(totalOrderValueQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const itemCategoryList = getItemCategoryList.rows;
        return { totalRowsCount, itemCategoryList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addItemCategoryData(itemCategoryData: any) {
    try {

        const columns = Object.keys(itemCategoryData);
        const values = Object.values(itemCategoryData);

        const insertQuery = `INSERT INTO item_category (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getItemCategoryById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "item_category" it
        WHERE
          it.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateItemCategory(id: any, itemCategoryData: any) {
    try {

        const columnValuePairs = Object.entries(itemCategoryData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(itemCategoryData);

        const query = `UPDATE item_category SET ${columnValuePairs} WHERE id = $${Object.keys(itemCategoryData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByItemCategoryColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "item_category" it
        WHERE
          it.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteItemCategoryById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "item_category" i
        WHERE
          i.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Item Group Queries */
export async function itemGroupList() {
    try {

        const query = 'SELECT id, name, code FROM item_group';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getItemGroupList(query: any) {
    try {
        const { searchColumn, searchValue } = query;

        let whereClause = '';
        let orderByClause = '';

        orderByClause = 'ORDER BY ig.created_date ASC';

        // Add search condition for the specified column
        if (searchValue) {
            whereClause += ` AND (ig.code ILIKE $1 OR ig.name ILIKE $1)`;
        }

        const totalOrderValueQuery = `
        SELECT 
            ig.id,
            ig.code,
            ig.name,
            ig.default_uom_id,
            json_build_object(
                'uom_id', uom.uom_id,
                'name', uom.name
            ) AS default_uom,
             ig.update_date,
            ig.created_date
        FROM 
           item_group ig
        LEFT JOIN 
             unit_of_measure uom ON ig.default_uom_id = uom.uom_id    
        WHERE
            1=1 ${whereClause}
        GROUP BY
                ig.id, uom.uom_id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM item_group ig 
            WHERE 1=1 ${whereClause};
        `;

        const values = searchValue ? [`%${searchValue}%`] : [];
        const totalCount = await client.query(queryCount, values);
        const getItemGroupList = await client.query(totalOrderValueQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const itemGroupList = getItemGroupList.rows;
        return { totalRowsCount, itemGroupList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addItemGroupData(itemGroupData: any) {
    try {

        const columns = Object.keys(itemGroupData);
        const values = Object.values(itemGroupData);

        const insertQuery = `INSERT INTO item_group (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getItemGroupById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "item_group" it
        WHERE
          it.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateItemGroup(id: any, itemGroupData: any) {
    try {

        const columnValuePairs = Object.entries(itemGroupData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(itemGroupData);

        const query = `UPDATE item_group SET ${columnValuePairs} WHERE id = $${Object.keys(itemGroupData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByItemGroupColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "item_group" it
        WHERE
          it.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteItemGroupById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "item_group" i
        WHERE
          i.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findAllitemType() {
    try {

        const query = 'SELECT id, name, code FROM item_type';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getAllitemcategory() {
    try {

        const query = 'SELECT id, name, code FROM item_category';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getAllitemgroup() {
    try {

        const query = 'SELECT id, name, code FROM item_group';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}