import client from '../util/database';

/**Uom */
export async function findAllUom() {
    try {

        const query = 'SELECT uom_id, name, code FROM unit_of_measure';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }

}

export async function getUomList(query: any) {
    try {
        const { search } = query;

        let whereClause = '';
        let orderByClause = 'ORDER BY u.created_date ASC';

        if (search) {
            whereClause += ` AND (u.code ILIKE $1 OR u.name ILIKE $1)`;
        }

        const totalOrderValueQuery = `
            SELECT
                u.*
            FROM
                unit_of_measure u
            WHERE
                1=1 ${whereClause}
            GROUP BY
                u.uom_id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM unit_of_measure u 
            WHERE 1=1 ${whereClause};
        `;

        const values = search ? [`%${search}%`] : [];

        const totalCount = await client.query(queryCount, values);
        const getUomList = await client.query(totalOrderValueQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const uomList = getUomList.rows;
        return { totalRowsCount, uomList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addUomData(uomData: any) {
    try {

        const columns = Object.keys(uomData);
        const values = Object.values(uomData);

        const insertQuery = `INSERT INTO unit_of_measure (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getUomById(uom_id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "unit_of_measure" um
        WHERE
          um.uom_id = $1;`;

        const result = await client.query(query, [uom_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateUom(uom_id: any, uomData: any) {
    try {

        const columnValuePairs = Object.entries(uomData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(uomData);

        const query = `UPDATE unit_of_measure SET ${columnValuePairs} WHERE uom_id = $${Object.keys(uomData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, uom_id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByUomColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "unit_of_measure" u
        WHERE
          u.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Uom Groups */
export async function uomGroupList() {
    try {

        const query = 'SELECT group_id, name FROM uom_group';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addUomGroupData(uomGroupData: any) {
    try {

        const columns = Object.keys(uomGroupData);
        const values = Object.values(uomGroupData);

        const insertQuery = `INSERT INTO uom_group (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addUomGroupItem(uomGroupItemData: any) {
    try {

        const columns = Object.keys(uomGroupItemData);
        const values = Object.values(uomGroupItemData);

        const insertQuery = `INSERT INTO uom_group_item (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getUomGroupById(group_id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "uom_group" um
        WHERE
          um.group_id = $1;`;

        const result = await client.query(query, [group_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getUomGroupList(query: any) {
    try {
        const { searchValue } = query;

        let orderByClause = '';

        orderByClause = 'ORDER BY ug.created_date DESC';

        const searchCondition = searchValue
            ? `AND (LOWER(ug.name) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const groupListDataQuery = `
            WITH grouped_data AS (
                SELECT 
                    ug.group_id,
                    ug.name,
                    ug.description ,
                    ug.created_date ,
                    ug.update_date,
                    json_agg(
                        json_build_object(
                            'item_id', ugi.item_id,
                            'alt_quantity', ugi.alt_quantity,
                            'alt_uom', ugi.alt_uom,
                            'base_quantity', ugi.base_quantity,
                            'base_uom_id', ugi.base_uom_id,
                            'created_date', ugi.created_date,
                            'update_date', ugi.update_date,
                            'base_uom', json_build_object(
                                'uom_id', uom.uom_id,
                                'code', uom.code,
                                'name', uom.name,
                                'ewb_unit', uom.ewb_unit,
                                'length', uom.length,
                                'width', uom.width,
                                'height', uom.height,
                                'volume', uom.volume,
                                'volume_uom', uom.volume_uom,
                                'weight', uom.weight,
                                'created_date', uom.created_date,
                                'update_date', uom.update_date
                            )
                        )
                    ) AS group_items
                FROM 
                    uom_group ug
                LEFT JOIN 
                    uom_group_item ugi ON ug.group_id = ugi.group_id
                LEFT JOIN 
                    unit_of_measure uom ON ugi.base_uom_id = uom.uom_id
                WHERE 
                    1=1 ${searchCondition}
                GROUP BY
                    ug.group_id
                ORDER BY 
                    ug.created_date DESC
            )
            SELECT 
                json_agg(grouped_data) AS uom_groups
            FROM 
                grouped_data;
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM uom_group ug 
            WHERE 1=1 ${searchCondition};
        `;

        const totalCount = await client.query(queryCount);
        const getUomList = await client.query(groupListDataQuery);
        const totalRowsCount = totalCount.rows[0].count;
        const uomGroupList = getUomList.rows[0].uom_groups || [];

        return { totalRowsCount, uomGroupList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function updateUomGroupData(group_id: any, uomGroupData: any) {
    try {

        const columnValuePairs = Object.entries(uomGroupData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(uomGroupData);

        const query = `UPDATE uom_group SET ${columnValuePairs} WHERE group_id = $${Object.keys(uomGroupData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, group_id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateUomGroupItem(item_id: any, uomGroupItemData: any) {
    try {

        const columnValuePairs = Object.entries(uomGroupItemData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(uomGroupItemData);

        const query = `UPDATE uom_group_item SET ${columnValuePairs} WHERE item_id = $${Object.keys(uomGroupItemData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, item_id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByUomGroupColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "uom_group" u
        WHERE
          u.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteUomGroupById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "uom_group" t
        WHERE
          t.group_id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteUomGroupItem(group_id: any) {
    try {

        const query = `
        DELETE
        FROM
          "uom_group_item" t
        WHERE
          t.group_id = $1;`;

        const result = await client.query(query, [group_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getUomGroupItemById(item_id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "uom_group_item" um
        WHERE
          um.item_id = $1;`;

        const result = await client.query(query, [item_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getUomGroupItems(group_id: any) {
    try {
        const query = `
        SELECT 
            um.*,
            json_build_object(
                'uom_id', u.uom_id,
                'name', u.name,
                'code', u.code
            ) AS base_uom
        FROM
            "uom_group_item" um
        LEFT JOIN 
            "unit_of_measure" u ON um.base_uom_id = u.uom_id
        WHERE
            um.group_id = $1;
        `;

        const result = await client.query(query, [group_id]);
        return result.rows;

    } catch (error) {
        throw new Error(error);
    }
}


export async function deleteUomGroupItemById(item_id: any) {
    try {

        const query = `
        DELETE
        FROM
          "uom_group_item" t
        WHERE
          t.item_id = $1;`;

        const result = await client.query(query, [item_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getUomGroupItemsDropdown(group_id: any) {
    try {
        const query = `
           SELECT 
            um.*,
            json_build_object(
                'uom_id', u.uom_id,
                'name', u.name,
                'code', u.code
            ) AS base_uom
        FROM
            "uom_group_item" um
        LEFT JOIN 
            "unit_of_measure" u ON um.base_uom_id = u.uom_id
        WHERE
            um.group_id = $1;
        `;

        const result = await client.query(query, [group_id]);
        return result;

    } catch (error) {
        throw new Error(error);
    }
}

export async function getUomGroupOfItems(item_id: any) {
    try {
        const query = `
           SELECT *
        FROM
            "uom_group_item" um
        WHERE
            item_id = $1;
        `;

        const result = await client.query(query, [item_id]);
        return result;

    } catch (error) {
        throw new Error(error);
    }
}