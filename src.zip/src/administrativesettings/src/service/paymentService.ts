import client from '../util/database';

/**Razorpay */
export async function findRazorPayData() {
    try {

        const query = 'SELECT * FROM razorpay_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addRazorpayConfig(razorPayData: any) {
    try {

        const columns = Object.keys(razorPayData);
        const values = Object.values(razorPayData);

        const insertQuery = `INSERT INTO razorpay_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateRazorpayConfig(id: any, razorPayData: any) {
    try {

        const columnValuePairs = Object.entries(razorPayData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(razorPayData);

        const query = `UPDATE razorpay_config SET ${columnValuePairs} WHERE id = $${Object.keys(razorPayData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getRazorpayConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "razorpay_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**STripe */
export async function findStripeData() {
    try {

        const query = 'SELECT * FROM stripe_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addStripeConfig(stripeData: any) {
    try {

        const columns = Object.keys(stripeData);
        const values = Object.values(stripeData);

        const insertQuery = `INSERT INTO stripe_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateStripeConfig(id: any, stripeData: any) {
    try {

        const columnValuePairs = Object.entries(stripeData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(stripeData);

        const query = `UPDATE stripe_config SET ${columnValuePairs} WHERE id = $${Object.keys(stripeData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getStripeConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "stripe_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Phonepe */
export async function findPhonepeData() {
    try {

        const query = 'SELECT * FROM phonepe_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPhonepeConfig(phonepeData: any) {
    try {

        const columns = Object.keys(phonepeData);
        const values = Object.values(phonepeData);

        const insertQuery = `INSERT INTO phonepe_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updatePhonepeConfig(id: any, phonepeData: any) {
    try {

        const columnValuePairs = Object.entries(phonepeData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(phonepeData);

        const query = `UPDATE phonepe_config SET ${columnValuePairs} WHERE id = $${Object.keys(phonepeData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPhonepeConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "phonepe_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Paytm */
export async function findPaytmData() {
    try {

        const query = 'SELECT * FROM paytm_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPaytmConfig(paytmData: any) {
    try {

        const columns = Object.keys(paytmData);
        const values = Object.values(paytmData);

        const insertQuery = `INSERT INTO paytm_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updatePaytmConfig(id: any, paytmData: any) {
    try {

        const columnValuePairs = Object.entries(paytmData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(paytmData);

        const query = `UPDATE paytm_config SET ${columnValuePairs} WHERE id = $${Object.keys(paytmData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPaytmConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "paytm_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Print Labs */
export async function findPineLabsData() {
    try {

        const query = 'SELECT * FROM pine_labs_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPineLabsConfig(pineLabsData: any) {
    try {

        const columns = Object.keys(pineLabsData);
        const values = Object.values(pineLabsData);

        const insertQuery = `INSERT INTO pine_labs_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updatePineLabsConfig(id: any, pineLabsData: any) {
    try {

        const columnValuePairs = Object.entries(pineLabsData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(pineLabsData);

        const query = `UPDATE pine_labs_config SET ${columnValuePairs} WHERE id = $${Object.keys(pineLabsData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPineLabsConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "pine_labs_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}