import client from '../util/database';

/**Tax Types */
export async function findAllTaxType() {
    try {

        const query = 'SELECT id, name FROM tax_type';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getTaxTypeList(query: any) {
    try {
        const { searchValue } = query;

        let whereClause = '';
        let orderByClause = '';

        // orderByClause = 'ORDER BY u.created_date DESC/ASC';
        orderByClause = 'ORDER BY t.created_date ASC';

        // Add search condition for the specified column
        const searchCondition = searchValue
            ? `AND (LOWER(t.name) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const totalOrderValueQuery = `
            SELECT
                t.*
            FROM
                tax_type t
            WHERE
                1=1 ${whereClause} ${searchCondition}
            GROUP BY
                t.id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM tax_type t 
            WHERE 1=1 ${whereClause} ${searchCondition};
        `;

        const totalCount = await client.query(queryCount);
        const getTaxTypeList = await client.query(totalOrderValueQuery);
        const totalRowsCount = totalCount.rows[0].count;
        const taxTypeList = getTaxTypeList.rows;
        return { totalRowsCount, taxTypeList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addTaxTypeData(taxTypeData: any) {
    try {

        const columns = Object.keys(taxTypeData);
        const values = Object.values(taxTypeData);

        const insertQuery = `INSERT INTO tax_type (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getTaxTypeById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "tax_type" t
        WHERE
          t.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateTaxType(id: any, taxTypeData: any) {
    try {

        const columnValuePairs = Object.entries(taxTypeData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(taxTypeData);

        const query = `UPDATE tax_type SET ${columnValuePairs} WHERE id = $${Object.keys(taxTypeData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteTaxTypeById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "tax_type" t
        WHERE
          t.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByTaxTypeColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "tax_type" t
        WHERE
          t.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Tax Combinations */
export async function getTaxCombinationList(query: any) {
    try {
        const { searchValue } = query;

        let whereClause = '';
        let orderByClause = 'ORDER BY tc.created_date ASC';

        // Add search condition for the specified column
        const searchCondition = searchValue
            ? `AND (LOWER(tc.code) ILIKE LOWER($1))`
            : '';

        const totalOrderValueQuery = `
            WITH grouped_data AS (
                SELECT 
                    tc.id,
                    tc.code,
                    tc.rate,
                    tc.effective_from,
                    json_agg(
                        json_build_object(
                            'id', tci.id,
                            'tax_combination_id', tci.tax_combination_id,
                            'tax_type_id', tci.tax_type_id,
                            'percentage', tci.percentage,
                            'sales_tax_acc', tci.sales_tax_acc,
                            'purchase_tax_acc', tci.purchase_tax_acc,
                            'created_date', tci.created_date,
                            'update_date', tci.update_date,
                            'tax_type', json_build_object(
                                'id', tax.id,
                                'name', tax.name
                            )
                        )
                    ) AS tax_combination_items,
                    tc.update_date,
                    tc.created_date
                FROM 
                    tax_combination tc
                LEFT JOIN 
                    tax_combination_item tci ON tc.id = tci.tax_combination_id
                LEFT JOIN 
                    tax_type tax ON tci.tax_type_id = tax.id    
                WHERE
                    1=1 ${whereClause} ${searchCondition}
                GROUP BY
                    tc.id
                ${orderByClause}
            )
            SELECT 
                json_agg(grouped_data) AS tax_combinations
            FROM 
                grouped_data;
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM tax_combination tc 
            WHERE 1=1 ${whereClause} ${searchCondition};
        `;

        const values = searchValue ? [`%${searchValue}%`] : [];

        const totalCount = await client.query(queryCount, values);
        const getTaxCombinationList = await client.query(totalOrderValueQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const taxCombinationList = getTaxCombinationList.rows[0].tax_combinations || [];
        return { totalRowsCount, taxCombinationList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addTaxCombinationData(taxCombinationData: any) {
    try {

        const columns = Object.keys(taxCombinationData);
        const values = Object.values(taxCombinationData);

        const insertQuery = `INSERT INTO tax_combination (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getTaxCombinationById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "tax_combination" t
        WHERE
          t.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateTaxCombination(id: any, taxCombinationData: any) {
    try {

        const columnValuePairs = Object.entries(taxCombinationData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(taxCombinationData);

        const query = `UPDATE tax_combination SET ${columnValuePairs} WHERE id = $${Object.keys(taxCombinationData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addTaxCombinationItems(taxCombinationData: any) {
    try {

        const columns = Object.keys(taxCombinationData);
        const values = Object.values(taxCombinationData);

        const insertQuery = `INSERT INTO tax_combination_item (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateTaxCombinationItems(id: any, taxCombinationData: any) {
    try {

        const columnValuePairs = Object.entries(taxCombinationData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(taxCombinationData);

        const query = `UPDATE tax_combination_item SET ${columnValuePairs} WHERE id = $${Object.keys(taxCombinationData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteTaxCombinationById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "tax_combination" t
        WHERE
          t.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteTaxCombinationItem(taxCombinationId: any) {
    try {

        const query = `
        DELETE
        FROM
          "tax_combination_item" t
        WHERE
          t.tax_combination_id = $1;`;

        const result = await client.query(query, [taxCombinationId]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteTaxCombinationItemById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "tax_combination_item" t
        WHERE
          t.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findTaxCombinationItemById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "tax_combination_item" t
        WHERE
          t.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findTaxCombinationItemByTaxType(taxTypeId: any) {
    try {
        console.log("checking this query of", taxTypeId);

        const query = `
        SELECT *
        FROM
          "tax_combination_item" t
        WHERE
          t.tax_type_id = $1;`;

        const result = await client.query(query, [taxTypeId]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findByTaxCombinationColoumn(coloumn: any, value: any) {
    try {
        const query = `
        SELECT *
        FROM
          "tax_combination" t
        WHERE
          t.${coloumn} ILIKE $1;`;

        const result = await client.query(query, [value]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function findAllTaxCombination() {
    try {

        const query = 'SELECT * FROM tax_combination';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}