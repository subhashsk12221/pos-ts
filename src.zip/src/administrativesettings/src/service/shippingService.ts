import client from '../util/database';

/**Manufacturer */
export async function findAllShippingType() {
    try {

        const query = 'SELECT * FROM shipping_type';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getShippingTypeList(query: any) {
    try {
        const { searchColumn, searchValue } = query;



        let whereClause = '';
        let orderByClause = '';

        orderByClause = 'ORDER BY m.created_date ASC';

        // Add search condition for the specified column
        if (searchValue) {
            whereClause += ` AND (m.carrier ILIKE $1 OR m.name ILIKE $1)`;
        }
        const values = searchValue ? [`%${searchValue}%`] : []

        const shippingTypeListQuery = `
            SELECT
                m.*
            FROM
                shipping_type m
            WHERE
                1=1 ${whereClause}
            GROUP BY
                m.id
            ${orderByClause};
        `;

        const queryCount = `
            SELECT COUNT(*) 
            FROM shipping_type m 
            WHERE 1=1 ${whereClause};
        `;

        const totalCount = await client.query(queryCount, values);
        const getShippingTypeList = await client.query(shippingTypeListQuery, values);
        const totalRowsCount = totalCount.rows[0].count;
        const shippingTypeList = getShippingTypeList.rows;
        return { totalRowsCount, shippingTypeList };

    } catch (error) {
        throw new Error(error);
    }
}

export async function addShippingtype(shippingTypeData: any) {
    try {

        const columns = Object.keys(shippingTypeData);
        const values = Object.values(shippingTypeData);

        const insertQuery = `INSERT INTO shipping_type (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getShippingTypeById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "shipping_type" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateShippingType(id: any, shippingTypeData: any) {
    try {

        const columnValuePairs = Object.entries(shippingTypeData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(shippingTypeData);

        const query = `UPDATE shipping_type SET ${columnValuePairs} WHERE id = $${Object.keys(shippingTypeData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function deleteShippingTypeById(id: any) {
    try {

        const query = `
        DELETE
        FROM
          "shipping_type" s
        WHERE
          s.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}