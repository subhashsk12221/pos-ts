import client from '../util/database';

/**SMTP */
export async function findSmtpData() {
    try {

        const query = 'SELECT * FROM smtp_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addSmtpConfig(smptData: any) {
    try {

        const columns = Object.keys(smptData);
        const values = Object.values(smptData);

        const insertQuery = `INSERT INTO smtp_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateSmtpConfig(id: any, smptData: any) {
    try {

        const columnValuePairs = Object.entries(smptData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(smptData);

        const query = `UPDATE smtp_config SET ${columnValuePairs} WHERE id = $${Object.keys(smptData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSmtpConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "smtp_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Whatsapp */
export async function findWhatsappData() {
    try {

        const query = 'SELECT * FROM whatsapp_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addWhatsappConfig(whatsappData: any) {
    try {

        const columns = Object.keys(whatsappData);
        const values = Object.values(whatsappData);

        const insertQuery = `INSERT INTO whatsapp_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateWhatsappConfig(id: any, whatsappData: any) {
    try {

        const columnValuePairs = Object.entries(whatsappData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(whatsappData);

        const query = `UPDATE whatsapp_config SET ${columnValuePairs} WHERE id = $${Object.keys(whatsappData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getWhatsappConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "whatsapp_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

/**Sms Config */
export async function findSmsData() {
    try {

        const query = 'SELECT * FROM sms_config';

        const result = await client.query(query);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function addSmsConfig(smsData: any) {
    try {

        const columns = Object.keys(smsData);
        const values = Object.values(smsData);

        const insertQuery = `INSERT INTO sms_config (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const result = await client.query(insertQuery, values);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateSmsConfig(id: any, smsData: any) {
    try {

        const columnValuePairs = Object.entries(smsData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        const values = Object.values(smsData);

        const query = `UPDATE sms_config SET ${columnValuePairs} WHERE id = $${Object.keys(smsData).length + 1}  RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, id]);

        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSmsConfigById(id: any) {
    try {

        const query = `
        SELECT *
        FROM
          "sms_config" m
        WHERE
          m.id = $1;`;

        const result = await client.query(query, [id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}