import * as uomController from '../controller/uomSetupController'
import * as itemController from '../controller/itemSetupController'
import * as taxController from '../controller/taxSetupController'
import * as manufacturerController from '../controller/manufacturerController'
import * as shippingController from '../controller/shippingSetupController'
import * as documentNumberingController from '../controller/documentNumberingController'
import * as testController from '../controller/testController';
import * as communicationController from '../controller/communicationController';
import * as paymentConfigController from '../controller/paymentConfigController';
import * as printPreferenceController from '../controller/printPreferenceController';

export function routes(app: any) {
    /**UOM Setup */
    /**Unit of Measures */
    app.post('/api/settings/uom/add', uomController.addUom)
    app.get('/api/settings/uom/list', uomController.getUomList)
    app.get('/api/settings/uom/view', uomController.getUomById)
    app.post('/api/settings/uom/update', uomController.updateUom)
    app.get('/api/settings/uoms', uomController.listUom)

    /**UOM Groups */
    app.post('/api/settings/uom-group/add', uomController.addUomGroup)
    app.get('/api/settings/uom-group/list', uomController.getUomGroupList)
    app.post('/api/settings/uom-group/update', uomController.updateUomGroup)
    app.post('/api/settings/uom-group/delete', uomController.deleteUomGroup)
    app.post('/api/settings/uom-group/item-delete', uomController.deleteUomGroupItem)
    app.get('/api/settings/uom-group/uom-list', uomController.listUom)
    app.get('/api/settings/uom-groups', uomController.listUomGroup)
    app.get('/api/settings/uom-group-items', uomController.listUomGroupItems)

    /**Item Setup */
    /**Item Types */
    app.post('/api/settings/item-type/add', itemController.addItemType)
    app.post('/api/settings/item-type/update', itemController.updateItemType)
    app.post('/api/settings/item-type/delete', itemController.deleteItemType)
    app.get('/api/settings/item-type/list', itemController.getItemTypeList)

    /**Item Category */
    app.post('/api/settings/item-category/add', itemController.addItemCategory)
    app.post('/api/settings/item-category/update', itemController.updateItemCategory)
    app.post('/api/settings/item-category/delete', itemController.deleteItemCategory)
    app.get('/api/settings/item-category/list', itemController.getItemCategoryList)

    /**Item Group */
    app.post('/api/settings/item-group/add', itemController.addItemGroup)
    app.post('/api/settings/item-group/update', itemController.updateItemGroup)
    app.post('/api/settings/item-group/delete', itemController.deleteItemGroup)
    app.get('/api/settings/item-group/list', itemController.getItemGroupList)
    app.get('/api/settings/itemgroup/dropdown', itemController.getAllitemgroup)
    app.get('/api/settings/itemgtype/dropdown', itemController.findAllitemType)
    app.get('/api/settings/itemgcategory/dropdown', itemController.getAllitemcategory)


    /**Tax Types */
    app.post('/api/settings/tax-type/add', taxController.addTaxType)
    app.post('/api/settings/tax-type/update', taxController.updateTaxType)
    app.post('/api/settings/tax-type/delete', taxController.deleteTaxType)
    app.get('/api/settings/tax-type/list', taxController.getTaxTypeList)
    app.get('/api/settings/tax-types', taxController.taxTypeList)


    /**Tax Combinations */
    app.post('/api/settings/tax-combination/add', taxController.addTaxCombination)
    app.post('/api/settings/tax-combination/update', taxController.updateTaxCombination)
    app.get('/api/settings/tax-combination/list', taxController.getTaxCombinationList)
    app.get('/api/settings/tax-combination/tax-types', taxController.taxTypeList)
    app.post('/api/settings/tax-combination/delete', taxController.deleteTaxCombination)
    app.post('/api/settings/tax-combination-item/delete', taxController.deleteTaxCombinationItem)
    app.get('/api/settings/tax-combination-item/dropdown', taxController.findAllTaxCombination)

    /**Manufacturer */
    app.post('/api/settings/manufacturer/add', manufacturerController.addManufacturer)
    app.post('/api/settings/manufacturer/update', manufacturerController.updateManufacturer)
    app.post('/api/settings/manufacturer/delete', manufacturerController.deleteManufacturer)
    app.get('/api/settings/manufacturer/list', manufacturerController.getManufacturerList)
    app.get('/api/settings/manufacturers', manufacturerController.manufacturerList)


    /**Shipping Type */
    app.post('/api/settings/shipping-type/add', shippingController.addShippingType)
    app.post('/api/settings/shipping-type/update', shippingController.updateShippingType)
    app.get('/api/settings/shipping-type/list', shippingController.getShippingTypeList)
    app.post('/api/settings/shipping-type/delete', shippingController.deleteShippingType)
    app.get('/api/settings/shipping-types', shippingController.shippingTypeList)

    /**Document numbering */
    app.post('/api/settings/document-numbering/add', documentNumberingController.addDocument)
    app.post('/api/settings/document-numbering/update', documentNumberingController.updateDocument)
    app.get('/api/settings/document-numbering/list', documentNumberingController.getDocumentList)
    app.post('/api/settings/document-numbering/delete', documentNumberingController.deleteDoc)

    app.post('/api/settings/document-numbering-series/add', documentNumberingController.addDocumentSeries)
    //app.post('/api/settings/document-numbering-series/update', documentNumberingController.updateDocumentSeries)
    app.get('/api/settings/document-numbering-series/list', documentNumberingController.getDocumentSeriesList)

    /**Test Routes */
    app.post('/api/test/sms', testController.testSms)
    app.post('/api/test/mail', testController.testMail)
    app.post('/api/test/whatsapp-message', testController.sendWhatsappMessage)

    /**Communication */
    /**SMTP */
    app.get('/api/settings/smtp/view', communicationController.findSmtpConfig)
    app.post('/api/settings/smtp/add', communicationController.addSmtpConfig)
    app.post('/api/settings/smtp/update', communicationController.updateSmtpConfig)

    /**Whatsapp */
    app.get('/api/settings/whatsapp/view', communicationController.findWhatsappConfig)
    app.post('/api/settings/whatsapp/add', communicationController.addWhatsappConfig)
    app.post('/api/settings/whatsapp/update', communicationController.updateWhatsappConfig)

    /**SMS */
    app.get('/api/settings/sms/view', communicationController.findSmsConfig)
    app.post('/api/settings/sms/add', communicationController.addSmsConfig)
    app.post('/api/settings/sms/update', communicationController.updateSmsConfig)

    /**Payment Config */
    /**Razorpay */
    app.get('/api/settings/razorpay/view', paymentConfigController.findRazorPayConfig)
    app.post('/api/settings/razorpay/add', paymentConfigController.addRazorPayConfig)
    app.post('/api/settings/razorpay/update', paymentConfigController.updateRazorPayConfig)

    /**Stripe */
    app.get('/api/settings/stripe/view', paymentConfigController.findStripeConfig)
    app.post('/api/settings/stripe/add', paymentConfigController.addStripeConfig)
    app.post('/api/settings/stripe/update', paymentConfigController.updateStripeConfig)

    /**Phonepe */
    app.get('/api/settings/phonepe/view', paymentConfigController.findPhonepeConfig)
    app.post('/api/settings/phonepe/add', paymentConfigController.addPhonepeConfig)
    app.post('/api/settings/phonepe/update', paymentConfigController.updatePhonepeConfig)

    /**Paytm */
    app.get('/api/settings/paytm/view', paymentConfigController.findPaytmConfig)
    app.post('/api/settings/paytm/add', paymentConfigController.addPaytmConfig)
    app.post('/api/settings/paytm/update', paymentConfigController.updatePaytmConfig)

    /**Paytm */
    app.get('/api/settings/pine-labs/view', paymentConfigController.findPineLabsConfig)
    app.post('/api/settings/pine-labs/add', paymentConfigController.addPineLabsonfig)
    app.post('/api/settings/pine-labs/update', paymentConfigController.updatePineLabsConfig)

    /**Print Preferences */
    app.get('/api/settings/print-preference/list', printPreferenceController.printPreferenceList)
    app.post('/api/settings/print-preference/add', printPreferenceController.addPrintPreference)
    app.post('/api/settings/print-preference/update', printPreferenceController.updatePrintPreference)
    app.get('/api/settings/print-preference/current', printPreferenceController.currentPrintPreference)
}