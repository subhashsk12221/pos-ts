import dotenv from 'dotenv';
dotenv.config();
import express, { Request, Response } from 'express';
import bodyParser from 'body-parser'
//import { createTables } from './models/model'
const app = express()
const port = process.env.APP_PORT || 3000;
import cors from 'cors';


//createTables()

app.use(cors());
app.use(bodyParser.json())
app.use((_req: express.Request, res: express.Response, next: express.NextFunction) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

import { routes } from './routes/routes';

routes(app);

app.get('/', async (req: Request, res: Response) => {
    res.status(200).json({ message: "Server working" });
})
export default app;

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
})