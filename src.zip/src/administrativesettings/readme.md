
# Zota POS Administrative Settings

This repository contains the administrative settings for Zota POS.

## Installation

To install the administrative settings, follow these steps:

1. Clone the repository:

    ```bash
    git clone https://github.com/akumar/zota-pos-administivesettings.git
    ```

2. Change to the project directory:

    ```bash
    cd zota-pos-administivesettings
    ```

3. Install the dependencies:

    ```bash
    npm install
    ```

4. Configure the settings:

    Open the `config.js` file and update the necessary settings.

5. Start the application:

    ```bash
    npm start
    ```

## Usage

Once the application is running, you can access the administrative settings by navigating to `http://localhost:3000` in your web browser.

## Contributing

Contributions are welcome! Please follow the guidelines in the [CONTRIBUTING.md](CONTRIBUTING.md) file.

## License

This project is licensed under the [MIT License](LICENSE).