import client from '../util/database';
import { ulid } from 'ulid';
import * as financialLegder from '../service/financialLedgerService'
import * as nextInvoicenumber  from '../service/documentNumberingSeries'
import { generateResponse } from '../util/genRes';
import * as  uomService from '../administrativesettings/src/service/uomService';
import socket from '../sync/syncScript';
import * as fs from 'fs';
function formatDate(date:any) {
    if (!date) return null; // Handle null or undefined dates
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
export async function getNextSaleOrderInvoiceNumber(store_id: any) {
    try {

        const getNextInvoiceNumber = await client.query('SELECT generate_sale_order_invoice_number($1) AS sott_invoice_number', [store_id]);
        return getNextInvoiceNumber

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPurchaseOrder(orderData: any, itemData: any) {
    try {

        await client.query('BEGIN');
        const pot_id = ulid()
        orderData.pot_id = pot_id
        orderData.pot_order_status = 'pending'
        const getNextInvoiceNumber =  await nextInvoicenumber.getPurchaseOrderNextInvoiceNumber()
          
            if (!getNextInvoiceNumber) {
                 throw new Error("Failed to generate next invoice number",);
            }
            
            orderData.pot_invoice_number = getNextInvoiceNumber
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO purchase_order_transaction_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                pot_id: pot_id,
                base_ref_no: Math.floor(Math.random() * 10000000),
                item_to_be_received:item.item_quantity,
                item_invoice_open_quantity:item.item_quantity
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );
            // console.log(itemValuesArray)

            // Flatten the array of values
            // const itemValues = itemValuesArray.flat();

            //            const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //   `(${innerArray.map((value: any) => (typeof value === 'string' || typeof value === 'object') ? `'${value}'` : value).join(', ')})`
            // );
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)




            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO purchase_order_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);
           
            let order = orderResult.rows[0]
            let item = itemResult.rows

            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
    
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function getPurchasesOrderList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.pot_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause
      

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }


    
        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM purchase_order_transaction_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM purchase_order_transaction_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPurchaseitemsList(query: any) {
    try {
console.log(query)
        const { pot_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
            SELECT
                purchase_order_items_list.*
            FROM
                purchase_order_items_list
            WHERE
                purchase_order_items_list.pot_id = $1
        `;
        
        const queryParams = [pot_id];
        
        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND purchase_order_items_list.item_id = $2`;
            queryParams.push(item_id);
        }
        
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);
        

        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function getVendor(query: any) {
    try {
        const { field, value } = query
        console.log(query)
        const getVendorquery = `
    SELECT
        customer_details.*
    FROM
        customer_details
    WHERE
        LEFT(${field}, 4) ILIKE $1 
        AND is_vendor_cmr = 'true';
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [`%${value}%`]);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}


export async function updateOrderData(orderData: any, pot_id: any) {
    try {
        await client.query('BEGIN');
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);
    
        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE purchase_order_transaction_table
        SET ${updateOrderFields}
        WHERE pot_id = $1
        RETURNING *;
      `;

        // Execute the updateSalesOrderQuery and get the result
        const salesOrderResult = await client.query(updateSalesOrderQuery, [pot_id, ...orderValues]);
        return salesOrderResult

    } catch (error) {
        await client.query('ROLLBACK');

        throw new Error(error)
    }
}

export async function existingItemsResult(pot_id: any) {
    try {
        const fetchItemsQuery = `
        SELECT * FROM purchase_order_items_list
        WHERE pot_id = $1;
        `;

        const existingItemsResult = await client.query(fetchItemsQuery, [pot_id])
        return existingItemsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function updatedItem(updatedItem: any, pot_id: any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .filter(([columnName]) => columnName !== 'pot_id' && columnName !== 'item_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE purchase_order_items_list
        SET ${itemFields}
        WHERE pot_id = '${pot_id}' AND item_id = '${updatedItem.item_id}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function removeItem(pot_id: any, item_id: any) {
    try {
        const removeItemQuery = `
DELETE FROM purchase_order_items_list
WHERE pot_id = $1 AND item_id = $2
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [pot_id, item_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function addItem(newItem: any) {
    try {
        newItem.item_to_be_received = newItem.item_quantity
        const columns = Object.keys(newItem);
        const values = Object.values(newItem);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO purchase_order_items_list (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        // Execute the query with parameterized values
        const addItemResult = await client.query(insertQuery, values);
        return addItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function additemBatchNumber(itemBatchData:any, itemData:any, client:any) {

    try {
         console.log(itemBatchData,itemData,"dddddddddddddddddddddddd1111111111ddd")
        for(let itemdata of itemData){
            for(let batch of itemBatchData ){
                if(itemdata.item_id === batch.item_id){
                    batch.item_uom_id = itemdata.item_uom_id
                }
            }
        }
        // const itemColumns = Object.keys(itemBatchData[0]);
        
        // const itemValuesArray = itemBatchData.map((item: any) =>
        //     Object.values(item)
        // );
      
        // const valuesStrings = itemValuesArray.map((innerArray: any) =>
        //     `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
        // );

        // console.log(valuesStrings)


        // const resultString = valuesStrings.join(', ');
     
        // const query = `INSERT INTO items_batch_no_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

        //     const result = await client.query(query);

        await client.query('BEGIN');
        for(let batchData of itemBatchData){


        const  itemData = {
            item_id :batchData.item_id,
            item_sellable_quantity:batchData.item_sellable_quantity,
            item_exp_date :formatDate(batchData.item_exp_date),
            item_batch_number:batchData.item_batch_number

        }

        const itemBinLocationData = {
        item_batch_number :batchData.item_batch_number,
        item_quantity:batchData.item_sellable_quantity,
        item_id:batchData.item_id,
        to_bin_id:batchData.to_bin_id,
        item_rack_location :batchData.to_bin_location 
        }
        console.log(itemBinLocationData,itemData,"ddddddddddddddddddddddddddddddddddd")
        if(batchData.item_uom_id){
       
            const getUomQunatity =   await uomService.getUomGroupOfItems(batchData.item_uom_id)
            if(getUomQunatity.rows.length>0){
                itemBinLocationData.item_quantity = (getUomQunatity.rows[0].base_quantity * batchData.item_sellable_quantity) + (getUomQunatity.rows[0].base_quantity * batchData.item_batch_free_quantity)
            }
              }

        const getbatchNumber = `SELECT * FROM  items_batch_no_table WHERE item_batch_number = $1 AND item_id = $2 `
        const getBatchNumberQueryResult = await client.query(getbatchNumber, [itemData.item_batch_number,itemData.item_id]);
         if(getBatchNumberQueryResult.rows.length>0){
        const   updateQuery = `
        UPDATE items_batch_no_table
        SET item_sellable_quantity = item_sellable_quantity + $1
        WHERE item_batch_number = $2 AND item_id = $3`;
        const updateresult = await client.query(updateQuery, [itemData.item_sellable_quantity,itemData.item_batch_number,itemData.item_id]);
        console.log(itemBinLocationData,itemData,updateQuery)
         }else{

        const columns = Object.keys(itemData);
        const values = Object.values(itemData);

        // Construct the parameterized query
        const insertCustomerQuery = `INSERT INTO items_batch_no_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        
        console.log(itemBinLocationData,itemData,insertCustomerQuery)
        // Execute the query with parameterized values
        const insertCustomerQueryResult = await client.query(insertCustomerQuery, values);

        //checking item_batch_bin_location
      


        // const binlocationcolumns = Object.keys(itemBinLocationData);
        // const binlocartionvalues = Object.values(itemBinLocationData);
       
        //   // Construct the parameterized query
        //   const insertBinQuery = `INSERT INTO store_inventory_item_location_table (${binlocationcolumns.join(', ')}) VALUES (${binlocartionvalues.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        //   console.log(insertBinQuery);
  
        //   // Execute the query with parameterized values
        //   const insertBinQueryResult = await client.query(insertBinQuery, binlocartionvalues);
        // const updateQuery = `
        //             INSERT INTO store_inventory_item_location_table (item_id, item_batch_number, item_rack_location, item_quantity)
        //             VALUES ($1, $2, $3, $4)
        //             ON CONFLICT ON CONSTRAINT unique_item_batch_location
        //              DO UPDATE SET item_quantity = EXCLUDED.item_quantity
        //         `;
        //       console.log(itemBinLocationData.item_id, itemBinLocationData.item_batch_number, itemBinLocationData.item_rack_location, itemBinLocationData.item_quantity)
                
        //           const updateResult = await client.query(updateQuery, [itemBinLocationData.item_id, itemBinLocationData.item_batch_number, itemBinLocationData.item_rack_location, itemBinLocationData.item_quantity]);
        }

        const getBatchBin = 'SELECT * FROM store_inventory_item_location_table WHERE item_id =$1 AND to_bin_id =$2 AND  item_batch_number= $3'

        const insertgetBatchBinQueryResult = await client.query(getBatchBin,[itemBinLocationData.item_id,itemBinLocationData.to_bin_id,itemBinLocationData.item_batch_number]);

        if(insertgetBatchBinQueryResult.rows.length>0){
           console.log(insertgetBatchBinQueryResult.rows,"insertgetBatchBinQueryResult.rows")
           const  updatebatchBinQuery  =  `UPDATE store_inventory_item_location_table
           SET item_quantity = item_quantity + $1 WHERE item_id =$2 AND to_bin_id =$3 AND  item_batch_number= $4 RETURNING *;`;
        
           let updateStatus = await client.query(updatebatchBinQuery, [itemBinLocationData.item_quantity,itemBinLocationData.item_id,itemBinLocationData.to_bin_id,itemBinLocationData.item_batch_number]);
           console.log(updateStatus.rows,"updateStatus.rows",updatebatchBinQuery,itemBinLocationData.item_quantity)
        }else{
            const binlocationcolumns = Object.keys(itemBinLocationData);
       const binlocartionvalues = Object.values(itemBinLocationData);
        const insertBinQuery = `INSERT INTO store_inventory_item_location_table (${binlocationcolumns.join(', ')}) VALUES (${binlocartionvalues.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        const insertBinQueryResult = await client.query(insertBinQuery, binlocartionvalues);
        }


   
    }
   
        
    } catch (error) {
        throw new Error(error)
    }
}

export async function additemToInventory(itemData:any) {
    try {
        
        const itemColumns = Object.keys(itemData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = itemData.map((item: any) =>
                Object.values(item)
            );
            // console.log(itemValuesArray)

            // Flatten the array of values
            // const itemValues = itemValuesArray.flat();

            //            const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //   `(${innerArray.map((value: any) => (typeof value === 'string' || typeof value === 'object') ? `'${value}'` : value).join(', ')})`
            // );
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)




            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `
            INSERT INTO store_inventory_table (${itemColumns.join(', ')})
            VALUES ${resultString}
            ON CONFLICT (item_id) DO UPDATE
            SET ${itemColumns.map((col: string) => `${col} = EXCLUDED.${col}`).join(', ')}
            RETURNING *;
        `;


            console.log(query)
            const itemResult = await client.query(query);
        // Join the arrays to construct the final query string
     
    console.log(query,'dddddddddddddddddddd')
        // Flatten the itemValuesArray to get the parameter values for the query
      //  const queryParams = itemValuesArray.flat();
     
    

        return itemResult;
    } catch (error) {
        throw new Error(error);
    }
}

export async function getPurchaseOrderById(pot_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            purchase_order_items_list.*,
            purchase_order_transaction_table.*
            FROM
            purchase_order_transaction_table
            LEFT JOIN
            purchase_order_items_list ON purchase_order_transaction_table.pot_id = purchase_order_items_list.pot_id
            WHERE
            purchase_order_transaction_table.pot_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [pot_id]);
        if (orderDetailsResult.rows.length > 0) {
            console.log(orderDetailsResult.rows, "ssssss")
            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.pot_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            pot_id: item.pot_id,
                            store_id: item.store_id,
                            cmr_id:item.cmr_id,
                            cmr_phone_number: item.cmr_phone_number,
                            pot_total_gst: item.pot_total_gst,
                            pot_total_discount: item.pot_total_discount,
                            pot_payment_status: item.pot_payment_status,
                            pot_transaction_id: item.pot_transaction_id,
                            pot_order_status: item.pot_order_status,
                            pot_payment_method: item.pot_payment_method,
                            pot_billing_address: item.pot_billing_address,
                            pot_total_amount: item.pot_total_amount,
                            pot_delivery_date: item.pot_delivery_date,
                            pot_document_date: item.pot_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                }

                    acc[key].itemData.push({
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_to_be_received:item.item_to_be_received,
                        item_invoice_open_quantity:item.item_invoice_open_quantity,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_uom:item.item_uom,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_maximum_purchasing:item.item_maximum_purchasing,
                        item_minimun_purchasing:item.item_maximum_purchasing,
                        item_return_availability:item.item_return_availability,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name
                        

                    });
                
                return acc;
            }, {});
            
            

            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);


        return resultArray
        }else{
            return []
        }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getVendorDetails(pot_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
         
            purchase_order_transaction_table.cmr_id,
            purchase_order_transaction_table.cmr_code,
            purchase_order_transaction_table.cmr_name
            FROM
            purchase_order_transaction_table
            WHERE
            purchase_order_transaction_table.pot_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [pot_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}


export async function addGopOrder(orderData: any, itemData: any, itemBatchData:any,client:any) {
    try {
        await client.query('BEGIN');
        const gort_id = ulid()
        orderData.gort_id = gort_id
        orderData.gort_order_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO goods_order_receipt_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                gort_id: gort_id,
                item_to_be_received:item.item_quantity,
                item_return_open_quantity:item.item_quantity
            }));

            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );
            // console.log(itemValuesArray)

            // Flatten the array of values
            // const itemValues = itemValuesArray.flat();

            //            const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //   `(${innerArray.map((value: any) => (typeof value === 'string' || typeof value === 'object') ? `'${value}'` : value).join(', ')})`
            // );
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)


            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO good_order_receipt_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

            // console.log(query)
            const itemResult = await client.query(query);
            if (itemResult.rows.length > 0) {
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    gort_id: gort_id
                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO good_order_receipt_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);

                const updatePurchaseOrder = await updatePurchaseOrderFn(newItemsData)
               
            
        }
            const [generalAccount,salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(),financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

            let  transcation_id =  ulid()
            
     
            const inventory_account_obj = {
                account_id :inventoryGLAccount.rows[0].allocation_account,
                transcation_id: transcation_id,
                debit_amount: 0,
                credit_amount  :orderData.gort_sub_total,
                
            }
    
    
          const  cos_goods_account_obj = {
            account_id :inventoryGLAccount.rows[0].inventory_account,
            transcation_id:transcation_id,
            debit_amount: orderData.gort_sub_total,
            credit_amount  :0,
          
          }
                   
          const journal_entry_obj = {
            transcation_id:transcation_id,
            origin_type :"GOP",
            origin_id :orderData.gort_invoice_number,
            journal_entry_no:Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000
    
          }
          const journal_entry_array = [inventory_account_obj,cos_goods_account_obj]
                await  financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
           
            let order = orderResult.rows
            let item = itemResult.rows

            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
    
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updateGOPItemData(itemData: any) {
    try {

        for (let item of itemData) {

    
            const updateQuery = `
        UPDATE good_order_receipt_items_list
        SET item_to_be_received =item_to_be_received - $1 
        WHERE item_id = $2 AND gort_id = $3;
        `;

            const updateresult = await client.query(updateQuery, [item.item_quantity, item.item_id, item.gort_id]);

            const checkStatusQuery = `SELECT * FROM good_order_receipt_items_list WHERE  gort_id = $1`
            let checkStatusQueryResult = await client.query(checkStatusQuery, [item.gort_id]);

            let gort_order_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                console.log(typeof(checkStatusQueryResult.rows[0].item_to_be_received),"dfffffffffffff",checkStatusQueryResult.rows[0])
                const allDelivered = checkStatusQueryResult.rows.every(item => item.item_to_be_received === 0);
                gort_order_status = allDelivered ? "closed" : "open";
            }

            const updatestatusQuery = `UPDATE goods_order_receipt_table
        SET gort_order_status = $1 WHERE  gort_id = $2`;
            let updateStatus = await client.query(updatestatusQuery, [gort_order_status, item.gort_id]);

        }

    } catch (error) {

        throw new Error(error)
    }



}


export async function updatePurchaseOrderFn(itemData:any){
    try{
        await client.query('BEGIN');


        for (const item of itemData) {
            console.log("sssssss", item)
            let { item_id, pot_id, item_received_quantity,item_quantity,gort_id, poit_id } = item;
            console.log(item_id, pot_id, typeof (item_received_quantity))
             let updateQuery 
             let values = []
                if(pot_id){
            if (item_received_quantity && gort_id  ) {
                updateQuery = "item_to_be_received = item_to_be_received - $1"
                values.push(item_received_quantity)
            }
            if(item_quantity && poit_id){
                updateQuery = "item_to_be_received = item_to_be_received - $1"
                values.push(item_quantity)
            }

            
                const updateResult = `UPDATE purchase_order_items_list SET ${updateQuery} WHERE item_id = $2 AND pot_id = $3;`;
                console.log(updateResult,"updateResult")
                const updateresult = await client.query(updateResult, [...values, item_id, pot_id]);
                console.log(updateresult, "updateresult")
        
                if(poit_id || gort_id){
                    const insertDoccumentlistObj = {
                        pot_id: pot_id,
                        poit_id: poit_id,
                        gort_id :gort_id
                    }
    
                    const insertDataObj = await insertPurhaseOrderDocument(insertDoccumentlistObj)
                

                

                const checkStatusQuery = `SELECT * FROM purchase_order_items_list WHERE  pot_id = $1`
                let checkStatusQueryResult = await client.query(checkStatusQuery, [pot_id]);

                let pot_order_status = "open"; // Default to "open" status

                if (checkStatusQueryResult.rows.length > 0) {
                    console.log(typeof(checkStatusQueryResult.rows[0].item_to_be_received),"dfffffffffffff",checkStatusQueryResult.rows[0])
                    const allDelivered = checkStatusQueryResult.rows.every(item => item.item_to_be_received === 0);
                    pot_order_status = allDelivered ? "closed" : "open";
                }

                const updatestatusQuery = `UPDATE purchase_order_transaction_table
            SET pot_order_status = $1 WHERE  pot_id = $2`;
                let updateStatus = await client.query(updatestatusQuery, [pot_order_status, pot_id]);
            

        }
        }}

        await client.query('COMMIT'); 

    }catch(error){
        await client.query('ROLLBACK');
        throw new Error(error)

    }
}


export async function insertPurhaseOrderDocument(insertObj:any){

    try{
        console.log(insertObj)
        const columns = Object.keys(insertObj);
        const values = Object.values(insertObj);

        // Construct the parameterized query
        const insertdocumentidquery = `INSERT INTO purchase_order_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
         console.log(insertdocumentidquery,"ffffffffffff")
        let insertdocumentidqueryResult = await client.query(insertdocumentidquery,values);

    }catch(error){
        throw new Error(error)
    }

}



export async function updateGop(orderData:any){
    try{
        const {gort_id} = orderData
        orderData.gort_order_status = 'open'
        const columnValuePairs = Object.entries(orderData)
        .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
        .join(', ');
    // Extracting values from the updatedFields object
    const values = Object.values(orderData);

    const query = `
UPDATE goods_order_receipt_table
SET ${columnValuePairs}
WHERE gort_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
    console.log(values)
    const result = await client.query(query, [...values, gort_id]);
    return result
    }catch(error){
        throw new Error(error)
    }

}


export async function insertGOPDocuments(itemData:any){
    
    try{
        for (const item of itemData) {
            let { prt_id, gort_id, poit_id } = item;

            if(gort_id){

            const insertObj = {
                gort_id :gort_id,
                prt_id :prt_id,
                poit_id :poit_id
            }

        console.log(insertObj)
        const columns = Object.keys(insertObj);
        const values = Object.values(insertObj);

        // Construct the parameterized query
        const insertdocumentquery = `INSERT INTO goods_order_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        
        let insertdocumentqueryResult = await client.query(insertdocumentquery,values);
        }
    }

    }catch(error){
        throw new Error(error)
    }
}

export async function getGopOrderList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.gort_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause
      

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }


    
        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM goods_order_receipt_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM goods_order_receipt_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getGopitemsList(query: any) {
    try {
console.log(query)
        const { gort_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
        SELECT
        good_order_receipt_items_list.*,
        good_order_receipt_items_batches_list.*
        FROM
        good_order_receipt_items_list
        JOIN 
        good_order_receipt_items_batches_list ON good_order_receipt_items_list.gort_id = good_order_receipt_items_batches_list.gort_id
        AND good_order_receipt_items_list.item_id = good_order_receipt_items_batches_list.item_id
        WHERE
        good_order_receipt_items_list.gort_id = $1
        `;
        
        const queryParams = [gort_id];
        
        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND good_order_receipt_items_list.item_id = $2`;
            queryParams.push(item_id);
        }
        
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);
        

        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function getGOPitemBatchData(query: any) {
    try {
        console.log(query)
        const { gort_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY_INVOICE = `
        SELECT
            purchase_order_invoice_items_list.*,
            purchase_order_invoice_items_batches_list.*
            FROM
            purchase_order_invoice_items_list
            LEFT JOIN 
            purchase_order_invoice_items_batches_list ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id
            AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
            WHERE
            purchase_order_invoice_items_list.gort_id = $1
      `;

        const queryParamsInvoice = [gort_id];

      

        const inoviceorderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY_INVOICE, queryParamsInvoice);
        let GET_ORDER_DETAILS_QUERY = `
               SELECT
                purchase_return_items_list.*,
                purchase_return_items_batches_list.*
                FROM
                purchase_return_items_list
                JOIN 
                purchase_return_items_batches_list ON purchase_return_items_list.prt_id = purchase_return_items_batches_list.prt_id
                AND  purchase_return_items_list.item_id = purchase_return_items_batches_list.item_id
                WHERE
                purchase_return_items_list.gort_id = $1
    `;

const queryParams = [gort_id];



const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


console.log(inoviceorderDetailsResult.rows, orderDetailsResult.rows, "werwererwertwert")
const invoice = inoviceorderDetailsResult.rows
const returnorder = orderDetailsResult.rows
        return {invoice,  returnorder}

    } catch (error) {
        throw new Error(error)
    }
}

export async function getGopVendorDetails(gort_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
         
            goods_order_receipt_table.cmr_id,
            goods_order_receipt_table.cmr_code,
            goods_order_receipt_table.cmr_name
            FROM
            goods_order_receipt_table
            WHERE
            goods_order_receipt_table.gort_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [gort_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}

export async function getGopOrderById(gort_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            goods_order_receipt_table.*,
            good_order_receipt_items_list.*,
            good_order_receipt_items_batches_list.*
            FROM
            goods_order_receipt_table
            LEFT JOIN
            good_order_receipt_items_list ON goods_order_receipt_table.gort_id = good_order_receipt_items_list.gort_id
            LEFT JOIN 
            good_order_receipt_items_batches_list ON good_order_receipt_items_list.gort_id = good_order_receipt_items_batches_list.gort_id
            AND good_order_receipt_items_list.item_id = good_order_receipt_items_batches_list.item_id
            WHERE
            goods_order_receipt_table.gort_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [gort_id]);
        if (orderDetailsResult.rows.length > 0) {
            console.log(orderDetailsResult.rows, "ssssss")
            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.gort_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            gort_id: item.gort_id,
                            store_id: item.store_id,
                            cmr_id: item.cmr_id,
                            cmr_phone_number: item.cmr_phone_number,
                            remarks: item.remarks,
                            gort_total_gst: item.gort_total_gst,
                            gort_total_discount: item.gort_total_discount,
                            gort_payment_status: item.gort_payment_status,
                            gort_transaction_id: item.gort_transaction_id,
                            gort_order_status: item.gort_order_status,
                            gort_payment_method: item.gort_payment_method,
                            gort_billing_address: item.gort_billing_address,
                            gort_total_amount: item.gort_total_amount,
                            gort_sub_total:item.gort_sub_total,
                            gort_delivery_date: item.gort_delivery_date,
                            gort_document_date: item.gort_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            created_date: item.created_date,
                            update_date: item.update_date,
                            inv_no:item.gort_invoice_number,
                            document_date:item.gort_document_date
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((data: { item_id: any; }) => data.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                        item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                        item_exp_date:formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_tax_amount:item.item_batch_tax_amount,
                        item_batch_tax_percentage:item.item_batch_tax_percentage,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                        to_bin_id :item.to_bin_id,
                        to_bin_location:item.to_bin_location
                    });
                } else {
                    acc[key].itemData.push({
                        gort_id:item.gort_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        pot_id:item.pot_id,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_received_quantity:item.item_received_quantity,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_return_open_quantity:item.item_return_open_quantity,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_to_be_received:item.item_to_be_received,
                        item_total_amount: item.item_total_amount,
                        item_uom:item.item_uom,
                        item_uom_id :item.item_uom_id,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_free_quantity:item.item_free_quantity,
                       item_hsn:item.item_hsn,
                       item_manufacturer_id:item.item_manufacturer_id,
                      item_manufacturer_name:item.item_manufacturer_name,

                        
                       
                        itemBatchData: [
                            {
                                item_id: item.item_id,
                                item_batch_number: item.item_batch_number,
                                item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                                item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                                item_exp_date: formatDate(item.item_exp_date),
                                item_mfg_date: item.item_mfg_date,
                                item_batch_free_quantity:item.item_batch_free_quantity,
                                item_batch_unit_price:item.item_batch_unit_price,
                                item_batch_purchase_rate:item.item_batch_purchase_rate,
                                item_batch_discount_percentage:item.item_batch_discount_percentage,
                                item_batch_discount_amount:item.item_batch_discount_amount,
                                item_batch_tax_amount:item.item_batch_tax_amount,
                                item_batch_tax_percentage:item.item_batch_tax_percentage,
                                item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                                to_bin_id :item.to_bin_id,
                                to_bin_location:item.to_bin_location
                            }
                        ]
                    });
                }

                return acc;
            }, {});



            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            //console.log(resultArray,"ddd", resultArray['orderData'])


    return resultArray
           
        }else {

            return []
        }

    

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPurchaseOrderInvoice(orderData: any, itemData: any ,itemBatchData:any) {
    try {
        await client.query('BEGIN');
        const poit_id = ulid()
        orderData.poit_id = poit_id
        orderData.poit_order_status = 'open'
        orderData.poit_due_amount = orderData.poit_total_amount
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO purchase_order_invoice_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                poit_id: poit_id,
                item_credit_quanity_remaining: item.item_quantity
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)


            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO purchase_order_invoice_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
            
            // console.log(query)
            const itemResult = await client.query(query);
            
            if (itemResult.rows.length > 0) {
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    poit_id: poit_id,
                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO purchase_order_invoice_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
                const revenue_account_obj = {
                    account_id: inventoryGLAccount.rows[0].allocation_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.poit_sub_total,
                    credit_amount: 0,
                }
    
                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.poit_total_gst,
                    credit_amount: 0,
    
                }
    
    
                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.poit_total_amount,
                }
    
    
                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "Purchase IN",
                    origin_id:orderData.poit_invoice_number ,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000
    
                }
                const journal_entry_array = [revenue_account_obj, tax_account_obj, customer_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
    
                const [updateDelivery,updatesaleOrder,DeliveryDocuments] = await Promise.all([updateGOPItemData(newItemsData),updatePurchaseOrderFn(newItemsData),insertGOPDocuments(newItemsData)])
              

                
            }

            let order = orderResult.rows[0]
            let item = itemResult.rows
            await client.query('COMMIT'); 
            return { order, item }
        }
    } catch (error) {

        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updatePurchaseOrderInvoice(orderData:any){
    try{
        const {poit_id} = orderData
        orderData.poit_order_status = 'open'
        const columnValuePairs = Object.entries(orderData)
        .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
        .join(', ');
    // Extracting values from the updatedFields object
    const values = Object.values(orderData);

    const query = `
UPDATE purchase_order_invoice_table
SET ${columnValuePairs}
WHERE poit_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
    console.log(values)
    const result = await client.query(query, [...values, poit_id]);
    return result
    }catch(error){
        throw new Error(error)
    }

}

export async function getPurchaseOrderInvoiceList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.poit_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM purchase_order_invoice_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM purchase_order_invoice_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPurchaseOrderInvoiceById(poit_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            purchase_order_invoice_table.*,
            purchase_order_invoice_items_list.*,
            purchase_order_invoice_items_batches_list.*
            FROM
            purchase_order_invoice_table
            LEFT JOIN
            purchase_order_invoice_items_list ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
            LEFT JOIN 
            purchase_order_invoice_items_batches_list ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id
            AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
            WHERE
            purchase_order_invoice_table.poit_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [poit_id]);

        if (orderDetailsResult.rows.length > 0) {
            console.log(orderDetailsResult.rows, "ssssss")
            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.poit_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            poit_id: item.poit_id,
                            store_id: item.store_id,
                            cmr_id: item.cmr_id,
                            cmr_phone_number: item.cmr_phone_number,
                            remarks: item.remarks,
                            poit_total_gst: item.poit_total_gst,
                            poit_total_discount: item.poit_total_discount,
                            poit_payment_status: item.poit_payment_status,
                            poit_transaction_id: item.poit_transaction_id,
                            poit_order_status: item.poit_order_status,
                            poit_payment_method: item.poit_payment_method,
                            poit_sub_total:item.poit_sub_total,
                            poit_billing_address: item.poit_billing_address,
                            poit_total_amount: item.poit_total_amount,
                            poit_delivery_date: item.poit_delivery_date,
                            poit_document_date: item.poit_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            created_date: item.created_date,
                            update_date: item.update_date,
                            inv_no:item.poit_invoice_number,
                            document_date:item.poit_document_date
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((data: { item_id: any; }) => data.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity: item.item_sellable_quantity,
                        item_non_sellable_quantity: item.item_non_sellable_quantity,
                        item_exp_date:formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_quantity :item.item_batch_quantity,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_tax_amount:item.item_batch_tax_amount,
                        item_batch_tax_percentage:item.item_batch_tax_percentage,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                        to_bin_id :item.to_bin_id,
                        to_bin_location:item.to_bin_location
                    });
                } else {
                    acc[key].itemData.push({
                        item_id: item.item_id,
                        item_code: item.item_code,
                        gort_id:item.gort_id,
                        pot_id:item.pot_id,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_credit_quanity_remaining:item.item_credit_quanity_remaining,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_uom:item.item_uom,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_free_quantity:item.item_free_quantity,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,

                        itemBatchData: [
                            {
                                item_id: item.item_id,
                                item_batch_number: item.item_batch_number,
                                item_sellable_quantity: item.item_sellable_quantity,
                                item_non_sellable_quantity: item.item_non_sellable_quantity,
                                item_exp_date:formatDate(item.item_exp_date),
                                item_mfg_date: item.item_mfg_date,
                                item_batch_quantity :item.item_batch_quantity,
                                item_batch_free_quantity:item.item_batch_free_quantity,
                                item_batch_unit_price:item.item_batch_unit_price,
                                item_batch_purchase_rate:item.item_batch_purchase_rate,
                                item_batch_discount_percentage:item.item_batch_discount_percentage,
                                item_batch_discount_amount:item.item_batch_discount_amount,
                                item_batch_tax_amount:item.item_batch_tax_amount,
                                item_batch_tax_percentage:item.item_batch_tax_percentage,
                                item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                                to_bin_id :item.to_bin_id,
                                to_bin_location:item.to_bin_location
                            }
                        ]
                    });
                }
                
                return acc;
            }, {});



            const resultArray: any = Object.values(groupedItems);


            return resultArray;
        }else {
            return []
        }

   

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPurchaseOrderInvoiceitemsList(query: any) {
    try {
        console.log(query)
        const { poit_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
                SELECT
                purchase_order_invoice_items_list.*,
                purchase_order_invoice_items_batches_list.*
                FROM
                purchase_order_invoice_items_list
                JOIN 
                purchase_order_invoice_items_batches_list ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id
                AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
                WHERE
                purchase_order_invoice_items_list.poit_id = $1
            `;

        const queryParams = [poit_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND purchase_order_invoice_items_list.item_id = $2`;
            queryParams.push(item_id);
        }

        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function getReturnInvoiceitemBatchData(query: any) {
    try {
        console.log(query)
        const { poit_id, item_id } = query;

        let GET_ORDER_DETAILS_QUERY = `
        SELECT

            purchase_credit_items_list_table.*,
            purchase_credit_items_batches_list.*
            FROM
            purchase_credit_items_list_table
            LEFT JOIN 
            purchase_credit_items_batches_list ON purchase_credit_items_list_table.pct_id = purchase_credit_items_batches_list.pct_id
            AND  purchase_credit_items_list_table.item_id = purchase_credit_items_batches_list.item_id
            WHERE
            purchase_credit_items_list_table.poit_id = $1
    `;

const queryParams = [poit_id];

if (item_id) {
    GET_ORDER_DETAILS_QUERY += ` AND purchase_credit_items_list_table.item_id = $2`;
    queryParams.push(item_id);
}

const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);

const returnorder = orderDetailsResult.rows
        return { returnorder}

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPurchaseInvoiceVendorDetails(poit_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            purchase_order_invoice_table.cmr_id,
            purchase_order_invoice_table.cmr_code,
            purchase_order_invoice_table.cmr_name
            FROM
            purchase_order_invoice_table
            WHERE
            purchase_order_invoice_table.poit_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [poit_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPurchaseReturnInvoice(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');
        const prt_id = ulid()
        orderData.prt_id = prt_id
        orderData.prt_order_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO purchase_return_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                item_credit_quanity_remaining:item.item_quantity,
                prt_id: prt_id
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO purchase_return_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemListResult = await client.query(query);



            if (itemListResult.rows.length > 0) {
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    prt_id: prt_id
                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO purchase_return_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);

                console.log(orderData, newItemsData)

                let order = orderResult.rows[0]
                let item = itemListResult.rows
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
             

            
                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.srt_total_amount,
                }


                const inventory_account_obj = {
                    account_id: inventoryGLAccount.rows[0].inventory_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.prt_sub_total,

                }


                const cos_goods_account_obj = {
                    account_id: inventoryGLAccount.rows[0].allocation_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.prt_sub_total,
                    credit_amount: 0,

                }

                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "purchase return",
                    origin_id:orderData.prt_invoice_number ,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [inventory_account_obj, cos_goods_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
          
                const updateDevliveryOrder = await Promise.all([updateGOPData(newItemsData), insertGOPDocuments(newItemsData)])
                updatepurhcaheReturn(itemBatchData,itemData,client)
                await client.query('COMMIT'); 

                return { order, item }
            }
        }
    } catch (error) {
        console.log(error)
await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updatePurchaseReturnInvoice(orderData:any){
    try{
        const {prt_id} = orderData
        const columnValuePairs = Object.entries(orderData)
        .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
        .join(', ');
    // Extracting values from the updatedFields object
    const values = Object.values(orderData);

    const query = `
UPDATE purchase_return_table
SET ${columnValuePairs}
WHERE prt_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
    console.log(values)
    const result = await client.query(query, [...values, prt_id]);
    return result
    }catch(error){
        throw new Error(error)
    }

}


export async function getPurchaseReturnitemsList(query: any) {
    try {
        console.log(query)
        const { prt_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
                SELECT
                purchase_return_items_list.*,
                purchase_return_items_batches_list.*
                FROM
                purchase_return_items_list
                JOIN 
                purchase_return_items_batches_list ON purchase_return_items_list.prt_id = purchase_return_items_batches_list.prt_id
                AND  purchase_return_items_list.item_id = purchase_return_items_batches_list.item_id
                WHERE
                purchase_return_items_list.prt_id = $1
            `;

        const queryParams = [prt_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND purchase_return_items_list.item_id = $2`;
            queryParams.push(item_id);
        }

        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function getReturnitemBatchData(query: any) {
    try {
        console.log(query)
        const { prt_id, item_id } = query;

        let GET_ORDER_DETAILS_QUERY = `
        SELECT

            purchase_credit_items_list_table.*,
            purchase_credit_items_batches_list.*
            FROM
            purchase_credit_items_list_table
            LEFT JOIN 
            purchase_credit_items_batches_list ON purchase_credit_items_list_table.pct_id = purchase_credit_items_batches_list.pct_id
            AND  purchase_credit_items_list_table.item_id = purchase_credit_items_batches_list.item_id
            WHERE
            purchase_credit_items_list_table.prt_id = $1
    `;

const queryParams = [prt_id];

if (item_id) {
    GET_ORDER_DETAILS_QUERY += ` AND purchase_credit_items_list_table.item_id = $2`;
    queryParams.push(item_id);
}

const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);

const returnorder = orderDetailsResult.rows
        return { returnorder}

    } catch (error) {
        throw new Error(error)
    }
}


export async function getPurchaseReturnInvoiceList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.prt_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM purchase_return_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM purchase_return_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPurchaseReturnInvoiceById(prt_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            purchase_return_table.*,
            purchase_return_items_list.*,
            purchase_return_items_batches_list.*
            FROM
            purchase_return_table
            LEFT JOIN
            purchase_return_items_list ON purchase_return_table.prt_id = purchase_return_items_list.prt_id
            JOIN 
            purchase_return_items_batches_list ON purchase_return_items_list.prt_id = purchase_return_items_batches_list.prt_id
            AND  purchase_return_items_list.item_id = purchase_return_items_batches_list.item_id
            WHERE
            purchase_return_table.prt_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [prt_id]);
        if (orderDetailsResult.rows.length > 0) {
            console.log(orderDetailsResult.rows, "ssssss")
            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.prt_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            prt_id: item.prt_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            remarks: item.remarks,
                             prt_total_gst: item. prt_total_gst,
                             prt_total_discount: item. prt_total_discount,
                             prt_payment_status: item. prt_payment_status,
                             prt_transaction_id: item. prt_transaction_id,
                             prt_order_status: item. prt_order_status,
                             prt_payment_method: item. prt_payment_method,
                             prt_billing_address: item. prt_billing_address,
                             prt_total_amount: item. prt_total_amount,
                             prt_sub_total:item.prt_sub_total,
                             prt_delivery_date: item. prt_delivery_date,
                             prt_document_date: item. prt_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((data: { item_id: any; }) => data.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity: item.item_sellable_quantity,
                        item_non_sellable_quantity: item.item_non_sellable_quantity,
                        item_exp_date:formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_quantity :item.item_batch_quantity,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                                item_batch_discount_amount:item.item_batch_discount_amount,
                                item_batch_tax_amount:item.item_batch_tax_amount,
                                item_batch_tax_percentage:item.item_batch_tax_percentage,
                                item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                                to_bin_id :item.to_bin_id,
                                to_bin_location:item.to_bin_location
                        
                    });
                } else {
                    acc[key].itemData.push({
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        gort_id:item.gort_id,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_uom:item.item_uom,
                        item_credit_quanity_remaining:item.item_credit_quanity_remaining,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_free_quantity:item.item_free_quantity,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,

                        itemBatchData: [
                            {
                                item_id: item.item_id,
                                item_batch_number: item.item_batch_number,
                                item_sellable_quantity: item.item_sellable_quantity,
                                item_non_sellable_quantity: item.item_non_sellable_quantity,
                                item_exp_date:formatDate(item.item_exp_date),
                                item_mfg_date: item.item_mfg_date,
                                item_batch_quantity :item.item_batch_quantity,
                                item_batch_free_quantity:item.item_batch_free_quantity,
                                item_batch_unit_price:item.item_batch_unit_price,
                                item_batch_purchase_rate:item.item_batch_purchase_rate,
                                item_batch_discount_percentage:item.item_batch_discount_percentage,
                                item_batch_discount_amount:item.item_batch_discount_amount,
                                item_batch_tax_amount:item.item_batch_tax_amount,
                                item_batch_tax_percentage:item.item_batch_tax_percentage,
                                item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                                to_bin_id :item.to_bin_id,
                                to_bin_location:item.to_bin_location
                            }
                        ]
                    });
                }

                return acc;
            }, {});



            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            //console.log(resultArray,"ddd", resultArray['orderData'])



            return resultArray;
        } else {
            return [];
        }


    } catch (error) {
        throw new Error(error)
    }
}


export async function getPurchaseReturnVendorDetails(prt_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
         
            purchase_return_table.cmr_id,
            purchase_return_table.cmr_code,
            purchase_return_table.cmr_name
            FROM
            purchase_return_table
            WHERE
            purchase_return_table.prt_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [prt_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}


export async function addPurchaseCreditNote(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');
        const pct_id = ulid()
        orderData.pct_id = pct_id
        orderData.pct_order_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO purchase_credit_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                pct_id: pct_id
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const itemquery = `INSERT INTO purchase_credit_items_list_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(itemquery);

            console.log(itemquery,"itemquery")

            if (itemResult.rows.length > 0) {
                console.log(itemBatchData)
                if(itemBatchData.length>0){
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    pct_id: pct_id
                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const addbatchuery = `INSERT INTO purchase_credit_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
                console.log(addbatchuery,"addbatchuery")
                const itemResult = await client.query(addbatchuery);
            }
                
            
                
                let order = orderResult.rows[0]
                let item = itemResult.rows
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
           

                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount:0 ,
                    credit_amount: orderData.pct_total_gst,

                }



                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: orderData.pct_total_amount,
                    credit_amount:0 ,
                }


                const inventory_account_obj = {
                    account_id: inventoryGLAccount.rows[0].inventory_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.pct_sub_total,

                }



                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "purchase credit note ",
                    origin_id: orderData.pct_invoice_number,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [inventory_account_obj,customer_account_obj,tax_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
                const updateInvoice = await Promise.all([updatePurchaseInvoicefn(newItemsData),updatePurchaseReturnfn(newItemsData)])
                await client.query('COMMIT'); 
                return { order, item }
            }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updatePurchaseInvoicefn(newItemsData: any){
    try{
       await client.query('BEGIN');

       for (const item of newItemsData) {
        console.log("sssssss", item)
        let { item_id, poit_id, item_quantity,pct_id } = item;
        console.log(item_id, poit_id, typeof (item_quantity))

        if (poit_id) {

            const inserDocumentObj ={
                poit_id:poit_id,
                pct_id:pct_id
            }
            const updateQuery = `
UPDATE purchase_order_invoice_items_list
SET item_credit_quanity_remaining = item_credit_quanity_remaining - $1
WHERE item_id = $2 AND poit_id = $3;
`;


 const [updateresult,inserDocumentObjResult] = await Promise.all([client.query(updateQuery, [item_quantity, item_id, poit_id]),insertPurchaseInvoiceDocument(inserDocumentObj)])
 const checkStatusQuery = `SELECT * FROM purchase_order_invoice_items_list WHERE  poit_id = $1`
 let checkStatusQueryResult = await client.query(checkStatusQuery, [poit_id]);

 let poit_order_status = "open"; // Default to "open" status

 if (checkStatusQueryResult.rows.length > 0) {
     console.log(typeof(checkStatusQueryResult.rows[0].item_credit_quanity_remaining),"dfffffffffffff",checkStatusQueryResult.rows[0])
     const allDelivered = checkStatusQueryResult.rows.every(item => item.item_credit_quanity_remaining === 0);
     poit_order_status = allDelivered ? "closed" : "open";
 }

 const updatestatusQuery = `UPDATE purchase_order_invoice_table
SET poit_order_status = $1 WHERE  poit_id = $2`;
 let updateStatus = await client.query(updatestatusQuery, [poit_order_status, poit_id]);

        }
       await client.query('COMMIT')
    }
    await client.query('COMMIT')
}catch(error){
       await client.query('ROLLBACK');
       throw new Error(error)
    }
}

export async function insertPurchaseInvoiceDocument(insertObj:any){

    try{
        
        console.log(insertObj)
        const columns = Object.keys(insertObj);
        const values = Object.values(insertObj);

        // Construct the parameterized query
        const insertdocumentidquery = `INSERT INTO purchase_order_invoice_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
         console.log(insertdocumentidquery,"ffffffffffff")
        let insertdocumentidqueryResult = await client.query(insertdocumentidquery,values);
        return insertdocumentidqueryResult

    }catch(error){
        throw new Error(error)
    }

}

export async function updatePurchaseCreditNote(orderData:any){
    try{
        const {pct_id} = orderData
        const columnValuePairs = Object.entries(orderData)
        .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
        .join(', ');
    // Extracting values from the updatedFields object
    const values = Object.values(orderData);

    const query = `
UPDATE purchase_credit_table
SET ${columnValuePairs}
WHERE pct_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
    console.log(values)
    const result = await client.query(query, [...values, pct_id]);
    return result
    }catch(error){
        throw new Error(error)
    }

}

export async function getPurchaseCreditNoteList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.pct_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM purchase_credit_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM purchase_credit_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getPurchaseCreditNoteById(pct_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            purchase_credit_table.*,
            purchase_credit_items_list_table.*,
            purchase_credit_items_batches_list.*
            FROM
            purchase_credit_table
            LEFT JOIN
            purchase_credit_items_list_table ON purchase_credit_table.pct_id = purchase_credit_items_list_table.pct_id
            LEFT JOIN 
            purchase_credit_items_batches_list ON purchase_credit_items_list_table.pct_id = purchase_credit_items_batches_list.pct_id
            AND  purchase_credit_items_list_table.item_id = purchase_credit_items_batches_list.item_id
            WHERE
            purchase_credit_table.pct_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [pct_id]);
        if (orderDetailsResult.rows.length > 0) {
            console.log(orderDetailsResult.rows, "ssssss")
            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.pct_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            pct_id: item.pct_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            remarks: item.remarks,
                            pct_total_gst: item.pct_total_gst,
                            pct_total_discount: item.pct_total_discount,
                            pct_payment_status: item.pct_payment_status,
                            pct_transaction_id: item.pct_transaction_id,
                            pct_order_status: item.pct_order_status,
                            pct_payment_method: item.pct_payment_method,
                            pct_billing_address: item.pct_billing_address,
                            pct_total_amount: item.pct_total_amount,
                            pct_sub_total:item.pct_sub_total,
                            pct_delivery_date: item.pct_delivery_date,
                            pct_document_date: item.pct_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((data: { item_id: any; }) => data.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity: item.item_sellable_quantity,
                        item_non_sellable_quantity: item.item_non_sellable_quantity,
                        item_exp_date:formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_quantity :item.item_batch_quantity,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                                item_batch_discount_amount:item.item_batch_discount_amount,
                                item_batch_tax_amount:item.item_batch_tax_amount,
                                item_batch_tax_percentage:item.item_batch_tax_percentage,
                                item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                                to_bin_id :item.to_bin_id,
                                to_bin_location:item.to_bin_location
                    });
                } else {
                    acc[key].itemData.push({
                        item_id: item.item_id,
                        poit_id:item.poit_id,
                        prt_id:item.prt_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_uom:item.item_uom,
                        item_free_quantity:item.item_free_quantity,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,

                        itemBatchData: [
                            {
                                item_id: item.item_id,
                                item_batch_number: item.item_batch_number,
                                item_sellable_quantity: item.item_sellable_quantity,
                                item_non_sellable_quantity: item.item_non_sellable_quantity,
                                item_exp_date:formatDate(item.item_exp_date),
                                item_mfg_date: item.item_mfg_date,
                                item_batch_quantity :item.item_batch_quantity,
                                item_batch_free_quantity:item.item_batch_free_quantity,
                                item_batch_unit_price:item.item_batch_unit_price,
                                item_batch_purchase_rate:item.item_batch_purchase_rate,
                                item_batch_discount_percentage:item.item_batch_discount_percentage,
                                item_batch_discount_amount:item.item_batch_discount_amount,
                                item_batch_tax_amount:item.item_batch_tax_amount,
                                item_batch_tax_percentage:item.item_batch_tax_percentage,
                                item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                                to_bin_id :item.to_bin_id,
                                to_bin_location:item.to_bin_location
                            }
                        ]
                    });
                }

                return acc;
            }, {});
            



            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            //console.log(resultArray,"ddd", resultArray['orderData'])
            const dataToWrite = JSON.stringify(resultArray, null, 2); // Pretty print with 2 spaces




            return resultArray;
        }
        else {
            return []
        }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getdocumentsListofPurchaseOrder(pot_id:any){
    try{

        const query = `
        SELECT purchase_order_document_list.*,goods_order_receipt_table.gort_invoice_number,purchase_order_invoice_table.poit_invoice_number
        FROM
        purchase_order_document_list
        LEFT JOIN 
        goods_order_receipt_table ON  purchase_order_document_list.gort_id = goods_order_receipt_table.gort_id
        LEFT JOIN 
        purchase_order_invoice_table ON  purchase_order_document_list.poit_id = purchase_order_invoice_table.poit_id
        WHERE
        purchase_order_document_list.pot_id = $1;`;

          const result = await client.query(query, [pot_id]);
          return result

    }catch(error){
              throw new Error(error)
    }
}

export async function insertCancelPurchaseOrder(orderData: any, itemData: any) {
    try {

        const pot_id = ulid()
        orderData.pot_id = pot_id
        orderData.pot_order_status = 'cancelled'
       
        orderData.pot_invoice_number = await nextInvoicenumber.getPurchaseOrderNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO purchase_order_transaction_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;
            
                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });
            
                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    pot_id: pot_id
                
                };
            });
        
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );
            // console.log(itemValuesArray)

            // Flatten the array of values
            // const itemValues = itemValuesArray.flat();

            //            const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //   `(${innerArray.map((value: any) => (typeof value === 'string' || typeof value === 'object') ? `'${value}'` : value).join(', ')})`
            // );
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)




            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO purchase_order_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);
           
            let order = orderResult.rows[0]
            let item = itemResult.rows

            return { order, item }
        }
    } catch (error) {
    console.log(error)
        throw new Error(error)
    }
}

export async function updatePurchaseOrderStatus(pot_order_status: any, pot_id: any) {
    try {
        const updatestatusQuery = `UPDATE purchase_order_transaction_table
                    SET pot_order_status = $1 WHERE  pot_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [pot_order_status, pot_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function getdocumentsListGOP(gort_id:any){
    try{

        const query = `
        SELECT goods_order_document_list.*,purchase_order_invoice_table.poit_invoice_number,purchase_return_table.prt_invoice_number
        FROM
        goods_order_document_list
        LEFT JOIN 
        purchase_order_invoice_table ON  goods_order_document_list.poit_id = purchase_order_invoice_table.poit_id
        LEFT JOIN 
        purchase_return_table ON  goods_order_document_list.prt_id = purchase_return_table.prt_id
        WHERE
        goods_order_document_list.gort_id = $1;`;

          const result = await client.query(query, [gort_id]);
          return result

    }catch(error){
              throw new Error(error)
    }
}


export async function insertCancelGopOrder(orderData: any, itemData: any) {
    try {
        await client.query('BEGIN');
        const gort_id = ulid()
        orderData.gort_id = gort_id
        orderData.gort_order_status = 'cancelled'
     
        orderData.gort_invoice_number = await nextInvoicenumber.getGORNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO goods_order_receipt_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;
            
                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });
            
                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    gort_id: gort_id,
                
                };
            });
           
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );
            // console.log(itemValuesArray)

            // Flatten the array of values
            // const itemValues = itemValuesArray.flat();

            //            const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //   `(${innerArray.map((value: any) => (typeof value === 'string' || typeof value === 'object') ? `'${value}'` : value).join(', ')})`
            // );
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)


            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO good_order_receipt_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

            const extractedBatchData :any= []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array
                
                if (Array.isArray(item.itemBatchData)) {
                  // Push each itemBatchData object into the extractedBatchData array
                  item.itemBatchData.forEach(batchData => {
                    extractedBatchData.push(batchData);
                  });
                }
              });
           
            // console.log(query)
            const itemResult = await client.query(query);
            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };

                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        item_exp_date: formatDateString(item.item_exp_date),
                        item_mfg_date: formatDateString(item.item_mfg_date),
                        gort_id: gort_id
                    };
                });
                
                const newbBatchItemsData = extractedBatchData.map((item: any) => ({
                    ...item,
                    item_exp_date: formatDateString(item.item_exp_date),
                    item_mfg_date: formatDateString(item.item_mfg_date),

                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings,itemColumns,"eeeeeeeeeeeeeeeeee")

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO good_order_receipt_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);
                if(itemResult.rows.length>0){
                    const updatePurchaseOrder = await updateStoreInventor(newbBatchItemsData)
               
            }
        }
            const [generalAccount,salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(),financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

            let  transcation_id =  ulid()
            
     
            const inventory_account_obj = {
                account_id :inventoryGLAccount.rows[0].allocation_account,
                transcation_id: transcation_id,
                debit_amount: orderData.gort_sub_total,
                credit_amount  :0,
                
            }
    
    
          const  cos_goods_account_obj = {
            account_id :inventoryGLAccount.rows[0].inventory_account,
            transcation_id:transcation_id,
            debit_amount:0,
            credit_amount  : orderData.gort_sub_total,
          
          }
                   
          const journal_entry_obj = {
            transcation_id:transcation_id,
            origin_type :"GOP",
            origin_id :orderData.gort_invoice_number,
            journal_entry_no:Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000
    
          }
          const journal_entry_array = [inventory_account_obj,cos_goods_account_obj]
                await  financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
           
            let order = orderResult.rows[0]
            let item = itemResult.rows
            await client.query('COMMIT'); 
            return { order, item }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}


export async function updateStoreInventor(itemBatchData:any) {
    try{

    for (const item of itemBatchData) {
        
        console.log("sssssss", item)
        const { item_id, item_sellable_quantity, item_batch_quantity } = item;
        console.log(item_id, item_sellable_quantity, typeof (item_batch_quantity))
       
   let  updateQuery = `UPDATE items_batch_no_table
    SET item_sellable_quantity = item_sellable_quantity + $1
    WHERE item_id = $2 AND item_batch_number = $3;
    `;
 
                const updateresult = await client.query(updateQuery, [item_batch_quantity, item_id, item_sellable_quantity]);
                console.log("Update result:", updateresult);
        
                

    }
}catch(error){
    throw new Error(error)
}
}


export async function updateGOPOrderStatus(gort_order_status: any, gort_id: any) {
    try {
        const updatestatusQuery = `UPDATE goods_order_receipt_table
                    SET gort_order_status = $1 WHERE  gort_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [gort_order_status, gort_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}



export async function deleteGOPDocumentlist(gort_id: any) {
    try {
        const updatestatusQuery = `DELETE FROM purchase_order_document_list  WHERE purchase_order_document_list.gort_id =$1`;
        let updateStatus = await client.query(updatestatusQuery, [gort_id]);
        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}


export async function cancelPurchaseOrderInvoice(orderData: any, itemData: any ) {
    try {
        await client.query('BEGIN');
        const poit_id = ulid()
        orderData.poit_id = poit_id
        orderData.poit_order_status = 'cancelled'
    
        orderData.poit_invoice_number =  await nextInvoicenumber.getPurchaseInvoiceNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO purchase_order_invoice_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;
            
                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });
            
                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    poit_id: poit_id,
                
                };
            });

           
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)


            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO purchase_order_invoice_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
            
            // console.log(query)
            const itemResult = await client.query(query);
            const extractedBatchData :any= []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array
                
                if (Array.isArray(item.itemBatchData)) {
                  // Push each itemBatchData object into the extractedBatchData array
                  item.itemBatchData.forEach(batchData => {
                    extractedBatchData.push(batchData);
                  });
                }
              });
           
            
            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };
                
                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        item_exp_date: formatDateString(item.item_exp_date),
                        item_mfg_date: formatDateString(item.item_mfg_date),
                        poit_id: poit_id,
                    };
                });
            
              
                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO purchase_order_invoice_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
                const revenue_account_obj = {
                    account_id: inventoryGLAccount.rows[0].allocation_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.poit_sub_total,
                }
    
                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.poit_total_gst,
    
                }
    
    
                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: orderData.poit_total_amount,
                    credit_amount:0,
                }
    
    
                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "Purchase IN",
                    origin_id: orderData.poit_invoice_number,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000
    
                }
                const journal_entry_array = [revenue_account_obj, tax_account_obj, customer_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
    
            
              

                
            }

            let order = orderResult.rows[0]
            let item = itemResult.rows

            await client.query('COMMIT'); 
            return { order, item }
        }
    } catch (error) {

        await client.query('ROLLBACK');
        throw new Error(error)
    }
}


export async function getdocumentsListofPurchaseInvoice(poit_id:any){
    try{

        const query = `
        SELECT purchase_order_invoice_document_list.*,purchase_credit_table.pct_invoice_number
        FROM
        purchase_order_invoice_document_list
        LEFT JOIN 
        purchase_credit_table ON  purchase_order_invoice_document_list.pct_id = purchase_credit_table.pct_id
        WHERE
        purchase_order_invoice_document_list.poit_id = $1;`;
console.log(poit_id)
          const result = await client.query(query, [poit_id]);
          return result

    }catch(error){
              throw new Error(error)
    }
}


export async function updateInvoiceOrderStatus(poit_order_status: any, poit_id: any) {
    try {
        const updatestatusQuery = `UPDATE purchase_order_invoice_table
                    SET poit_order_status = $1 WHERE  poit_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [poit_order_status, poit_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}



export async function deleteInvoiceDocumentlist(poit_id: any) {
    try {
        const deleteFromSaleOrderDocumentQuery = `DELETE FROM goods_order_document_list  WHERE goods_order_document_list.poit_id =$1`;
        const deleteFromDeliveryDocumentOuery = `DELETE FROM purchase_order_document_list  WHERE purchase_order_document_list.poit_id =$1`;
        
    const results =  await Promise.all([client.query(deleteFromSaleOrderDocumentQuery, [poit_id]),client.query(deleteFromDeliveryDocumentOuery, [poit_id])])
        return results
    } catch (error) {
        throw new Error(error)
    }

}


export async function insertCancelCreditNote(orderData: any, itemData: any, ) {
    try {

        const pct_id = ulid()
        orderData.pct_id = pct_id
        orderData.pct_order_status = 'cancelled'
        orderData.pct_invoice_number =  await nextInvoicenumber.getPurchaseCreditNoteNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO purchase_credit_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;
            
                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });
            
                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    pct_id: pct_id
                
                };
            });
           
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const itemquery = `INSERT INTO purchase_credit_items_list_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(itemquery);
            const extractedBatchData :any= []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array
                
                if (Array.isArray(item.itemBatchData)) {
                  // Push each itemBatchData object into the extractedBatchData array
                  item.itemBatchData.forEach(batchData => {
                    extractedBatchData.push(batchData);
                  });
                }
              });

            console.log(itemquery,"itemquery")

            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };

                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        item_exp_date: formatDateString(item.item_exp_date),
                        item_mfg_date: formatDateString(item.item_mfg_date),
                        pct_id: pct_id
                    };
                });
                
            
              
                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const addbatchuery = `INSERT INTO purchase_credit_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
                console.log(addbatchuery,"addbatchuery")
                const itemResult = await client.query(addbatchuery);
            }
                

                
                let order = orderResult.rows[0]
                let item = itemResult.rows
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
           

                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount:orderData.pct_total_gst,
                    credit_amount: 0,

                }



                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount:orderData.pct_total_amount,
                }


                const inventory_account_obj = {
                    account_id: inventoryGLAccount.rows[0].inventory_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.pct_sub_total,
                    credit_amount: 0,

                }



                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "purchase credit note ",
                    origin_id: orderData.pct_invoice_number,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [inventory_account_obj,customer_account_obj,tax_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)

                return { order, item }
            }
        } catch (error) {

        throw new Error(error)
    }
}

export async function deleteCreditNoteDocumentlist(pct_id: any) {
    try {
        const updatestatusQuery = `DELETE FROM purchase_order_invoice_document_list  WHERE purchase_order_invoice_document_list.pct_id =$1`;
        const deleteFromReturnDocument =  `DELETE FROM purchase_return_document_list  WHERE purchase_return_document_list.pct_id =$1`;
        let updateStatus = await Promise.all([client.query(updatestatusQuery, [pct_id]),client.query(deleteFromReturnDocument, [pct_id])])
        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function updateCreditNoteStatus(pct_order_status: any, pct_id: any) {
    try {
        const updatestatusQuery = `UPDATE purchase_credit_table
                    SET pct_order_status = $1 WHERE  pct_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [pct_order_status, pct_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function updatePurchaseReturnfn(newItemsData: any) {
    try {
        await client.query('BEGIN');

        for (const item of newItemsData) {
            console.log("sssssss", item)

            let { item_id, prt_id, item_quantity, pct_id } = item;
            console.log(item_id, prt_id, typeof (item_quantity))

            if (prt_id) {
                const inserDocumentObj = {
                    prt_id: prt_id,
                    pct_id: pct_id
                }
                const updateQuery = `
UPDATE purchase_return_items_list
SET item_credit_quanity_remaining = item_credit_quanity_remaining - $1
WHERE item_id = $2 AND prt_id = $3;
`;


                const [updateresult, inserDocumentObjResult] = await Promise.all([client.query(updateQuery, [item_quantity, item_id, prt_id]), insertPurchaseReturnDocument(inserDocumentObj)])
                const checkStatusQuery = `SELECT * FROM purchase_return_items_list WHERE  prt_id = $1`
 let checkStatusQueryResult = await client.query(checkStatusQuery, [prt_id]);

 let prt_order_status = "open"; // Default to "open" status

 if (checkStatusQueryResult.rows.length > 0) {
     console.log(typeof(checkStatusQueryResult.rows[0].item_credit_quanity_remaining),"dfffffffffffff",checkStatusQueryResult.rows[0])
     const allDelivered = checkStatusQueryResult.rows.every(item => item.item_credit_quanity_remaining === 0);
     prt_order_status = allDelivered ? "closed" : "open";
 }

 const updatestatusQuery = `UPDATE purchase_return_table
SET prt_order_status = $1 WHERE  prt_id = $2`;
 let updateStatus = await client.query(updatestatusQuery, [prt_order_status, prt_id]);
            }


        }
        await client.query('COMMIT')
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function insertPurchaseReturnDocument(insertObj: any) {

    try {

        console.log(insertObj)
        const columns = Object.keys(insertObj);
        const values = Object.values(insertObj);

        // Construct the parameterized query
        const insertdocumentidquery = `INSERT INTO purchase_return_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        console.log(insertdocumentidquery, "ffffffffffff")
        let insertdocumentidqueryResult = await client.query(insertdocumentidquery, values);
        return insertdocumentidqueryResult

    } catch (error) {
        throw new Error(error)
    }

}

export async function updateGOPData(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery
            const { gort_id, item_quantity, item_id, poit_id, prt_id } = item

            if (gort_id && poit_id) {
                console.log(gort_id, item_quantity, item_id, poit_id, prt_id,"ertertrtrtrt")
                updateQuery = `
        UPDATE good_order_receipt_items_list
        SET item_to_be_received =item_to_be_received - $1
        WHERE item_id = $2 AND gort_id = $3;
        `;
            }
            if (gort_id && prt_id) {
                console.log(gort_id, item_quantity, item_id, poit_id, prt_id,"wwerertertrer")
                updateQuery = `
            UPDATE good_order_receipt_items_list
            SET item_to_be_received =item_to_be_received - $1 
            WHERE item_id = $2 AND gort_id = $3;`
            }
            if (updateQuery) {
                const updateresult = await client.query(updateQuery, [item_quantity, item_id, gort_id]);


            } 
            const checkStatusQuery = `SELECT * FROM good_order_receipt_items_list WHERE  gort_id = $1`
            let checkStatusQueryResult = await client.query(checkStatusQuery, [item.gort_id]);

            let gort_order_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                console.log(typeof(checkStatusQueryResult.rows[0].item_to_be_received),"dfffffffffffff",checkStatusQueryResult.rows[0])
                const allDelivered = checkStatusQueryResult.rows.every(item => item.item_to_be_received === 0);
                gort_order_status = allDelivered ? "closed" : "open";
            }

            const updatestatusQuery = `UPDATE goods_order_receipt_table
        SET gort_order_status = $1 WHERE  gort_id = $2`;
            let updateStatus = await client.query(updatestatusQuery, [gort_order_status, item.gort_id]);

        }


    } catch (error) {

        throw new Error(error)
    }



}

export async function getdocumentsListofPurchaseReturn(prt_id:any){
    try{

        const query = `
        SELECT purchase_return_document_list.*,purchase_credit_table.pct_invoice_number
        FROM
        purchase_return_document_list
        LEFT JOIN 
        purchase_credit_table ON  purchase_return_document_list.pct_id = purchase_credit_table.pct_id
        WHERE
        purchase_return_document_list.prt_id = $1;`;
console.log(prt_id)
          const result = await client.query(query, [prt_id]);
          return result

    }catch(error){
              throw new Error(error)
    }
}

export async function insertCancelurchaseReturnInvoice(orderData: any, itemData: any,) {
    try {
        await client.query('BEGIN');
        const prt_id = ulid()
        orderData.prt_id = prt_id
        orderData.prt_order_status = 'cancelled'
   
        orderData.prt_invoice_number =   await nextInvoicenumber.getPurchaseReturnNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO purchase_return_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

              const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;
            
                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });
            
                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    prt_id: prt_id
                
                };
            });
         
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO purchase_return_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);


            const extractedBatchData :any= []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array
                
                if (Array.isArray(item.itemBatchData)) {
                  // Push each itemBatchData object into the extractedBatchData array
                  item.itemBatchData.forEach(batchData => {
                    extractedBatchData.push(batchData);
                  });
                }
              });

         

            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };
                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        item_exp_date: formatDateString(item.item_exp_date),
                        item_mfg_date: formatDateString(item.item_mfg_date),
                        prt_id: prt_id
                    };
                });
                
               
                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO purchase_return_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);

                console.log(orderData, newItemsData)

                let order = orderResult.rows[0]
                let item = itemResult.rows
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
             

            
                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: orderData.srt_total_amount,
                    credit_amount: 0,
                }


                const inventory_account_obj = {
                    account_id: inventoryGLAccount.rows[0].inventory_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.prt_sub_total,
                    credit_amount: 0,

                }


                const cos_goods_account_obj = {
                    account_id: inventoryGLAccount.rows[0].allocation_account,
                    transcation_id: transcation_id,
                    debit_amount:0,
                    credit_amount:  orderData.prt_sub_total,

                }

                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "purchase return",
                    origin_id:orderData.prt_invoice_number,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [inventory_account_obj, cos_goods_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
          

                
                await client.query('COMMIT'); 

                return { order, item }
            }
        }
    } catch (error) {
        console.log(error)
await client.query('ROLLBACK');
        throw new Error(error)
    }
}


export async function updateReturnOrderStatus(prt_order_status: any, prt_id: any) {
    try {
        const updatestatusQuery = `UPDATE purchase_return_table
                    SET prt_order_status = $1 WHERE  prt_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [prt_order_status, prt_id])
        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function deleteReturnInvoiceDocumentlist(prt_id: any) {
    try {
        const deleteFromSaleOrderDocumentQuery = `DELETE FROM goods_order_document_list  WHERE goods_order_document_list.prt_id =$1`;
  
    const results =  await client.query(deleteFromSaleOrderDocumentQuery, [prt_id])
        return results
    } catch (error) {
        throw new Error(error)
    }

}

export async function resetCreditOpenQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            const { item_quantity, poit_id, prt_id, item_id } = item
            let updateQuery
            const values = []
          
            
            if (prt_id !== 'null' && prt_id !== '' && prt_id !== null) {
                let prt_order_status = 'open'
                updateQuery = `
        UPDATE purchase_return_items_list
        SET item_credit_quanity_remaining =item_credit_quanity_remaining + $1
        WHERE item_id = $2 AND prt_id = $3;
        `;
                values.push(item_quantity, item_id, prt_id)
               await updateReturnOrderStatus(prt_order_status,prt_id)
               
            }
            if (poit_id!== 'null' && poit_id !== '' && poit_id !== poit_id) {

                let poit_order_status = 'open'
                updateQuery = `
            UPDATE purchase_order_invoice_items_list
            SET item_credit_quanity_remaining = item_credit_quanity_remaining + $1 
            WHERE item_id = $2 AND poit_id = $3;`

                values.push(item_quantity, item_id, poit_id)

               const updateInvoiceStatus =  updateInvoiceOrderStatus(poit_order_status,poit_id)

            }
            console.log(updateQuery,values,item_quantity, poit_id, prt_id, item_id)
            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);

            } 

        }

    } catch (error) {

        throw new Error(error)
    }



}

export async function resetPurchaseReturnQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery

            const { item_quantity, gort_id, item_id } = item
            const values = []
            if (gort_id) {
                updateQuery = `
        UPDATE good_order_receipt_items_list
        SET item_to_be_received =item_to_be_received + $1
        WHERE item_id = $2 AND gort_id = $3;
        `;
                values.push(item_quantity, item_id, gort_id)


            }

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);

                let  gort_order_status = "open"
                const gopOrderStatus =    await  updateGOPOrderStatus(gort_order_status,gort_id)

            } 

        }

    } catch (error) {

        throw new Error(error)
    }



}

export async function resetInvoiceOpenQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery
            const values = []
            const { item_quantity, pot_id, gort_id, item_id } = item
            if (pot_id !== 'null' && pot_id !== '' && pot_id !==null) {
                 let  pot_order_status = "open"
                updateQuery = `
        UPDATE purchase_order_items_list
        SET item_to_be_received =item_to_be_received + $1
        WHERE item_id = $2 AND pot_id = $3;
        `;
                values.push(item_quantity, item_id, pot_id)
                
               const updatestatusofSaleOrder =  await  updatePurchaseOrderStatus(pot_order_status, pot_id)


            }
            if (gort_id !=='null' && gort_id !== '' && gort_id !==null) {
             let  gort_order_status = "open"
                updateQuery = `
            UPDATE good_order_receipt_items_list
            SET item_to_be_received = item_to_be_received + $1 
            WHERE item_id = $2 AND gort_id = $3;`

                values.push(item_quantity, item_id, gort_id)
                
             const gopOrderStatus =    await  updateGOPOrderStatus(gort_order_status,gort_id)
            }
            console.log(values)

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);

            } 

        }

    } catch (error) {

        throw new Error(error)
    }



}

export async function resetGOPOpenQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery

            const { item_quantity, pot_id, item_id } = item
            console.log(item_quantity, pot_id, item_id, "eeeeeeeeeeeeeeee")
       let  pot_order_status = "open"
       
            const values = []
            if (pot_id) {
                updateQuery = `
        UPDATE purchase_order_items_list
        SET item_to_be_received =item_to_be_received + $1
        WHERE item_id = $2 AND pot_id = $3;
        `;
                values.push(item_quantity, item_id, pot_id)

            }
            console.log(values,"eeee")

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);
                console.log(updateresult)
               const updatestatusofSaleOrder =  await  updatePurchaseOrderStatus(pot_order_status, pot_id)

            }

        }

    } catch (error) {

        throw new Error(error)
    }



}

export async function updateInvoiceItemAmount(paymentData:any){
    try {


        for (let payment of paymentData) {
            let updateQuery

            const { podt_current_payment, poit_id } = payment
      
            const values = []
            if (poit_id) {
             updateQuery = `
        UPDATE purchase_order_invoice_table
        SET poit_due_amount = poit_due_amount - $1
        WHERE  poit_id = $2;
        `;
                values.push(podt_current_payment,poit_id)
                console.log(updateQuery,)

            }
            console.log(values,"eeee")

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);
               

            } 
            const checkStatusQuery = `SELECT * FROM purchase_order_invoice_table WHERE  poit_id = $1`

            let checkStatusQueryResult = await client.query(checkStatusQuery, [poit_id]);

            let poit_order_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                let allpayed = false
           console.log(checkStatusQueryResult.rows,"allpayed")
                if(parseInt(checkStatusQueryResult.rows[0].poit_due_amount)===0){
                    allpayed = true
                }
                console.log(allpayed,"allpayed")
                poit_order_status = allpayed ? "closed" : "open";
                console.log(poit_order_status,"soit_order_status")
            }
            const result = updateInvoiceOrderStatus(poit_order_status, poit_id)



        }

        
    } catch (error) {

        throw new Error(error)
    }

}

export async function getPurchaseInvoiceListSearch(query: any) {
    try {
        const { sortfield, sortValue, field, value } = query;

        let whereClause = `po.poit_order_status = 'open'`;

        // Add sorting to the ORDER BY clause if needed
        let orderByClause = '';
        if (sortfield && sortValue) {
            orderByClause = `ORDER BY c.${sortfield} = ${sortValue}`;
        }

        // Add search condition for the specified column
        const searchCondition = field
            ? `AND (LOWER(c.${field}) ILIKE LOWER('%${value}%'))`
            : '';

        const totalOrderValueQuery = `
            SELECT
                c.*,
                po.*
            FROM
                customer_details AS c
            LEFT JOIN
                purchase_order_invoice_table AS po ON c.cmr_id = po.cmr_id
            WHERE
                ${whereClause} ${searchCondition}
                ${orderByClause}
        `;
          
        console.log(totalOrderValueQuery)
        console.log(totalOrderValueQuery); // For debugging purposes

        const result = await client.query(totalOrderValueQuery);
        console.log(result.rows); // For debugging purposes

        return result

    } catch (error) {
        console.error('Error in getSalesInvoiceListSearch:', error);
        throw new Error('Failed to fetch sales invoice list.'); // You can customize the error message as needed
    }
}

export async function getOpenBalanceOfCMR(account_id: any) {
    try {
        
       console.log()

        const getCMROpenBalanceQuery = `
            SELECT
            gl.cmr_open_balance
            FROM
            general_accounts_table AS gl
            WHERE
            account_id = $1 
        `;

        const result = await client.query(getCMROpenBalanceQuery,[account_id]);
        console.log(result.rows,"ddd",account_id); // For debugging purposes
   
        return result

    } catch (error) {
        console.error('Error in getSalesInvoiceListSearch:', error);
        throw new Error('Failed to fetch sales invoice list.'); // You can customize the error message as needed
    }
}


export async function additemBatchNumberfromStockIn(itemBatchDataofInventory:any,itemData:any,client:any) {
    console.log(Object.keys(itemBatchDataofInventory[0]),"wer34444444ererewertrwerert")
    try {
        await client.query('BEGIN');

        for(let itemdata of itemData){
            for(let batch of itemBatchDataofInventory ){
                if(itemdata.item_id === batch.item_id){
                    batch.item_uom_id = itemdata.item_uom_id
                }
            }
        }
      
        for(let batchData of itemBatchDataofInventory){


        let  itemData = {
            item_id :batchData.item_id,
            item_sellable_quantity:batchData.item_batch_quantity,
            item_exp_date :batchData.item_exp_date,
            item_batch_number:batchData.item_batch_number,
            item_batch_id:''
    

        }

        const itemBinLocationData = {
        item_batch_number :batchData.item_batch_number,
        item_quantity:batchData.item_batch_quantity,
        item_id:batchData.item_id,
        to_bin_id:batchData.to_bin_id,
        item_rack_location :batchData.to_bin_location 
        }

        if(batchData.item_uom_id){
       
            const getUomQunatity =   await uomService.getUomGroupOfItems(batchData.item_uom_id)
            if(getUomQunatity.rows.length>0){
                
                itemBinLocationData.item_quantity = (getUomQunatity.rows[0].base_quantity * batchData.item_batch_quantity) + (getUomQunatity.rows[0].base_quantity * batchData.item_batch_free_quantity)
            }
              }

        const getbatchNumber = `SELECT * FROM  items_batch_no_table WHERE item_batch_number = $1 AND item_id = $2 `
        const getBatchNumberQueryResult = await client.query(getbatchNumber, [itemData.item_batch_number,itemData.item_id]);
         if(getBatchNumberQueryResult.rows.length>0){
        const   updateQuery = `
        UPDATE items_batch_no_table
        SET item_sellable_quantity = item_sellable_quantity + $1
        WHERE item_batch_number = $2 AND item_id = $3`;
        const updateresult = await client.query(updateQuery, [itemData.item_sellable_quantity,itemData.item_batch_number,itemData.item_id]);

         }else{
               
        itemData.item_batch_id = ulid();
        const columns = Object.keys(itemData);
        const values = Object.values(itemData);


        // Construct the parameterized query
        const insertCustomerQuery = `INSERT INTO items_batch_no_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertCustomerQuery);

        // Execute the query with parameterized values
        const insertCustomerQueryResult = await client.query(insertCustomerQuery, values);

        //checking item_batch_bin_location
      


        // const binlocationcolumns = Object.keys(itemBinLocationData);
        // const binlocartionvalues = Object.values(itemBinLocationData);
       
        //   // Construct the parameterized query
        //   const insertBinQuery = `INSERT INTO store_inventory_item_location_table (${binlocationcolumns.join(', ')}) VALUES (${binlocartionvalues.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        //   console.log(insertBinQuery);
  
        //   // Execute the query with parameterized values
        //   const insertBinQueryResult = await client.query(insertBinQuery, binlocartionvalues);
        // const updateQuery = `
        //             INSERT INTO store_inventory_item_location_table (item_id, item_batch_number, item_rack_location, item_quantity)
        //             VALUES ($1, $2, $3, $4)
        //             ON CONFLICT ON CONSTRAINT unique_item_batch_location
        //              DO UPDATE SET item_quantity = EXCLUDED.item_quantity
        //         `;
        //       console.log(itemBinLocationData.item_id, itemBinLocationData.item_batch_number, itemBinLocationData.item_rack_location, itemBinLocationData.item_quantity)
                
        //           const updateResult = await client.query(updateQuery, [itemBinLocationData.item_id, itemBinLocationData.item_batch_number, itemBinLocationData.item_rack_location, itemBinLocationData.item_quantity]);
        }

        const getBatchBin = 'SELECT * FROM store_inventory_item_location_table WHERE item_id =$1 AND to_bin_id =$2 AND  item_batch_number= $3'

        const insertgetBatchBinQueryResult = await client.query(getBatchBin,[itemBinLocationData.item_id,itemBinLocationData.to_bin_id,itemBinLocationData.item_batch_number]);

        if(insertgetBatchBinQueryResult.rows.length>0){
           console.log(insertgetBatchBinQueryResult.rows,"insertgetBatchBinQueryResult.rows")
           const  updatebatchBinQuery  =  `UPDATE store_inventory_item_location_table
           SET item_quantity = item_quantity + $1 WHERE item_id =$2 AND to_bin_id =$3 AND  item_batch_number= $4 RETURNING *;`;
             console.log(itemBinLocationData.item_quantity,itemBinLocationData.item_id,itemBinLocationData.to_bin_id,itemBinLocationData.item_batch_number,"werwerer")
           let updateStatus = await client.query(updatebatchBinQuery, [itemBinLocationData.item_quantity,itemBinLocationData.item_id,itemBinLocationData.to_bin_id,itemBinLocationData.item_batch_number]);
           console.log(updateStatus.rows,"updateStatus.rows",updatebatchBinQuery,itemBinLocationData.item_quantity)
        }else{
            const binlocationcolumns = Object.keys(itemBinLocationData);
       const binlocartionvalues = Object.values(itemBinLocationData);
        const insertBinQuery = `INSERT INTO store_inventory_item_location_table (${binlocationcolumns.join(', ')}) VALUES (${binlocartionvalues.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        const insertBinQueryResult = await client.query(insertBinQuery, binlocartionvalues);
        }
       

    }
    await client.query('COMMIT')
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}


export async function getBatchNumber(itemBatchData:any){
    try {


        for(let batchData of itemBatchData){

           const getbatchNumber = `SELECT * FROM  items_batch_no_table WHERE item_batch_number = $1 AND item_id = $2 `
           const insertCustomerQueryResult = await client.query(getbatchNumber, [batchData.item_batch_number,batchData.item_id]);

           if(insertCustomerQueryResult.rows.length>0){
            throw new Error('batch number should be unique for this item')
           }

        }

        
    } catch (error) {

        throw new Error(error)
    }

}

export async function getUnSyncPurchaseOrder() {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            purchase_order_items_list.*,
            purchase_order_transaction_table.*
            FROM
            purchase_order_transaction_table
            LEFT JOIN
            purchase_order_items_list ON purchase_order_transaction_table.pot_id = purchase_order_items_list.pot_id
            WHERE
            purchase_order_transaction_table.data_synced = false
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}


export async function getUnSyncPurchaseOrderIncompany() {
    try {
console.log("dddddddddddd")
        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            purchase_order_items_list.*,
            purchase_order_transaction_table.*
            FROM
            purchase_order_transaction_table
            LEFT JOIN
            purchase_order_items_list ON purchase_order_transaction_table.pot_id = purchase_order_items_list.pot_id
            JOIN customer_details cd  on purchase_order_transaction_table.cmr_id = cd.cmr_id
            WHERE
            purchase_order_transaction_table.data_synced = false AND cd.inter_company_sync = true
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}



export async function syncPurchaseOrder(orderData: any, itemData: any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "transaction_type":"purchase_order"
        }
    
    }

   // console.log(req,"34562345")
       
        socket.emit('purhcaseOrderSync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}

export async function syncPurchaseOrderDataResult(orderData: any, pot_id: any) {
    try {
        delete orderData.itt_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE purchase_order_transaction_table
        SET ${updateOrderFields}
        WHERE pot_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [pot_id, ...orderValues]);
        console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getUnSyncedGRN() {
    try {
         
        const GET_ORDER_DETAILS_QUERY = `
        SELECT
        goods_order_receipt_table.*,
        good_order_receipt_items_list.*,
        good_order_receipt_items_batches_list.*
        FROM
        goods_order_receipt_table
        LEFT JOIN
        good_order_receipt_items_list ON goods_order_receipt_table.gort_id = good_order_receipt_items_list.gort_id
        LEFT JOIN 
        good_order_receipt_items_batches_list ON good_order_receipt_items_list.gort_id = good_order_receipt_items_batches_list.gort_id
        AND good_order_receipt_items_list.item_id = good_order_receipt_items_batches_list.item_id
        WHERE
        goods_order_receipt_table.data_synced = false 
      `;
        
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function syncGRN(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"syncGRN"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('syncGRN', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncGRNDataResult(orderData: any, gort_id: any) {
    try {
        delete orderData.gort_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE goods_order_receipt_table
        SET ${updateOrderFields}
        WHERE gort_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [gort_id, ...orderValues]);
      //  console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getUnPurchaseInvoice() {
    try {
         
        

      const GET_ORDER_DETAILS_QUERY = `
      SELECT
      purchase_order_invoice_table.*,
      purchase_order_invoice_items_list.*,
      purchase_order_invoice_items_batches_list.*
      FROM
      purchase_order_invoice_table
      LEFT JOIN
      purchase_order_invoice_items_list ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
      LEFT JOIN 
      purchase_order_invoice_items_batches_list ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id
      AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
      WHERE
      purchase_order_invoice_table.data_synced = false 
    `;
        
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function syncPurchaseInvoice(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"purchase_invoice_sync"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('purchase_invoice_sync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncPurchaseInvoiceDataResult(orderData: any, poit_id: any) {
    try {
        delete orderData.poit_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE purchase_order_invoice_table
        SET ${updateOrderFields}
        WHERE poit_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [poit_id, ...orderValues]);
      //  console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getUnPurchaseReturn() {
    try {
         
        



    const GET_ORDER_DETAILS_QUERY = `
    SELECT
    purchase_return_table.*,
    purchase_return_items_list.*,
    purchase_return_items_batches_list.*
    FROM
    purchase_return_table
    LEFT JOIN
    purchase_return_items_list ON purchase_return_table.prt_id = purchase_return_items_list.prt_id
    JOIN 
    purchase_return_items_batches_list ON purchase_return_items_list.prt_id = purchase_return_items_batches_list.prt_id
    AND  purchase_return_items_list.item_id = purchase_return_items_batches_list.item_id
    WHERE
    purchase_return_table.data_synced = false 
  `;
        
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function syncPurchaseReturn(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"purchase_return_sync"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('purchase_return_sync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncPurchaseReturnDataResult(orderData: any, prt_id: any) {
    try {
        delete orderData.prt_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE purchase_return_table
        SET ${updateOrderFields}
        WHERE prt_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [prt_id, ...orderValues]);
      //  console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getUnPurchaseCreditNote() {
    try {
         
        



   
  
  const GET_ORDER_DETAILS_QUERY = `
  SELECT
  purchase_credit_table.*,
  purchase_credit_items_list_table.*,
  purchase_credit_items_batches_list.*
  FROM
  purchase_credit_table
  LEFT JOIN
  purchase_credit_items_list_table ON purchase_credit_table.pct_id = purchase_credit_items_list_table.pct_id
  LEFT JOIN 
  purchase_credit_items_batches_list ON purchase_credit_items_list_table.pct_id = purchase_credit_items_batches_list.pct_id
  AND  purchase_credit_items_list_table.item_id = purchase_credit_items_batches_list.item_id
  WHERE
  purchase_credit_table.data_synced = false 
`;
        
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function syncPurchaseCreditNote(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"purchase_credit_note_sync"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('purchase_credit_note_sync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncPurchaseCreditNoteDataResult(orderData: any, pct_id: any) {
    try {
        delete orderData.pct_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE purchase_credit_table
        SET ${updateOrderFields}
        WHERE pct_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [pct_id, ...orderValues]);
      //  console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}

export async function updatepurhcaheReturn(itemBatchDataofInventory: any,itemData:any, client:any) {
    try{
      for(let itemdata of itemData){
          for(let batch of itemBatchDataofInventory ){
              if(itemdata.item_id === batch.item_id){
                  batch.item_uom_id = itemdata.item_uom_id
              }
          }
      }
      
      for (const item of itemBatchDataofInventory) {
          console.log("sssssssrrrrrrrrr", item)
          const { item_id, item_batch_number, item_sellable_quantity, item_batch_free_quantity ,to_bin_location} = item;
          console.log(item_id, item_batch_number, typeof (item_sellable_quantity))
         let item_quantity
          if(item.item_uom_id){
         
              const getUomQunatity =   await uomService.getUomGroupOfItems(item.item_uom_id)
              if(getUomQunatity.rows.length>0){
                  
                  item_quantity = (getUomQunatity.rows[0].base_quantity * item_sellable_quantity) + (getUomQunatity.rows[0].base_quantity * item_batch_free_quantity)
              }
                }
  
  const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
      SET item_quantity = item_quantity - $1
      WHERE item_id = $2 AND item_batch_number = $3 AND item_rack_location = $4;`
  
        
  
          const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item_quantity, item_id, item_batch_number, to_bin_location]);
       
            
  
      }
  }catch(error){
      throw new Error(error)
  }
  }


  
  export async function syncPurchaseOrderInterCompany(orderData: any, itemData: any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "transaction_type":"purchase_order_inter_company"
        }
    
    }

   // console.log(req,"34562345")
       
        socket.emit('purhcaseOrderSyncInterCompany', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function grnSync(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');
     //  console.log(orderData,"sales_salesivery")
     const getcustomerDetails  = `SELECT * FROM purchase_order_transaction_table where pot_id = $1`
     const getcustomerDetailsOrNot = await client.query(getcustomerDetails, [itemData[0].pot_id])
     if(getcustomerDetailsOrNot.rows.length>0){
        const checksalesExitOrNotQuery  = `SELECT * FROM goods_order_receipt_table where gort_id = $1`
        const checksalesOrderExitOrNot = await client.query(checksalesExitOrNotQuery, [orderData.gort_id])
      //  console.log(checksalesOrderExitOrNot.rows.length === 0,"eeeeeeeeeeeeeefgfgfg")

    if(checksalesOrderExitOrNot.rows.length === 0){
       console.log(checksalesOrderExitOrNot.rows.length === 0,"edfdfvfgvfgfdfgfgfg")
       orderData.cmr_id = getcustomerDetailsOrNot.rows[0].cmr_id
       orderData.cmr_name = getcustomerDetailsOrNot.rows[0].cmr_name
       orderData.cmr_code = getcustomerDetailsOrNot.rows[0].cmr_code
       orderData.gort_invoice_number = await nextInvoicenumber.getGORNextInvoiceNumber()
          const columns = Object.keys(orderData);
         const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO goods_order_receipt_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
        console.log(orderResult.rows,"orderList")
        

            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(itemData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = itemData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO good_order_receipt_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

console.log(query,"itemquery")
            // console.log(query)
            const itemResult = await client.query(query);




            if (itemResult.rows.length > 0) {
            //    console.log(itemResult.rows,"orderList")
                const itemColumns = Object.keys(itemBatchData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = itemBatchData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

               

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO good_order_receipt_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString};`;
                console.log(query,"batchedquery")
                const itembatchResult = await client.query(query);
              //  console.log(itembatchResult.rows,"orderList")
               

            }
            
            let order = orderResult.rows[0]
            let item = itemResult.rows
            
            await client.query('COMMIT');
            return order
        }
    }else if (checksalesOrderExitOrNot.rows.length>0){
        let order = checksalesOrderExitOrNot.rows[0]
        return order
    }
}
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}



export async function poupdateOrderDataStatus(orderData: any, pot_id: any, pos_id:any) {
    try {
        await client.query('BEGIN');
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);
    
        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE purchase_order_transaction_table
        SET ${updateOrderFields}
        WHERE pot_id = $1
        RETURNING *;
      `;

        // Execute the updateSalesOrderQuery and get the result
        const salesOrderResult = await client.query(updateSalesOrderQuery, [pot_id, ...orderValues]);
        if(salesOrderResult.rows.length>0){
            socket.emit('purchase_order_status_update_acknowlegement', {
                pot_id:pot_id,
                sync: true,
                pos_id:pos_id
              })
        }

    } catch (error) {
        await client.query('ROLLBACK');

        throw new Error(error)
    }
}





export async function invoiceSync(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');
     //  console.log(orderData,"sales_salesivery")
     const getcustomerDetails  = `SELECT * FROM purchase_order_transaction_table where pot_id = $1`
     const getcustomerDetailsOrNot = await client.query(getcustomerDetails, [itemData[0].pot_id])
     if(getcustomerDetailsOrNot.rows.length>0){
        const checksalesExitOrNotQuery  = `SELECT * FROM purchase_order_invoice_table where poit_id = $1`
        const checksalesOrderExitOrNot = await client.query(checksalesExitOrNotQuery, [orderData.poit_id])
      //  console.log(checksalesOrderExitOrNot.rows.length === 0,"eeeeeeeeeeeeeefgfgfg")

    if(checksalesOrderExitOrNot.rows.length === 0){
       console.log(checksalesOrderExitOrNot.rows.length === 0,"edfdfvfgvfgfdfgfgfg")
       orderData.cmr_id = getcustomerDetailsOrNot.rows[0].cmr_id
       orderData.cmr_name = getcustomerDetailsOrNot.rows[0].cmr_name
       orderData.cmr_code = getcustomerDetailsOrNot.rows[0].cmr_code
       orderData.poit_invoice_number =  await nextInvoicenumber.getPurchaseInvoiceNextInvoiceNumber()
          const columns = Object.keys(orderData);
         const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO purchase_order_invoice_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
        console.log(orderResult.rows,"orderList")
        

            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(itemData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = itemData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO purchase_order_invoice_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

console.log(query,"itemquery")
            // console.log(query)
            const itemResult = await client.query(query);




            if (itemResult.rows.length > 0) {
            //    console.log(itemResult.rows,"orderList")
                const itemColumns = Object.keys(itemBatchData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = itemBatchData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

               

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO purchase_order_invoice_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString};`;
                console.log(query,"batchedquery")
                const itembatchResult = await client.query(query);
              //  console.log(itembatchResult.rows,"orderList")
               

            }
            
            let order = orderResult.rows[0]
            let item = itemResult.rows
            
            await client.query('COMMIT');
            return order
        }
    }else if (checksalesOrderExitOrNot.rows.length>0){
        let order = checksalesOrderExitOrNot.rows[0]
        return order
    }
}
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}


export async function getStoreDetails(){
    try{
        const qurey="select * from store_information_for_user_table";
        const result=await client.query(qurey);
        console.log(result.rows);
        return result.rows;
    }
    catch(error){
        throw new Error(error)
    }
        
}

export async function TaxInfo(poit_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
        SELECT
    purchase_order_invoice_items_list.item_gst,
    (COALESCE(SUM(purchase_order_invoice_items_list.item_total_amount), 0) - 
     COALESCE(SUM(purchase_order_invoice_items_list.item_tax_amount), 0) - 
     COALESCE(SUM(purchase_order_invoice_items_list.item_discount_amount), 0)) AS taxable,
    COALESCE(SUM(purchase_order_invoice_items_list.item_cgst), 0) AS cgst,
    COALESCE(SUM(purchase_order_invoice_items_list.item_sgst), 0) AS sgst,
    COALESCE(SUM(purchase_order_invoice_items_list.item_igst), 0) AS igst
FROM
    purchase_order_invoice_table
LEFT JOIN
    purchase_order_invoice_items_list ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
LEFT JOIN 
    purchase_order_invoice_items_batches_list ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id
    AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
WHERE
    purchase_order_invoice_items_list.item_gst IS NOT NULL
    AND purchase_order_invoice_table.poit_id = $1
GROUP BY 
    purchase_order_invoice_items_list.item_gst;

          `;
        const res = await client.query(GET_ORDER_DETAILS_QUERY, [poit_id]);
        if (res.rows.length === 0) {
            console.log('No records found.');
            return [];
          }
          const resultArray = res.rows.map(row => ({
            item_gst: row.item_gst,
            taxable: row.taxable,
            gst: row.cgst,
            sgst: row.sgst,
            igst: row.igst,
          }));
          console.log('Query result:', resultArray);
          return resultArray;
    } catch (error) {
        throw new Error(error)
    }
}

export async function TaxInfoGRN(poit_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
        SELECT
    good_order_receipt_items_list.item_gst,
    (COALESCE(SUM(good_order_receipt_items_list.item_total_amount), 0) - 
     COALESCE(SUM(good_order_receipt_items_list.item_tax_amount), 0) - 
     COALESCE(SUM(good_order_receipt_items_list.item_discount_amount), 0)) AS taxable,
    COALESCE(SUM(good_order_receipt_items_list.item_cgst), 0) AS cgst,
    COALESCE(SUM(good_order_receipt_items_list.item_sgst), 0) AS sgst,
    COALESCE(SUM(good_order_receipt_items_list.item_igst), 0) AS igst
FROM
    goods_order_receipt_table
LEFT JOIN
    good_order_receipt_items_list ON goods_order_receipt_table.gort_id = good_order_receipt_items_list.gort_id
LEFT JOIN 
    good_order_receipt_items_batches_list ON good_order_receipt_items_list.gort_id = good_order_receipt_items_batches_list.gort_id
    AND good_order_receipt_items_list.item_id = good_order_receipt_items_batches_list.item_id
where good_order_receipt_items_list.item_gst is not null
    AND goods_order_receipt_table.gort_id = $1
GROUP BY 
    good_order_receipt_items_list.item_gst;
          `;
        const res = await client.query(GET_ORDER_DETAILS_QUERY, [poit_id]);
        if (res.rows.length === 0) {
            console.log('No records found.');
            return [];
          }
          console.log('Number of rows returned:', res.rows.length);
          const resultArray = res.rows.map(row => ({
            item_gst: row.item_gst,
            taxable: row.taxable,
            gst: row.cgst,
            sgst: row.sgst,
            igst: row.igst,
          }));
          console.log('Query result:', resultArray);
          return resultArray;
    } catch (error) {
        throw new Error(error)
    }
}