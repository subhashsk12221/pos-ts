import client from "../util/database";

export async function uomSync(unitOfMeasure: any) {
  try {
   for(let item of unitOfMeasure ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'uom_id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO unit_of_measure (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (uom_id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
        //  console.log(result.rows[0]);
   }
          
      
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
  }


  export async function uomGroupSync(uomGroup: any) {
    try {
      for(let item of uomGroup ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .filter(column => column !== 'group_id')  // Exclude the primary key from the update
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO uom_group (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            ON CONFLICT (group_id)
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
// Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
    }  
 
export async function uomGroupItemSync(uomGroupItem: any) {
      try {
        for(let item of uomGroupItem ){
          // Get the keys of the object dynamically
          const columns = Object.keys(item);
          // Create placeholders for the values dynamically (e.g., $1, $2, ...)
          const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
          
          // Generate the "SET" part of the update statement dynamically
          const updateSetClause = columns
              .filter(column => column !== 'item_id')  // Exclude the primary key from the update
              .map(column => `${column} = EXCLUDED.${column}`)
              .join(', ');
      
          const query = `
              INSERT INTO uom_group_item (${columns.join(', ')})
              VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (item_id)
              DO UPDATE SET
              ${updateSetClause}
              RETURNING *;
          `;
      
          // Get the values from the object in the same order as the columns
          const values = columns.map(column => item[column]);
      
        
              const result = await client.query(query, values);
            //  console.log(result.rows[0]);
        }
  // Return the inserted or updated row
          } 
          catch (error) {
            console.error('Error in upsert:', error);
            throw error;
        }
 }  
 
 export async function itemTypeSync(itemType: any) {
  try {
    for(let item of itemType ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);

      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO item_type (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
         // console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}   
 

export async function itemCategorySync(itemCategory: any) {
  try {
    for(let item of itemCategory ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);

      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO item_category (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
        //  console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}   

export async function taxTypeSync(taxType: any) {
  try {
    for(let item of taxType ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO tax_type (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
         // console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}   


export async function taxCombinationSync(taxCombination: any) {
  try {
    for(let item of taxCombination ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
     
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO tax_combination (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
        //  console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}

export async function taxCombinationItemSync(taxCombinationItem: any) {
  try {
    for(let item of taxCombinationItem ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO tax_combination_item (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
       //   console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}


export async function manufacturerSync(manufacturer: any) {
  try {
    for(let item of manufacturer ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
     
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO manufacturer (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
        //  console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}

export async function shippingTypeSync(shippingType: any) {
  try {
    for(let item of shippingType ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO shipping_type (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
        //  console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}

export async function itemGroupSync(itemGroup: any) {
  try {
    for(let item of itemGroup ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO item_group (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
       //   console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}