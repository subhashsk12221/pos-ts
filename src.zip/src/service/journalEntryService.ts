
import client from '../util/database';
import { ulid } from 'ulid';
import * as financialLegder from '../service/financialLedgerService'
import * as paymentInCSerivce from '../service/paymentInService'

export async function addPaymentInJournalEntry(paymenModeData:any,pit_invoice_number:any,pit_total_amount:any, cmr_id:any,client:any){
    try{

    
let transcation_id = ulid()
let journal_entry_array = []

for(let paymentMode of paymenModeData){

    journal_entry_array.push({
        account_id: paymentMode.account_id,
   transcation_id: transcation_id,
   debit_amount:paymentMode.pmt_total_amount,
   credit_amount: 0,
    })
    

}

const customer_account_obj = {
   account_id: cmr_id,
   transcation_id: transcation_id,
   debit_amount: 0,
   credit_amount: pit_total_amount,
}

const journal_entry_obj = {
   transcation_id: transcation_id,
   origin_type: "Payment In",
   origin_id:pit_invoice_number,
   journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

}

journal_entry_array.push(customer_account_obj)

await financialLegder.addJournalEntry(journal_entry_obj)
await financialLegder.addJournalEntryRow(journal_entry_array)
    }catch(error){
        throw new Error(error)
    }


}

export async function addPaymentOutJournalEntry(paymenModeData:any,pot_invoice_number:any,pot_total_amount:any, cmr_id:any){
    try{

    
let transcation_id = ulid()
let journal_entry_array = []

for(let paymentMode of paymenModeData){

    journal_entry_array.push({
        account_id: paymentMode.account_id,
   transcation_id: transcation_id,
   debit_amount:0,
   credit_amount: paymentMode.pmt_total_amount
    })
    

}

const customer_account_obj = {
   account_id: cmr_id,
   transcation_id: transcation_id,
   debit_amount: pot_total_amount,
   credit_amount:0 ,
}

const journal_entry_obj = {
   transcation_id: transcation_id,
   origin_type: "Payment Out",
   origin_id:pot_invoice_number,
   journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

}

journal_entry_array.push(customer_account_obj)

await financialLegder.addJournalEntry(journal_entry_obj)
await financialLegder.addJournalEntryRow(journal_entry_array)
    }catch(error){
        throw new Error(error)
    }


}


export async function inovicePaymentINJournalEntry(paymenModeData:any,orderData:any){
    try{
 
let transcation_id = ulid()
let journal_entry_array = []
let getAccount = await paymentInCSerivce.getGlAccount()

for(let paymentMode of paymenModeData){
    let account_id 
    if(paymentMode.payment_mode_name === 'UPI'){
        account_id = "01J0QQY8Y2V3QNXQKHZYJS6DBX"
    }else if(paymentMode.payment_mode_name === 'Cash'){
        account_id = "01J0QQZTER6RPWGRZE60NC9MK4"
    }else if(paymentMode.payment_mode_name === 'Card'){
         account_id = "01J0QQY8Y2V3QNXQKHZYJS6DBX"
    }

    journal_entry_array.push({
        account_id: account_id,
   transcation_id: transcation_id,
   debit_amount: paymentMode.payment_amount,
   credit_amount:0,
    })
    

}

const customer_account_obj = {
   account_id: orderData.cmr_id,
   transcation_id: transcation_id,
   debit_amount: 0,
   credit_amount:orderData.sot_total_amount,
}

const journal_entry_obj = {
   transcation_id: transcation_id,
   origin_type: "Payment IN",
   origin_id:orderData.sot_invoice_number,
   journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

}

journal_entry_array.push(customer_account_obj)

await financialLegder.addJournalEntry(journal_entry_obj)
await financialLegder.addJournalEntryRow(journal_entry_array)
    }catch(error){
        throw new Error(error)
    }


}


export async function invoicejournalEntry(orderData:any){
    try{

        const [generalAccount,salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(),financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

       let  transcation_id =  ulid()
        const revenue_account_obj = {
            account_id :salesAccount.rows[0].revenue_account,
            transcation_id: transcation_id,
            debit_amount: 0,
            credit_amount  :orderData.sot_sub_total,
        }

        const tax_account_obj = {
            account_id :inventoryGLAccount.rows[0].tax_account,
            transcation_id: transcation_id,
            debit_amount: 0,
            credit_amount  :orderData.sot_total_gst,

        }

        const inventory_account_obj = {
            account_id :inventoryGLAccount.rows[0].inventory_account,
            transcation_id: transcation_id,
            debit_amount: 0,
            credit_amount  :orderData.sot_sub_total,
            
        }

        const customer_account_obj = {
            account_id :orderData.cmr_id,
            transcation_id:transcation_id,
            debit_amount: orderData.sot_total_amount,
            credit_amount  :0,
        }

      const  cos_goods_account_obj = {
        account_id :inventoryGLAccount.rows[0].cost_of_goods_sold_account,
        transcation_id:transcation_id,
        debit_amount: orderData.sot_sub_total,
        credit_amount  :0,
      
      }
               
      const journal_entry_obj = {
        transcation_id:transcation_id,
        origin_type :"IN",
        origin_id :orderData.sot_invoice_number,
        journal_entry_no:Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

      }
     const journal_entry_array = [revenue_account_obj,tax_account_obj,inventory_account_obj,customer_account_obj,cos_goods_account_obj]
            await  financialLegder.addJournalEntry(journal_entry_obj)
            await financialLegder.addJournalEntryRow(journal_entry_array)
    }catch(error){
        throw new Error(error)

    }
}


export async function inovicePaymentOutJournalEntry(paymenModeData:any,orderData:any){
    try{
 
let transcation_id = ulid()
let journal_entry_array = []
let getAccount = await paymentInCSerivce.getGlAccount()

for(let paymentMode of paymenModeData){
    let account_id 
    if(paymentMode.payment_mode_name === 'UPI'){
        account_id = "01J0QQY8Y2V3QNXQKHZYJS6DBX"
    }else if(paymentMode.payment_mode_name === 'cash'){
        account_id = "01J0QQZTER6RPWGRZE60NC9MK4"
    }else if(paymentMode.payment_mode_name === 'Card'){
         account_id = "01J0QQY8Y2V3QNXQKHZYJS6DBX"
    }
console.log(account_id,'eeeeeeeee')
    journal_entry_array.push({
     account_id: account_id,
   transcation_id: transcation_id,
   debit_amount:0,
   credit_amount: paymentMode.payment_amount,
    })
    

}

const customer_account_obj = {
   account_id: orderData.cmr_id,
   transcation_id: transcation_id,
   debit_amount: orderData.icn_total_amount,
   credit_amount:0,
}

const journal_entry_obj = {
   transcation_id: transcation_id,
   origin_type: "Payment Out",
   origin_id:orderData.icn_invoice_number,
   journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

}

journal_entry_array.push(customer_account_obj)

await financialLegder.addJournalEntry(journal_entry_obj)
await financialLegder.addJournalEntryRow(journal_entry_array)
    }catch(error){
        console.log(error)
        throw new Error(error)
    }


}



export async function invoiceCreditNotejournalEntry(orderData:any){
    try{

        const [generalAccount,salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(),financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

       let  transcation_id =  ulid()
        const revenue_account_obj = {
            account_id :salesAccount.rows[0].revenue_account,
            transcation_id: transcation_id,
            debit_amount: orderData.icn_sub_total,
            credit_amount  :0,
        }

        const tax_account_obj = {
            account_id :inventoryGLAccount.rows[0].tax_account,
            transcation_id: transcation_id,
            debit_amount: orderData.icn_total_gst,
            credit_amount  :0,

        }

        const inventory_account_obj = {
            account_id :inventoryGLAccount.rows[0].inventory_account,
            transcation_id: transcation_id,
            debit_amount: orderData.icn_sub_total,
            credit_amount  :0,
            
        }

        const customer_account_obj = {
            account_id :orderData.cmr_id,
            transcation_id:transcation_id,
            debit_amount: 0,
            credit_amount  :orderData.icn_total_amount,
        }

      const  cos_goods_account_obj = {
        account_id :inventoryGLAccount.rows[0].cost_of_goods_sold_account,
        transcation_id:transcation_id,
        debit_amount:0 ,
        credit_amount  :orderData.icn_sub_total,
      
      }
               
      const journal_entry_obj = {
        transcation_id:transcation_id,
        origin_type :"Inovice Credit Note",
        origin_id :orderData.icn_invoice_number,
        journal_entry_no:Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

      }
     const journal_entry_array = [revenue_account_obj,tax_account_obj,inventory_account_obj,customer_account_obj,cos_goods_account_obj]
            await  financialLegder.addJournalEntry(journal_entry_obj)
            await financialLegder.addJournalEntryRow(journal_entry_array)
    }catch(error){
        throw new Error(error)

    }
}