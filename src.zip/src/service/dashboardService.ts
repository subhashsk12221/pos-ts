import client from "../util/database";

export async function getSalesReportService(
  period: any,
  from?: string,
  to?: string
) {
  try {
    let query;
    if (period === "daily") {
      query = `SELECT 
  to_char(hourly_series.hour, 'YYYY-MM-DD HH24:MI:SS') AS hour, 
  COALESCE(SUM(sales_order.sot_total_amount), 0) AS total_sales,
  COALESCE(COUNT(sales_order.sot_id), 0) AS total_orders
FROM 
  generate_series(
    date_trunc('day', CURRENT_DATE), 
    date_trunc('day', CURRENT_DATE) + interval '1 day' - interval '1 hour', 
    interval '1 hour'
  ) AS hourly_series(hour)
LEFT JOIN 
  sales_order 
ON 
  date_trunc('hour', sales_order.created_date) = hourly_series.hour
  AND sales_order.is_draft_order = FALSE
GROUP BY 
  hourly_series.hour
ORDER BY 
  hourly_series.hour ASC;
      `;
    } else if (period === "weekly") {
      query = `SELECT 
      to_char(week_series.day, 'YYYY-MM-DD') AS date,
      to_char(week_series.day, 'Day') AS day_of_week,
      COALESCE(SUM(sales_order.sot_total_amount), 0) AS total_sales,
      COALESCE(COUNT(sales_order.sot_id), 0) AS total_orders
    FROM 
      generate_series(
        date_trunc('week', CURRENT_DATE), 
        date_trunc('week', CURRENT_DATE) + interval '6 days', 
        interval '1 day'
      ) AS week_series(day)
    LEFT JOIN 
      sales_order 
    ON 
      DATE(sales_order.created_date) = week_series.day
      AND sales_order.is_draft_order = FALSE
    GROUP BY 
      week_series.day
    ORDER BY 
      week_series.day ASC     `;
    } else if (period === "yearly") {
      query = `WITH sales_data AS (
        SELECT 
          DATE_TRUNC('month', created_date) AS month,
          TO_CHAR(DATE_TRUNC('month', created_date), 'Month') AS month_name,
          COALESCE(SUM(sot_total_amount), 0) AS total_sales,
          COALESCE(COUNT(sot_id), 0) AS total_orders
        FROM 
          sales_order
        WHERE 
          created_date >= DATE_TRUNC('year', CURRENT_DATE)
          AND is_draft_order = FALSE
        GROUP BY 
          DATE_TRUNC('month', created_date)
      ),
      calendar AS (
        SELECT 
          DATE_TRUNC('month', generate_series(
            DATE_TRUNC('year', CURRENT_DATE),
            DATE_TRUNC('year', CURRENT_DATE) + INTERVAL '11 months',
            '1 month'
          )) AS month
      )
      SELECT 
        c.month AS date,
        TO_CHAR(c.month, 'YYYY-MM') AS month_year,
        TO_CHAR(c.month, 'Month') AS month_name,
        COALESCE(sd.total_sales, 0) AS total_sales,
        COALESCE(sd.total_orders, 0) AS total_orders
      FROM 
        calendar c
      LEFT JOIN 
        sales_data sd
      ON 
        c.month = sd.month
      ORDER BY 
        c.month ASC`;
    } else if (period === "custom_date" && from && to) {
      query = `
      SELECT 
        to_char(day_series.day, 'YYYY-MM-DD') AS date,
        COALESCE(SUM(sales_order.sot_total_amount), 0) AS total_sales,
        COALESCE(COUNT(sales_order.sot_id), 0) AS total_orders
      FROM 
        generate_series(
          '${from}'::date, 
          '${to}'::date, 
          interval '1 day'
        ) AS day_series(day)
      LEFT JOIN 
        sales_order 
      ON 
        DATE(sales_order.created_date) = day_series.day
        AND sales_order.is_draft_order = FALSE
      GROUP BY 
        day_series.day
      ORDER BY 
        day_series.day ASC;
      `;
    } else {
      return [];
    }
    console.log(query, "QUERRRRRRRRy");

    const result = await client.query(query);
    const totalSales = result.rows.reduce(
      (acc, row) => acc + parseFloat(row.total_sales),
      0
    );
    const totalOrders = result.rows.reduce(
      (acc, row) => acc + parseInt(row.total_orders, 10),
      0
    );

    return {
      total_sales: totalSales,
      total_orders: totalOrders,
      line_graph_data: result.rows,
    };
  } catch (error) {
    console.error(error);
    return [];
  }
}

export async function getTopSellingProducts(
  period: any,
  type: any,
  from?: string,
  to?: string
) {
  try {
    let query;
    const now = new Date();
    const startDate =
      period === "daily"
        ? now.toISOString().split("T")[0]
        : period === "weekly"
        ? new Date(now.setDate(now.getDate() - now.getDay()))
            .toISOString()
            .split("T")[0]
        : period === "yearly"
        ? new Date(now.getFullYear(), 0, 1).toISOString().split("T")[0]
        : "";

    if (period === "daily" || period === "weekly" || period === "yearly") {
      query = `
        SELECT 
          item_name,
          SUM(item_quantity) AS total_quantity,
          SUM(item_total_amount) AS total_sales
        FROM 
          order_items_list
        JOIN 
          sales_order
        ON 
          order_items_list.sot_id = sales_order.sot_id
        WHERE 
          sales_order.created_date >= '${startDate}'
          AND sales_order.is_draft_order = FALSE
        GROUP BY 
          item_name
        ORDER BY 
          ${type === "quantity" ? "total_quantity" : "total_sales"} DESC
        LIMIT 7;
      `;
    } else if (period === "custom_date" && from && to) {
      query = `
        SELECT 
          item_name,
          SUM(item_quantity) AS total_quantity,
          SUM(item_total_amount) AS total_sales
        FROM 
          order_items_list
        JOIN 
          sales_order
        ON 
          order_items_list.sot_id = sales_order.sot_id
        WHERE 
          sales_order.created_date BETWEEN '${from}'::date AND '${to}'::date
          AND sales_order.is_draft_order = FALSE
        GROUP BY 
          item_name
        ORDER BY 
          ${type === "quantity" ? "total_quantity" : "total_sales"} DESC
        LIMIT 7;
      `;
    } else {
      return [];
    }

    const result = await client.query(query);
    return result.rows;
  } catch (error) {
    console.error(error);
    return [];
  }
}

export async function getLowStockProducts() {
  try {
    const query = `
      SELECT
          items_table.item_id,
          items_table.item_code,
          items_table.item_name,
          COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_quantity
      FROM
          items_table
      LEFT JOIN
          items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
      LEFT JOIN
          store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
      LEFT JOIN
          sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
      WHERE
          (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
          AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false OR sublevel_bins.bin_no_id IS NULL)
      GROUP BY
          items_table.item_id
      ORDER BY
          total_quantity ASC
      LIMIT 10;
    `;
    const result = await client.query(query);
    return result.rows;
  } catch (error) {
    console.error("Error fetching low stock products:", error);
    throw new Error("Error fetching low stock products");
  }
}

export async function getExpiringSoonProducts() {
  try {
    const query = `
      SELECT
          items_table.item_name,
          items_batch_no_table.item_batch_number,
          items_batch_no_table.item_exp_date
      FROM
          items_table
      LEFT JOIN
          items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
      WHERE
          items_batch_no_table.item_exp_date IS NOT NULL
          AND items_batch_no_table.item_exp_date > CURRENT_DATE
      ORDER BY
          items_batch_no_table.item_exp_date ASC
      LIMIT 10;
    `;
    const result = await client.query(query);
    return result.rows;
  } catch (error) {
    console.error("Error fetching expiring soon products:", error);
    throw new Error("Error fetching expiring soon products");
  }
}

export async function getNewCustomersReportService(period: any, from?: string, to?: string) {
  try {
    let query;
    if (period === "daily") {
      query = `
        SELECT 
          to_char(hourly_series.hour, 'YYYY-MM-DD HH24:MI:SS') AS hour, 
          COALESCE(COUNT(customer_details.cmr_id), 0) AS total_customers
        FROM 
          generate_series(
            date_trunc('day', CURRENT_DATE), 
            date_trunc('day', CURRENT_DATE) + interval '1 day' - interval '1 hour', 
            interval '1 hour'
          ) AS hourly_series(hour)
        LEFT JOIN 
          customer_details 
        ON 
          date_trunc('hour', customer_details.created_date) = hourly_series.hour
        GROUP BY 
          hourly_series.hour
        ORDER BY 
          hourly_series.hour ASC;
      `;
    } else if (period === "weekly") {
      query = `
        SELECT 
          to_char(week_series.day, 'YYYY-MM-DD') AS date,
          to_char(week_series.day, 'Day') AS day_of_week,
          COALESCE(COUNT(customer_details.cmr_id), 0) AS total_customers
        FROM 
          generate_series(
            date_trunc('week', CURRENT_DATE), 
            date_trunc('week', CURRENT_DATE) + interval '6 days', 
            interval '1 day'
          ) AS week_series(day)
        LEFT JOIN 
          customer_details 
        ON 
          DATE(customer_details.created_date) = week_series.day
        GROUP BY 
          week_series.day
        ORDER BY 
          week_series.day ASC;
      `;
    } else if (period === "yearly") {
      query = `
        WITH customer_data AS (
          SELECT 
            DATE_TRUNC('month', created_date) AS month,
            COALESCE(COUNT(cmr_id), 0) AS total_customers
          FROM 
            customer_details
          WHERE 
            created_date >= DATE_TRUNC('year', CURRENT_DATE)
          GROUP BY 
            DATE_TRUNC('month', created_date)
        ),
        calendar AS (
          SELECT 
            DATE_TRUNC('month', generate_series(
              DATE_TRUNC('year', CURRENT_DATE),
              DATE_TRUNC('year', CURRENT_DATE) + INTERVAL '11 months',
              '1 month'
            )) AS month
        )
        SELECT 
          c.month AS date,
          TO_CHAR(c.month, 'YYYY-MM') AS month_year,
          TO_CHAR(c.month, 'Month') AS month_name,
          COALESCE(cd.total_customers, 0) AS total_customers
        FROM 
          calendar c
        LEFT JOIN 
          customer_data cd
        ON 
          c.month = cd.month
        ORDER BY 
          c.month ASC;
      `;
    }
    else if (period === "custom_date" && from && to) {
      query = `
        SELECT 
          to_char(day_series.day, 'YYYY-MM-DD') AS date,
          COALESCE(COUNT(customer_details.cmr_id), 0) AS total_customers
        FROM 
          generate_series(
            '${from}'::date, 
            '${to}'::date, 
            interval '1 day'
          ) AS day_series(day)
        LEFT JOIN 
          customer_details 
        ON 
          DATE(customer_details.created_date) = day_series.day
        GROUP BY 
          day_series.day
        ORDER BY 
          day_series.day ASC;
      `;
    }
    else {
      return [];
    }

    const result = await client.query(query);
    const totalCustomers = result.rows.reduce(
      (acc, row) => acc + parseInt(row.total_customers, 10),
      0
    );

    return {
      total_customers: totalCustomers,
      line_graph_data: result.rows,
    };
  } catch (error) {
    console.error(error);
    return [];
  }
}
