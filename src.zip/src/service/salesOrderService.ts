import client from '../util/database';
import { ulid } from 'ulid';
import * as orderService from '../service/orderService'
import * as financialLegder from '../service/financialLedgerService'
import * as nextInvoicenumber  from '../service/documentNumberingSeries'
import * as  uomService from '../administrativesettings/src/service/uomService';
import socket from '../sync/syncScript';
import { updateStoreInventorForVStockout } from './stockTransferService';
import * as fs from 'fs';
export async function getNextSaleOrderInvoiceNumber(store_id: any) {
    try {

        const getNextInvoiceNumber = await client.query('SELECT generate_sale_order_invoice_number($1) AS sott_invoice_number', [store_id]);
        return getNextInvoiceNumber

    } catch (error) {
        throw new Error(error)
    }
}

export async function addSalesOrder(orderData: any, itemData: any) {
    try {
        await client.query('BEGIN');
        const sott_id = ulid()
        orderData.sott_id = sott_id
        orderData.sott_order_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO sales_order_transaction_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                sott_id: sott_id,
                item_to_be_delivered: item.item_quantity,
                item_invoice_open_quantity: item.item_quantity
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );
           
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)




            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sales_order_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);

            let order = orderResult.rows[0]
            let item = itemResult.rows
            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function getSalesOrderList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.sott_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM sales_order_transaction_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM sales_order_transaction_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSalesOrderById(sott_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_order_transaction_table.*,
            sales_order_items_list.*,
            uom_group_item.base_quantity
            FROM
        sales_order_transaction_table
        INNER JOIN
        sales_order_items_list ON sales_order_transaction_table.sott_id = sales_order_items_list.sott_id
        INNER JOIN uom_group_item on sales_order_items_list.item_uom_id = uom_group_item.item_id
        WHERE
        sales_order_transaction_table.sott_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sott_id]);
console.log(orderDetailsResult.rows)
        if (orderDetailsResult.rows.length === 0) {
            return []; // Or handle the case where no order is found
        }

        const orderDetails = orderDetailsResult.rows;

        // Step 2: Calculate total_sellable_quantity for each item in the order
        for (const item of orderDetails) {
            const itemId = item.item_id; // Assuming `item_id` is part of `order_items_list`
            const CALCULATE_SELLABLE_QUANTITY_QUERY = `
                SELECT
                    COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
                FROM
                    items_table
                LEFT JOIN
                    items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number 
                    AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id 
                WHERE
                    items_table.item_id = $1
                    AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
                    AND (
                        sublevel_bins.is_expired_bin_location = false 
                        AND sublevel_bins.is_non_sellable_bin_location = false 
                        OR sublevel_bins.bin_no_id IS NULL
                    )
                GROUP BY
                    items_table.item_id;
            `;
            const sellableQuantityResult = await client.query(CALCULATE_SELLABLE_QUANTITY_QUERY, [itemId]);

            // Add total_sellable_quantity to the item details
            item.total_sellable_quantity = sellableQuantityResult.rows.length > 0
                ? sellableQuantityResult.rows[0].total_sellable_quantity/item.base_quantity
                : 0;
                 
        }
        if (orderDetails.length > 0) {
            console.log(orderDetailsResult.rows, "ssssss")
            const groupedItems = orderDetails.reduce((acc, item) => {
                const key = item.sott_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            sott_id: item.sott_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            sott_total_gst: item.sott_total_gst,
                            sott_total_discount: item.sott_total_discount,
                            sott_payment_status: item.sott_payment_status,
                            sott_transaction_id: item.sott_transaction_id,
                            sott_order_status: item.sott_order_status,
                            sott_payment_method: item.sott_payment_method,
                            sott_billing_address: item.sott_billing_address,
                            sott_total_amount: item.sott_total_amount,
                            sott_delivery_date: item.sott_delivery_date,
                            sott_document_date: item.sott_document_date,
                            remarks: item.remarks,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                }
                acc[key].itemData.push({
                    item_id: item.item_id,
                    item_code: item.item_code,
                    item_generic_name: item.item_generic_name,
                    item_name: item.item_name,
                    item_pack_size: item.item_pack_size,
                    item_rack_location: item.item_rack_location,
                    item_unit_price: item.item_unit_price,
                    item_quantity: item.item_quantity,
                    item_schedule: item.item_schedule,
                    item_discount_amount: item.item_discount_amount,
                    item_discount_percentage: item.item_discount_percentage,
                    item_tax_amount: item.item_tax_amount,
                    item_invoice_open_quantity: item.item_invoice_open_quantity,
                    item_to_be_delivered: item.item_to_be_delivered,
                    item_total_tax_percentage: item.item_total_tax_percentage,
                    item_total_amount: item.item_total_amount,
                    item_gst: item.item_gst,
                    item_sgst: item.item_sgst,
                    item_cgst: item.item_cgst,
                    item_igst: item.item_igst,
                    item_uom:item.item_uom,
                    total_sellable_quantity:item.total_sellable_quantity

                });

                return acc;
            }, {});



            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            return resultArray
            //console.log(resultArray,"ddd", resultArray['orderData'])
        } else {
            return []
        }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getVendorDetails(sott_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
         
            sales_order_transaction_table.cmr_id,
            sales_order_transaction_table.cmr_code,
            sales_order_transaction_table.cmr_name
            FROM
            sales_order_transaction_table
            WHERE
            sales_order_transaction_table.sott_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sott_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSalesitemsList(query: any) {
    try {
        console.log(query)
        const { sott_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_order_items_list.*,
            uom_group_item.base_quantity
            FROM
            sales_order_items_list
            join uom_group_item on sales_order_items_list.item_uom_id = uom_group_item.item_id
            WHERE
            sales_order_items_list.sott_id = $1
        `;

        const queryParams = [sott_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND sales_order_items_list.item_id = $2`;
            queryParams.push(item_id);
        }

        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateSaleOrderStatus(sott_order_status: any, sott_id: any) {
    try {
        const updatestatusQuery = `UPDATE sales_order_transaction_table
                    SET sott_order_status = $1 WHERE  sott_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [sott_order_status, sott_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function addSaleDeliveryOrder(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');
        const sodtt_id = ulid()
        orderData.sodtt_id = sodtt_id
        orderData.sodtt_order_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO sales_order_delivery_transaction_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                sodtt_id: sodtt_id,
                item_to_be_delivered: item.item_quantity,
                item_return_open_quantity:item.item_quantity
        
            }));

            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sale_order_delivery_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);



            if (itemResult.rows.length > 0) {
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    sodtt_id: sodtt_id

                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO sale_order_delivery_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);

                console.log(orderData, newItemsData)
                const updateInventory = await updateStoreInventor(itemBatchData, "minus")
                
                
                updateStoreInventorForVStockout(itemBatchData,itemData,client)
                updatepurhcaheReturn(itemBatchData,itemData,client)
            }
            const updateSalesOrderData = await updateSaleOrderData(newItemsData)
            let order = orderResult.rows[0]
            let item = itemResult.rows
            const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

            let transcation_id = ulid()

            const inventory_account_obj = {
                account_id: inventoryGLAccount.rows[0].inventory_account,
                transcation_id: transcation_id,
                debit_amount: 0,
                credit_amount: orderData.sodtt_sub_total,

            }



            const cos_goods_account_obj = {
                account_id: inventoryGLAccount.rows[0].cost_of_goods_sold_account,
                transcation_id: transcation_id,
                debit_amount: orderData.sodtt_sub_total,
                credit_amount: 0,

            }

            const journal_entry_obj = {
                transcation_id: transcation_id,
                origin_type: "DN",
                origin_id: orderData.sodtt_invoice_number,
                journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

            }
            const journal_entry_array = [inventory_account_obj, cos_goods_account_obj]
            await financialLegder.addJournalEntry(journal_entry_obj)
            await financialLegder.addJournalEntryRow(journal_entry_array)
            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}
export async function updateSaleOrderData(itemData: any) {
    try {
        for (const item of itemData) {
            let { item_id, sodtt_id, sott_id, item_delivered_quantity, item_quantity, soit_id } = item;
            await client.query('BEGIN')
            if (sott_id) {
                let updateColumn
                let values = []
                if (item_delivered_quantity && sodtt_id) {
                    updateColumn = 'item_to_be_delivered = item_to_be_delivered - $1'
                    values.push(item_delivered_quantity)
                }
                if (item_quantity && soit_id) {
                    updateColumn = 'item_to_be_delivered = item_to_be_delivered - $1'
                    values.push(item_quantity)
                }

                const updateQuery = `UPDATE sales_order_items_list SET ${updateColumn} WHERE item_id = $2 AND sott_id = $3;`;
                console.log(updateQuery, "updateQuery")
                const updateresult = await client.query(updateQuery, [...values, item_id, sott_id]);

                if (sodtt_id || soit_id) {
                    const insertDoccumentlistObj = {
                        sott_id: sott_id,
                        sodtt_id: sodtt_id,
                        soit_id: soit_id
                    }

                    const insertDataObj = await insertSalesOrderDocument(insertDoccumentlistObj)
                }
                

                    const checkStatusQuery = `SELECT * FROM sales_order_items_list WHERE  sott_id = $1`

                    let checkStatusQueryResult = await client.query(checkStatusQuery, [sott_id]);

                    let sott_order_status = "open"; // Default to "open" status

                    if (checkStatusQueryResult.rows.length > 0) {
                        const allDelivered = checkStatusQueryResult.rows.every(item => item.item_to_be_delivered === 0);
                        sott_order_status = allDelivered ? "closed" : "open";
                    }

                    const result = updateSaleOrderStatus(sott_order_status, sott_id)
                

            }

        }
        await client.query('COMMIT'); // Commit the transaction
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)

        throw new Error(error)


    }
}
export async function insertSalesOrderDocument(insertObj: any) {

    try {


        console.log(insertObj)
        const columns = Object.keys(insertObj);
        const values = Object.values(insertObj);

        // Construct the parameterized query
        const insertdocumentidquery = `INSERT INTO sales_order_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        console.log(insertdocumentidquery, "ffffffffffff")
        let insertdocumentidqueryResult = await client.query(insertdocumentidquery, values);

    } catch (error) {
        throw new Error(error)
    }

}

export async function updateDeliveryOrder(orderData: any) {
    try {
        const { sodtt_id } = orderData
        const columnValuePairs = Object.entries(orderData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(orderData);

        const query = `
UPDATE sales_order_delivery_transaction_table
SET ${columnValuePairs}
WHERE sodtt_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, sodtt_id]);
        return result
    } catch (error) {
        throw new Error(error)
    }

}

export async function getSaleDelivery(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.sodtt_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM sales_order_delivery_transaction_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM sales_order_delivery_transaction_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateStoreInventor(itemBatchData: any, condition: string) {
    try {

        for (const item of itemBatchData) {
            let updateQuery
            console.log("sssssss", item)
            const { item_id, item_batch_number, item_batch_quantity } = item;
            console.log(item_id, item_batch_number, typeof (item_batch_quantity))
            

            if (condition === "minus") {
                updateQuery = `UPDATE items_batch_no_table
SET item_sellable_quantity = item_sellable_quantity - $1
WHERE item_id = $2 AND item_batch_number = $3;
`;
            }

            if (condition === "add") {
                updateQuery = `UPDATE items_batch_no_table
    SET item_sellable_quantity = item_sellable_quantity + $1
    WHERE item_id = $2 AND item_batch_number = $3;
    `;
            }

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, [item_batch_quantity, item_id, item_batch_number]);
                console.log("Update result:", updateresult);
            } else {
                console.error(`Invalid condition provided: ${condition}`);
                throw new Error(`Invalid condition provided: ${condition}`);
            }

        }
    } catch (error) {
        throw new Error(error)
    }
}

export async function getDeliveryitemsList(query: any) {
    try {
        console.log(query)
        const { sodtt_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
                SELECT
                sale_order_delivery_items_list.*,
                sale_order_delivery_items_batches_list.*
                FROM
                sale_order_delivery_items_list
                JOIN 
                sale_order_delivery_items_batches_list ON sale_order_delivery_items_list.sodtt_id = sale_order_delivery_items_batches_list.sodtt_id
                AND  sale_order_delivery_items_list.item_id = sale_order_delivery_items_batches_list.item_id
                WHERE
                sale_order_delivery_items_list.sodtt_id = $1
            `;

        const queryParams = [sodtt_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND sale_order_delivery_items_list.item_id = $2`;
            queryParams.push(item_id);
        }

        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function getinvoiceOrReturnitemBatchData(query: any) {
    try {
        console.log(query)
        const { sodtt_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY_INVOICE = `
        SELECT
        sales_order_invoice_items_list.*,
        sales_order_invoice_items_batches_list.*
        FROM
        sales_order_invoice_items_list
        LEFT JOIN 
        sales_order_invoice_items_batches_list ON sales_order_invoice_items_list.soit_id = sales_order_invoice_items_batches_list.soit_id
        AND  sales_order_invoice_items_list.item_id = sales_order_invoice_items_batches_list.item_id
        WHERE
          sales_order_invoice_items_list.sodtt_id = $1
      `;

        const queryParamsInvoice = [sodtt_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY_INVOICE += ` AND sales_order_invoice_items_list.item_id = $2`;
            queryParamsInvoice.push(item_id);
        }

        const inoviceorderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY_INVOICE, queryParamsInvoice);
        let GET_ORDER_DETAILS_QUERY = `
        SELECT
        sales_return_items_list.*,
        sales_return_items_batches_list.*
        FROM
        sales_return_items_list
        JOIN 
        sales_return_items_batches_list ON sales_return_items_list.srt_id = sales_return_items_batches_list.srt_id 
        AND  sales_return_items_list.item_id = sales_return_items_batches_list.item_id
        WHERE
        sales_return_items_list.sodtt_id = $1
    `;

const queryParams = [sodtt_id];

if (item_id) {
    GET_ORDER_DETAILS_QUERY += ` AND sales_return_items_list.item_id = $2`;
    queryParams.push(item_id);
}

const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


console.log(inoviceorderDetailsResult.rows, orderDetailsResult.rows, "werwererwertwert")
const invoice = inoviceorderDetailsResult.rows
const returnorder = orderDetailsResult.rows
        return {invoice,  returnorder}

    } catch (error) {
        throw new Error(error)
    }
}


export async function getDeliveryOrderById(sodtt_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_order_delivery_transaction_table.*,
            sale_order_delivery_items_list.*,
            sale_order_delivery_items_batches_list.*
            FROM
            sales_order_delivery_transaction_table
            LEFT JOIN
            sale_order_delivery_items_list ON sales_order_delivery_transaction_table.sodtt_id = sale_order_delivery_items_list.sodtt_id 
            LEFT JOIN 
            sale_order_delivery_items_batches_list ON sale_order_delivery_items_list.sodtt_id = sale_order_delivery_items_batches_list.sodtt_id
			AND  sale_order_delivery_items_list.item_id = sale_order_delivery_items_batches_list.item_id
            WHERE
            sales_order_delivery_transaction_table.sodtt_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sodtt_id]);
        if (orderDetailsResult.rows.length > 0) {

            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.sodtt_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            sodtt_id: item.sodtt_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            sodtt_total_gst: item.sodtt_total_gst,
                            sodtt_total_discount: item.sodtt_total_discount,
                            sodtt_payment_status: item.sodtt_payment_status,
                            sodtt_transaction_id: item.sodtt_transaction_id,
                            sodtt_order_status: item.sodtt_order_status,
                            sodtt_sub_total: item.sodtt_sub_total,
                            sodtt_payment_method: item.sodtt_payment_method,
                            sodtt_billing_address: item.sodtt_billing_address,
                            sodtt_total_amount: item.sodtt_total_amount,
                            sodtt_delivery_date: item.sodtt_delivery_date,
                            sodtt_document_date: item.sodtt_document_date,
                            is_invoice_created: item.is_invoice_created,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            remarks: item.remarks,
                            created_date: item.created_date,
                            update_date: item.update_date,
                            inv_no:item.sodtt_invoice_number,
                            document_date:item.sodtt_document_date,
                        },
                        itemData: [],
                    };
                }

                // Create or update itemData
                const existingItem = acc[key].itemData.find((i: { item_id: any; }) => i.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,                       
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_sales_rate:item.item_batch_sales_rate,
                        from_bin_location:item.from_bin_location,
                        from_bin_id:item.from_bin_id,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_tax_percentage :item.item_batch_tax_percentage,
                        item_batch_tax_amount :item.item_batch_tax_amount,
                        item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                        item_batch_final_sales_rate:item.item_batch_final_sales_rate,

                    });
                } else {
                    acc[key].itemData.push({
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        sott_id:item.sott_id,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        is_item_invoice_created: item.is_item_invoice_created,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_uom:item.item_uom,
                        item_hsn :item.item_hsn,
                        item_manufacturer_id :item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,
                        item_free_quantity:item.item_free_quantity,
                        item_to_be_delivered:item.item_to_be_delivered,
                        itemBatchData: [{
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date: item.item_exp_date,                       
                            item_batch_purchase_rate:item.item_batch_final_sales_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            
                            from_bin_location:item.from_bin_location,
                            item_batch_sales_rate:item.item_batch_sales_rate,
                            from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate,

                            

                        }]
                    });
                }

                return acc;
            }, {});





            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);

            return resultArray

        } else {
            return []
        }

    } catch (error) {
        throw new Error(error)
    }
}

export async function addSalesOrderInvoice(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');
        const soit_id = ulid()
        orderData.soit_id = soit_id
        orderData.soit_order_status = 'open'
        orderData.soit_due_amount = orderData.soit_total_amount
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO sales_order_invoice_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        console.log(orderResult.rows)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                soit_id: soit_id,
                item_credit_quanity_remaining: item.item_quantity
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)


            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sales_order_invoice_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;



            // console.log(query)
            const itemResult = await client.query(query);


            if (itemResult.rows.length > 0) {
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    soit_id: soit_id,
                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO sales_order_invoice_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);



                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                 console.log(inventoryGLAccount,"ffffffff")

                let transcation_id = ulid()
                const revenue_account_obj = {
                    account_id: salesAccount.rows[0].revenue_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.soit_sub_total,
                }

                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.soit_total_gst,

                }


                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: orderData.soit_total_amount,
                    credit_amount: 0,
                }


                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "Sales IN",
                    origin_id:orderData.soit_invoice_number ,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [revenue_account_obj, tax_account_obj, customer_account_obj]
                if(itemData.some((item: any) => item.sott !== null)){
                    const  cos_goods_account_obj = {
                        account_id :inventoryGLAccount.rows[0].cost_of_goods_sold_account,
                        transcation_id:transcation_id,
                        debit_amount: orderData.soit_sub_total,
                        credit_amount  :0,
                      }
                      const inventory_account_obj = {
                        account_id :inventoryGLAccount.rows[0].inventory_account,
                        transcation_id: transcation_id,
                        debit_amount: 0,
                        credit_amount  :orderData.soit_sub_total,
                        
                    } 

                    journal_entry_array.push(cos_goods_account_obj,inventory_account_obj)
                }
               
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)


            }

            const [updateDelivery, updatesaleOrder, DeliveryDocuments] = await Promise.all([updateDeliveryData(newItemsData), updateSaleOrderData(newItemsData), insertDeliveryDocuments(newItemsData)])

            let order = orderResult.rows[0]
            let item = itemResult.rows

            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}
export async function insertDeliveryDocuments(itemData: any) {

    try {
        for (const item of itemData) {
            let { srt_id, sodtt_id, soit_id } = item;

            if (sodtt_id) {

                const insertObj = {
                    sodtt_id: sodtt_id,
                    srt_id: srt_id ||null,
                    soit_id: soit_id || null
                }

                console.log(insertObj)
                const columns = Object.keys(insertObj);
                const values = Object.values(insertObj);

                // Construct the parameterized query
                const insertdocumentquery = `INSERT INTO sale_order_delivery_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;

                let insertdocumentqueryResult = await client.query(insertdocumentquery, values);
            }
        }

    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}
export async function updateSalesOrderInvoice(orderData: any) {
    try {
        const { soit_id } = orderData
        const columnValuePairs = Object.entries(orderData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(orderData);

        const query = `
UPDATE sales_order_invoice_table
SET ${columnValuePairs}
WHERE soit_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, soit_id]);
        return result
    } catch (error) {
        throw new Error(error)
    }

}

export async function getSalesOrderInvoiceList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.soit_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM sales_order_invoice_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM sales_order_invoice_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSalesOrderInvoiceById(soit_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_order_invoice_table.*,
            sales_order_invoice_items_list.*,
            sales_order_invoice_items_batches_list.*
            FROM
            sales_order_invoice_table
            LEFT JOIN
            sales_order_invoice_items_list ON sales_order_invoice_table.soit_id = sales_order_invoice_items_list.soit_id
            LEFT JOIN 
            sales_order_invoice_items_batches_list ON sales_order_invoice_items_list.soit_id = sales_order_invoice_items_batches_list.soit_id
            AND  sales_order_invoice_items_list.item_id = sales_order_invoice_items_batches_list.item_id
            WHERE
            sales_order_invoice_table.soit_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [soit_id]);
        if (orderDetailsResult.rows.length > 0) {
            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.soit_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            soit_id: item.soit_id,
                            store_id: item.store_id,
                            cmr_id: item.cmr_id,
                            cmr_phone_number: item.cmr_phone_number,
                            soit_total_gst: item.soit_total_gst,
                            soit_total_discount: item.soit_total_discount,
                            soit_payment_status: item.soit_payment_status,
                            soit_transaction_id: item.soit_transaction_id,
                            soit_order_status: item.soit_order_status,
                            soit_payment_method: item.soit_payment_method,
                            soit_billing_address: item.soit_billing_address,
                            soit_total_amount: item.soit_total_amount,
                            soit_sub_total: item.soit_sub_total,
                            soit_delivery_date: item.soit_delivery_date,
                            soit_document_date: item.soit_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            remarks: item.remarks,
                            created_date: item.created_date,
                            update_date: item.update_date,
                            inv_no:item.soit_invoice_number,
                            document_date:item.soit_document_date
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((i: { item_id: any; }) => i.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,                       
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_unit_price:item.item_batch_unit_price,
                        from_bin_location:item.from_bin_location,
                       from_bin_id:item.from_bin_id,
                       item_batch_free_quantity:item.item_batch_free_quantity,
                       item_batch_discount_amount:item.item_batch_discount_amount,
                       item_batch_discount_percentage:item.item_batch_discount_percentage,
                       item_batch_tax_percentage :item.item_batch_tax_percentage,
                       item_batch_tax_amount :item.item_batch_tax_amount,
                       item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                       item_batch_final_sales_rate:item.item_batch_final_sales_rate,
                       item_batch_sales_rate:item.item_batch_sales_rate
                    });
                } else {
                    acc[key].itemData.push({
                        item_id: item.item_id,
                        sodtt_id: item.sodtt_id,
                        sott_id:item.sott_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        item_credit_quanity_remaining:item.item_credit_quanity_remaining,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_uom:item.item_uom,
                        item_hsn :item.item_hsn,
                        item_manufacturer_id :item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,
                        item_free_quantity:item.item_free_quantity,
                        item_to_be_delivered:item.item_to_be_delivered,
                        itemBatchData: [{
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date: item.item_exp_date,                       
                            item_batch_purchase_rate:item.item_batch_final_sales_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            from_bin_location:item.from_bin_location,
                           from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate,
                           item_batch_sales_rate:item.item_batch_sales_rate,

                        }]
                    });
                }

                return acc;
            }, {});



            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            return resultArray

        } else {

            return []
        }


    } catch (error) {
        throw new Error(error)
    }
}

export async function getDeliveryVendorDetails(sodtt_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
         
            sales_order_delivery_transaction_table.cmr_id,
            sales_order_delivery_transaction_table.cmr_code,
            sales_order_delivery_transaction_table.cmr_name
            FROM
            sales_order_delivery_transaction_table
            WHERE
            sales_order_delivery_transaction_table.sodtt_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sodtt_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSaleReturnVendorDetails(srt_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
         
            sales_return_table.cmr_id,
            sales_return_table.cmr_code,
            sales_return_table.cmr_name
            FROM
            sales_return_table
            WHERE
            sales_return_table.srt_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [srt_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}

export async function addSalesReturnInvoice(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');
        const srt_id = ulid()
        orderData.srt_id = srt_id
        orderData.srt_order_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO sales_return_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                srt_id: srt_id,
                item_credit_quanity_remaining: item.item_quantity
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sales_return_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemListResult = await client.query(query);



            if (itemListResult.rows.length > 0) {
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    srt_id: srt_id
                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO sales_return_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);

                console.log(orderData, newItemsData)

                let order = orderResult.rows[0]
                let item = itemListResult.rows
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
                const revenue_account_obj = {
                    account_id: salesAccount.rows[0].revenue_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.srt_sub_total,
                    credit_amount: 0,
                }

                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.srt_total_gst,
                    credit_amount: 0,

                }



                const customer_account_obj = {
                    account_id: "01HWN99B0D09TFZGXR5RFEB768",
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.srt_total_amount,
                }


                const inventory_account_obj = {
                    account_id: inventoryGLAccount.rows[0].inventory_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.srt_sub_total,
                    credit_amount: 0,

                }



                const cos_goods_account_obj = {
                    account_id: inventoryGLAccount.rows[0].cost_of_goods_sold_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.srt_sub_total,

                }

                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "sales return",
                    origin_id: orderData.srt_invoice_number ,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [inventory_account_obj, cos_goods_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)

                const updateDevliveryOrder = await Promise.all([updateDeliveryData(newItemsData), insertDeliveryDocuments(newItemsData)])
                await client.query('COMMIT');
                return { order, item }
            }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function getSaleReturnitemsList(query: any) {
    try {
        console.log(query)
        const { srt_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
                SELECT
                sales_return_items_list.*,
                sales_return_items_batches_list.*
                FROM
                sales_return_items_list
                JOIN 
                sales_return_items_batches_list ON sales_return_items_list.srt_id = sales_return_items_batches_list.srt_id 
                AND  sales_return_items_list.item_id = sales_return_items_batches_list.item_id
                WHERE
                sales_return_items_list.srt_id = $1
            `;

        const queryParams = [srt_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND sales_return_items_list.item_id = $2`;
            queryParams.push(item_id);
        }

        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}


export async function getReturnitemBatchData(query: any) {
    try {
        console.log(query)
        const { srt_id, item_id } = query;

        let GET_ORDER_DETAILS_QUERY = `
        SELECT
            sales_credit_items_list_table.*,
            sales_credit_items_batches_list.*
            FROM
            sales_credit_items_list_table
            LEFT JOIN 
            sales_credit_items_batches_list ON sales_credit_items_list_table.sct_id = sales_credit_items_batches_list.sct_id
            AND  sales_credit_items_list_table.item_id = sales_credit_items_batches_list.item_id
            WHERE
            sales_credit_items_list_table.srt_id = $1
    `;

const queryParams = [srt_id];

if (item_id) {
    GET_ORDER_DETAILS_QUERY += ` AND sales_credit_items_list_table.item_id = $2`;
    queryParams.push(item_id);
}

const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);

const returnorder = orderDetailsResult.rows
        return { returnorder}

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSalesReturnInvoiceList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.srt_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM sales_return_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM sales_return_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSalesReturnInvoiceById(srt_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_return_table.*,
            sales_return_items_list.*,
            sales_return_items_batches_list.*
            FROM
            sales_return_table
            LEFT JOIN
            sales_return_items_list ON sales_return_table.srt_id = sales_return_items_list.srt_id
            JOIN 
            sales_return_items_batches_list ON sales_return_items_list.srt_id = sales_return_items_batches_list.srt_id
            AND  sales_return_items_list.item_id = sales_return_items_batches_list.item_id
            WHERE
            sales_return_table.srt_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [srt_id]);
        if (orderDetailsResult.rows.length > 0) {

            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.srt_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            srt_id: item.srt_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            srt_total_gst: item.srt_total_gst,
                            srt_total_discount: item.srt_total_discount,
                            srt_payment_status: item.srt_payment_status,
                            srt_transaction_id: item.srt_transaction_id,
                            srt_order_status: item.srt_order_status,
                            srt_payment_method: item.srt_payment_method,
                            srt_billing_address: item.srt_billing_address,
                            srt_total_amount: item.srt_total_amount,
                            srt_sub_total: item.srt_sub_total,
                            srt_delivery_date: item.srt_delivery_date,
                            srt_document_date: item.srt_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            remarks: item.remarks,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((i: { item_id: any; }) => i.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,                       
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_unit_price:item.item_batch_unit_price,
                        from_bin_location:item.from_bin_location,
                       from_bin_id:item.from_bin_id,
                       item_batch_free_quantity:item.item_batch_free_quantity,
                       item_batch_discount_amount:item.item_batch_discount_amount,
                       item_batch_discount_percentage:item.item_batch_discount_percentage,
                       item_batch_tax_percentage :item.item_batch_tax_percentage,
                       item_batch_tax_amount :item.item_batch_tax_amount,
                       item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                       item_batch_final_sales_rate:item.item_batch_final_sales_rate,
                       item_batch_sales_rate:item.item_batch_sales_rate,
                    });
                } else {
                    acc[key].itemData.push({
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        sodtt_id: item.sodtt_id,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_uom:item.item_uom,
                        item_hsn :item.item_hsn,
                        item_manufacturer_id :item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,
                        item_free_quantity:item.item_free_quantity,
                        item_to_be_delivered:item.item_to_be_delivered,
                        itemBatchData: [{
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date: item.item_exp_date,                       
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            from_bin_location:item.from_bin_location,
                           from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate,
                           item_batch_sales_rate:item.item_batch_sales_rate,
                        }]
                    });
                }
                return acc;
            }, {});




            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            return resultArray
        } else {
            return []
        }

    } catch (error) {
        throw new Error(error)
    }
}

export async function addSalesCreditNote(orderData: any, itemData: any, itemBatchData: any) {
    try {
        await client.query('BEGIN');

        const sct_id = ulid()
        orderData.sct_id = sct_id
        orderData.sct_order_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO sales_credit_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                sct_id: sct_id
            }));
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const itemquery = `INSERT INTO sales_credit_items_list_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(itemquery);

            console.log(itemquery, "itemquery")

            if (itemResult.rows.length > 0) {
                console.log(itemBatchData)
                if (itemBatchData.length > 0) {
                    const newbBatchItemsData = itemBatchData.map((item: any) => ({
                        ...item,
                        sct_id: sct_id
                    }));
                    const itemColumns = Object.keys(newbBatchItemsData[0]);
                    // Extract values for each item in newItemsData
                    const itemValuesArray = newbBatchItemsData.map((item: any) =>
                        Object.values(item)
                    );

                    const valuesStrings = itemValuesArray.map((innerArray: any) =>
                        `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                    );

                    console.log(valuesStrings)

                    // Join the strings into a single string
                    const resultString = valuesStrings.join(', ');
                    //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                    const addbatchuery = `INSERT INTO sales_credit_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
                    console.log(addbatchuery, "addbatchuery")
                    const itemResult = await client.query(addbatchuery);
                }




                let order = orderResult.rows[0]
                let item = itemResult.rows
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
                const revenue_account_obj = {
                    account_id: salesAccount.rows[0].revenue_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.sct_sub_total,
                    credit_amount: 0,
                }

                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.sct_total_gst,
                    credit_amount: 0,

                }



                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.sct_total_amount,
                }


                const inventory_account_obj = {
                    account_id: inventoryGLAccount.rows[0].inventory_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.sct_sub_total,
                    credit_amount: 0,

                }



                const cos_goods_account_obj = {
                    account_id: inventoryGLAccount.rows[0].cost_of_goods_sold_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.sct_sub_total,

                }

                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "sales credit note ",
                    origin_id: orderData.sct_invoice_number,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [inventory_account_obj, cos_goods_account_obj, revenue_account_obj, customer_account_obj, tax_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)
                const updateSaleInvoice = await Promise.all([updateSaleInvoicefn(newItemsData), updateSaleReturnfn(newItemsData)])

                await client.query('COMMIT');
                return { order, item }
            }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updateSaleReturnfn(newItemsData: any) {
    try {
        await client.query('BEGIN');

        for (const item of newItemsData) {
            console.log("sssssss", item)

            let { item_id, srt_id, item_quantity, sct_id } = item;
            console.log(item_id, srt_id, typeof (item_quantity))

            if (srt_id) {
                const inserDocumentObj = {
                    srt_id: srt_id,
                    sct_id: sct_id
                }
                const updateQuery = `
UPDATE sales_return_items_list
SET item_credit_quanity_remaining = item_credit_quanity_remaining - $1
WHERE item_id = $2 AND srt_id = $3;
`;


                const [updateresult, inserDocumentObjResult] = await Promise.all([client.query(updateQuery, [item_quantity, item_id, srt_id]), insertSaleReturnDocument(inserDocumentObj)])
            }
            const checkStatusQuery = `SELECT * FROM sales_return_items_list WHERE  srt_id = $1`

            let checkStatusQueryResult = await client.query(checkStatusQuery, [srt_id]);

            let srt_order_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                const allDelivered = checkStatusQueryResult.rows.every(item => item.item_credit_quanity_remaining === 0);
                srt_order_status = allDelivered ? "closed" : "open";
            }
            const result = updateSalesReturnInvoicStatus(srt_order_status, srt_id)

        }
        await client.query('COMMIT')
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function insertSaleReturnDocument(insertObj: any) {

    try {

        console.log(insertObj)
        const columns = Object.keys(insertObj);
        const values = Object.values(insertObj);

        // Construct the parameterized query
        const insertdocumentidquery = `INSERT INTO sales_return_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        console.log(insertdocumentidquery, "ffffffffffff")
        let insertdocumentidqueryResult = await client.query(insertdocumentidquery, values);
        return insertdocumentidqueryResult

    } catch (error) {
        throw new Error(error)
    }

}

export async function updateSaleInvoicefn(newItemsData: any) {
    try {
        await client.query('BEGIN');

        for (const item of newItemsData) {
            console.log("sssssss", item)

            let { item_id, soit_id, item_quantity, sct_id } = item;
            console.log(item_id, soit_id, typeof (item_quantity))

            if (soit_id) {
                const inserDocumentObj = {
                    soit_id: soit_id,
                    sct_id: sct_id
                }
                const updateQuery = `
    UPDATE sales_order_invoice_items_list
    SET item_credit_quanity_remaining = item_credit_quanity_remaining - $1
    WHERE item_id = $2 AND soit_id = $3;
    `;


                const [updateresult, inserDocumentObjResult] = await Promise.all([client.query(updateQuery, [item_quantity, item_id, soit_id]), insertSaleInvoiceDocument(inserDocumentObj)])
            }

            const checkStatusQuery = `SELECT * FROM sales_order_invoice_items_list WHERE  soit_id = $1`

            let checkStatusQueryResult = await client.query(checkStatusQuery, [soit_id]);

            let soit_order_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                const allDelivered = checkStatusQueryResult.rows.every(item => item.item_credit_quanity_remaining === 0);
                soit_order_status = allDelivered ? "closed" : "open";
            }
            const result = updateSalesInvoiceStatus(soit_order_status, soit_id)

        }       

        
        await client.query('COMMIT')
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function insertSaleInvoiceDocument(insertObj: any) {

    try {

        console.log(insertObj)
        const columns = Object.keys(insertObj);
        const values = Object.values(insertObj);

        // Construct the parameterized query
        const insertdocumentidquery = `INSERT INTO sales_order_invoice_document_list (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        console.log(insertdocumentidquery, "ffffffffffff")
        let insertdocumentidqueryResult = await client.query(insertdocumentidquery, values);
        return insertdocumentidqueryResult

    } catch (error) {
        throw new Error(error)
    }

}

export async function getSalesCreditNoteList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.sct_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM sales_credit_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM sales_credit_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}

export async function getSalesCreditNoteById(sct_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_credit_table.*,
            sales_credit_items_list_table.*,
            sales_credit_items_batches_list.*
            FROM
            sales_credit_table
            LEFT JOIN
            sales_credit_items_list_table ON sales_credit_table.sct_id = sales_credit_items_list_table.sct_id
            LEFT JOIN 
            sales_credit_items_batches_list ON sales_credit_items_list_table.sct_id = sales_credit_items_batches_list.sct_id
            AND  sales_credit_items_list_table.item_id = sales_credit_items_batches_list.item_id
            WHERE
            sales_credit_table.sct_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sct_id]);
        if (orderDetailsResult.rows.length > 0) {
            console.log(orderDetailsResult.rows, "ssssss")
            const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                const key = item.sct_id;
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                            sct_id: item.sct_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            sct_total_gst: item.sct_total_gst,
                            sct_total_discount: item.sct_total_discount,
                            sct_payment_status: item.sct_payment_status,
                            sct_transaction_id: item.sct_transaction_id,
                            sct_order_status: item.sct_order_status,
                            sct_payment_method: item.sct_payment_method,
                            sct_billing_address: item.sct_billing_address,
                            sct_total_amount: item.sct_total_amount,
                            sct_sub_total: item.sct_sub_total,
                            sct_delivery_date: item.sct_delivery_date,
                            sct_document_date: item.sct_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            remarks: item.remarks,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((i: { item_id: any; }) => i.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,                       
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_unit_price:item.item_batch_unit_price,
                        from_bin_location:item.from_bin_location,
                       from_bin_id:item.from_bin_id,
                       item_batch_free_quantity:item.item_batch_free_quantity,
                       item_batch_discount_amount:item.item_batch_discount_amount,
                       item_batch_discount_percentage:item.item_batch_discount_percentage,
                       item_batch_tax_percentage :item.item_batch_tax_percentage,
                       item_batch_tax_amount :item.item_batch_tax_amount,
                       item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                       item_batch_final_sales_rate:item.item_batch_final_sales_rate,
                       item_batch_sales_rate:item.item_batch_sales_rate,
                    });
                } else {
                    acc[key].itemData.push({
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        srt_id: item.srt_id,
                        soit_id: item.soit_id,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_uom:item.item_uom,
                        item_hsn :item.item_hsn,
                        item_manufacturer_id :item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,
                        item_free_quantity:item.item_free_quantity,
                        item_to_be_delivered:item.item_to_be_delivered,
                        itemBatchData: [{
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date: item.item_exp_date,                       
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            from_bin_location:item.from_bin_location,
                           from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate,
                           item_batch_sales_rate:item.item_batch_sales_rate,
                        }]
                    });
                }

                return acc;
            }, {});




            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            //console.log(resultArray,"ddd", resultArray['orderData'])

            return resultArray

        } else {
            return []
        }

    } catch (error) {
        throw new Error(error)
    }
}


export async function updateSalesOrderData(orderData: any, sott_id: any) {
    try {
        await client.query('BEGIN');
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_order_transaction_table
        SET ${updateOrderFields}      
        WHERE sott_id = $1
        RETURNING *;
      `;

        // Execute the updateSalesOrderQuery and get the result
        const salesOrderResult = await client.query(updateSalesOrderQuery, [sott_id, ...orderValues]);
        return salesOrderResult

    } catch (error) {
        await client.query('ROLLBACK');

        throw new Error(error)
    }
}



export async function existingItemsResult(sott_id: any) {
    try {
        const fetchItemsQuery = `
        SELECT * FROM sales_order_items_list
        WHERE sott_id = $1;
        `;

        const existingItemsResult = await client.query(fetchItemsQuery, [sott_id])
        return existingItemsResult

    } catch (error) {
        throw new Error(error)
    }
}



export async function updatedItem(updatedItem: any, sott_id: any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .filter(([columnName]) => columnName !== 'sott_id' && columnName !== 'item_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE sales_order_items_list
        SET ${itemFields}
        WHERE sott_id = '${sott_id}' AND item_id = '${updatedItem.item_id}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}



export async function removeItem(sott_id: any, item_id: any) {
    try {
        const removeItemQuery = `
DELETE FROM sales_order_items_list
WHERE sott_id = $1 AND item_id = $2
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [sott_id, item_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}


export async function addItem(newItem: any) {
    try {
        newItem.item_to_be_delivered = newItem.item_quantity
        const columns = Object.keys(newItem);
        const values = Object.values(newItem);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO sales_order_items_list (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        // Execute the query with parameterized values
        const addItemResult = await client.query(insertQuery, values);
        return addItemResult

    } catch (error) {
        throw new Error(error)
    }
}


export async function getInvoiceitemsList(query: any) {
    try {
        console.log(query)
        const { soit_id, item_id } = query;
        let GET_ORDER_DETAILS_QUERY = `
                SELECT
                sales_order_invoice_items_list.*,
                sales_order_invoice_items_batches_list.*
                FROM
                sales_order_invoice_items_list
                LEFT JOIN
                sales_order_invoice_items_batches_list ON sales_order_invoice_items_list.soit_id = sales_order_invoice_items_batches_list.soit_id
                AND sales_order_invoice_items_list.item_id = sales_order_invoice_items_batches_list.item_id
                WHERE
                sales_order_invoice_items_list.soit_id = $1
            `;

        const queryParams = [soit_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND sales_order_invoice_items_list.item_id = $2`;
            queryParams.push(item_id);
        }

        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function getReturnInvoiceitemBatchData(query: any) {
    try {
        console.log(query)
        const { soit_id, item_id } = query;

        let GET_ORDER_DETAILS_QUERY = `
        SELECT
            sales_credit_items_list_table.*,
            sales_credit_items_batches_list.*
            FROM
            sales_credit_items_list_table
            LEFT JOIN 
            sales_credit_items_batches_list ON sales_credit_items_list_table.sct_id = sales_credit_items_batches_list.sct_id
            AND  sales_credit_items_list_table.item_id = sales_credit_items_batches_list.item_id
            WHERE
            sales_credit_items_list_table.soit_id = $1
    `;

const queryParams = [soit_id];

if (item_id) {
    GET_ORDER_DETAILS_QUERY += ` AND sales_credit_items_list_table.item_id = $2`;
    queryParams.push(item_id);
}

const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);

const returnorder = orderDetailsResult.rows
        return { returnorder}

    } catch (error) {
        throw new Error(error)
    }
}


export async function getInvoiceVendorDetails(soit_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_order_invoice_table.cmr_id,
            sales_order_invoice_table.cmr_code,
            sales_order_invoice_table.cmr_name
            FROM
            sales_order_invoice_table
            WHERE
            sales_order_invoice_table.soit_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [soit_id]);

        return orderDetailsResult.rows

    } catch (error) {
        throw new Error(error)
    }
}


export async function updateSalesReturnInvoice(orderData: any) {
    try {
        const { srt_id } = orderData
        const columnValuePairs = Object.entries(orderData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(orderData);

        const query = `
UPDATE sales_return_table
SET ${columnValuePairs}
WHERE srt_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, srt_id]);
        return result
    } catch (error) {
        throw new Error(error)
    }

}



export async function updateSalesCreditInvoice(orderData: any) {
    try {
        const { sct_id } = orderData
        const columnValuePairs = Object.entries(orderData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(orderData);

        const query = `
UPDATE sales_credit_table
SET ${columnValuePairs}
WHERE sct_id = $${Object.keys(orderData).length + 1}
RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, sct_id]);
        return result
    } catch (error) {
        throw new Error(error)
    }

}


export async function voidDeliveryOrder(sodtt_order_status: any, sodtt_id: any) {
    try {
        const updatestatusQuery = `UPDATE sales_order_delivery_transaction_table
        SET sodtt_order_status = $1 WHERE  sodtt_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [sodtt_order_status, sodtt_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}


export async function updateDeliveryData(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery
            const { sodtt_id, item_quantity, item_id, soit_id, srt_id } = item
            if (sodtt_id && soit_id) {
                updateQuery = `
        UPDATE sale_order_delivery_items_list
        SET item_to_be_delivered =item_to_be_delivered - $1
        WHERE item_id = $2 AND sodtt_id = $3;
        `;
            }
            if (sodtt_id && srt_id) {
                updateQuery = `
            UPDATE sale_order_delivery_items_list
            SET item_to_be_delivered =item_to_be_delivered - $1 
            WHERE item_id = $2 AND sodtt_id = $3;`
            }
            if (updateQuery) {
                const updateresult = await client.query(updateQuery, [item_quantity, item_id, sodtt_id]);

            } 

            const checkStatusQuery = `SELECT * FROM sale_order_delivery_items_list WHERE  sodtt_id = $1`

            let checkStatusQueryResult = await client.query(checkStatusQuery, [sodtt_id]);

            let sodtt_order_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                const allDelivered = checkStatusQueryResult.rows.every(item => item.item_to_be_delivered === 0);
                sodtt_order_status = allDelivered ? "closed" : "open";
            }
            const result = updateDeliveryOrderStatus(sodtt_order_status, sodtt_id)

        }



    } catch (error) {

        throw new Error(error)
    }



}

export async function getdocumentsListofSalesOrder(sott_id: any) {
    try {

        const query = `
        SELECT sales_order_document_list.*,sales_order_delivery_transaction_table.sodtt_invoice_number,sales_order_invoice_table.soit_id
        FROM
        sales_order_document_list
        LEFT JOIN 
        sales_order_delivery_transaction_table ON  sales_order_document_list.sodtt_id = sales_order_delivery_transaction_table.sodtt_id
        LEFT JOIN 
        sales_order_invoice_table ON  sales_order_document_list.soit_id = sales_order_invoice_table.soit_id
        WHERE
        sales_order_document_list.sott_id = $1;`;

        const result = await client.query(query, [sott_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function insertCancelOrder(orderData: any, itemData: any) {
    try {

        const sott_id = ulid()
        orderData.sott_id = sott_id
        orderData.sott_invoice_number = await nextInvoicenumber.getSaleOrderNextInvoiceNumber()
        orderData.sott_order_status = 'cancelled'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        console.log(columns, values, "cancelled")
        // Construct the parameterized query
        const query = `INSERT INTO sales_order_transaction_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
            console.log(itemData)
            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;

                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });

                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    sott_id: sott_id,
                };
            });

       
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );
            // console.log(itemValuesArray)

            // Flatten the array of values
            // const itemValues = itemValuesArray.flat();

            //            const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //   `(${innerArray.map((value: any) => (typeof value === 'string' || typeof value === 'object') ? `'${value}'` : value).join(', ')})`
            // );
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)



            console.log()
            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sales_order_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);

            let order = orderResult.rows[0]
            let item = itemResult.rows

            return { order, item }
        }
    } catch (error) {

        throw new Error(error)
    }
}

export async function getdocumentsListofDeliveryOrder(sodtt_id: any) {
    try {

        const query = `
        SELECT sale_order_delivery_document_list.*,sales_return_table.srt_invoice_number,sales_order_invoice_table.soit_invoice_number
        FROM
        sale_order_delivery_document_list
        LEFT JOIN 
        sales_return_table ON  sale_order_delivery_document_list.srt_id = sales_return_table.srt_id
        LEFT JOIN 
        sales_order_invoice_table ON  sale_order_delivery_document_list.soit_id = sales_order_invoice_table.soit_id
        WHERE
        sale_order_delivery_document_list.sodtt_id = $1;`;

        const result = await client.query(query, [sodtt_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateDeliveryOrderStatus(sodtt_order_status: any, sodtt_id: any) {
    try {
        const updatestatusQuery = `UPDATE sales_order_delivery_transaction_table
                    SET sodtt_order_status = $1 WHERE  sodtt_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [sodtt_order_status, sodtt_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}


export async function insertCancelDeliveryOrder(orderData: any, itemData: any,) {
    try {
        await client.query('BEGIN');
        const sodtt_id = ulid()
        orderData.sodtt_id = sodtt_id
        orderData.sodtt_order_status = 'cancelled'
        orderData.sodtt_invoice_number =  await nextInvoicenumber.getSalesDeliveryNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO sales_order_delivery_transaction_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)
        console.log(orderData.sodtt_invoice_number)
        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;

                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });

                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    sodtt_id: sodtt_id,
                };
            });




            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings, itemColumns, "eeeee")

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sale_order_delivery_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);

            const extractedBatchData: any = []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array

                if (Array.isArray(item.itemBatchData)) {
                    // Push each itemBatchData object into the extractedBatchData array
                    item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                    });
                }
            });


            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };
                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        sodtt_id: sodtt_id,
                        item_exp_date: formatDateString(item.item_exp_date),
                    };
                });
                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO sale_order_delivery_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);

                console.log(orderData, newItemsData)
                const updateInventory = await updateStoreInventor(newBatchItemsData, 'add')

            }
            //   const updateSalesOrderData = await updateSaleOrderData(newItemsData)
            let order = orderResult.rows[0]
            let item = itemResult.rows
            const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

            let transcation_id = ulid()

            const inventory_account_obj = {
                account_id: inventoryGLAccount.rows[0].inventory_account,
                transcation_id: transcation_id,
                debit_amount: orderData.sodtt_sub_total,
                credit_amount: 0,

            }



            const cos_goods_account_obj = {
                account_id: inventoryGLAccount.rows[0].cost_of_goods_sold_account,
                transcation_id: transcation_id,
                debit_amount: 0,
                credit_amount: orderData.sodtt_sub_total,

            }

            const journal_entry_obj = {
                transcation_id: transcation_id,
                origin_type: "DN",
                origin_id:orderData.sodtt_invoice_number,
                journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

            }
            const journal_entry_array = [inventory_account_obj, cos_goods_account_obj]
            await financialLegder.addJournalEntry(journal_entry_obj)
            await financialLegder.addJournalEntryRow(journal_entry_array)
            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
        console.log(error)
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function getdocumentsListofInvoice(soit_id: any) {
    try {

        const query = `
        SELECT sales_order_invoice_document_list.*,sales_credit_table.sct_invoice_number
        FROM
        sales_order_invoice_document_list
        LEFT JOIN 
        sales_credit_table ON  sales_order_invoice_document_list.sct_id = sales_credit_table.sct_id
        WHERE
        sales_order_invoice_document_list.soit_id = $1;`;
        console.log(soit_id)
        const result = await client.query(query, [soit_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}


export async function insertCancelInvoice(orderData: any, itemData: any) {
    try {
        await client.query('BEGIN');
        const soit_id = ulid()
        orderData.soit_id = soit_id
        orderData.soit_order_status = 'cancelled'

        orderData.soit_invoice_number =  await nextInvoicenumber.getSalesInvoiceNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);

        // Construct the parameterized query
        const query = `INSERT INTO sales_order_invoice_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;

                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });

                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    soit_id: soit_id,
                    item_credit_quanity_remaining: item.item_quantity
                };
            });


            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)


            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sales_order_invoice_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

            const extractedBatchData: any = []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array

                if (Array.isArray(item.itemBatchData)) {
                    // Push each itemBatchData object into the extractedBatchData array
                    item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                    });
                }
            });

            // console.log(query)
            const itemResult = await client.query(query);


            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };

                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        soit_id: soit_id,
                        item_exp_date: formatDateString(item.item_exp_date),
                    };
                });

                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO sales_order_invoice_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);



                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])


                let transcation_id = ulid()
                const revenue_account_obj = {
                    account_id: salesAccount.rows[0].revenue_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.soit_sub_total,
                    credit_amount: 0,
                }

                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.soit_total_gst,
                    credit_amount: 0,

                }


                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.soit_total_amount,
                }


                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "Sales IN",
                    origin_id:orderData.soit_invoice_number ,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [revenue_account_obj, tax_account_obj, customer_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)


            }



            let order = orderResult.rows[0]
            let item = itemResult.rows

            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updateSalesInvoiceStatus(soit_order_status: any, soit_id: any) {
    try {
        const updatestatusQuery = `UPDATE sales_order_invoice_table
                    SET soit_order_status = $1 WHERE  soit_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [soit_order_status, soit_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}


export async function insertCancelCreditNote(orderData: any, itemData: any) {
    try {
        await client.query('BEGIN');

        const sct_id = ulid()
        orderData.sct_id = sct_id
        orderData.sct_order_status = 'cancelled'
        orderData.sct_invoice_number = await nextInvoicenumber.getSalesCreditNoteNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO sales_credit_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;

                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });

                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    sct_id: sct_id
                };
            });




            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const itemquery = `INSERT INTO sales_credit_items_list_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(itemquery);
            const extractedBatchData: any = []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array

                if (Array.isArray(item.itemBatchData)) {
                    // Push each itemBatchData object into the extractedBatchData array
                    item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                    });
                }
            });

            console.log(itemquery, "itemquery")

            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };

                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        sct_id: sct_id,
                        item_exp_date: formatDateString(item.item_exp_date),
                    };
                });

                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const addbatchuery = `INSERT INTO sales_credit_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
                console.log(addbatchuery, "addbatchuery")
                const itemResult = await client.query(addbatchuery);
            }




            let order = orderResult.rows[0]
            let item = itemResult.rows
            const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

            let transcation_id = ulid()
            const revenue_account_obj = {
                account_id: salesAccount.rows[0].revenue_account,
                transcation_id: transcation_id,
                debit_amount: 0,
                credit_amount: orderData.sct_sub_total,
            }

            const tax_account_obj = {
                account_id: inventoryGLAccount.rows[0].tax_account,
                transcation_id: transcation_id,
                debit_amount: 0,
                credit_amount: orderData.sct_total_gst,

            }



            const customer_account_obj = {
                account_id: orderData.cmr_id,
                transcation_id: transcation_id,
                debit_amount: orderData.sct_total_amount,
                credit_amount: 0,
            }


            const inventory_account_obj = {
                account_id: inventoryGLAccount.rows[0].inventory_account,
                transcation_id: transcation_id,
                debit_amount: 0,
                credit_amount: orderData.sct_sub_total,

            }



            const cos_goods_account_obj = {
                account_id: inventoryGLAccount.rows[0].cost_of_goods_sold_account,
                transcation_id: transcation_id,
                debit_amount: orderData.sct_sub_total,
                credit_amount: 0,

            }

            const journal_entry_obj = {
                transcation_id: transcation_id,
                origin_type: "sales credit note ",
                origin_id:orderData.sct_invoice_number ,
                journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

            }
            const journal_entry_array = [inventory_account_obj, cos_goods_account_obj, revenue_account_obj, customer_account_obj, tax_account_obj]
            await financialLegder.addJournalEntry(journal_entry_obj)
            await financialLegder.addJournalEntryRow(journal_entry_array)
            await client.query('COMMIT');
            return { order, item }
        }

    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}


export async function deleteCreditNote(sct_id: any) {
    try {
        const deleteFromInvoiceDocument = `DELETE FROM sales_order_invoice_document_list  WHERE sales_order_invoice_document_list.sct_id =$1`;
        const deleteFromReturnDocument = `DELETE FROM sales_return_document_list  WHERE sales_return_document_list.sct_id =$1`;
        let updateStatus = await Promise.all([client.query(deleteFromInvoiceDocument, [sct_id]), client.query(deleteFromReturnDocument, [sct_id])])
        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function updateSalesCreditNoteStatus(sct_order_status: any, sct_id: any) {
    try {
        const updatestatusQuery = `UPDATE sales_credit_table
                    SET sct_order_status = $1 WHERE  sct_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [sct_order_status, sct_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}


export async function deleteInvoiceDocumentlist(soit_id: any) {
    try {
        const deleteFromSaleOrderDocumentQuery = `DELETE FROM sales_order_document_list  WHERE sales_order_document_list.soit_id =$1`;
        const deleteFromDeliveryDocumentOuery = `DELETE FROM sale_order_delivery_document_list  WHERE sale_order_delivery_document_list.soit_id =$1`;

        const results = await Promise.all([client.query(deleteFromSaleOrderDocumentQuery, [soit_id]), client.query(deleteFromDeliveryDocumentOuery, [soit_id])])
        return results
    } catch (error) {
        throw new Error(error)
    }

}


export async function deleteSalesDocumentlist(sodtt_id: any) {
    try {
        const updatestatusQuery = `DELETE FROM sales_order_document_list  WHERE sales_order_document_list.sodtt_id =$1`;
        let updateStatus = await client.query(updatestatusQuery, [sodtt_id]);
        return updateStatus

    } catch (error) {
        throw new Error(error)
    }

}

export async function insertCancelReturnInvoice(orderData: any, itemData: any) {
    try {
        await client.query('BEGIN');
        const srt_id = ulid()
        orderData.srt_id = srt_id
        orderData.srt_order_status = 'cancelled'
        orderData.srt_invoice_number =  await nextInvoicenumber.getSalesReturnNextInvoiceNumber()
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);


        // Construct the parameterized query
        const query = `INSERT INTO sales_return_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, item_mfg_date, ...rest } = item;

                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });

                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    srt_id: srt_id
                };
            });


            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO sales_return_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemListResult = await client.query(query);

            const extractedBatchData: any = []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array

                if (Array.isArray(item.itemBatchData)) {
                    // Push each itemBatchData object into the extractedBatchData array
                    item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                    });
                }
            });

            if (itemListResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };
                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        srt_id: srt_id,
                        item_exp_date: formatDateString(item.item_exp_date),
                        
                    };
                });

                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO sales_return_items_batches_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);

                console.log(orderData, newItemsData)

                let order = orderResult.rows[0]
                let item = itemListResult.rows
                const [generalAccount, salesAccount, inventoryGLAccount] = await Promise.all([financialLegder.generalGLAccount(), financialLegder.salesGLAccount(), financialLegder.inventoryGLAccount()])

                let transcation_id = ulid()
                const revenue_account_obj = {
                    account_id: salesAccount.rows[0].revenue_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.srt_sub_total,
                }

                const tax_account_obj = {
                    account_id: inventoryGLAccount.rows[0].tax_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.srt_total_gst,

                }



                const customer_account_obj = {
                    account_id: orderData.cmr_id,
                    transcation_id: transcation_id,
                    debit_amount: orderData.srt_total_amount,
                    credit_amount: 0,
                }


                const inventory_account_obj = {
                    account_id: inventoryGLAccount.rows[0].inventory_account,
                    transcation_id: transcation_id,
                    debit_amount: 0,
                    credit_amount: orderData.srt_sub_total,

                }



                const cos_goods_account_obj = {
                    account_id: inventoryGLAccount.rows[0].cost_of_goods_sold_account,
                    transcation_id: transcation_id,
                    debit_amount: orderData.srt_sub_total,
                    credit_amount: 0,

                }

                const journal_entry_obj = {
                    transcation_id: transcation_id,
                    origin_type: "sales return",
                    origin_id: orderData.srt_invoice_number,
                    journal_entry_no: Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000

                }
                const journal_entry_array = [inventory_account_obj, cos_goods_account_obj]
                await financialLegder.addJournalEntry(journal_entry_obj)
                await financialLegder.addJournalEntryRow(journal_entry_array)


                await client.query('COMMIT');
                return { order, item }
            }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updateSalesReturnInvoicStatus(srt_order_status: any, srt_id: any) {
    try {
        const updatestatusQuery = `UPDATE sales_return_table
                    SET srt_order_status = $1 WHERE  srt_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [srt_order_status, srt_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function deleteSaleReturnDocument(srt_id: any) {
    try {
        const updatestatusQuery = `DELETE FROM sale_order_delivery_document_list  WHERE sale_order_delivery_document_list.srt_id =$1`;
        let updateStatus = await client.query(updatestatusQuery, [srt_id]);
        return updateStatus

    } catch (error) {
        throw new Error(error)
    }

}

export async function getdocumentsListofReturn(srt_id: any) {
    try {

        const query = `
        SELECT sales_return_document_list.*,sales_credit_table.sct_invoice_number
        FROM
        sales_return_document_list
        LEFT JOIN 
        sales_credit_table ON  sales_return_document_list.sct_id = sales_credit_table.sct_id
        WHERE
        sales_return_document_list.srt_id = $1;`;
        console.log(srt_id)
        const result = await client.query(query, [srt_id]);
        return result

    } catch (error) {
        throw new Error(error)
    }
}


export async function resetCreditOpenQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            const { item_quantity, soit_id, srt_id, item_id } = item
            let updateQuery
            const values = []
          
            
            if (srt_id) {
                updateQuery = `
        UPDATE sales_return_items_list
        SET item_credit_quanity_remaining =item_credit_quanity_remaining + $1
        WHERE item_id = $2 AND srt_id = $2;
        `;
                values.push(item_quantity, item_id, srt_id)
                let srt_order_status = 'open'
                updateSalesReturnInvoicStatus(srt_order_status,srt_id)

            }
            if (soit_id) {
                updateQuery = `
            UPDATE sales_order_invoice_items_list
            SET item_credit_quanity_remaining = item_credit_quanity_remaining + $1 
            WHERE item_id = $2 AND soit_id = $3;`

                values.push(item_quantity, item_id, soit_id)
                let soit_order_status = "open"
                updateSalesInvoiceStatus(soit_order_status,soit_id)

            }
            console.log(updateQuery,values,item_quantity, soit_id, srt_id, item_id)
            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);

            } 

        }

    } catch (error) {

        throw new Error(error)
    }



}

export async function resetSaleReturnQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery

            const { item_quantity, sodtt_id, item_id } = item
            const values = []
            if (sodtt_id) {
                updateQuery = `
        UPDATE sale_order_delivery_items_list
        SET item_to_be_delivered =item_to_be_delivered + $1
        WHERE item_id = $2 AND sodtt_id = $3;
        `;
                values.push(item_quantity, item_id, sodtt_id)
                

            }

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);
                let sodtt_order_status = 'open'
                const updateStatus =   await updateDeliveryOrderStatus(sodtt_order_status,sodtt_id)

            } 

        }

    } catch (error) {

        throw new Error(error)
    }



}



export async function resetInvoiceOpenQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery
            const values = []
            const { item_quantity, sott_id, sodtt_id, item_id } = item
            if (sott_id !=='null'&& sott_id !== '' ) {
                updateQuery = `
        UPDATE sales_order_items_list
        SET item_to_be_delivered =item_to_be_delivered + $1
        WHERE item_id = $2 AND sott_id = $3;
        `;
                values.push(item_quantity, item_id, sott_id)
                let sott_order_status = 'open'
                const updatestatusofSaleOrder =  await  updateSaleOrderStatus(sott_order_status, sott_id)    

            }
            if (sodtt_id !=='null'&& sodtt_id !== '' ) {
                updateQuery = `
            UPDATE sale_order_delivery_items_list
            SET item_to_be_delivered = item_to_be_delivered + $1 
            WHERE item_id = $2 AND sodtt_id = $3;`

                values.push(item_quantity, item_id, sodtt_id)
                let sodtt_order_status = 'open'
             const updateStatus =   await updateDeliveryOrderStatus(sodtt_order_status,sodtt_id)

            }
            if (updateQuery) {
                console.log(values)
                const updateresult = await client.query(updateQuery, values);

            } 

        }

    } catch (error) {

        throw new Error(error)
    }



}



export async function resetDeliveryOpenQuantity(itemData: any) {
    try {

        for (let item of itemData) {
            let updateQuery

            const { item_quantity, sott_id, item_id } = item
       let  sott_order_status = "open"
       
            const values = []
            if (sott_id) {
                updateQuery = `
        UPDATE sales_order_items_list
        SET item_to_be_delivered =item_to_be_delivered + $1
        WHERE item_id = $2 AND sott_id = $3;
        `;
                values.push(item_quantity, item_id, sott_id)

            }
            console.log(values,"eeee")

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);
                const updatestatusofSaleOrder =  await  updateSaleOrderStatus(sott_order_status, sott_id)

            } 

        }

    } catch (error) {

        throw new Error(error)
    }



}


export async function updateInvoiceItemAmount(paymentData:any){
    try {


        for (let payment of paymentData) {
            let updateQuery

            const { pdt_current_payment, soit_id } = payment
      
            const values = []
            if (soit_id) {
                updateQuery = `
        UPDATE sales_order_invoice_table
        SET soit_due_amount = soit_due_amount - $1
        WHERE  soit_id = $2;
        `;
                values.push(pdt_current_payment,soit_id)
                console.log(updateQuery,)

            }
            console.log(values,"eeee")

            if (updateQuery) {
                const updateresult = await client.query(updateQuery, values);
               

            } 
            const checkStatusQuery = `SELECT * FROM sales_order_invoice_table WHERE  soit_id = $1`

            let checkStatusQueryResult = await client.query(checkStatusQuery, [soit_id]);

            let soit_order_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                let allpayed = false
           console.log(checkStatusQueryResult.rows,"allpayed")
                if(parseInt(checkStatusQueryResult.rows[0].soit_due_amount)===0){
                    allpayed = true
                }
                console.log(allpayed,"allpayed")
                soit_order_status = allpayed ? "closed" : "open";
                console.log(soit_order_status,"soit_order_status")
            }
            const result = updateSalesInvoiceStatus(soit_order_status, soit_id)



        }

        
    } catch (error) {

        throw new Error(error)
    }

}





export async function getSalesInvoiceList(soit_id: any) {
    try {

        const query = `
        SELECT sales_order_invoice_table.*
        FROM
        sales_order_invoice_table
        WHERE
        sales_order_invoice_table.soit_id = $1;`;
        console.log(soit_id,"rrrrr")
        const result = await client.query(query, [soit_id]);
        console.log(result.rows,"eee")
        return result

    } catch (error) {
        throw new Error(error)
    }
}


export async function getSalesInvoiceListSearch(query: any) {
    try {
        const { sortfield, sortValue, field, value } = query;

        let whereClause = `so.soit_order_status = 'open'`;

        // Add sorting to the ORDER BY clause if needed
        let orderByClause = '';
        if (sortfield && sortValue) {
            orderByClause = `ORDER BY c.${sortfield} = ${sortValue}`;
        }

        // Add search condition for the specified column
        const searchCondition = field
            ? `AND (LOWER(c.${field}) ILIKE LOWER('%${value}%'))`
            : '';

        const totalOrderValueQuery = `
            SELECT
                c.*,
                so.*
            FROM
                customer_details AS c
            LEFT JOIN
                sales_order_invoice_table AS so ON c.cmr_id = so.cmr_id
            WHERE
                ${whereClause} ${searchCondition}
                ${orderByClause}
        `;

        console.log(totalOrderValueQuery); // For debugging purposes

        const result = await client.query(totalOrderValueQuery);
        console.log(result.rows); // For debugging purposes

        return result

    } catch (error) {
        console.error('Error in getSalesInvoiceListSearch:', error);
        throw new Error('Failed to fetch sales invoice list.'); // You can customize the error message as needed
    }
}


export async function getOpenBalanceOfCMR(account_id: any) {
    try {
        
       console.log()

        const getCMROpenBalanceQuery = `
            SELECT
            gl.cmr_open_balance
            FROM
            general_accounts_table AS gl
            WHERE
            account_id = $1 
        `;

        const result = await client.query(getCMROpenBalanceQuery,[account_id]);
        console.log(result.rows,"ddd",account_id); // For debugging purposes
   
        return result

    } catch (error) {
        console.error('Error in getSalesInvoiceListSearch:', error);
        throw new Error('Failed to fetch sales invoice list.'); // You can customize the error message as needed
    }
}



export async function getUnSyncedSalesOrder() {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_order_transaction_table.*,
            sales_order_items_list.*
            FROM
            sales_order_transaction_table
            LEFT JOIN
            sales_order_items_list ON sales_order_transaction_table.sott_id = sales_order_items_list.sott_id
            WHERE
            sales_order_transaction_table.data_synced = false
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
    
         return orderDetailsResult
    } catch (error) {
        throw new Error(error)
    }
}

export async function syncSalesOrder(orderData: any, itemData: any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "transaction_type":"sales_order"
        }
    
    }

   // console.log(req,"34562345")
   
        socket.emit('salesOrderSync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}

export async function syncSalesOrderDataResult(orderData: any, sott_id: any) {
    try {
        delete orderData.itt_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_order_transaction_table
        SET ${updateOrderFields}
        WHERE sott_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [sott_id, ...orderValues]);
     //   console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}



export async function getUnSyncedSaleDelivery() {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            sales_order_delivery_transaction_table.*,
            sale_order_delivery_items_list.*,
            sale_order_delivery_items_batches_list.*
            FROM
            sales_order_delivery_transaction_table
            LEFT JOIN
            sale_order_delivery_items_list ON sales_order_delivery_transaction_table.sodtt_id = sale_order_delivery_items_list.sodtt_id 
            LEFT JOIN 
            sale_order_delivery_items_batches_list ON sale_order_delivery_items_list.sodtt_id = sale_order_delivery_items_batches_list.sodtt_id
			AND  sale_order_delivery_items_list.item_id = sale_order_delivery_items_batches_list.item_id
            WHERE
            sales_order_delivery_transaction_table.data_synced = false limit 10
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}



export async function syncSalesDelivery(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"salesDelivery"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('salesDeliverySync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncSalesDeliveryDataResult(orderData: any, sodtt_id: any) {
    try {
        delete orderData.sodtt_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_order_delivery_transaction_table
        SET ${updateOrderFields}
        WHERE sodtt_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [sodtt_id, ...orderValues]);
      //  console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getUnSyncedSaleInvoice() {
    try {

        
          const GET_ORDER_DETAILS_QUERY = `
          SELECT
          sales_order_invoice_table.*,
          sales_order_invoice_items_list.*,
          sales_order_invoice_items_batches_list.*
          FROM
          sales_order_invoice_table
          LEFT JOIN
          sales_order_invoice_items_list ON sales_order_invoice_table.soit_id = sales_order_invoice_items_list.soit_id
          LEFT JOIN 
          sales_order_invoice_items_batches_list ON sales_order_invoice_items_list.soit_id = sales_order_invoice_items_batches_list.soit_id
          AND  sales_order_invoice_items_list.item_id = sales_order_invoice_items_batches_list.item_id
          WHERE
          sales_order_invoice_table.data_synced = false 
        `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}



export async function syncSalesInvoice(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"salesInvoice"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('salesInvoiceSync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncSalesInoviceDataResult(orderData: any, soit_id: any) {
    try {
        delete orderData.soit_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_order_invoice_table
        SET ${updateOrderFields}
        WHERE soit_id = $1
        RETURNING *;
        
      `;
//console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [soit_id, ...orderValues]);
      //  console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getUnSyncedSaleReturn() {
    try {

        

        const GET_ORDER_DETAILS_QUERY = `
        SELECT
        sales_return_table.*,
        sales_return_items_list.*,
        sales_return_items_batches_list.*
        FROM
        sales_return_table
        LEFT JOIN
        sales_return_items_list ON sales_return_table.srt_id = sales_return_items_list.srt_id
        JOIN 
        sales_return_items_batches_list ON sales_return_items_list.srt_id = sales_return_items_batches_list.srt_id
        AND  sales_return_items_list.item_id = sales_return_items_batches_list.item_id
        WHERE
        sales_return_table.data_synced = false 
      `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        console.log(orderDetailsResult.rowCount)
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}



export async function syncSalesReturn(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"salesReturn"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('salesReturnSync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncSalesReturneDataResult(orderData: any, srt_id: any) {
    try {
        delete orderData.srt_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_return_table
        SET ${updateOrderFields}
        WHERE srt_id = $1
        RETURNING *;
        
      `;
//console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [srt_id, ...orderValues]);
       // console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}





export async function getUnSyncedSaleCreditNote() {
    try {

        


      const GET_ORDER_DETAILS_QUERY = `
      SELECT
      sales_credit_table.*,
      sales_credit_items_list_table.*,
      sales_credit_items_batches_list.*
      FROM
      sales_credit_table
      LEFT JOIN
      sales_credit_items_list_table ON sales_credit_table.sct_id = sales_credit_items_list_table.sct_id
      LEFT JOIN 
      sales_credit_items_batches_list ON sales_credit_items_list_table.sct_id = sales_credit_items_batches_list.sct_id
      AND  sales_credit_items_list_table.item_id = sales_credit_items_batches_list.item_id
      WHERE
      sales_credit_table.data_synced = false 
      `;
    
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY);
        console.log(orderDetailsResult.rowCount)
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}



export async function syncSalesCreditNote(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"salesCreditSync"
        }
    
    }

   // console.log(req,"34562345")
        socket.emit('salesCreditSync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}



export async function syncSalesCreditNoteDataResult(orderData: any, sct_id: any) {
    try {
        delete orderData.sct_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_credit_table
        SET ${updateOrderFields}
        WHERE sct_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [sct_id, ...orderValues]);
        console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function updatepurhcaheReturn(itemBatchDataofInventory: any,itemData:any, client:any) {
    try{
      for(let itemdata of itemData){
          for(let batch of itemBatchDataofInventory ){
              if(itemdata.item_id === batch.item_id){
                  batch.item_uom_id = itemdata.item_uom_id
              }
          }
      }
      
      for (const item of itemBatchDataofInventory) {
          console.log("sssssssrrrrrrrrr", item)
          const { item_id, item_batch_number, item_batch_quantity, item_batch_free_quantity ,to_bin_location} = item;
          console.log(item_id, item_batch_number, typeof (item_batch_quantity))
         let item_quantity
          if(item.item_uom_id){
         
              const getUomQunatity =   await uomService.getUomGroupOfItems(item.item_uom_id)
              if(getUomQunatity.rows.length>0){
                  
                  item_quantity = (getUomQunatity.rows[0].base_quantity * item_batch_quantity) + (getUomQunatity.rows[0].base_quantity * item_batch_free_quantity)
              }
                }
  
  const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
      SET item_quantity = item_quantity - $1
      WHERE item_id = $2 AND item_batch_number = $3 AND item_rack_location = $4;`
  
        
  
          const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item_quantity, item_id, item_batch_number, to_bin_location]);
       
            
  
      }
  }catch(error){
      throw new Error(error)
  }
  }

  
export async function getStoreDetails(){
    try{
        const qurey="select * from store_information_for_user_table";
        const result=await client.query(qurey);
        console.log(result.rows);
        return result.rows;
    }
    catch(error){
        throw new Error(error)
    }
        
}

export async function TaxInfoDN(sodtt_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
 SELECT
     sale_order_delivery_items_list.item_gst,
    (COALESCE(SUM(sale_order_delivery_items_list.item_total_amount), 0) - 
     COALESCE(SUM(sale_order_delivery_items_list.item_tax_amount), 0) - 
     COALESCE(SUM(sale_order_delivery_items_list.item_discount_amount), 0)) AS taxable,
    COALESCE(SUM(sale_order_delivery_items_list.item_cgst), 0) AS cgst,
    COALESCE(SUM(sale_order_delivery_items_list.item_sgst), 0) AS sgst,
    COALESCE(SUM(sale_order_delivery_items_list.item_igst), 0) AS igst
            FROM
            sales_order_delivery_transaction_table
            LEFT JOIN
            sale_order_delivery_items_list ON sales_order_delivery_transaction_table.sodtt_id = sale_order_delivery_items_list.sodtt_id 
            LEFT JOIN 
            sale_order_delivery_items_batches_list ON sale_order_delivery_items_list.sodtt_id = sale_order_delivery_items_batches_list.sodtt_id
			AND  sale_order_delivery_items_list.item_id = sale_order_delivery_items_batches_list.item_id
			WHERE
    sale_order_delivery_items_list.item_gst IS NOT NULL and sales_order_delivery_transaction_table.sodtt_id = $1
			GROUP BY 
    sale_order_delivery_items_list.item_gst;
          `;
          const res = await client.query(GET_ORDER_DETAILS_QUERY, [sodtt_id]);
          if (res.rows.length === 0) {
              console.log('No records found.');
              return [];
            }
            console.log('Number of rows returned:', res.rows.length);
            const resultArray = res.rows.map(row => ({
              item_gst: row.item_gst,
              taxable: row.taxable,
              gst: row.cgst,
              sgst: row.sgst,
              igst: row.igst,
            }));
            console.log('Query result:', resultArray);
            return resultArray;

    } catch (error) {
        throw new Error(error)
    }
}

export async function TaxInfo(soit_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
           SELECT
    sales_order_invoice_items_list.item_gst,
    (COALESCE(SUM(sales_order_invoice_items_list.item_total_amount), 0) - 
     COALESCE(SUM(sales_order_invoice_items_list.item_tax_amount), 0) - 
     COALESCE(SUM(sales_order_invoice_items_list.item_discount_amount), 0)) AS taxable,
    COALESCE(SUM(sales_order_invoice_items_list.item_cgst), 0) AS cgst,
    COALESCE(SUM(sales_order_invoice_items_list.item_sgst), 0) AS sgst,
    COALESCE(SUM(sales_order_invoice_items_list.item_igst), 0) AS igst
            FROM
            sales_order_invoice_table
            LEFT JOIN
            sales_order_invoice_items_list ON sales_order_invoice_table.soit_id = sales_order_invoice_items_list.soit_id
            LEFT JOIN 
            sales_order_invoice_items_batches_list ON sales_order_invoice_items_list.soit_id = sales_order_invoice_items_batches_list.soit_id
            AND  sales_order_invoice_items_list.item_id = sales_order_invoice_items_batches_list.item_id
			WHERE
    sales_order_invoice_items_list.item_gst IS NOT NULL and sales_order_invoice_table.soit_id = $1
			GROUP BY 
    sales_order_invoice_items_list.item_gst;
          `;
          const res  = await client.query(GET_ORDER_DETAILS_QUERY, [soit_id]);
          if (res.rows.length === 0) {
            console.log('No records found.');
            return [];
          }
          console.log('Number of rows returned:', res.rows.length);
          const resultArray = res.rows.map(row => ({
            item_gst: row.item_gst,
            taxable: row.taxable,
            gst: row.cgst,
            sgst: row.sgst,
            igst: row.igst,
          }));
          console.log('Query result:', resultArray);
          return resultArray;
    } catch (error) {
        throw new Error(error)
    }
}
