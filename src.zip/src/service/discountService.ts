import client from '../util/database';
import * as customerService from './customerService'


export async function getDiscount(totalAmountOfItem: any) {
    try {

console.log(totalAmountOfItem,"sssssss")

        if (totalAmountOfItem) {
            const query = `
            SELECT 
                min_order_value,
                discount_percentage
            FROM 
                discount_table
            WHERE 
                min_order_value <= $1
            ORDER BY 
                min_order_value DESC
            LIMIT 1;
        `;


            const discountResult = await client.query(query, [totalAmountOfItem]);
            var discountAmount = 0
            var discountPercentage = 0


            if (discountResult.rows.length > 0) {
                discountPercentage = discountResult.rows[0].discount_percentage
                discountAmount = (totalAmountOfItem * discountPercentage) / 100
            }

            const taxquery = `
SELECT *
FROM tax_table
WHERE item_category = $1;

`;


            const Medical = 'Medical'

            const taxResult = await client.query(taxquery, [Medical]);


            if (taxResult.rows.length > 0) {
                var cgstRate = parseInt(taxResult.rows[0].cgst_rate || 0);
                var sgstRate = parseInt(taxResult.rows[0].sgst_rate || 0);
                var igstRate = parseInt(taxResult.rows[0].igst_rate || 0);
                var taxPercentage = cgstRate + sgstRate + igstRate;

                var discountedAmount = totalAmountOfItem - discountAmount
                var taxAmount = (discountedAmount * taxPercentage) / 100

                const resultObj = {
                    item_discount_amount: discountAmount,
                    item_discount_percentage: discountPercentage,
                    item_tax_amount: taxAmount,
                    item_total_tax_percentage: taxPercentage,
                    cgstRate: cgstRate,
                    sgstRate: sgstRate,
                    igstRate: igstRate
                }
                console.log(resultObj)

return resultObj

            }
        }

    } catch (error) {
        throw new Error(error)
    }

}

export async function addPricelist(pricelistData:any){
    try{
      delete   pricelistData.multiplying_factor
        const columns = Object.keys(pricelistData);
        const values = Object.values(pricelistData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO price_list_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function getAllPricelist (query:any) {
  
    try {
       const { pageNumber, pageSize} = query
       const offset = (pageNumber - 1) * pageSize;

const getPriceListQuery = `
    SELECT *
    FROM price_list_table
    LIMIT $1
    OFFSET $2;
`;
const totalCountQuerry = `SELECT COUNT(*) FROM price_list_table`
const totalCount = await client.query(totalCountQuerry)
const getPricelist = await client.query(getPriceListQuery, [pageSize, offset]);


return {getPricelist, totalCount}
    }

    catch (error) {
        throw new Error(error)
    } 
    
}

export async function addItems(itemsData:any){
    try{

        const itemColumns = Object.keys(itemsData[0]);
        
        const itemValuesArray = itemsData.map((item: any) =>
            Object.values(item)
        );
        const valuesStrings = itemValuesArray.map((innerArray: any) =>
            `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
        );

        const resultString = valuesStrings.join(', ');
        console.log(resultString, "eeeeeeeeeeeeeeee")
        //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
        const query = `INSERT INTO price_list_items_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
        console.log(query,"edeeeeee")

        // console.log(query)
        const result = await client.query(query);

        return result

    }catch(error){
                      throw new Error(error)
    }
}

export async function addItemsToBasePriceListV1(itemsData:any,client:any){
    try{
           


                for(let item of itemsData){
        
                   const getbatchNumber = `SELECT * FROM  price_list_items_table WHERE item_id = $1 AND price_list_id = $2 AND item_batch_number = $3`
                   const insertCustomerQueryResult = await client.query(getbatchNumber, [item.item_id,item.price_list_id,item.item_batch_number]);
                   console.log("Rows length:", insertCustomerQueryResult.rows.length);
                   console.log("Rows:", insertCustomerQueryResult.rows, insertCustomerQueryResult.rows.length <=0);
                   if(insertCustomerQueryResult.rows.length <= 0){
                    const columns = Object.keys(item);
                    console.log()
        const values = Object.values(item);

        // Construct the parameterized query
        const insertCustomerQuery = `INSERT INTO price_list_items_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;

        console.log(insertCustomerQuery);
        const insertCustomerQueryResult = await client.query(insertCustomerQuery, values);

                   }
        
                }
        
                
           
        

    }catch(error){
                      throw new Error(error)
    }
}

export async function addItemsToBasePriceList(itemsData:any){
    try{
           


                for(let item of itemsData){
        
                   const getbatchNumber = `SELECT * FROM  price_list_items_table WHERE item_id = $1 AND price_list_id = $2  AND item_batch_number = $3`
                   const insertCustomerQueryResult = await client.query(getbatchNumber, [item.item_id,item.price_list_id,item.item_batch_number]);
                   console.log("Rows length:", insertCustomerQueryResult.rows.length);
                   console.log("Rows:", insertCustomerQueryResult.rows, insertCustomerQueryResult.rows.length <=0);
                   if(insertCustomerQueryResult.rows.length <= 0){
                    const columns = Object.keys(item);
                    console.log()
        const values = Object.values(item);

        // Construct the parameterized query
        const insertCustomerQuery = `INSERT INTO price_list_items_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;

        console.log(insertCustomerQuery);
        const insertCustomerQueryResult = await client.query(insertCustomerQuery, values);

                   }
        
                }
        
                
           
        

    }catch(error){
                      throw new Error(error)
    }
}

export async function getPricelistItems(price_list_id:any){

    try{
//         const query = `SELECT *
// FROM 
//     price_list_items_table AS pli
// JOIN 
//     price_list_table AS price ON pli.price_list_id = price.price_list_id
// JOIN 
//     price_list_table AS price ON pli.price_list_id = price.default_base_price_list_id 
// WHERE 
//     pli.price_list_id = $1;`;

const query = `SELECT 
pli.*, price.*, si.item_code
FROM 
price_list_items_table AS pli
JOIN 
price_list_table AS price ON pli.price_list_id = price.price_list_id
JOIN 
items_table AS si ON pli.item_id = si.item_id
WHERE 
pli.price_list_id = $1
 ORDER BY
si.item_name ASC  ;`


        const result = await client.query(query,[price_list_id]);

        return result


    }catch(error){
        throw new Error(error)
    }
}

export async function updatePriceList(price_list_id: any,pricelistlData: any) {
    try {
        let default_factor = parseFloat(pricelistlData.default_factor)
        let margin_factor = parseFloat(pricelistlData.margin_factor)

        if(pricelistlData.default_price_list){
            const updateAllPriceASFalse = `UPDATE price_list_table SET default_price_list = FALSE `
            const resultUpdateAllPriceASFalse = await client.query(updateAllPriceASFalse)
        }
        const columnValuePairs = Object.entries(pricelistlData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(pricelistlData);

        const query = `UPDATE price_list_table SET ${columnValuePairs} WHERE price_list_id = $${Object.keys(pricelistlData).length + 1} RETURNING *;`;
        
        const result = await client.query(query, [...values, price_list_id]);
   let  itemUpdateQuery
        if(pricelistlData.is_margin_percentage){
               itemUpdateQuery = `UPDATE price_list_items_table
            SET item_selling_price = item_batch_final_purchase_rate +( item_batch_final_purchase_rate * ${margin_factor} / 100)
            WHERE price_list_id = '${price_list_id}';`
        }else{
              itemUpdateQuery = `UPDATE price_list_items_table
            SET item_selling_price = item_base_price - (item_base_price * ${default_factor} / 100)
            WHERE price_list_id = '${price_list_id}';`
        }
           
        const result12 = await client.query(itemUpdateQuery);

  
      
        return result

    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}

export async function deletePriceList(price_list_id: any) {
    try {
        
        const deletePriceListquery1 = `DELETE FROM  period_volume_discount_table WHERE price_list_id = $1`
        const deletePriceListquery3 = `DELETE FROM  period_volume_discount_items_table WHERE price_list_id = $1`
        const deleteItemquery = ` DELETE FROM  price_list_items_table WHERE price_list_id = $1` 
        const deletePriceListquery2 = `DELETE FROM  price_list_table WHERE price_list_id = $1`
        const[ result1,result2,result3,result4] = await Promise.all([client.query(deletePriceListquery1, [ price_list_id]),client.query(deleteItemquery, [ price_list_id]),
        client.query(deletePriceListquery3, [ price_list_id]),
        client.query(deletePriceListquery2, [ price_list_id])
    ]);
console.log(result4)
        return result4

    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}

export async function getSelectedItems(query: any) {
    try {
        const { pageNumber, pageSize, price_list_id, item_from, item_to } = query;
        const offset = (pageNumber - 1) * pageSize;

        let whereCondition = `pli.price_list_id = '${price_list_id}'`;

        // Check if item_from and item_to are provided and convert them to integers
        if (item_from !== undefined && item_to !== undefined) {
            const start_range = parseInt(item_from);
            const end_range = parseInt(item_to);
            whereCondition += ` AND (CAST(si.item_code AS INTEGER) BETWEEN ${start_range} AND ${end_range})`;

        }

        const getQuery = `
           SELECT 
    pli.*, 
    price.*, 
    si.item_code, 
    si.item_id, 
    si.item_name, 
    CASE 
    WHEN pli.item_base_price = 0 THEN 0 
    ELSE ROUND(((pli.item_base_price - pli.item_selling_price) / pli.item_base_price) * 100) 
    END AS discount_percentage,
    CASE 
     WHEN pli.item_batch_final_purchase_rate = 0 THEN 0 
     ELSE ROUND(((pli.item_selling_price - pli.item_batch_final_purchase_rate) / pli.item_batch_final_purchase_rate) * 100) 
     END AS margin_percentage

FROM 
    price_list_items_table AS pli
JOIN 
    price_list_table AS price ON pli.price_list_id = price.price_list_id
JOIN 
    items_table AS si ON pli.item_id = si.item_id
WHERE 
    ${whereCondition}
ORDER BY 
    si.item_name
LIMIT 
    ${pageSize} 
OFFSET 
    ${offset};

        `;

        const totalCountQuery = `
            SELECT 
                COUNT(*)
            FROM 
                price_list_items_table AS pli
            JOIN 
                items_table AS si ON pli.item_id = si.item_id
            WHERE 
                ${whereCondition};
        `;
console.log(getQuery)
        const [result, totalCountResult] = await Promise.all([
            client.query(getQuery),
            client.query(totalCountQuery)
        ]);

        return { result, totalCount: totalCountResult.rows[0].count };
    } catch (error) {
        throw new Error(error);
    }
}

export async function updateitem(item_id:any,price_list_id:any,itemObj:any){
    try{
     
        const itemFields = Object.entries(itemObj)
            .filter(([columnName]) => columnName !== 'item_id' && columnName !== 'price_list_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE price_list_items_table
        SET ${itemFields}
        WHERE item_id = '${item_id}' AND price_list_id = '${price_list_id}'
        RETURNING *;
      `;

      console.log(updateItemQuery,"updateItemQuery")

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);
        console.log(updateItemResult)

        return updateItemResult

    }catch(error){
              throw new Error(error)
    }
}

export async function getPricelist(price_list_id:any){
    try{

        const query = 'SELECT * FROM price_list_table WHERE default_base_price_list_id = $1';

        const  result = await client.query(query, [price_list_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}
export async function getPricelistById(price_list_id:any){
    try{

        const query = 'SELECT * FROM price_list_table WHERE price_list_id = $1';

        const  result = await client.query(query, [price_list_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function updateitembyid(updateItemObj: any) {
    try {
        const {item_id,price_list_id} = updateItemObj
        const itemFields = Object.entries(updateItemObj)
            .filter(([columnName]) => columnName !== 'price_list_id' && columnName !== 'item_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE price_list_items_table
        SET ${itemFields}
        WHERE item_id = '${item_id}' AND price_list_id = '${price_list_id}'
        RETURNING *;
      `;
console.log(updateItemQuery)
      console.log(item_id,price_list_id)
        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPeriodDiscountItems(itemsData:any){
    try{

        const itemColumns = Object.keys(itemsData[0]);
        
        const itemValuesArray = itemsData.map((item: any) =>
            Object.values(item)
        );
        const valuesStrings = itemValuesArray.map((innerArray: any) =>
            `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
        );

        const resultString = valuesStrings.join(', ');
        //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
        const query = `INSERT INTO period_discount_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


        // console.log(query)
        const result = await client.query(query);

        return result

    }catch(error){
        console.log(error)
              throw new Error(error)
    }
}

export async function updatePeriodDiscountItems(item_id:any,itemData:any){
    try{
        const columnValuePairs = Object.entries(itemData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(itemData);

    const query = `
    UPDATE period_discount_table
    SET ${columnValuePairs}
    WHERE item_id = $${Object.keys(itemData).length + 1}
    RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, item_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getPeriodDiscountItems(query:any) {
  
    try {
     

       const { pageNumber, pageSize, price_list_id, item_from, item_to } = query;
       const offset = (pageNumber - 1) * pageSize;

       let whereCondition = '';


       // Check if item_from and item_to are provided and convert them to integers
       if (item_from !== undefined && item_to !== undefined) {
           const start_range = parseInt(item_from);
           const end_range = parseInt(item_to);
           whereCondition += ` AND (si.item_code BETWEEN ${start_range} AND ${end_range})`;
       }
       const getPriceListQuery = `
       SELECT period.*, plt.* , pl.*, si.item_code,si.item_name,ROUND(((plt.item_base_price - plt.item_selling_price) / plt.item_base_price), 2) AS discount_percentage
       FROM period_discount_table AS period
       JOIN price_list_items_table AS plt ON period.item_id = plt.item_id AND period.price_list_id = plt.price_list_id
       JOIN price_list_table AS pl ON period.price_list_id = pl.price_list_id
       JOIN  items_table AS si ON plt.item_id = si.item_id
        WHERE 1=1 ${whereCondition} LIMIT ${pageSize} OFFSET ${offset}
   `;
   
const totalCountQuerry = `SELECT COUNT(*) FROM period_discount_table AS period  JOIN items_table AS si ON period.item_id = si.item_id
 WHERE 1=1 ${whereCondition}`
console.log(getPriceListQuery)
console.log(totalCountQuerry)

const totalCount = await client.query(totalCountQuerry)
const getPeriodDiscountItems = await client.query(getPriceListQuery);

return {getPeriodDiscountItems, totalCount}
    }

    catch (error) {
        throw new Error(error)
    } 
    
}

export async function getpricelistWithoutPageniation () {
  
    try {

const getPriceListQuery = `
    SELECT *
    FROM price_list_table
`;


const getPricelist = await client.query(getPriceListQuery);


return getPricelist
    }

    catch (error) {
        throw new Error(error)
    } 
    
}

export async function getDiscountGroup(discountQuery:any){
    try{
        const {discount_type_id,customer_group_id} = discountQuery

        const query = 'SELECT * FROM discount_group_table WHERE discount_type_id = $1 AND customer_group_id= $2';

        const  result = await client.query(query, [discount_type_id,customer_group_id]);
        console.log(result.rows,"eeeee")
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function addDiscountGroup(discountGroupData:any){
    try{

        const columns = Object.keys(discountGroupData);
        const values = Object.values(discountGroupData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO discount_group_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addItemGroupData(itemsGroupData:any){
    try{

        const columns = Object.keys(itemsGroupData);
        const values = Object.values(itemsGroupData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO items_group_discount_group_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery, values);
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addItemGroupTable(itemsGroupData:any){
    try{

        const columns = Object.keys(itemsGroupData);
        const values = Object.values(itemsGroupData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO item_group_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getItemGroupTable(){
    try{

        const query = 'SELECT * FROM item_group ';

        const  result = await client.query(query,);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function addManufacturesGroup(manufactureGroupData:any){
    try{

        const columns = Object.keys(manufactureGroupData);
        const values = Object.values(manufactureGroupData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO manufacture_group_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getManufacturesGroup(){
    try{

        const query = 'SELECT * FROM manufacture_group_table ';

        const  result = await client.query(query,);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function addCustomerGroup(manufactureGroupData:any){
    try{

        const columns = Object.keys(manufactureGroupData);
        const values = Object.values(manufactureGroupData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO customer_group_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getCustomerGroup(){
    try{

        const query = 'SELECT * FROM customer_group_table ';

        const  result = await client.query(query,);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function addDiscountType(manufactureGroupData:any){
    try{

        const columns = Object.keys(manufactureGroupData);
        const values = Object.values(manufactureGroupData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO discount_type_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getDiscountType(){
    try{

        const query = 'SELECT * FROM discount_type_table ';

        const  result = await client.query(query,);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function existingItemsGroupResult(discount_group_id:any){
    try{

        const query = 'SELECT * FROM items_group_discount_group_table WHERE customer_group_id = $1 ';

        const  result = await client.query(query,[discount_group_id]);
        //
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function updatedItemGroup(updatedItem: any, item_group_id:any,customer_group_id: any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .filter(([columnName]) => columnName !== 'item_group_id' && columnName !== 'customer_group_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE items_group_discount_group_table
        SET ${itemFields}
        WHERE item_group_id = '${item_group_id}' AND customer_group_id = '${customer_group_id}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function removeItemGroup(item_group_id: any, customer_group_id: any) {
    try {
        const removeItemQuery = `
DELETE FROM items_group_discount_group_table
WHERE item_group_id = $1 AND customer_group_id = $2
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [item_group_id, customer_group_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function updateDiscountGroup(discount_group_id:any,discountGroupData:any){
    try{

        const columnValuePairs = Object.entries(discountGroupData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(discountGroupData);

        const query = `
    UPDATE discount_group_table
    SET ${columnValuePairs}
    WHERE discount_group_id = $${Object.keys(discountGroupData).length + 1}
    RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, discount_group_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getitemsGroup( customer_group_id:any){
    try{

      const query = `SELECT dg.*, igdg.*, itm.*
        FROM discount_group_table AS dg
        JOIN items_group_discount_group_table AS igdg ON dg.customer_group_id = igdg.customer_group_id
        JOIN item_group AS itm ON igdg.item_group_id =  itm.id
        WHERE dg.customer_group_id = $1`   

   
        const  result = await client.query(query,[customer_group_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function getDiscountManufacturesGroup( customer_group_id:any){
    try{

        const query = `SELECT dg.*, igdg.*, mgr.*
        FROM discount_group_table AS dg
        JOIN manufactures_group_discount_group_table AS igdg ON dg.customer_group_id = igdg.customer_group_id
        JOIN  manufacturer AS mgr ON  igdg.manufacture_group_id = mgr.id
        WHERE dg.customer_group_id =$1`

        const  result = await client.query(query,[customer_group_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function getDiscountGroupItems(discount_type_id:any, customer_group_id:any){
    try{

        const query = `SELECT dg.*,igdg.*,mgr.*
        FROM discount_group_table AS dg
        JOIN items_discount_group_table AS igdg ON dg.discount_group_id = igdg.discount_group_id
        JOIN  items_table AS mgr ON  igdg.item_id = mgr.item_id
        WHERE dg.customer_group_id = $1
        AND dg.discount_type_id = $2 ;` 

        const  result = await client.query(query,[customer_group_id,discount_type_id]);
       // console.log(result)
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function existingManufactureGroupResult(customer_group_id:any){
    try{

        const query = 'SELECT * FROM manufactures_group_discount_group_table WHERE customer_group_id = $1 ';

        const  result = await client.query(query,[customer_group_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function updatedManufactureGroup(updatedItem: any, manufactures_group_id:any,customer_group_id: any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .filter(([columnName]) => columnName !== 'item_group_id' && columnName !== 'customer_group_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE manufactures_group_discount_group_table
        SET ${itemFields}
        WHERE manufacture_group_id = '${manufactures_group_id}' AND customer_group_id = '${customer_group_id}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function removeManufactureGroup(manufactures_group_id: any, customer_group_id: any) {
    try {
        const removeItemQuery = `
DELETE FROM manufactures_group_discount_group_table
WHERE manufacture_group_id = $1 AND customer_group_id = $2
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [manufactures_group_id, customer_group_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function addManufactureGroupData(manufactureGroupData:any){
    try{

        const columns = Object.keys(manufactureGroupData);
        const values = Object.values(manufactureGroupData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO manufactures_group_discount_group_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery, values);
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function existingDiscountGroupItems(customer_group_id:any){
    try{

        const query = 'SELECT * FROM items_discount_group_table WHERE customer_group_id = $1 ';

        const  result = await client.query(query,[customer_group_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function updatedDiscountGroupItems(updatedItem: any, item_id:any,customer_group_id: any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .filter(([columnName]) => columnName !== 'item_id' && columnName !== 'customer_group_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE items_discount_group_table
        SET ${itemFields}
        WHERE item_id = '${item_id}' AND discount_group_id = '${customer_group_id}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function removeDiscountGroupItems(item_id: any, customer_group_id: any) {
    try {
        const removeItemQuery = `
DELETE FROM items_discount_group_table
WHERE item_id = $1 AND customer_group_id = $2
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [item_id, customer_group_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function addDiscountGroupItems(itemsData:any){
    try{

        const columns = Object.keys(itemsData);
        const values = Object.values(itemsData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO items_discount_group_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery, values);
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getSelectedItemsFromStoreInvetory(query: any) {
    try {
        const { item_from, item_to } = query;
        

        // Check if item_from and item_to are provided and convert them to integers
        
            const start_range = parseInt(item_from);
            const end_range = parseInt(item_to);

        const getQuery = 'SELECT * FROM items_table WHERE item_code BETWEEN $1 AND $2'
    
        const result = await client.query(getQuery,[start_range,end_range]);
        return result
    } catch (error) {
        throw new Error(error);
    }
}


export async function getPeriodAndVolumeDiscountOfPriceList(price_list_id:any){
    try{

        const query = 'SELECT * FROM period_volume_discount_table WHERE price_list_id = $1 ';

        const  result = await client.query(query,[price_list_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}


export async function addPeriodAndVolumePricelist(pricelistData:any){
    try{

        const columns = Object.keys(pricelistData);
        const values = Object.values(pricelistData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO period_volume_discount_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery, values);
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function existingPeriodAndVoulmeItems(price_list_id:any){
    try{

        const query = 'SELECT * FROM period_volume_discount_items_table WHERE price_list_id = $1 ';

        const  result = await client.query(query,[price_list_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function updatedPeriodAndVoulmeItems(updatedItem: any, item_id:any,price_list_id: any) {
    try {
        console.log(item_id,price_list_id,updatedItem)
       
        // Construct the query to update the order_items_list table
       
        const itemFields = Object.entries(updatedItem).map(([columnName, value]) => `"${columnName}" = '${value}'`)
        .join(', ');
    
console.log(itemFields,"ffffffffff")
  // Construct the query to update the order_items_list table
  const updateItemQuery = `
  UPDATE period_volume_discount_items_table
  SET ${itemFields}
  WHERE item_id = '${item_id}' AND price_list_id = '${price_list_id}'
  RETURNING *;
`;
console.log(updateItemQuery,'updateItemQuery')
        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}
export async function removePeriodAndVoulmeItems(item_id: any, price_list_id: any) {
    try {
        const removeItemQuery = `
DELETE FROM period_volume_discount_items_table
WHERE item_id = $1 AND price_list_id = $2
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [item_id, price_list_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function addPeriodAndVolumeItems(itemsData:any){
    try{

        const columns = Object.keys(itemsData);
        const values = Object.values(itemsData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO period_volume_discount_items_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery, values);
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function updatePeriodAndVolumePriclist(price_list_id: any, priceListData:any){
    try{

        const columnValuePairs = Object.entries(priceListData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(priceListData);

        const query = `
    UPDATE period_volume_discount_table
    SET ${columnValuePairs}
    WHERE price_list_id = $${Object.keys(priceListData).length + 1}
    RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, price_list_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getPeriodAndVolumeSelectedItems(query: any) {
    try {
        const {  price_list_id, item_from, item_to } = query;


        let whereCondition = `pli.price_list_id = '${price_list_id}'`;

        // Check if item_from and item_to are provided and convert them to integers
        if (item_from !== undefined && item_to !== undefined) {
            const start_range = parseInt(item_from);
            const end_range = parseInt(item_to);
            whereCondition +=` AND (CAST(si.item_code AS INTEGER) BETWEEN ${start_range} AND ${end_range})`;
        }

        const getQuery = `
            SELECT 
            price.price_list_id, 
            price.price_list_name,
            price.default_base_price_list_id ,
            price.default_base_price_list AS base_price_list,
            price.default_factor ,
            price.rounding_method,
            price.rounding_rule , pli.*, si.item_code, si.item_id,si.item_name, ROUND(((pli.item_base_price - pli.item_selling_price) / pli.item_base_price), 2) AS discount_percentage

            FROM 
                price_list_items_table AS pli
            JOIN 
                price_list_table AS price ON pli.price_list_id = price.price_list_id
            JOIN 
                items_table AS si ON pli.item_id = si.item_id
            WHERE 
                ${whereCondition}
        `;


        const result = await  client.query(getQuery)
            

        return  result;
    } catch (error) {
        throw new Error(error);
    }
}



export async function getPeriodAndVolumePricelistItems(query:any){
    try{
        const {price_list_id} = query
        console.log(price_list_id,"sddddd")


        const getQuery = `SELECT 
        pvdit.*,
        pvdt.from_date ,
        pvdt.to_date ,
        plt.price_list_name,
        plt.default_base_price_list_id ,
        plt.default_base_price_list AS base_price_list,
        plt.default_factor ,
        plt.rounding_method,
        plt.rounding_rule,
        plit.is_manual,
        plit.item_base_price,
        plit.item_selling_price,
        plit.item_inventory_uom,
        plit.item_pricing_uom,
        sit.item_code,
        sit.item_name,
        ROUND(((plit.item_base_price - plit.item_selling_price) / plit.item_base_price), 2) AS discount_percentage
    FROM 
        period_volume_discount_items_table AS pvdit
    JOIN 
        period_volume_discount_table AS pvdt ON pvdit.price_list_id = pvdt.price_list_id
    JOIN 
        price_list_table AS plt ON pvdit.price_list_id = plt.price_list_id
    JOIN 
        price_list_items_table AS plit ON pvdit.price_list_id = plit.price_list_id AND pvdit.item_id = plit.item_id
    JOIN 
        items_table AS sit ON pvdit.item_id = sit.item_id
    WHERE 
        pvdit.price_list_id = $1`;

        const result = await  client.query(getQuery,[price_list_id])

        return result 


    }catch(error){
                throw new Error(error);
    }
}


export async function existingItemPeriod(period_discount_item_id:any){
    try{

        const query = 'SELECT * FROM items_period_validity_table WHERE period_discount_item_id = $1 ';

        const  result = await client.query(query,[period_discount_item_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function updatedItemPeriod(updatedItem: any, period_validity_id:any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .filter(([columnName]) => columnName !== 'period_validity_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE items_period_validity_table
        SET ${itemFields}
        WHERE period_validity_id = '${period_validity_id}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function removeItemPeriod(period_validity_id:any) {
    try {
        const removeItemQuery = `
DELETE FROM items_period_validity_table
WHERE period_validity_id = $1 
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [period_validity_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function addPeriodItems(itemsData:any){
    try{

        const columns = Object.keys(itemsData);
        const values = Object.values(itemsData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO items_period_validity_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery, values);
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function existingItemVolume(period_validity_id:any){
    try{

        const query = 'SELECT * FROM items_volume_validity_table WHERE period_validity_id = $1 ';

        const  result = await client.query(query,[period_validity_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function updatedItemVolume(updatedItem: any, volume_validity_id:any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .filter(([columnName]) => columnName !== 'volume_validity_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE items_volume_validity_table
        SET ${itemFields}
        WHERE volume_validity_id = '${volume_validity_id}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function removeItemVoulme(volume_validity_id:any) {
    try {
        const removeItemQuery = `
DELETE FROM items_volume_validity_table
WHERE volume_validity_id = $1 
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [volume_validity_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function removeItemVoulmeByperiodValidityId(period_validity_id:any) {
    try {
        const removeItemQuery = `
DELETE FROM items_volume_validity_table
WHERE period_validity_id = $1 
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [period_validity_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}
export async function addItemVolume(itemsData:any){
    try{

        const columns = Object.keys(itemsData);
        const values = Object.values(itemsData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO items_volume_validity_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery, values);
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getItemPeriod(period_discount_item_id:any){
    try{
 
        const query = `SELECT ipvt.*, plit.item_selling_price, ivvt.volume_effective_price, ivvt.volume_discount_percentage,ivvt.item_quantity,ivvt.volume_validity_id
        FROM items_period_validity_table AS ipvt
        LEFT JOIN
        items_volume_validity_table AS ivvt ON ivvt.period_validity_id = ipvt.period_validity_id
        JOIN
         period_volume_discount_items_table AS pvdtt ON ipvt.period_discount_item_id = pvdtt.period_discount_item_id
        JOIN 
        price_list_items_table AS plit ON pvdtt.price_list_id = plit.price_list_id AND pvdtt.item_id = plit.item_id
        WHERE ipvt.period_discount_item_id = $1
         `;

        const  result = await client.query(query,[period_discount_item_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function getSellingPriceofItem(period_discount_item_id:any){
    try{
 
        const query = `SELECT ipvt.*, plit.item_selling_price
        FROM 
         period_volume_discount_items_table AS pvdtt ON ipvt.period_discount_item_id = pvdtt.period_discount_item_id
        JOIN 
        price_list_items_table AS plit ON pvdtt.price_list_id = plit.price_list_id AND pvdtt.item_id = plit.item_id
        WHERE ipvt.period_discount_item_id = $1
         `;

        const  result = await client.query(query,[period_discount_item_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function getItemVolume(period_validity_id:any){
    try{

        const query = `SELECT ipvt.period_discount_item_id, ivvt.*, plit.item_base_price
        FROM items_volume_validity_table AS ivvt 
        JOIN
        items_period_validity_table AS ipvt ON ivvt.period_validity_id = ipvt.period_validity_id
        JOIN
         period_volume_discount_items_table AS pvdtt ON ipvt.period_discount_item_id = pvdtt.period_discount_item_id
        JOIN 
        price_list_items_table AS plit ON pvdtt.price_list_id = plit.price_list_id AND pvdtt.item_id = plit.item_id
        WHERE ipvt.period_validity_id = $1
         `;

        const  result = await client.query(query,[period_validity_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}

export async function getItemPeriodValidity(period_validity_id:any){
    try{

        const query = 'SELECT * FROM items_period_validity_table WHERE period_validity_id = $1';
        const result = await client.query(query, [period_validity_id]);
        return result;
        
    }catch(error){  
          throw new Error(error)
    }
}


export async function getItemDiscount(price_list_id:any,item_id:any,item_batch_number:any){
    try{

        const getdefault = `SELECT * FROM period_volume_discount_table as pvd JOIN price_list_table  as pt on pt.price_list_id = pvd.price_list_id WHERE pt.default_price_list = true AND CURRENT_DATE BETWEEN pvd.from_date AND pvd.to_date`
        const resultgetdefault = await client.query(getdefault)
        console.log(resultgetdefault.rows,"eewerferfgfrewqwsderfgv")
        if(resultgetdefault.rows.length>0){
        const getQuery = `SELECT ipvt.*, ivvt.* 
        FROM period_volume_discount_items_table AS pvdt
        LEFT JOIN items_period_validity_table AS ipvt ON ipvt.period_discount_item_id = pvdt.period_discount_item_id
        LEFT JOIN items_volume_validity_table AS ivvt ON ivvt.period_validity_id = ipvt.period_validity_id
        WHERE pvdt.price_list_id = $1 
        AND pvdt.item_id = $2 AND pvdt.item_batch_number = $3
         AND CURRENT_DATE BETWEEN ipvt.from_date AND ipvt.to_date;
        `
let  result = await client.query(getQuery,[resultgetdefault.rows[0].price_list_id,item_id,item_batch_number])
if(result.rows.length>0){
    return result
}else{

            const getQuery2 = `SELECT pltt.item_id,pltt.item_base_price,pltt.item_selling_price ,ROUND(((pltt.item_base_price - pltt.item_selling_price) / pltt.item_base_price)*100, 2) AS discount_percentage
            FROM price_list_items_table AS pltt
            WHERE pltt.price_list_id = $1 
            AND pltt.item_id = $2
            `
    const result11 = await client.query(getQuery2,[resultgetdefault.rows[0].price_list_id,item_id])
    console.log(result.rows,resultgetdefault.rows[0].price_list_id,item_id,"eeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
    return result11
        }
    }else{

    return  resultgetdefault
    }

    }catch(error){
        throw new Error(error)
    }
}


export async function getItemPricelistDiscount(price_list_id:any,item_id:any, item_batch_number:any){
    try{
        console.log(item_id,item_batch_number,"ddddddd")
        const getQuery = `SELECT pltt.item_id,pltt.item_base_price,pltt.item_selling_price ,
         CASE 
    WHEN pltt.item_mrp_price = 0 THEN 0 
    ELSE   ROUND(((pltt.item_mrp_price - pltt.item_selling_price) / pltt.item_mrp_price)*100, 2) 
    END AS discount_percentage

        FROM price_list_items_table AS pltt
        JOIN price_list_table  as pt on pt.price_list_id = pltt.price_list_id 
        WHERE pt.default_price_list = true
        AND pltt.item_id = $1 AND pltt.item_batch_number = $2
        `
const result = await client.query(getQuery,[item_id,item_batch_number])
console.log(price_list_id,item_id)
return result
    }catch(error){
        throw new Error(error)
    }
}

export async function getTaxAmount (item_id:any){
    try{

        const taxquery = `SELECT tt.item_tax_category,  tc.rate
        FROM items_table as tt join tax_combination as tc on tt.item_tax_category = tc.id 
        WHERE item_id = $1;`;

            const taxResult = await client.query(taxquery, [item_id]);
            console.log(taxResult.rows, "sssssssssssssss")
            
            return taxResult

    }catch(error){
        throw new Error(error)
    
    }
}


export async function updateTriggerofItemPRicelist(eventObj: any) {

    try {
        console.log(eventObj.data.price_list_id, 'eeee')
        const getPriceListidQuery = 'SELECT * FROM price_list_table WHERE default_base_price_list_id = $1'
        const getPriceListidQueryResult = await client.query(getPriceListidQuery,[eventObj.data.price_list_id]);
        console.log(getPriceListidQueryResult.rows[0],"outside yloog")
        if(getPriceListidQueryResult.rows.length>0){
           console.log(getPriceListidQueryResult.rows,"inside loog")
           let   item_base_price = eventObj.data.item_selling_price
           let   item_selling_price = getPriceListidQueryResult.rows[0].default_factor * item_base_price 
           let updateItemObj = {
            item_id:eventObj.data.item_id,
            price_list_id:getPriceListidQueryResult.rows[0].price_list_id,
            item_base_price:item_base_price,
            item_selling_price:item_selling_price

           }

        const itemFields = Object.entries(updateItemObj)
            .filter(([columnName]) => columnName !== 'price_list_id' && columnName !== 'item_id') // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE price_list_items_table
        SET ${itemFields}
        WHERE item_id = '${updateItemObj.item_id}' AND price_list_id = '${updateItemObj.price_list_id}'
        RETURNING *;
      `;
console.log(updateItemQuery)

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);
           
           
        }
        

        

    } catch (error) {
        throw new Error(error)
    }
}

export async function getDiscountAndTaxAmount(query:any){
    try {
        const { item_id, item_quantity,totalAmountOfItem, cmr_phone_number,item_batch_number } = query
        let price_list_id 
        let resultObj
        let discount_percentage = 0
        let  discountAmount = 0
        
        const findPricelistOfCustomer  = await customerService.findCustomerByPhoneNumber(cmr_phone_number)
        if(findPricelistOfCustomer.rows.length>0){
            price_list_id = findPricelistOfCustomer.rows[0].price_list_id
        }
        console.log(price_list_id)
        const[ getItemDiscountofItem,taxResult] = await Promise.all([getItemDiscount(price_list_id, item_id,item_batch_number), getTaxAmount(item_id)])
        console.log(getItemDiscountofItem.rows)
        if (getItemDiscountofItem.rows.length > 0) {
            
            for (let item of getItemDiscountofItem.rows) {
                if (item.item_quantity !== null && item_quantity > item.item_quantity) {
                    discount_percentage = item.volume_discount_percentage;
                    break
                } else {
                    discount_percentage = getItemDiscountofItem.rows[0].discount_percentage
                }

            }
               discountAmount = (totalAmountOfItem * discount_percentage) / 100
        }
        if (taxResult.rows.length > 0) {
            var cgstRate = parseInt(taxResult.rows[0].rate)/2 || 0;
            var sgstRate = parseInt(taxResult.rows[0].rate)/2 || 0;
         //   var igstRate = parseInt(taxResult.rows[0] || 0;
            var taxPercentage = cgstRate + sgstRate 

            var discountedAmount = totalAmountOfItem - discountAmount
            var taxAmount = discountedAmount - (discountedAmount* ( 100 / (100+taxPercentage)))

             resultObj = {
                item_discount_amount: parseInt(discountAmount.toFixed(2)),
                item_discount_percentage: parseInt(discount_percentage.toFixed(2)),
                item_tax_amount: parseInt(taxAmount.toFixed(2)),
                item_total_tax_percentage: parseInt(taxPercentage.toFixed(2)),
                cgstRate: parseInt(cgstRate.toFixed(2)),
                sgstRate: parseInt(sgstRate.toFixed(2))
              //  igstRate: parseInt(igstRate.toFixed(2))
            }
            console.log(resultObj)



    
            return resultObj

        } 

        
        resultObj = {
            item_discount_amount: 0,
            item_discount_percentage: 0,
            item_tax_amount: 0,
            item_total_tax_percentage: 0,
            cgstRate: 0,
            sgstRate: 0
          //  igstRate: parseInt(igstRate.toFixed(2))
        }

             return resultObj 
            
        
    } catch(error){
        throw new Error(error)
    }
}



export async function bulkUpdatedItemPeriod(updatedItem: any) {
    try {
        const itemFields = Object.entries(updatedItem) // Exclude sot_id and item_id
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');
console.log(itemFields,"werty")
        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE items_period_validity_table
        SET ${itemFields}
        WHERE period_discount_item_id = '${updatedItem.period_discount_item_id}'
        RETURNING *;
      `;
console.log(updateItemQuery,"wertw3e4r5t3e45")
        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}


// export async function pricelisttableSync(priceist: any) {
//     try {
//       for(let item of priceist ){
//         // Get the keys of the object dynamically
//         const columns = Object.keys(item);
//         // Create placeholders for the values dynamically (e.g., $1, $2, ...)
//         const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
//         // Generate the "SET" part of the update statement dynamically
//         const updateSetClause = columns
//             .filter(column => column !== 'price_list_id')  // Exclude the primary key from the update
//             .map(column => `${column} = EXCLUDED.${column}`)
//             .join(', ');
    
//         const query = `
//             INSERT INTO price_list_table (${columns.join(', ')})
//             VALUES (${valuePlaceholders.join(', ')})
//             ON CONFLICT (price_list_id)
//             DO UPDATE SET
//             ${updateSetClause}
//             RETURNING *;
//         `;
    
//         // Get the values from the object in the same order as the columns
//         const values = columns.map(column => item[column]);
    
      
//             const result = await client.query(query, values);
//          //   console.log(result.rows[0]);
//       }
//   // Return the inserted or updated row
//         } 
//         catch (error) {
//           console.error('Error in upsert:', error);
//           throw error;
//       }
//   }


export async function pricelisttableSync(priceList: any) {
    try {
      for (let item of priceList) {
        if(item.default_price_list){
            const updateAllPriceASFalse = `UPDATE price_list_table SET default_price_list = FALSE `
            const resultUpdateAllPriceASFalse = await client.query(updateAllPriceASFalse)
        }
        const columns = Object.keys(item);
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        const values = columns.map((column) => item[column]);
  
        // Build the query to check if price_list_id exists
        const checkExistQuery = `
          SELECT price_list_id
          FROM price_list_table
          WHERE price_list_id = $1;
        `;
  
        const checkResult = await client.query(checkExistQuery, [item.price_list_id]);
  
        // If the price_list_id exists, perform the update
        if (checkResult.rows.length > 0) {
          const updateSetClause = columns
            .filter((column) => column !== 'price_list_id') // Exclude the primary key from the update
            .map((column) => `${column} = $${columns.indexOf(column) + 1}`)
            .join(', ');
  
          const updateQuery = `
            UPDATE price_list_table
            SET ${updateSetClause}
            WHERE price_list_id = $1
            RETURNING *;
          `;
  
          // Perform the update query
          const updateResult = await client.query(updateQuery, [item.price_list_id, ...values.filter(v => v !== item.price_list_id)]);
          // Optionally log the result of the update operation
          // console.log(updateResult.rows[0]);
        } else {
          // If price_list_id doesn't exist, perform the insert
          const insertQuery = `
            INSERT INTO price_list_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            RETURNING *;
          `;
  
          // Perform the insert query
          const insertResult = await client.query(insertQuery, values);
          // Optionally log the result of the insert operation
          // console.log(insertResult.rows[0]);
        }
      }
      // Return the result if needed (optional)
    } catch (error) {
      console.error('Error in pricelisttableSync:', error);
      throw error;
    }
  }
  

//   export async function pricelistitemstableSync(pricelistitems: any) {
//     try {
//       for(let item of pricelistitems ){
//         // Get the keys of the object dynamically
//         const columns = Object.keys(item);
//         // Create placeholders for the values dynamically (e.g., $1, $2, ...)
//         const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
//         // Generate the "SET" part of the update statement dynamically
//         const updateSetClause = columns
//             .map(column => `${column} = EXCLUDED.${column}`)
//             .join(', ');
    
//         const query = `
//             INSERT INTO price_list_items_table (${columns.join(', ')})
//             VALUES (${valuePlaceholders.join(', ')})
//               ON CONFLICT (item_id, price_list_id) 
//             DO UPDATE SET
//             ${updateSetClause}
//             RETURNING *;
//         `;
    
//         // Get the values from the object in the same order as the columns
//         const values = columns.map(column => item[column]);
    
      
//             const result = await client.query(query, values);
//           //  console.log(result.rows[0]);
//       }
//   // Return the inserted or updated row
//         } 
//         catch (error) {
//           console.error('Error in upsert:', error);
//           throw error;
//       }
//   } 

export async function pricelistitemstableSync(pricelistitems: any) {
  try {
    for (let item of pricelistitems) {
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      const values = columns.map((column) => item[column]);

      // Build the query to check if (item_id, price_list_id, item_batch_number) exists
      const checkExistQuery = `
        SELECT 1
        FROM price_list_items_table
        WHERE item_id = $1 
          AND price_list_id = $2 
          AND item_batch_number = $3;
      `;

      const checkResult = await client.query(checkExistQuery, [item.item_id, item.price_list_id, item.item_batch_number]);

      // If the record exists, perform the update
      if (checkResult.rows.length > 0) {
        const updateSetClause = columns
          .filter((column) => column !== 'item_id' && column !== 'price_list_id' && column !== 'item_batch_number') // Exclude the primary keys from the update
          .map((column, idx) => `${column} = $${idx + 4}`) // Adjust indexes accordingly
          .join(', ');

        const updateQuery = `
          UPDATE price_list_items_table
          SET ${updateSetClause}
          WHERE item_id = $1 AND price_list_id = $2 AND item_batch_number = $3
          RETURNING *;
        `;

        // Perform the update query
        const updateResult = await client.query(updateQuery, [item.item_id, item.price_list_id, item.item_batch_number, ...values.filter((_, i) => i !== columns.indexOf('item_id') && i !== columns.indexOf('price_list_id') && i !== columns.indexOf('item_batch_number'))]);
        // Optionally log the result of the update operation
        // console.log(updateResult.rows[0]);
      } else {
        // If (item_id, price_list_id, item_batch_number) doesn't exist, perform the insert
        const insertQuery = `
          INSERT INTO price_list_items_table (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          RETURNING *;
        `;

        // Perform the insert query
        const insertResult = await client.query(insertQuery, values);
        // Optionally log the result of the insert operation
        // console.log(insertResult.rows[0]);
      }
    }
    // Return the result if needed (optional)
  } catch (error) {
    console.error('Error in pricelistitemstableSync:', error);
    throw error;
  }
}

  

  export async function periodvolumediscounttableSync(periodvolumediscount: any) {
    try {
      for(let item of periodvolumediscount ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO period_volume_discount_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (price_list_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }  


  export async function periodvolumediscountitemstableSync(periodvolumediscountitems: any) {
    try {
      for(let item of periodvolumediscountitems ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO period_volume_discount_items_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (period_discount_item_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
           // console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }  


  export async function itemsperiodvaliditytableSync(itemsperiodvalidity: any) {
    try {
      for(let item of itemsperiodvalidity ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO items_period_validity_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (period_discount_item_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }  


  export async function itemsvolumevaliditytableSync(itemsvolumevalidity: any) {
    try {
      for(let item of itemsvolumevalidity ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO items_volume_validity_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (volume_validity_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }


  export async function itemgroupSync(itemgrouptable: any) {
    try {
      for(let item of itemgrouptable ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO item_group_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (item_group_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }


  export async function customergrouptableSync(customergrouptable: any) {
    try {
      for(let item of customergrouptable ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO customer_group_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (customer_group_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }


  export async function discounttypetableSync(customergrouptable: any) {
    try {
      for(let item of customergrouptable ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO customer_group_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (customer_group_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }

  export async function manufacturegrouptableSync(manufacturegrouptable: any) {
    try {
      for(let item of manufacturegrouptable ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO manufacture_group_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (manufacture_group_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
           // console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }


  export async function itemsgroupdiscountgrouptableSync(itemsgroupdiscountgrouptable: any) {
    try {
      for(let item of itemsgroupdiscountgrouptable ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO items_group_discount_group_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (discount_group_id,item_group_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
           // console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }

  export async function manufacturesgroupdiscountgrouptableSync(manufacturesgroupdiscountgrouptable: any) {
    try {
      for(let item of manufacturesgroupdiscountgrouptable ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO manufactures_group_discount_group_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (discount_group_id,manufacture_group_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }

  export async function itemsdiscountgrouptableSync(itemsdiscountgrouptable: any) {
    try {
      for(let item of itemsdiscountgrouptable ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO items_discount_group_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
              ON CONFLICT (discount_group_id,item_id) 
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
      }
  // Return the inserted or updated row
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }



export async function getGroupDiscount(customer_group_id: any, item_id:any) {

    try {
        let discount_percentage = 0
        let  itemGroupQuery = "Select * from items_table where item_id = $1"
        const checkItemGroup = await client.query(itemGroupQuery,[item_id])
        let discountGroupObj = {
            discount_percentage : 0,
            discount_group_apply:false
        }

      let  item_manufacturer = checkItemGroup.rows[0].item_manufacturer
    console.log(checkItemGroup.rows[0].item_group,'eee',customer_group_id)
        let itemGroupDiscountQuery = `Select * from items_group_discount_group_table where  customer_group_id = $1 AND item_group_id = $2 `
        const checkItemGroupDiscount = await client.query(itemGroupDiscountQuery,[customer_group_id,checkItemGroup.rows[0].item_group])
        console.log(checkItemGroupDiscount.rows,"checkItemGroupDiscount")
        if(checkItemGroupDiscount.rows.length>0){
            discountGroupObj.discount_percentage = checkItemGroupDiscount.rows[0].discount_percentage
            discountGroupObj.discount_group_apply = true
        
        return  discountGroupObj
            
        }else{
            let itemGroupDiscountQuery = `Select * from manufactures_group_discount_group_table  where  customer_group_id = $1 AND manufacture_group_id = $2 `
            const checkManufactutereDiscount = await client.query(itemGroupDiscountQuery,[customer_group_id,item_manufacturer])
            console.log(checkManufactutereDiscount.rows,"checkManufactutereDiscount")
            if(checkManufactutereDiscount.rows.length>0){
            discountGroupObj.discount_percentage =checkManufactutereDiscount.rows[0].discount_percentage
            discountGroupObj.discount_group_apply = true
            return  discountGroupObj
            }else{
                return  discountGroupObj
            }
        }

      
    }catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
  }



  export async function additemstopricelistlink(itemsData:any,client:any){
    try{
           const getlinkedPricelist =
            `WITH RECURSIVE price_list_hierarchy AS (
    SELECT 
        price_list_id,
        default_base_price_list_id, 
	     default_factor,
        margin_factor,
        is_margin_percentage,
        ARRAY[price_list_id]::character varying[] AS visited  -- Explicitly cast to match recursive term
    FROM price_list_table
    WHERE price_list_id = '01HS5HJYWZ5DG2CW4EHX2W7A8V'

    UNION ALL

    SELECT 
        child.price_list_id, 
        child.default_base_price_list_id,
	    child.default_factor,
        child.margin_factor,
        child.is_margin_percentage,
        visited || child.price_list_id
    FROM price_list_table child
    JOIN price_list_hierarchy parent
    ON child.default_base_price_list_id = parent.price_list_id
    WHERE NOT child.price_list_id = ANY (parent.visited)  -- Avoid revisiting
)
SELECT price_list_id ,default_base_price_list_id,default_factor , margin_factor,is_margin_percentage
FROM price_list_hierarchy
WHERE price_list_id != '01HS5HJYWZ5DG2CW4EHX2W7A8V';
`
const getlinkedPricelistResult = await client.query(getlinkedPricelist)

if(getlinkedPricelistResult.rows.length>0){
    const delay = (ms: number | undefined) => new Promise(resolve => setTimeout(resolve, ms));

         for(let pricelist of getlinkedPricelistResult.rows)
            
                for(let item of itemsData){
                    await delay(30000)
                    const getallItemofPricelist = await getPricelistItemsforLinkedPriclist(pricelist.default_base_price_list_id,item.item_id,item.item_batch_number)
                 //   console.log(getallItemofPricelist.rows)
                 if(getallItemofPricelist.rows.length>0){
                   console.log(getallItemofPricelist.rows, pricelist,item,"eeeeeeeeeeeeeeeeeeee")

                   let  item_selling_priceee
                   if(pricelist.is_margin_percentage){
                       console.log(item)
                   item_selling_priceee =   parseFloat( item.item_batch_final_purchase_rate )+  ( parseFloat(item.item_batch_final_purchase_rate) * parseFloat(pricelist.margin_factor) / 100)
                   
                       console.log(item_selling_priceee,item.item_batch_final_purchase_rate,pricelist.margin_factor ,"dddddd")
                   }else{
                       item_selling_priceee = item.item_batch_unit_price-  (item.item_batch_unit_price *  pricelist.default_factor/100)
                       console.log(item_selling_priceee,item.item_batch_final_purchase_rate, pricelist.default_factor< "ffffffffff")
                   }
                    const additemObject = {
                        item_id: item.item_id,
                        item_base_price: parseFloat(getallItemofPricelist.rows[0].item_selling_price),
                         price_list_id: pricelist.price_list_id,
                        item_selling_price: (item_selling_priceee).toFixed(2),
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_number:item.item_batch_number,
                        item_mrp_price:item.item_batch_unit_price,
                        item_pricing_uom_id:item.item_uom_id,
                        item_pricing_uom:item.item_uom
                        
                    }

                    console.log(additemObject,pricelist,'additemObject')
        
                   const getbatchNumber = `SELECT * FROM  price_list_items_table WHERE item_id = $1 AND price_list_id = $2 AND item_batch_number = $3`
                   const insertCustomerQueryResult = await client.query(getbatchNumber, [additemObject.item_id,additemObject.price_list_id,additemObject.item_batch_number]);
                   console.log("Rows length:", insertCustomerQueryResult.rows.length);
                   console.log("Rows:", insertCustomerQueryResult.rows, insertCustomerQueryResult.rows.length <=0);
                   if(insertCustomerQueryResult.rows.length <= 0){
                    const columns = Object.keys(additemObject);
                    console.log()
        const values = Object.values(additemObject);

        // Construct the parameterized query
        const insertCustomerQuery = `INSERT INTO price_list_items_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;

        console.log(insertCustomerQuery);
        const insertCustomerQueryResult = await client.query(insertCustomerQuery, values);

                   }
        
                 }
        
            } 
        } 
           
        

    }catch(error){
                      throw new Error(error)
    }
}  


export async function getPricelistItemsforLinkedPriclist(price_list_id:any,item_id:any,item_batch_number:any){

    try{
//         const query = `SELECT *
// FROM 
//     price_list_items_table AS pli
// JOIN 
//     price_list_table AS price ON pli.price_list_id = price.price_list_id
// JOIN 
//     price_list_table AS price ON pli.price_list_id = price.default_base_price_list_id 
// WHERE 
//     pli.price_list_id = $1;`;

const query = `SELECT 
pli.*, price.*, si.item_code
FROM 
price_list_items_table AS pli
JOIN 
price_list_table AS price ON pli.price_list_id = price.price_list_id
JOIN 
items_table AS si ON pli.item_id = si.item_id
WHERE 
pli.price_list_id = $1 AND pli.item_id = $2 AND pli.item_batch_number = $3
 ;`


        const result = await client.query(query,[price_list_id,item_id,item_batch_number]);

        return result


    }catch(error){
        throw new Error(error)
    }
}