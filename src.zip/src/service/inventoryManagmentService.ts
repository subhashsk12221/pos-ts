import { Client } from 'pg';
import client from '../util/database';

export async function createWareHouse(warehouseData:any){
    try{

        const columns = Object.keys(warehouseData);
        const values = Object.values(warehouseData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO warehouses_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function addBinLocation(warehouseData:any){
    try{

        const columns = Object.keys(warehouseData);
        const values = Object.values(warehouseData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO bin_location_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function addSublevel(sublevelData:any){
    try{

        const columns = Object.keys(sublevelData);
        const values = Object.values(sublevelData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO sublevel_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addSubLevelBin(subLevelBinData:any){
    try{

        const itemColumns = Object.keys(subLevelBinData[0]);
        
        const itemValuesArray = subLevelBinData.map((item: any) =>
            Object.values(item)
        );
        const valuesStrings = itemValuesArray.map((innerArray: any) =>
            `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
        );

        const resultString = valuesStrings.join(', ');
        //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
        const query = `INSERT INTO sublevel_bins (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


        // console.log(query)
        const result = await client.query(query);

        return result

    }catch(error){
        console.log(error)
              throw new Error(error)
    }
}


export async function getWarehouse(warehouse_id:any){
    try{

        const query = `SELECT 
        w.*,
        bl.*,
        COUNT(sb.bin_no_id) AS bin_location_count
    FROM 
        warehouses_table w
    JOIN 
    bin_location_table bl ON  w.warehouse_id =  bl.warehouse_id   
   LEFT JOIN 
        sublevel_table sl ON w.warehouse_id = sl.warehouse_id
   LEFT JOIN 
        sublevel_bins sb ON sl.sublevel_id = sb.sublevel_id
    WHERE 
    w.warehouse_id = $1 
    GROUP BY 
    w.warehouse_id,
    w.warehouse_code,
    w.warehouse_name,
    w.tax_code,
    w.warehouse_location,
    w.bin_location_enabled,
    bl.warehouse_id,
    bl.default_bin_location,
    bl.auto_alloc_on_issue,
    bl.auto_alloc_on_receipt,
    bl.enable_receiving_bin_location,
    bl.enforce_default_bin_location,
    bl.receive_up_to_max_quantity,
    bl.receive_up_to_max_weight;`;

        const  result = await client.query(query, [warehouse_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
          
}


export async function getNextSublevel(warehouse_id:any){
    try{

        const query = `SELECT MAX(sublevel_no) + 1 AS next_sublevel_no
        FROM sublevel_table
        WHERE warehouse_id = $1;
        `;

        const  result = await client.query(query, [warehouse_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
          
}

export async function getByWareHouseCode(warehouse_code:any){
    try{

        const query = `
        SELECT
        warehouses_table.*
        FROM
        warehouses_table
        WHERE
        LEFT(warehouse_code, 4) ILIKE $1 ;
      `;

        const  result = await client.query(query, [`%${warehouse_code}%`]);
    
        return result

    }catch(error){  
          throw new Error(error)
    }
          
}


export async function getAllBinLocation(warehouse_id:any){
    try{
        const query = `
        SELECT
        sublevel_table.*,
        sublevel_bins.*
        FROM
        sublevel_table 
        JOIN
        sublevel_bins  on sublevel_bins.sublevel_id = sublevel_table.sublevel_id
        WHERE 
        sublevel_table.warehouse_id = $1 ;
      `;

        const  result = await client.query(query,[warehouse_id]);
    
        return result

    }catch(error){  
          throw new Error(error)
    }
          
}


export async function getBinLocation(bin_no_id:any){
    try{
        const getBinQuery = `SELECT * FROM sublevel_bins where bin_no_id = $1`

        const getBinQueryResult = await client.query(getBinQuery,[bin_no_id]);
        return getBinQueryResult

    }catch(error){
        throw new Error(error)
    }

    

}



