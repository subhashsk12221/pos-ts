import client from '../util/database';


 export async function getstoreRevenueAccount(store_id:any){
    try{

        const query = `SELECT * FROM general_accounts_table WHERE store_id = $1 AND account_name = 'sales_transaction_account' `;

        const  result = await client.query(query, [store_id]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
          
}



export async function addTransaction(transactionData:any){
    try{

        const columns = Object.keys(transactionData);
        const values = Object.values(transactionData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO account_ledger_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        const updateQuery = `
        UPDATE general_accounts_table
        SET current_balance = current_balance + $1
        WHERE account_code = $2 ;
        `;

        const updateresult = await client.query(updateQuery, [transactionData.credit_amount,transactionData.account_code]);
        console.log(updateresult.rows)
                 
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);



        return result

    }catch(error){
              throw new Error(error)
    }
}



export async function addChartsOfAccounts(accountData:any){
    try{

        const columns = Object.keys(accountData);
        const values = Object.values(accountData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO general_accounts_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}



export async function getChartsOfAccounts(){
    try {
        const query = `WITH RECURSIVE AccountTree AS (
            SELECT 
                account_id,
                account_code,
                account_name,
                current_balance,
                opening_balance,
                main_group,
                account_status,
                account_level,
                account_category,
                account_type,
                parent_account_key,
                external_code,
                user_sign,
                capital_account,
                year_transfer,
                system_reconciliation_no,
                update_date,
                created_date,
                is_directory,
                is_gl_account,
                is_file, -- Include the is_directory column in the query
                1 AS level
            FROM 
                general_accounts_table
            WHERE 
                parent_account_key IS NULL

            UNION ALL

            SELECT 
                child.account_id,
                child.account_code,
                child.account_name,
                child.current_balance,
                child.opening_balance,
                child.main_group,
                child.account_status,
                child.account_level,
                child.account_category,
                child.account_type,
                child.parent_account_key,
                child.external_code,
                child.user_sign,
                child.capital_account,
                child.year_transfer,
                child.system_reconciliation_no,
                child.update_date,
                child.created_date,
                child.is_directory,
                child.is_gl_account,
                child.is_file, -- Include the is_directory column in the query
                parent.level + 1 AS level
            FROM 
                general_accounts_table AS child
            JOIN 
                AccountTree AS parent ON child.parent_account_key = parent.account_id
        )
        SELECT * FROM AccountTree
        ORDER BY created_date;
        `;

        const result = await client.query(query);
        const hierarchicalStructure = buildHierarchy(result.rows);

        return hierarchicalStructure;
    } catch(error) {  
        throw new Error(error);
    }
}

function buildHierarchy(accounts: any[], parentKey: string | null = null): any[] {
    const children = accounts.filter(account => account.parent_account_key === parentKey);
    if (children.length === 0) return [];

    const result: any[] = [];
    children.forEach(child => {
        let childObject: Record<string, any> = {};

        // Check if is_directory is true or false
        if (child.is_directory) {
            // If is_directory is true, include only account_id, account_name, and account_level
            childObject = {
                account_id: child.account_id,
                account_name: child.account_name,
                account_level: child.account_level,
                is_directory:child.is_directory,
                is_gl_account:child.is_gl_account,
                is_file: child.is_file, 
            };
        } else {
            // If is_directory is false, include all details
            childObject = {
                account_id: child.account_id,
                account_code: child.account_code,
                account_name: child.account_name,
                current_balance: child.current_balance,
                opening_balance: child.opening_balance,
                main_group: child.main_group,
                account_status: child.account_status,
                account_level: child.account_level,
                account_category: child.account_category,
                account_type: child.account_type,
                parent_account_key: child.parent_account_key,
                external_code: child.external_code,
                user_sign: child.user_sign,
                capital_account: child.capital_account,
                year_transfer: child.year_transfer,
                system_reconciliation_no: child.system_reconciliation_no,
                is_directory:child.is_directory,
                is_gl_account:child.is_gl_account,
                is_file: child.is_file, 
                update_date: child.update_date,
                created_date: child.created_date
            };
        }

        if (hasChildren(child.account_id, accounts)) {
            childObject.children = buildHierarchy(accounts, child.account_id);
        }
        result.push(childObject);
    });

    return result;
}

function hasChildren(accountId: string, accounts: any[]): boolean {
    return accounts.some(account => account.parent_account_key === accountId);
}





export async function addFinancialYear(accountData:any){
    try{

        const columns = Object.keys(accountData);
        const values = Object.values(accountData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO general_account_allocation_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const insertQueryintSale = `INSERT INTO sales_account_allocation_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);
        const insertQueryintPurchase = `INSERT INTO purchase_account_allocation_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;

        const insertQueryintInventory = `INSERT INTO inventory_account_allocation_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        // Execute the query with parameterized values
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);
        const result1 = await client.query(insertQueryintSale, values);
        const resul3 = await client.query(insertQueryintPurchase, values);
        const resul4 = await client.query(insertQueryintInventory, values);
        
        return result


    }catch(error){
              throw new Error(error)
    }
}


export async function updateGeneralAccountAllocation(accountData:any){
    try{
       const {gcct_id,period_category} = accountData
       const itemFields = Object.entries(accountData)
       .filter(([columnName]) => columnName !== 'gcct_id' && columnName !== 'period_category') // Exclude sot_id and item_id
       .map(([columnName, value]) => `"${columnName}" = '${value}'`)
       .join(', ');

   // Construct the query to update the order_items_list table
   const updateItemQuery = `
   UPDATE general_account_allocation_table
   SET ${itemFields}
   WHERE gcct_id = '${gcct_id}' 
   RETURNING *;
 `;

 

   // Execute the updateItemQuery and add the result to itemResults
   const updateItemResult = await client.query(updateItemQuery);

   return updateItemResult

    }catch(error){

        console.log(error)
              throw new Error(error)
    }
}

export async function updateSaleAccountAllocation(accountData:any){
    try{
       const {gcct_id,period_category} = accountData
       const itemFields = Object.entries(accountData)
       .filter(([columnName]) => columnName !== 'gcct_id' && columnName !== 'period_category') // Exclude sot_id and item_id
       .map(([columnName, value]) => `"${columnName}" = '${value}'`)
       .join(', ');

   // Construct the query to update the order_items_list table
   const updateItemQuery = `
   UPDATE sales_account_allocation_table
   SET ${itemFields}
   WHERE gcct_id = '${gcct_id}' 
   RETURNING *;
 `;

 

   // Execute the updateItemQuery and add the result to itemResults
   const updateItemResult = await client.query(updateItemQuery);

   return updateItemResult

    }catch(error){

        console.log(error)
              throw new Error(error)
    }
}


export async function updatePurchaseAccountAllocation(accountData:any){
    try{
       const {gcct_id,period_category} = accountData
       const itemFields = Object.entries(accountData)
       .filter(([columnName]) => columnName !== 'gcct_id' && columnName !== 'period_category') // Exclude sot_id and item_id
       .map(([columnName, value]) => `"${columnName}" = '${value}'`)
       .join(', ');

   // Construct the query to update the order_items_list table
   const updateItemQuery = `
   UPDATE purchase_account_allocation_table
   SET ${itemFields}
   WHERE gcct_id = '${gcct_id}' 
   RETURNING *;
 `;

 

   // Execute the updateItemQuery and add the result to itemResults
   const updateItemResult = await client.query(updateItemQuery);

   return updateItemResult

    }catch(error){

        console.log(error)
              throw new Error(error)
    }
}

export async function updateInventoryAccountAllocation(accountData:any){
    try{
       const {gcct_id,period_category} = accountData
       const itemFields = Object.entries(accountData)
       .filter(([columnName]) => columnName !== 'gcct_id' && columnName !== 'period_category') // Exclude sot_id and item_id
       .map(([columnName, value]) => `"${columnName}" = '${value}'`)
       .join(', ');

   // Construct the query to update the order_items_list table
   const updateItemQuery = `
   UPDATE inventory_account_allocation_table
   SET ${itemFields}
   WHERE gcct_id = '${gcct_id}' 
   RETURNING *;
 `;

 

   // Execute the updateItemQuery and add the result to itemResults
   const updateItemResult = await client.query(updateItemQuery);

   return updateItemResult

    }catch(error){

        console.log(error)
              throw new Error(error)
    }
}

export async function getGeneralAccount(query: any) {
    try {
        const { field, value } = query
        console.log(query)
        const getVendorquery = `
    SELECT
    general_accounts_table.account_name,general_accounts_table.account_code, general_accounts_table.account_id
    FROM
    general_accounts_table
    WHERE
        LEFT(${field}, 4) ILIKE $1 
        AND is_file = 'true';
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [`%${value}%`]);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}



export async function getColumnofAccountType() {
    try {
        
        const getVendorquery = `
        SELECT column_name
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE table_name = 'general_account_allocation_table'
        AND column_name IN (
            'domestic_accounts_receivable',
            'checks_received',
            'cash_on_hand',
            'account_sales_tax_account',
            'customers_deduction_at_source',
            'credit_card_deposit_fee',
            'purchase_tax',
            'foreign_accounts_receivable',
            'domestic_accounts_payable',
            'foreign_accounts_payable',
            'bank_transfer',
            'tax_payable',
            'tax_definition',
            'equipment_and_assets',
            'withholding_tax',
            'advances_on_corp_income_tax',
            'opening_balance_account',
            'revenue_account',
            'tax_exempt_revenue_account',
            'expense_account'
        );   
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function addJournalEntryRow(EntryData: any,) {
    try {
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(EntryData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = EntryData.map((item: any) =>
                Object.values(item)
            );
            // console.log(itemValuesArray)

            // Flatten the array of values
            // const itemValues = itemValuesArray.flat();

            //            const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //   `(${innerArray.map((value: any) => (typeof value === 'string' || typeof value === 'object') ? `'${value}'` : value).join(', ')})`
            // );
            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

    

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const query = `INSERT INTO journal_entry_rows_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(query);
          

            return itemResult
        
    } catch (error) {
    
        throw new Error(error)
    }
}

export async function getjournEntry(query: any) {
    try {
        const { transcation_id } = query
        console.log(query)
        const getVendorquery = `
        SELECT 
        jrt.*, 
        jrt.remarks AS jrt_remarks,
        jert.*,
        jert.remarks AS jert_remarks,
        gct.account_name,
        gct.account_code
    FROM 
        journal_entry_table AS jrt
    JOIN 
        journal_entry_rows_table AS jert ON jert.transcation_id = jrt.transcation_id
    JOIN 
        general_accounts_table AS gct ON gct.account_id = jert.account_id
    WHERE 
    jrt.transcation_id = $1;
    
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [transcation_id]);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}



export async function getGeneralAccountsOfYears(query: any) {
    try {
        const { gcct_id } = query
        console.log(gcct_id)
        const getVendorquery = `
    SELECT 
    gcat.gcct_id,
    gcat.credit_card_deposit_fee,
    gcat.rounding_account,
    gcat.automatic_reconcillation_diff,
    gcat.period_end_closing_account,
    gcat.realized_exchange_diff_gain,
    gcat.realized_exchange_diff_loss,
    gcat.opening_balance_account,
    gcat.bank_charges_account,
    gcat.ex_rate_on_def_tax_account
    FROM
    general_account_allocation_table AS gcat
    WHERE
    gcct_id = $1  
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [gcct_id]);
        return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function getYearList() {
    try {

        const getVendorquery = `
    SELECT gcct.gcct_id, gcct.period_category
    FROM 
    general_account_allocation_table as gcct
   
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery);

return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function addJournalEntry(entryData:any){
    try{

        const columns = Object.keys(entryData);
        const values = Object.values(entryData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO journal_entry_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;

        const result = await client.query(insertQuery, values);


        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getJournalEntryList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        

        // Add order status filter to the WHERE clause
      

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }


    
        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM journal_entry_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM journal_entry_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const entryList = getOrderList.rows

        return { totalRowsCount, entryList }

    } catch (error) {
        throw new Error(error)
    }
}



export async function getSaletabOfYear(query: any) {
    try {
        const { gcct_id } = query
        
    
        const getVendorquery = `
        SELECT 
        gcat.gcct_id,
        gcat.underpayment_ar_account,
        gcat.overpayment_ar_account,
        gcat.revenue_account,
        gcat.payment_advances,
        gcat.dunning_interest,
        gcat.realized_exchange_diff_gain,
        gcat.realized_exchange_diff_loss,
        gcat.dunning_fee,
        gcat.domestic_accounts_receivable,
        gcat.foreign_accounts_receivable,
        gcat.cash_on_hand,
        gcat.checks_received,
        gcat.sales_credit_account
        FROM
        sales_account_allocation_table AS gcat
        WHERE
        gcat.gcct_id = $1  
    `;
    
    console.log(getVendorquery); // Check the generated SQL query
    
    // Execute the query with the value as a parameter
   

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [gcct_id]);
        return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function getPurchaseTabOfYear(query: any) {
    try {
        const { gcct_id } = query
        console.log(query)
        const getVendorquery = `
    SELECT 
    gcat.gcct_id,
    gcat.purchase_credit_account,
    gcat.overpayment_ap_account,
    gcat.underpayment_ap_account,
    gcat.payment_advances,
    gcat.expense_and_inventory_account,
    gcat.realized_exchange_diff_gain,
    gcat.realized_exchange_diff_loss,
    gcat.expense_account,
    gcat.domestic_accounts_payable,
    gcat.foreign_accounts_payable,
    gcat.bank_transfer,
    gcat.cash_discount,
    gcat.cash_discount_clearing
    FROM
    purchase_account_allocation_table AS gcat
    WHERE
    gcat.gcct_id = $1  
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [gcct_id]);
        return result

    
 } catch (error) {
        throw new Error(error)
    }
}


export async function getInventoryTabOfYear(query: any) {
    try {
        const { gcct_id } = query
        console.log(query)
        const getVendorquery = `
    SELECT 
    gcat.gcct_id,
    gcat.inventory_account,
    gcat.cost_of_goods_sold_account,
    gcat.allocation_account,
    gcat.variance_account,
    gcat.price_differnce_account,
    gcat.negative_invetory_adj_acct,
    gcat.inventory_offset_decr_acct,
    gcat.inventory_offset_incr_acct,
    gcat.sales_returns_account,
    gcat.exhange_rate_differencee_account,
    gcat.goods_clearing_account,
    gcat.gl_decrease_account,
    gcat.gl_increase_account,
    gcat.wip_inventory_account,
    gcat.wip_inventory_variance,
    gcat.wip_offet_p_and_l_account,
    gcat.inventory_offset_p_and_Laccount,
    gcat.expense_clearing_account,
    gcat.stock_in_transit_account,
    gcat.shipped_goods_account,
    gcat.tax_account,
    gcat.expense_clearing_account,
    gcat.stock_in_transit_account
    FROM
    inventory_account_allocation_table AS gcat
    WHERE
    gcat.gcct_id = $1  
`;


console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [gcct_id]);
        return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function updateChartsOfAccounts(account_id: any, accountData: any) {
    try {

        const columnValuePairs = Object.entries(accountData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(accountData);

        const query = `UPDATE general_accounts_table SET ${columnValuePairs} WHERE account_id = $${Object.keys(accountData).length + 1} RETURNING *;`;


        const result = await client.query(query, [...values, account_id]);

        return result

    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}


export async function deletechartsAccount(account_id: any) {
    try {

   
    const deleteOrderItemsQuery = `
    DELETE FROM general_accounts_table
    WHERE account_id = $1;
`;;
        const orderlistresult = await client.query(deleteOrderItemsQuery, [account_id]);
        // Check if the order was deleted successfully

        return orderlistresult


    } catch (error) {
        throw new Error(error)
    }
}


export async function getaccountName(account_id:any) {
    try {

        const getVendorquery = `
    SELECT account_code,account_name
    FROM 
    general_accounts_table 
    WHERE account_id = $1
   
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery,[account_id]);

return result

    
 } catch (error) {
        throw new Error(error)
    }
}



export async function searchJournalEntry(query: any) {
    try {
        const { field, value } = query
        console.log(query)
        const getVendorquery = `
        SELECT 
        jrt.*
        FROM 
        journal_entry_table AS jrt
        WHERE 
        LEFT(${field}, 4) ILIKE $1;
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery, [`%${value}%`]);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}




export async function generalGLAccount() {
    try {
        
        const getVendorquery = `
    SELECT *
    FROM
    general_account_allocation_table
    WHERE
    period_category = '2024'
`;


const result = await client.query(getVendorquery);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function salesGLAccount() {
    try {
        
        const getVendorquery = `
    SELECT *
    FROM
    sales_account_allocation_table
    WHERE
    period_category = '2024'
`;


const result = await client.query(getVendorquery);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function purchaseGLAccount() {
    try {
        
        const getVendorquery = `
    SELECT *
    FROM
    purchase_account_allocation_table
    WHERE
    period_category = '2024'
`;


const result = await client.query(getVendorquery);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}

export async function inventoryGLAccount() {
    try {
        
        const getVendorquery = `
    SELECT *
    FROM
    inventory_account_allocation_table
    WHERE
    period_category = '2024'
`;


const result = await client.query(getVendorquery);


        return result

    
 } catch (error) {
        throw new Error(error)
    }
}


export async function  updateCustomerDueAmount(balance_due_amount:any,cmr_id:any){
    try {
        const updatestatusQuery = `UPDATE general_accounts_table
                    SET balance_due_amount = balance_due_amount + $1 WHERE  account_id = $2 RETURNING *;`;
        let updateStatus = await client.query(updatestatusQuery, [balance_due_amount, cmr_id]);
        console.log(updateStatus.rows,"dueamount")

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function detectCustomerDueAmount(paymentData: any,client:any) {
    try {
        const totalAmount = parseInt(paymentData.pit_total_amount);
        const currentPayment = parseInt(paymentData.pit_current_payment);
        const accountId = paymentData.cmr_id;

        // Get customer due amount
        const getCmrDueAmountQuery = 'SELECT cmr_open_balance FROM general_accounts_table WHERE account_id = $1';
        const getCmrDueAmountResult = await client.query(getCmrDueAmountQuery, [accountId]);

        if (getCmrDueAmountResult.rows.length === 0) {
            throw new Error(`Account with ID ${accountId} not found.`);
        }

        const dueAmount = parseInt(getCmrDueAmountResult.rows[0].cmr_open_balance);
        const openBalance = parseInt(paymentData.pit_open_balance);
        console.log(openBalance, "openBalance",dueAmount)
        let updateStatusQuery = '';
        let values :any= [];

        if (openBalance>0 && dueAmount>0 ) {
            console.log(openBalance, "in loop",dueAmount)
           let  updateStatusOpenBalance = `UPDATE general_accounts_table SET cmr_open_balance = cmr_open_balance - $1 WHERE account_id = $2 RETURNING *;`;
            
            const updateStatus = await client.query(updateStatusOpenBalance,[openBalance, accountId]);
            console.log(updateStatus.rows,"updateStatusOpenBalance",updateStatusOpenBalance,openBalance, accountId)

            
        } 
        
        
        if (totalAmount > currentPayment) {
            // If total amount is greater than current payment (debit case)
            const debit = totalAmount - currentPayment;
            updateStatusQuery = `UPDATE general_accounts_table SET cmr_open_balance = cmr_open_balance - $1 WHERE account_id = $2 RETURNING *;`;
            values = [debit, accountId];
            console.log(values, "debit");
        } 
         if (totalAmount < currentPayment) {
            // If total amount is less than current payment (credit case)
            const credit = currentPayment - totalAmount;
            updateStatusQuery = `UPDATE general_accounts_table SET cmr_open_balance = cmr_open_balance + $1 WHERE account_id = $2 RETURNING *;`;
            values = [credit, accountId];
            console.log(values, "credit");
        } 

        // Execute update query
        if (updateStatusQuery) {
            console.log(updateStatusQuery, values, "updateStatusQuery");
            const updateStatus = await client.query(updateStatusQuery, values);
            console.log(updateStatus.rows, "dueamount");
            return updateStatus;
        } 
    } catch (error) {
        console.error("Error:", error);
        throw new Error(error.message);
    }
}


export async function detectCustomerDueAmountforPaymentOut(paymentData: any) {
    try {
        const totalAmount = parseInt(paymentData.pot_total_amount);
        const currentPayment = parseInt(paymentData.pot_current_payment);
        const accountId = paymentData.cmr_id;

        // Get customer due amount
        const getCmrDueAmountQuery = 'SELECT cmr_open_balance FROM general_accounts_table WHERE account_id = $1';
        const getCmrDueAmountResult = await client.query(getCmrDueAmountQuery, [accountId]);

        if (getCmrDueAmountResult.rows.length === 0) {
            throw new Error(`Account with ID ${accountId} not found.`);
        }

        const dueAmount = parseInt(getCmrDueAmountResult.rows[0].cmr_open_balance);
        const openBalance = parseInt(paymentData.pot_open_balance);
        console.log(openBalance, "openBalance",dueAmount ,totalAmount,currentPayment)
        let updateStatusQuery = '';
        let values :any= [];

        if (openBalance>0 && dueAmount>0 ) {
            console.log(openBalance, "in loop",dueAmount)
           let  updateStatusOpenBalance = `UPDATE general_accounts_table SET cmr_open_balance = cmr_open_balance - $1 WHERE account_id = $2 RETURNING *;`;
            
            const updateStatus = await client.query(updateStatusOpenBalance,[openBalance, accountId]);
            console.log(updateStatus.rows,"updateStatusOpenBalance",updateStatusOpenBalance,openBalance, accountId)

            
        } 
        
        if (totalAmount > currentPayment) {
            // If total amount is greater than current payment (debit case)
            const debit = totalAmount - currentPayment;
            updateStatusQuery = `UPDATE general_accounts_table SET cmr_open_balance = cmr_open_balance - $1 WHERE account_id = $2 RETURNING *;`;
            values = [debit, accountId];
            console.log(values, "debit");
        } 
         if (totalAmount < currentPayment) {
            // If total amount is less than current payment (credit case)
            const credit = currentPayment - totalAmount;
            updateStatusQuery = `UPDATE general_accounts_table SET cmr_open_balance = cmr_open_balance + $1 WHERE account_id = $2 RETURNING *;`;
            values = [credit, accountId];
            console.log(values, "credit");
        } 

        // Execute update query
        if (updateStatusQuery) {
            console.log(updateStatusQuery, values, "updateStatusQuery");
            const updateStatus = await client.query(updateStatusQuery, values);
            console.log(updateStatus.rows, "dueamount");
            return updateStatus;
        } 
    } catch (error) {
        console.error("Error:", error);
        throw new Error(error.message);
    }
}


