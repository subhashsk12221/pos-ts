import client from '../util/database';

export async function addPaymentTypeService(paymentData: any) {
  const columns = Object.keys(paymentData);
  const values = Object.values(paymentData);
  const query = `INSERT INTO payment_type_table (${columns.join(
    ", "
  )}) VALUES (${values.map((_, i) => `$${i + 1}`).join(", ")}) RETURNING *;`;

  try {
    const result = await client.query(query, values);
    return result.rows[0];
  } catch (error) {
    console.log(error, "Database query error");
    throw new Error("Failed to add Payment type");
  }
}


export async function getPaymentTypeByIdService() {
  console.log("*******************************************");

  let sqlQuery = `SELECT * FROM payment_type_table`;


  try {
    const dbResult = await client.query(sqlQuery);
    if (dbResult.rows.length==0) {
      throw new Error("Payment Type Not Found");
    }
    return dbResult.rows[0];
  } catch (error) {
    console.log(`error is -----------------${error}`)
    throw new Error(`Failed to fetch Payment Type Details`);
  }
}


export async function editPaymentTypeService(leadId: string, leadData: any) {
  const columns = Object.keys(leadData);
  const values = Object.values(leadData);
  const query = `UPDATE payment_type_table SET ${columns.map((col, i) => `${col} = $${i + 2}`).join(", ")} WHERE payment_type_id = $1 RETURNING *;`;
  
  try {
    const result = await client.query(query, [leadId, ...values]);
    return result.rows[0];
  } catch (error) {
    console.error("Database query error:", error);
    throw new Error("Failed to update Payment Type Details");
  }
}
