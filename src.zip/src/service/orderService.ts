import client from '../util/database';
import { ulid } from 'ulid';
import * as financialLegder from '../service/financialLedgerService'
import * as paymentInCSerivce from '../service/paymentInService'
import * as journalEntryService from '../service/journalEntryService'
import axios from 'axios';
import socket from '../sync/syncScript';
import * as stockTransferService from '../service/stockTransferService'
//import { getSocket } from '../sync/syncScript';

//const socket = getSocket();
export async function getNextInvoiceNumber(store_id: any) {
    try {
        const getNextInvoiceNumber = await client.query('SELECT generate_invoice_number($1) AS sot_invoice_number', [store_id]);
        return getNextInvoiceNumber

    } catch (error) {
        throw new Error(error)
    }
}

export async function addOrder(orderData: any, itemData: any, paymentData: any) {
    try {
        await client.query('BEGIN');
        const sot_id = ulid()
        orderData.sot_id = sot_id
        orderData.sot_return_status = 'open'
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);
        const sot_total_amount = orderData.sot_total_amount

       

        // Construct the parameterized query
               const query = `INSERT INTO sales_order (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                sot_id: sot_id,
                item_open_quantity:item.item_quantity,
                item_open_free_quantity:item.item_free_quantity
            }));


            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            const resultString = valuesStrings.join(', ');
            const query = `INSERT INTO order_items_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
            const itemResult = await client.query(query);
            // if (itemResult.rows.length > 0) {
            //     console.log(orderData, newItemsData)
              
            // }

            const newInvoicePaymentData = paymentData.map((item: any) => ({
                ...item,
                sot_id: sot_id
            }));
         
            if (!orderData.is_draft_order) {
                const updateInventory = await updateStoreInventor(orderData, newItemsData)
                const addPaymentData = await paymentInCSerivce.addInvoicePaymentData(newInvoicePaymentData)
                stockTransferService.updateStockUsedInBillingAndDelivery(newItemsData)
    
            }

            
            let order = orderResult.rows
            let item = itemResult.rows
            await client.query('COMMIT');

            return { order, item }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updateStoreInventor(orderData: any, newItemsData: any) {
    console.log(!orderData.is_draft_order)
    if (!orderData.is_draft_order) {

        for (const item of newItemsData) {
            console.log("sssssss", item)
            const { item_id, item_batch_number, item_quantity ,item_rack_location, item_free_quantity} = item;
            console.log(item_id, item_batch_number, typeof (item_quantity))

        const item_total_quantity = item_quantity + item_free_quantity
            const updateQuery = `
UPDATE items_batch_no_table
SET item_sellable_quantity = item_sellable_quantity - $1
WHERE item_id = $2 AND item_batch_number = $3;
`;

const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
        SET item_quantity = item_quantity - $1
        WHERE item_id = $2 AND item_batch_number = $3 AND item_rack_location = $4;`

            const updateresult = await client.query(updateQuery, [item_total_quantity, item_id, item_batch_number]);

            const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item_total_quantity, item_id, item_batch_number, item_rack_location]);
            console.log(updateresult, "updateresult")


        }
    }
}


export async function syncOrder(orderData: any, itemData: any,paymentData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "paymentData":paymentData,
            "transaction_type":"order"
        }
    }

        socket.emit('sync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}

export async function updateDraftOrderData(orderData: any, sot_id: any, paymentData: any) {
    try {
        await client.query('BEGIN');
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_order
        SET ${updateOrderFields}
        WHERE sot_id = $1
        RETURNING *;
        
      `;
      const newInvoicePaymentData = paymentData.map((item: any) => ({
        ...item,
        sot_id: sot_id
    }));
       

        const salesOrderResult = await client.query(updateSalesOrderQuery, [sot_id, ...orderValues]);
        if (!orderData.is_draft_order) {
            console.log(orderData,"dddddddd")
            orderData.sot_invoice_number = salesOrderResult.rows[0].sot_invoice_number
            orderData.cmr_id = salesOrderResult.rows[0].cmr_id
            
            const [addPaymentInJournalEntry, addinvoiceJournalEntry] = await Promise.all([journalEntryService.inovicePaymentINJournalEntry(paymentData, orderData), journalEntryService.invoicejournalEntry(orderData)])

            const addPaymentData = await paymentInCSerivce.addInvoicePaymentData(newInvoicePaymentData)
        }
        
        return salesOrderResult

    } catch (error) {
        await client.query('ROLLBACK');

        throw new Error(error)
    }
}


export async function existingItemsResult(sot_id: any) {
    try {
        const fetchItemsQuery = `
        SELECT * FROM order_items_list
        WHERE sot_id = $1;
        `;

        const existingItemsResult = await client.query(fetchItemsQuery, [sot_id])
        return existingItemsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function updatedItem(updatedItem: any, sot_id: any) {
    try {
        const itemFields = Object.entries(updatedItem)
            .map(([columnName, value]) => `"${columnName}" = '${value}'`)
            .join(', ');

        // Construct the query to update the order_items_list table
        const updateItemQuery = `
        UPDATE order_items_list
        SET ${itemFields}
        WHERE sot_id = '${sot_id}' AND item_id = '${updatedItem.item_id}' AND item_batch_number = '${updatedItem.item_batch_number}' AND item_rack_location = '${updatedItem.item_rack_location}'
        RETURNING *;
      `;

        // Execute the updateItemQuery and add the result to itemResults
        const updateItemResult = await client.query(updateItemQuery);
        console.log(updateItemResult.rows,updateItemQuery)

        return updateItemResult

    } catch (error) {
        throw new Error(error)
    }
}


export async function removeItem(sot_id: any, item_id: any) {
    try {
        const removeItemQuery = `
DELETE FROM order_items_list
WHERE sot_id = $1 AND item_id = $2
RETURNING *;
`;

        // Execute the removeItemQuery and add the result to itemResults


        const removeItemResult = await client.query(removeItemQuery, [sot_id, item_id]);
        return removeItemResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function addItem(newItem: any) {
    try {
        const columns = Object.keys(newItem);
        const values = Object.values(newItem);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO order_items_list (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
      //  console.log(insertQuery);
        // Execute the query with parameterized values
        const addItemResult = await client.query(insertQuery, values);
        return addItemResult

    } catch (error) {
        throw new Error(error)
    }
}


export async function getOrderList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, paymentStatus, is_draft_order, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (paymentStatus) {
            whereClause += ` AND so.sot_payment_status = '${paymentStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause
        if (is_draft_order) {
            whereClause += ` AND so.is_draft_order = '${is_draft_order}'`;  // Specify the table alias
        }

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }


        const joinClause = `JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`;

        // Add search condition for the specified column in both tables
        // const searchCondition = searchColumn
        // ? `AND (LOWER(${searchColumn === 'cmr_phone_number' ? 'so.' + searchColumn : 'c.' + searchColumn}) ILIKE LOWER('%${searchValue}%'))`
        // : '';
        const salesOrderAlias = 'so';
        const customerAlias = 'c';
        
        // Determine the column and table based on searchColumn
        const columnPrefix = searchColumn === 'cmr_first_name' ? customerAlias : salesOrderAlias;
        const columnReference = `${columnPrefix}.${searchColumn}`;
        
        // Construct the search condition
        const searchCondition = searchColumn
            ? `AND (LOWER(${columnReference}) ILIKE LOWER('%${searchValue}%'))`
            : '';


        const queryCount = `SELECT COUNT(*) FROM sales_order so ${joinClause} WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.*, c.cmr_first_name, c.cmr_last_name, c.cmr_email, c.cmr_address ,c.cmr_phone_number FROM sales_order so
     ${joinClause} WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        console.log(findquery,"wwwwww")
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}


export async function repeatPastOrder(cmr_phone_number: any) {
    try {
        const GET_ORDER_DETAILS_QUERY = `
       SELECT
    sales_order.*,
    order_items_list.*
FROM
    sales_order
INNER JOIN
    order_items_list ON sales_order.sot_id = order_items_list.sot_id
WHERE
    sales_order.sot_id = (
        SELECT
            sot_id
        FROM
            sales_order
        WHERE
            cmr_phone_number = $1
        ORDER BY
            created_date DESC
        LIMIT 1
    );
      `
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [cmr_phone_number]);
        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}



// export async function getOrderById(sot_id: any) {
//     try {

//         const GET_ORDER_DETAILS_QUERY = `
//             SELECT
//               sales_order.*,
//               order_items_list.*,
//               customer_details.*,
//               billing_invoice_payment_modes.*
//             FROM
//               sales_order
//             INNER JOIN
//               order_items_list ON sales_order.sot_id = order_items_list.sot_id
//             LEFT JOIN 
//             billing_invoice_payment_modes ON billing_invoice_payment_modes.sot_id = sales_order.sot_id
//               INNER JOIN
//               customer_details ON sales_order.cmr_phone_number = customer_details.cmr_phone_number
//             WHERE
//             sales_order.sot_id = $1
//           `;
//         const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sot_id]);

//         return orderDetailsResult

//     } catch (error) {
//         throw new Error(error)
//     }
// }

export async function getOrderById(sot_id: any) {
    try {
        // Step 1: Fetch order details
        const GET_ORDER_DETAILS_QUERY = `
            SELECT
                sales_order.*,
                order_items_list.*,
                customer_details.*,
                billing_invoice_payment_modes.*
            FROM
                sales_order
            INNER JOIN
                order_items_list ON sales_order.sot_id = order_items_list.sot_id
            LEFT JOIN 
                billing_invoice_payment_modes ON billing_invoice_payment_modes.sot_id = sales_order.sot_id
            INNER JOIN
                customer_details ON sales_order.cmr_phone_number = customer_details.cmr_phone_number
            WHERE
                sales_order.sot_id = $1
        `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sot_id]);

        if (orderDetailsResult.rows.length === 0) {
            return []; // Or handle the case where no order is found
        }

        const orderDetails = orderDetailsResult.rows;

        // Step 2: Calculate total_sellable_quantity for each item in the order
        for (const item of orderDetails) {
            const itemId = item.item_id; // Assuming `item_id` is part of `order_items_list`
            const CALCULATE_SELLABLE_QUANTITY_QUERY = `
                SELECT
                    COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
                FROM
                    items_table
                LEFT JOIN
                    items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number 
                    AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id 
                WHERE
                    items_table.item_id = $1
                    AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
                    AND (
                        sublevel_bins.is_expired_bin_location = false 
                        AND sublevel_bins.is_non_sellable_bin_location = false 
                        OR sublevel_bins.bin_no_id IS NULL
                    )
                GROUP BY
                    items_table.item_id;
            `;
            const sellableQuantityResult = await client.query(CALCULATE_SELLABLE_QUANTITY_QUERY, [itemId]);

            // Add total_sellable_quantity to the item details
            item.total_sellable_quantity = sellableQuantityResult.rows.length > 0
                ? sellableQuantityResult.rows[0].total_sellable_quantity
                : 0;
                item.sot_id = sot_id   
        }
        
          console.log(orderDetails,"3e45e34")
        return orderDetails;
    } catch (error) {
        throw new Error(error.message);
    }
}



export async function deleteDraftOrder(sot_id: any) {
    try {

        const deleteOrderItemsQuery = `
        DELETE FROM order_items_list
        WHERE sot_id = $1;
    `;

        const orderlistresult = await client.query(deleteOrderItemsQuery, [sot_id]);
        // Check if the order was deleted successfully
        if (orderlistresult.rows.length == 0) {
            // Delete corresponding items from order_items_list


            const deleteSalesOrderQuery = `
            DELETE FROM sales_order
            WHERE sot_id = $1
            RETURNING *;
            
        `;
            const salesOrderResult = await client.query(deleteSalesOrderQuery, [sot_id]);
        }

        return orderlistresult


    } catch (error) {
        throw new Error(error)
    }
}



export async function getPastOrder(query: any) {
    try {

        const { cmr_phone_number, pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate } = query;



        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND o.created_date >= '${fromDate}' AND o.created_date < '${toDate}'::date + interval '1 day'`;
        }

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            orderByClause = `ORDER BY o.${sortBy} ${sortOrder}`;
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY o.created_date DESC';
        }

        const joinClause = `JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number JOIN order_items_list o ON so.sot_id = o.sot_id`;

        // Add search condition for the specified column in both tables

        const queryCount = `
            SELECT COUNT(*) 
            FROM sales_order so
            ${joinClause} 
            WHERE 1=1 ${whereClause} AND so.cmr_phone_number = $1;
        `;

        const findquery = `
            SELECT o.*, c.cmr_first_name, c.cmr_last_name, c.cmr_email, c.cmr_address
            FROM sales_order so
            ${joinClause} 
            WHERE 1=1 ${whereClause} AND so.cmr_phone_number = $1
            ${orderByClause} OFFSET $2 LIMIT $3;
        `;


        const totalCount = await client.query(queryCount, [cmr_phone_number]);
        const orderDetailsResult = await client.query(findquery, [cmr_phone_number, offset, limit]);
        console.log(totalCount)


        return { totalCount, orderDetailsResult }


    } catch (error) {
        throw new Error(error)
    }
}

export async function getDashboardGraph1(query: any) {
    try {
        const { filter } = query;
        let dashboardQueryBuilder = '';
        let queryParams: any[] | undefined = []

        if (filter === 'today') {
            const today = new Date();
            const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
            const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);

            dashboardQueryBuilder = `
                SELECT 
                    EXTRACT(HOUR FROM created_date) AS hour, 
                    COUNT(*) AS count 
                FROM sales_order 
                WHERE created_date >= $1 AND created_date < $2 
                GROUP BY hour 
                ORDER BY hour;
            `;
            queryParams = [startOfDay.toISOString(), endOfDay.toISOString()];
        }

        const res = await client.query(dashboardQueryBuilder, queryParams);
        const hourlyCounts = Array.from({ length: 24 }, (_, hour) => ({ hour, count: 0 }));

        // Update the hourly counts based on the query results
        res.rows.forEach(row => {
            const hour = parseInt(row.hour, 10);
            hourlyCounts[hour].count = parseInt(row.count, 10);
        });
        return hourlyCounts;

    
    } catch (error) {
        throw new Error(error.message);
    }
}


export async function getInvoiceItemsList(query: any) {
    try {
        console.log(query)
        const { sot_id, item_id, item_batch_number, item_rack_location} = query;
        let GET_ORDER_DETAILS_QUERY = `
            SELECT
            order_items_list.*,
            order_items_list.item_open_free_quantity as item_free_quantity,
            sales_order.*
            FROM
            order_items_list
            JOIN sales_order on order_items_list.sot_id = sales_order.sot_id
            WHERE
            order_items_list.sot_id = $1
        `;

        const queryParams = [sot_id];

        if (item_id) {
            GET_ORDER_DETAILS_QUERY += ` AND order_items_list.item_id = $2`;
            queryParams.push(item_id);
        }
        if (item_batch_number) {
            GET_ORDER_DETAILS_QUERY += ` AND order_items_list.item_batch_number = $3`;
            queryParams.push(item_batch_number);
        }
        if (item_rack_location) {
            GET_ORDER_DETAILS_QUERY += ` AND order_items_list.item_rack_location = $4`;
            queryParams.push(item_rack_location);
        }

        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, queryParams);


        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function getInvoiceCustomerDetails(sot_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
            cd.cmr_id,
            cd.cmr_code,
            cd.cmr_first_name,
            cd.cmr_phone_number,
            so.cmr_phone_number
            FROM
            sales_order as so
            JOIN customer_details AS cd on cd.cmr_phone_number = so.cmr_phone_number
            WHERE
            so.sot_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [sot_id]);

        return orderDetailsResult.rows[0]

    } catch (error) {
        throw new Error(error)
    }
}





export async function addInoviceCreditNote(orderData: any, itemData: any, paymentData: any) {
    try {
        await client.query('BEGIN');
        const icn_id = ulid()
        orderData.icn_id = icn_id
        const columns = Object.keys(orderData);
        const values = Object.values(orderData);
        const sot_total_amount = orderData.sot_total_amount

       

        // Construct the parameterized query
               const query = `INSERT INTO  invoice_credit_note (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {
         console.log(orderResult.rows,"eeeeeeeeeeee")
            const newItemsData = itemData.map((item: any) => ({
                ...item,
                icn_id: icn_id,
            }));


            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            const resultString = valuesStrings.join(', ');
            const query = `INSERT INTO invoice_credit_note_item_list (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
            const itemResult = await client.query(query);
            if (itemResult.rows.length > 0) {
                console.log(orderData, newItemsData,"ddddddddddddddddddddddddddddddddddddd")
                const[ updateInventory,updateInvoiceItemData] = await Promise.all([updateStoreInventorOnCreditNote(orderData, newItemsData),updateInvoiceItem(newItemsData)])
                   
            }

            const newInvoicePaymentData = paymentData.map((item: any) => ({
                ...item,
                icn_id: icn_id
            }));
         
            if (!orderData.is_draft_order) {
                 console.log(newInvoicePaymentData,"fgdfgvfdfgvfdfgfgbgffgbgfgbgf")
               const addPaymentData = await paymentInCSerivce.addCredNoteInvoicePaymentData(newInvoicePaymentData)
               const [addPaymentOutJournalEntry, addinvoiceJournalEntry] = await Promise.all([journalEntryService.inovicePaymentOutJournalEntry(paymentData, orderData), journalEntryService.invoiceCreditNotejournalEntry(orderData)])
              //  syncInoviceeData(orderData,newItemsData,newInvoicePaymentData)
             stockTransferService.updateStockUsedInBillingReturn(newItemsData)
            }

            
            let order = orderResult.rows
            let item = itemResult.rows
            await client.query('COMMIT');

            return { order, item }
        }
    } catch (error) {
        console.log(error,"ddddd")
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}


export async function updateStoreInventorOnCreditNote(orderData: any, newItemsData: any) {
    console.log(!orderData.is_draft_order)
    if (!orderData.is_draft_order) {

       for (const item of newItemsData) {
             console.log("sssssss", item)
          const { item_id, item_batch_number, item_quantity,item_rack_location,item_free_quantity  } = item;
           console.log(item_id, item_batch_number, typeof (item_quantity))

          const  item_total_quantity =item_quantity + item_free_quantity
           const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
           SET item_quantity = item_quantity + $1
           WHERE item_id = $2 AND item_batch_number = $3 AND item_rack_location = $4;`
   
             
          const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item_total_quantity, item_id, item_batch_number, item_rack_location]);
            
   


       }
    }
}



export async function updateInvoiceItem(newItemsData: any) {
    try {
        await client.query('BEGIN');

        for (const item of newItemsData) {
            console.log("sssssss", item)

            let { item_id, sot_id, item_quantity, item_free_quantity, item_batch_number, item_rack_location   } = item;
            console.log(item_id, sot_id, typeof (item_quantity),typeof(item_free_quantity ), item_free_quantity,"dddddd")

            if (sot_id) {
               
    const updateQuery = ` UPDATE order_items_list 
     SET 
     item_open_quantity = item_open_quantity - $1 ,
     item_open_free_quantity = item_open_free_quantity- $2
    WHERE item_id = $3 AND sot_id = $4 AND item_batch_number = $5 AND item_rack_location = $6;
    `;


                const updateresult = await client.query(updateQuery, [item_quantity, item_free_quantity,item_id, sot_id,item_batch_number,item_rack_location])
            
            }
            const checkStatusQuery = `SELECT * FROM order_items_list WHERE  sot_id = $1`
            let checkStatusQueryResult = await client.query(checkStatusQuery, [sot_id]);

            let sot_return_status = "open"; // Default to "open" status

            if (checkStatusQueryResult.rows.length > 0) {
                console.log(typeof(checkStatusQueryResult.rows[0].item_to_be_received),"dfffffffffffff",checkStatusQueryResult.rows[0])
                const allDelivered = checkStatusQueryResult.rows.every(item => item.item_open_quantity === 0);
                sot_return_status = allDelivered ? "closed" : "open";
            }

            const updatestatusQuery = `UPDATE sales_order
        SET sot_return_status = $1 WHERE  sot_id = $2`;
            let updateStatus = await client.query(updatestatusQuery, [sot_return_status, sot_id]);
        



            
            

        }
        await client.query('COMMIT')
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}



export async function getCredNoteOrderList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, paymentStatus, searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (paymentStatus) {
            whereClause += ` AND so.icn_payment_status = '${paymentStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause
        

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }


        const joinClause = `JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`;

        // Add search condition for the specified column in both tables
        // const searchCondition = searchColumn
        // ? `AND (LOWER(${searchColumn === 'cmr_phone_number' ? 'so.' + searchColumn : 'c.' + searchColumn}) ILIKE LOWER('%${searchValue}%'))`
        // : '';

        const salesOrderAlias = 'so';
        const customerAlias = 'c';
        
        // Determine the column and table based on searchColumn
        const columnPrefix = searchColumn === 'cmr_first_name' ? customerAlias : salesOrderAlias;
        const columnReference = `${columnPrefix}.${searchColumn}`;
        
        // Construct the search condition
        const searchCondition = searchColumn
            ? `AND (LOWER(${columnReference}) ILIKE LOWER('%${searchValue}%'))`
            : '';


        const queryCount = `SELECT COUNT(*) FROM invoice_credit_note so ${joinClause} WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.*, c.cmr_first_name, c.cmr_last_name, c.cmr_email, c.cmr_address ,c.cmr_phone_number FROM invoice_credit_note so
     ${joinClause} WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(queryCount,findquery,"eeeeeeeeeee");
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}


export async function getCreditNoteOrderById(icn_id: any) {
    try {

        const GET_ORDER_DETAILS_QUERY = `
            SELECT
              invoice_credit_note.*,
              invoice_credit_note_item_list.*,
              customer_details.*,
              credit_note_invoice_payment_modes.*,
              so.sot_invoice_number
            FROM
              invoice_credit_note
            INNER JOIN
            invoice_credit_note_item_list ON invoice_credit_note.icn_id = invoice_credit_note_item_list.icn_id
            LEFT JOIN 
            credit_note_invoice_payment_modes ON credit_note_invoice_payment_modes.icn_id = invoice_credit_note.icn_id
            INNER JOIN
            customer_details ON invoice_credit_note.cmr_phone_number = customer_details.cmr_phone_number
            LEFT JOIN sales_order as so ON so.sot_id = invoice_credit_note_item_list.sot_id
            WHERE
            invoice_credit_note.icn_id = $1
          `;
        const orderDetailsResult = await client.query(GET_ORDER_DETAILS_QUERY, [icn_id]);

        return orderDetailsResult

    } catch (error) {
        throw new Error(error)
    }
}

export async function syncOrderDataResult(orderData: any, sot_id: any) {
    try {
        delete orderData.sot_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE sales_order
        SET ${updateOrderFields}
        WHERE sot_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [sot_id, ...orderValues]);
     //   console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getUnSynOrder(){
    try{
        const GET_ORDER_DETAILS_QUERY = `
        SELECT
            sales_order.*,
            order_items_list.*,
            billing_invoice_payment_modes.*
        FROM
            sales_order
        INNER JOIN
            order_items_list ON sales_order.sot_id = order_items_list.sot_id
        LEFT JOIN 
            billing_invoice_payment_modes ON billing_invoice_payment_modes.sot_id = sales_order.sot_id
        WHERE
          sales_order.data_synced = false AND sales_order.is_draft_order = false limit 5
    `;
        // const getCustomerQuery = `
        // SELECT *
        // FROM
        //   sales_order
        // WHERE
        //   data_synced = false AND is_draft_order = false ;`;

          const result = await client.query(GET_ORDER_DETAILS_QUERY);
       // console.log("orderdataunsynced" , result.rows)
         
          
          return result

    }catch(error){
              throw new Error(error)
    }
}



export async function getUnSynReturnOrder(){
    try{
        const GET_ORDER_DETAILS_QUERY = `
        SELECT
              invoice_credit_note.*,
              invoice_credit_note_item_list.*,
              credit_note_invoice_payment_modes.*
            FROM
              invoice_credit_note
            INNER JOIN
            invoice_credit_note_item_list ON invoice_credit_note.icn_id = invoice_credit_note_item_list.icn_id
            LEFT JOIN 
            credit_note_invoice_payment_modes ON credit_note_invoice_payment_modes.icn_id = invoice_credit_note.icn_id
        
        WHERE
          invoice_credit_note.data_synced = false 
    `;
        // const getCustomerQuery = `
        // SELECT *
        // FROM
        //   sales_order
        // WHERE
        //   data_synced = false AND is_draft_order = false ;`;

          const result = await client.query(GET_ORDER_DETAILS_QUERY);
      ///  console.log("orderdataunsynced" , result.rows)
         
          
          return result

    }catch(error){
              throw new Error(error)
    }
}







export async function syncReturnOrder(orderData: any, itemData: any,paymentData:any) {
    try {
        const req = {
         body: {
            "orderData": orderData,
            "itemData": itemData,
            "paymentData":paymentData,
            "transaction_type":"return_order"
        }
    }

        socket.emit('return_order', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}


export async function syncOrderRetunResult(orderData: any, sot_id: any) {
    try {
        delete orderData.icn_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE invoice_credit_note
        SET ${updateOrderFields}
        WHERE icn_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [sot_id, ...orderValues]);
      console.log(salesOrderResult.rows,[sot_id, ...orderValues],"return")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}
export async function getStoreDetails(){
    try{
        const qurey="select * from store_information_for_user_table";
        const result=await client.query(qurey);
        console.log(result.rows);
        return result.rows;
    }
    catch(error){
        throw new Error(error)
    }
        
}