import client from '../util/database';
import { ulid } from 'ulid';
import * as nextInvoicenumber  from '../service/documentNumberingSeries'
import { Socket } from 'socket.io-client';
import socket from '../sync/syncScript';
import { getposId } from './storeService';
import * as purchaseOrderService  from '../service/purchaseOrderService';
import * as  uomService from '../administrativesettings/src/service/uomService';


export async function addStockTransfer(stockTransferData: any, itemData: any,itemBatchData:any) {
    try {
        await client.query('BEGIN');
       
      
        let itt_id =  ulid()
        stockTransferData.itt_id = itt_id
        stockTransferData.stock_transfer_status = 'success'
        console.log(stockTransferData,itemData,itemBatchData,"erter")
        stockTransferData.stock_transfer_doc_number =  await nextInvoicenumber.getStockTransferNextInvoiceNumber()
        const columns = Object.keys(stockTransferData);
        const values = Object.values(stockTransferData);
        

        // Construct the parameterized query
        const insertstockDataquery = `INSERT INTO inventory_transfer_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(insertstockDataquery, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            const newItemsData = itemData.map((item: any) => ({
                ...item,
                itrt_id: ulid(),
                itt_id: itt_id

            }));


            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            const resultString = valuesStrings.join(', ');
            const query = `INSERT INTO inventory_transfer_rows_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
            const itemResult = await client.query(query);
            if (itemResult.rows.length > 0) {

                if(stockTransferData.stock_management_action !='stock_transfer_request'){
                const newbBatchItemsData = itemBatchData.map((item: any) => ({
                    ...item,
                    itt_id: itt_id
                }));
                const itemColumns = Object.keys(newbBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newbBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(itemColumns,valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const query = `INSERT INTO inventory_transfer_item_batches_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                const itemResult = await client.query(query);
            //    const updateInventory = await updateInventoryItems(itemBatchData,client)
           if(stockTransferData.stock_management_action ==='stock_out') {
            await   updateStoreInventorForVStockout(newbBatchItemsData,newItemsData,client)    
           }
             
            }
            }
           
            let order = orderResult.rows
            let item = itemResult.rows
            if(stockTransferData.stock_management_action ==='stock_in') {
                const additemBatches  =   await purchaseOrderService.additemBatchNumberfromStockIn(itemBatchData,itemData,client)
               }

            await client.query('COMMIT');

            return { order, item }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

async function updateInventoryItems(newItemsData:any, clien:any) {
    try{
        await client.query('BEGIN');
    for (const item of newItemsData) {
        console.log("Processing item:", item);
        const { item_id, item_batch_number, to_bin_location, item_batch_quantity ,to_bin_id} = item;


        // Fetch current items and their rack locations
        const fetchQuery = `
            SELECT item_rack_location
            FROM store_inventory_item_location_table
            WHERE item_id = $1 AND item_batch_number = $2
        `;
        const fetchResult = await client.query(fetchQuery, [item_id, item_batch_number]);
        const existingLocations = fetchResult.rows.map(row => row.item_rack_location);

        // Check if the item needs to be updated or inserted
        if (!existingLocations.includes(to_bin_location)) {
            // Insert new record or update existing one
            const updateQuery = `
            INSERT INTO store_inventory_item_location_table (item_id, item_batch_number, item_rack_location, item_quantity, to_bin_id)
            VALUES ($1, $2, $3, $4,$5)
            ON CONFLICT ON CONSTRAINT unique_item_batch_location
            DO UPDATE SET item_quantity = store_inventory_item_location_table.item_quantity + EXCLUDED.item_quantity;
        `;
        console.log(item_id, item_batch_number, to_bin_location, item_batch_quantity,to_bin_id, updateQuery, "updateQuery")
        
        
            const updateResult = await client.query(updateQuery, [item_id, item_batch_number, to_bin_location, item_batch_quantity,to_bin_id]);
            console.log(updateResult, "updateResult");
        } else {
            console.log(`No update needed for item_id: ${item_id}, item_batch_number: ${item_batch_number}, item_rack_location: ${to_bin_location}`);
        }

    }
                await client.query('COMMIT');
}catch(error){
    await client.query('ROLLBACK');
    console.log(error)
    throw new Error(error)
}
}


// export async function getStockTransferList(query: any) {
//     try {
//         const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate,  searchColumn, searchValue, filterValue } = query


//         const offset = (pageNumber - 1) * pageSize;
//         const limit = pageSize;

//         let whereClause = '';
//         let orderByClause = '';

//         // Add date range filter to the WHERE clause
//         if (fromDate && toDate) {
//             whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
//         }
        
//             if (filterValue) {
//                 whereClause += ` AND so.stock_management_action = '${filterValue}'`;  // Specify the table alias
//             }
        
       
//         if (sortBy && sortOrder) {
           
//                 orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            
//         } else {
//             // Default sorting by created_date in descending order if no sorting parameters provided
//             orderByClause = 'ORDER BY so.created_date DESC';
//         }



//         // Add search condition for the specified column in both tables
//         const searchCondition = searchColumn
//             ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
//             : '';

//         const queryCount = `SELECT COUNT(*) FROM inventory_transfer_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
//         const findquery: any = `SELECT so.* FROM inventory_transfer_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;
// console.log(queryCount,"queryCount")
// console.log(findquery,"findquery")
//         console.log(query);
//         const totalCount = await client.query(queryCount);
//         const getOrderList = await client.query(findquery, [offset, limit]);
//         const totalRowsCount = totalCount.rows[0].count
//         const orderList = getOrderList.rows

//         return { totalRowsCount, orderList }

//     } catch (error) {
//         throw new Error(error)
//     }
// }


export async function getStockTransferList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, searchColumn, searchValue, filterValue } = query;

        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;
        }

        // Add filter value condition
        if (filterValue) {
            whereClause += ` AND so.stock_management_action = '${filterValue}'`;
        }

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;
        } else {
            orderByClause = 'ORDER BY so.created_date DESC';
        }

        // Add search condition for the specified column in both tables
        let searchCondition = '';
        if (searchColumn && searchValue) {
            if (searchColumn === 'item_name') {
                searchCondition = `AND LOWER(itr.${searchColumn}) ILIKE LOWER('%${searchValue}%')`;
            } else {
                searchCondition = `AND LOWER(so.${searchColumn}) ILIKE LOWER('%${searchValue}%')`;
            }
        }

        const queryCount = `
            SELECT COUNT(DISTINCT so.itt_id) 
            FROM inventory_transfer_table so 
            LEFT JOIN inventory_transfer_rows_table itr ON so.itt_id = itr.itt_id 
            WHERE 1=1 ${whereClause} ${searchCondition};
        `;

        const findQuery = `
            SELECT DISTINCT so.*
            FROM inventory_transfer_table so 
            LEFT JOIN inventory_transfer_rows_table itr ON so.itt_id = itr.itt_id 
            WHERE 1=1 ${whereClause} ${searchCondition} 
            ${orderByClause} OFFSET $1 LIMIT $2;
        `;

        console.log(queryCount, "queryCount");
        console.log(findQuery, "findQuery");
        console.log(query);

        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findQuery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count;
        const orderList = getOrderList.rows;

        return { totalRowsCount, orderList };

    } catch (error) {
        throw new Error(error.message);
    }
}



export async function addWareHouse(wareHouseData:any){
    try{
        wareHouseData.warehouse_id = ulid();
        const columns = Object.keys(wareHouseData);
        const values = Object.values(wareHouseData);

        // Construct the parameterized query
        const addWareHouseQuery = `INSERT INTO all_store_details_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(addWareHouseQuery);

        // Execute the query with parameterized values
        const insertCustomerQueryResult = await client.query(addWareHouseQuery, values);

        return insertCustomerQueryResult

    }catch(error){
              throw new Error(error)
    }
}


export async function getWareHouseList(){
    try{

       
        // Construct the parameterized query
        const getWarehouserQuery = `SELECT *  FROM all_store_details_table `;
        console.log(getWarehouserQuery);

        // Execute the query with parameterized values
        const getWarehouserQueryResult = await client.query(getWarehouserQuery);

        return getWarehouserQueryResult.rows

    }catch(error){
              throw new Error(error)
    }
}


export async function getStockTransferById(itt_id:any){
    try{

       
        // Construct the parameterized query
        const getStocktransferQuery = 
        `
        SELECT 
        it.* , 
        ir.*, 
        ib.* 
        FROM inventory_transfer_table AS it
        LEFT JOIN  inventory_transfer_rows_table  AS ir on ir.itt_id = it.itt_id
        LEFT JOIN  inventory_transfer_item_batches_table as ib on  ir.itt_id = ib.itt_id AND  ir.item_id = ib.item_id
        WHERE it.itt_id = $1 `
         ;
       
        // Execute the query with parameterized values
        const getStockTransferQueryResult = await client.query(getStocktransferQuery,[itt_id]);
        const getStockOrderid = 'SELECT * FROM inventory_transfer_table WHERE itt_id = $1 '
        const getStockOrderidResult = await client.query(getStockOrderid, [itt_id]);

        console.log(getStockTransferQueryResult.rows, "quereyrrr");

        if (getStockTransferQueryResult.rows.length > 0) {

            const groupedItems = getStockTransferQueryResult.rows.reduce((acc, item) => {
                const key = item.itt_id;
                if (!acc[key]) {
                    acc[key] = {
                        stocktransferData: {
                        itt_id:item.itt_id,
                        warehouse_id :item.warehouse_id,
                        warehouse_name :item.warehouse_name,
                        transfer_date :item.transfer_date,
                        stock_management_action :item.stock_management_action,
                        posting_date  : item.posting_date,
                        from_warehouse_id :item.from_warehouse_id,
                        from_warehouse_name  :item.from_warehouse_name,
                        to_warehouse_id  :item.to_warehouse_id,
                        to_warehouse_name  :item.to_warehouse_name,
                        stock_transfer_doc_number :item.stock_transfer_doc_number,
                        stock_transfer_reason : item.stock_transfer_reason,
                        is_stock_in_void_able:item.is_stock_in_void_able,
                        stock_transfer_status:item.stock_transfer_status,
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((i: { item_id: any; }) => i.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_id :item.item_id,
                        item_batch_number :item.item_batch_number,
                        from_bin_location:item.from_bin_location,
                        to_bin_location :item.to_bin_location,
                        item_exp_date:item.item_exp_date,
                        from_warehouse_id :item.from_warehouse_id,
                        from_warehouse_name :item.from_warehouse_name,
                        to_warehouse_id  :item.to_warehouse_id,
                        to_bin_id:item.to_bin_id,
                        from_bin_id :item.from_bin_id,
                        to_warehouse_name :item.to_warehouse_name,
                        item_batch_quantity :item.item_batch_quantity,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate
                    });
                } else {
                    acc[key].itemData.push({

                        item_id :item.item_id,
                        item_name :item.item_name,
                        item_uom_source :item.item_uom_source,
                        item_uom_destination :item.item_uom_destination,
                        item_uom :item.item_uom,
                        item_code :item.item_code,
                        item_quantity :item.item_quantity,
                        is_item_void_able:item.is_item_void_able,
                        item_void_status:item.item_void_status,
                        item_uom_id :item.item_uom_id,
                        itemBatchData: [{
                            item_id :item.item_id,
                            item_batch_number :item.item_batch_number,
                            from_bin_location:item.from_bin_location,
                            to_bin_location :item.to_bin_location,
                            item_exp_date:item.item_exp_date,
                            from_warehouse_id :item.from_warehouse_id,
                            from_warehouse_name :item.from_warehouse_name,
                            to_warehouse_id  :item.to_warehouse_id,
                            to_bin_id:item.to_bin_id,
                            from_bin_id :item.from_bin_id,
                            to_warehouse_name :item.to_warehouse_name,
                            item_batch_quantity :item.item_batch_quantity,
                            item_batch_free_quantity:item.item_batch_free_quantity,
                            item_batch_unit_price:item.item_batch_unit_price,
                            item_batch_purchase_rate:item.item_batch_purchase_rate
                        }]
                    });
                }
                return acc;
            }, {});




            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);


            return resultArray
        } else {
            return []
        }




    }catch(error){
              throw new Error(error)
    }
}

// export async function  updateStockUsedInBillingAndDelivery(newItemsData:any){


//     try {
//         // Begin transaction
//         await client.query('BEGIN');

//         for (let item of newItemsData) {
//             const { item_id, item_batch_number, item_quantity } = item;

//             const getIdOfStockTransfer = `
//                 SELECT itt_id 
//                 FROM inventory_transfer_item_batches_table 
//                 WHERE item_id = $1 
//                 AND item_batch_number = $2
//                 ORDER BY created_date DESC 
//                 LIMIT 1
//             `;

//             // Fetch the most recent transfer ID
//             const getIdOfStockTransferResult = await client.query(getIdOfStockTransfer, [item_id, item_batch_number]);

//             if (getIdOfStockTransferResult.rows.length > 0) {
//                 const itt_id = getIdOfStockTransferResult.rows[0].itt_id;

//                 const updateVoidStatusStockItems = `
//                     UPDATE inventory_transfer_rows_table 
//                     SET item_quantity_used = $1, is_item_void_able = FALSE 
//                     WHERE itt_id = $2
//                 `;

//                 const updateVoidStatusStockin = `
//                     UPDATE inventory_transfer_table 
//                     SET is_stock_in_void_able = FALSE 
//                     WHERE itt_id = $1
//                 `;

//                 // Run both updates concurrently using Promise.all
//                 await Promise.all([
//                     client.query(updateVoidStatusStockItems, [item_quantity, itt_id]),
//                     client.query(updateVoidStatusStockin, [itt_id])
//                 ]);
//             }
//         }

//         // Commit the transaction if all updates succeed
//         await client.query('COMMIT');
//     } catch (error) {
//         // Rollback in case of any error
//         await client.query('ROLLBACK');
//         console.error("Error updating stock used in billing and delivery: ", error);
//         throw error;  // Re-throw the original error
//     }
// }
export async function updateStockUsedInBillingAndDelivery(newItemsData:any) {
    try {
        await client.query('BEGIN');
        for (let item of newItemsData) {
            const { item_id, item_batch_number, item_quantity,sot_id,item_rack_location } = item;
           
            const getIdOfStockTransfer = `
                SELECT itt_id 
                FROM inventory_transfer_item_batches_table 
                WHERE item_id = $1 
                AND item_batch_number = $2
                ORDER BY created_date DESC 
                LIMIT 4
            `;
            const getIdOfStockTransferResult = await client.query(getIdOfStockTransfer, [item_id, item_batch_number]);
            if (getIdOfStockTransferResult.rows.length > 0) {
                for(let item of getIdOfStockTransferResult.rows){
                const itt_id = item.itt_id
                const updateVoidStatusStockItems = `
                    UPDATE inventory_transfer_rows_table 
                    SET item_quantity_used = item_quantity_used + $1, is_item_void_able = FALSE 
                    WHERE itt_id = $2
                `;
                const updateVoidStatusStockin = `
                    UPDATE inventory_transfer_table 
                    SET is_stock_in_void_able = FALSE 
                    WHERE itt_id = $1  RETURNING *;
                `;
              

                
           const [updateItemsRows,updateMasterData] =      await Promise.all([
                    client.query(updateVoidStatusStockItems, [item_quantity, itt_id]),
                    client.query(updateVoidStatusStockin, [itt_id])
                ]);
              
            if(updateMasterData.rows[0].stock_management_action === 'stock_in')  {
                let stock_in_itt_id = updateMasterData.rows[0].itt_id
                const updateOrderItemittId = `
                UPDATE order_items_list 
                SET stock_in_itt_id = $1
                WHERE sot_id = $2 AND item_id = $3  AND item_batch_number = $4 AND item_rack_location = $5 RETURNING *;
            `;

           const updateOrderItem =    await   client.query(updateOrderItemittId, [stock_in_itt_id, sot_id,item_id,item_batch_number,item_rack_location])
           console.log(updateOrderItem,"2222222")
            }  

            }

            }
        }
        await client.query('COMMIT');
    }
    catch (error) {
        await client.query('ROLLBACK');
        console.error("Error updating stock used in billing and delivery: ", error);
        throw error;
    }
}

export async function voidStockTransfer(stockTransferData: any, itemData: any) {
    try {
        await client.query('BEGIN');
        console.log(stockTransferData,JSON.stringify(stockTransferData, null, 2))
        let itt_id =  ulid()
         stockTransferData.stock_transfer_status = 'closed'
        stockTransferData.itt_id = itt_id
      //  console.log(stockTransferData,itemData,itemBatchData,"erter")
        stockTransferData.stock_transfer_doc_number =  await nextInvoicenumber.getStockTransferNextInvoiceNumber()
        const columns = Object.keys(stockTransferData);
        const values = Object.values(stockTransferData);
        

        // Construct the parameterized query
        const insertstockDataquery = `INSERT INTO inventory_transfer_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        //  console.log(query)

        // Execute the query with parameterized values
        const orderResult = await client.query(insertstockDataquery, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            // const newItemsData = itemData.map((item: any) => ({
            //     ...item,
            //     itrt_id: ulid(),
            //     itt_id: itt_id

            // }));


            //console.log(newItemsData, 'rrrrr')
            // const itemColumns = Object.keys(newItemsData[0]);
            // // Extract values for each item in newItemsData
            // const itemValuesArray = newItemsData.map((item: any) =>
            //     Object.values(item)
            // );

            // const valuesStrings = itemValuesArray.map((innerArray: any) =>
            //     `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            // );

            // console.log(valuesStrings)

            // const resultString = valuesStrings.join(', ');
            // const query = `INSERT INTO inventory_transfer_rows_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
            // const itemResult = await client.query(query);

            const newItemsData = itemData.map((item: any) => {
                // Destructure item to extract specific properties and the rest
                const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
            console.log(itemBatchData)
                // Filter out properties with null values
                const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {} as { [key: string]: any });
            
                // Return the new item object with additional properties
                return {
                    ...filteredItem,
                    itrt_id: ulid(),
                    itt_id: itt_id,
                    item_void_status:'cancelled'
                
                };
            });
           
            //console.log(newItemsData, 'rrrrr')
            const itemColumns = Object.keys(newItemsData[0]);
            // Extract values for each item in newItemsData
            const itemValuesArray = newItemsData.map((item: any) =>
                Object.values(item)
            );

            const valuesStrings = itemValuesArray.map((innerArray: any) =>
                `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
            );

            console.log(valuesStrings)

            // Join the strings into a single string
            const resultString = valuesStrings.join(', ');
            //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
            const itemquery = `INSERT INTO inventory_transfer_rows_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;


            // console.log(query)
            const itemResult = await client.query(itemquery);
            const extractedBatchData :any= []
            itemData.forEach((item: { itemBatchData: any[]; }) => {
                // Check if itemBatchData exists and is an array
                
                if (Array.isArray(item.itemBatchData)) {
                  // Push each itemBatchData object into the extractedBatchData array
                  item.itemBatchData.forEach(batchData => {
                    extractedBatchData.push(batchData);
                  });
                }
              });

            console.log(itemquery,"itemquery")

            if (itemResult.rows.length > 0) {
                const formatDateString = (dateString: string | number | Date) => {
                    const date = new Date(dateString);
                    return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                };


                const newBatchItemsData = extractedBatchData.map((item: any) => {
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });

                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                        item_exp_date: formatDateString(item.item_exp_date),
                        itt_id: itt_id
                    };
                });
                
            
              
                const itemColumns = Object.keys(newBatchItemsData[0]);
                // Extract values for each item in newItemsData
                const itemValuesArray = newBatchItemsData.map((item: any) =>
                    Object.values(item)
                );

                const valuesStrings = itemValuesArray.map((innerArray: any) =>
                    `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
                );

                console.log(valuesStrings)

                // Join the strings into a single string
                const resultString = valuesStrings.join(', ');
                //   const itemValuesPlaceholders = itemValues.map((_, i) => `$${i + 1}`).join(', ');
                const addbatchuery = `INSERT INTO inventory_transfer_item_batches_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

                console.log(addbatchuery,"addbatchuery")
                const itemResult = await client.query(addbatchuery);
                updateStoreInventorForVoidStockTransfer(newBatchItemsData,newItemsData)

            
           
            let order = orderResult.rows
            let item = itemResult.rows
            await client.query('COMMIT');

            return { order, item }
            }
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function updateStoreInventorForVoidStockTransfer(itemBatchDataofInventory: any,itemData:any) {
  
try{
    
    for(let itemdata of itemData){
        for(let batch of itemBatchDataofInventory ){
            if(itemdata.item_id === batch.item_id){
                batch.item_uom_id = itemdata.item_uom_id
            }
        }
    }
        for (const item of itemBatchDataofInventory) {
            console.log("sssssss", item)
            const { item_id, item_batch_number, item_batch_quantity ,to_bin_location} = item;


            let item_quantity
            if(item.item_uom_id){
           
                const getUomQunatity =   await uomService.getUomGroupOfItems(item.item_uom_id)
                if(getUomQunatity.rows.length>0){
                    
                    item_quantity = getUomQunatity.rows[0].base_quantity * item.item_batch_quantity
                }
                  }

                  

        const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
        SET item_quantity = item_quantity - $1
        WHERE item_id = $2 AND item_batch_number = $3 AND item_rack_location = $4;`

          
        console.log(item_id, item_batch_number, typeof (item_quantity),item_quantity, item_id, item_batch_number, to_bin_location,"wwwwwwwww")
        const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item_quantity, item_id, item_batch_number, to_bin_location]);
            


        }
    }catch(error){
        console.log(error)
    }
}

export async function getStockTransferByIdANDItem_id(itt_id:any,item_id:any){
    try{

       
        // Construct the parameterized query
        const getStocktransferQuery = 
        `SELECT 
        it.* , 
        ir.*, 
        ib.* 
        FROM inventory_transfer_table AS it
        LEFT JOIN  inventory_transfer_rows_table  AS ir on ir.itt_id = it.itt_id
        LEFT JOIN  inventory_transfer_item_batches_table as ib on  ir.itt_id = ib.itt_id AND  ir.item_id = ib.item_id
        WHERE ir.itt_id = $1 AND ir.item_id = $2 `
         ;
        console.log(getStocktransferQuery);

        // Execute the query with parameterized values
        const getStockTransferQueryResult = await client.query(getStocktransferQuery,[itt_id,item_id]);


        if (getStockTransferQueryResult.rows.length > 0) {

            const groupedItems = getStockTransferQueryResult.rows.reduce((acc, item) => {
                const key = item.itt_id;
                if (!acc[key]) {
                    acc[key] = {
                        stocktransferData: {
                            itt_id:item.itt_id,
                        warehouse_id :item.warehouse_id,
                        warehouse_name :item.warehouse_name,
                        transfer_date :item.transfer_date,
                        stock_management_action :item.stock_management_action,
                        posting_date  : item.posting_date,
                        from_warehouse_id :item.from_warehouse_id,
                        from_warehouse_name  :item.from_warehouse_name,
                        to_warehouse_id  :item.to_warehouse_id,
                        to_warehouse_name  :item.to_warehouse_name,
                        stock_transfer_doc_number :item.stock_transfer_doc_number,
                        stock_transfer_reason : item.stock_transfer_reason,
                        is_stock_in_void_able:item.is_stock_in_void_able
                        },
                        itemData: [],
                    };
                }
                const existingItem = acc[key].itemData.find((i: { item_id: any; }) => i.item_id === item.item_id);
                if (existingItem) {
                    existingItem.itemBatchData.push({
                        item_id :item.item_id,
                        item_batch_number :item.item_batch_number,
                        from_bin_location:item.from_bin_location,
                        to_bin_location :item.to_bin_location,
                        item_exp_date:item.item_exp_date,
                        from_warehouse_id :item.from_warehouse_id,
                        from_warehouse_name :item.from_warehouse_name,
                        to_warehouse_id  :item.to_warehouse_id,
                        to_bin_id:item.to_bin_id,
                        from_bin_id :item.from_bin_id,
                        to_warehouse_name :item.to_warehouse_name,
                        item_batch_quantity :item.item_batch_quantity,
                    });
                } else {
                    acc[key].itemData.push({

                        item_id :item.item_id,
                        item_name :item.item_name,
                        item_uom_source :item.item_uom_source,
                        item_uom_destination :item.item_uom_destination,
                        item_uom :item.item_uom,
                        item_quantity :item.item_quantity,
                        is_item_void_able:item.is_item_void_able,
                        itemBatchData: [{
                            item_id :item.item_id,
                            item_batch_number :item.item_batch_number,
                            from_bin_location:item.from_bin_location,
                            to_bin_location :item.to_bin_location,
                            item_exp_date:item.item_exp_date,
                            from_warehouse_id :item.from_warehouse_id,
                            from_warehouse_name :item.from_warehouse_name,
                            to_warehouse_id  :item.to_warehouse_id,
                            to_bin_id:item.to_bin_id,
                            from_bin_id :item.from_bin_id,
                            to_warehouse_name :item.to_warehouse_name,
                            item_batch_quantity :item.item_batch_quantity,
                        }]
                    });
                }
                return acc;
            }, {});




            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);


            return resultArray
        } else {
            return []
        }




    }catch(error){
              throw new Error(error)
    }
}


export async function getUnSyncedStockTransfer(){
    try{
        const GET_ORDER_DETAILS_QUERY = `
       SELECT 
        it.* , 
        ir.*, 
        ib.* 
        FROM inventory_transfer_table AS it
        LEFT JOIN  inventory_transfer_rows_table  AS ir on ir.itt_id = it.itt_id
        LEFT JOIN  inventory_transfer_item_batches_table as ib on  ir.itt_id = ib.itt_id AND  ir.item_id = ib.item_id
        WHERE it.data_synced = false `
     
    
        // const getCustomerQuery = `
        // SELECT *
        // FROM
        //   sales_order
        // WHERE
        //   data_synced = false AND is_draft_order = false ;`;

          const result = await client.query(GET_ORDER_DETAILS_QUERY);
      //    console.log("datasynced" , result.rows)
         
          
          return result

    }catch(error){
              throw new Error(error)
    }
}

export async function syncStockTransferDocument(orderData: any, itemData: any,itemBatchData:any) {
    try {
        const req = {
         body: {
            "stockTransferData": orderData,
            "itemData": itemData,
            "itemBatchData":itemBatchData,
            "transaction_type":"stockTransfer"
        }
    
    }

    console.log(req,"stockTransfer")
        socket.emit('stockTransferSync', req)
   
    } catch (error) {
        console.error('Error:', error);
    }
}


export async function syncStockTransferDataResult(orderData: any, itt_id: any) {
    try {
        delete orderData.itt_id
    
        const updateOrderFields = Object.entries(orderData)
            .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
            .join(', ');

        // Get the values for the updateSalesOrderQuery
        const orderValues = Object.values(orderData);

        // Construct the query to update the sales_order table
        const updateSalesOrderQuery = `
        UPDATE inventory_transfer_table
        SET ${updateOrderFields}
        WHERE itt_id = $1
        RETURNING *;
        
      `;
console.log(updateSalesOrderQuery,orderValues,"w34")
        

        const salesOrderResult = await client.query(updateSalesOrderQuery, [itt_id, ...orderValues]);
      //  console.log(salesOrderResult.rows,"qwewewwewe")
        return salesOrderResult

    } catch (error) {
       

        throw new Error(error)
    }
}


export async function getItemInventory(){
    try{
          const getposInventoryBatches = `SELECT * FROM items_batch_no_table`
          const getposInventoryBatchesLocation = `SELECT * FROM store_inventory_item_location_table`
     //   const getposid = await   getposId()

console.log(getposInventoryBatches,getposInventoryBatchesLocation,'getposInventoryBatchesLocationgetposInventoryBatchesLocation')
          const [item_batches, item_location,getposid] = await Promise.all([client.query(getposInventoryBatches),client.query(getposInventoryBatchesLocation),   getposId()])
          const pos_id = getposid.rows[0].pos_id
        //  console.log(pos_id,"2222222")
          item_batches.rows = item_batches.rows.map(item => ({
            ...item,
            pos_id :pos_id // Add the pos_id field
          }));
          
          // Add pos_id to each item in item_location
          item_location.rows = item_location.rows.map(item => ({
            ...item,
            pos_id :pos_id // Add the pos_id field
          }));

//console.log(item_location.rows )
        const req = {
            body: {
                "item_batches":item_batches.rows ,
                "item_location": item_location.rows,
                "transaction_type":"inventory"
            }
        }
        
          socket.emit('inventorySync', req)
    }catch(error){


    }
}

export async function updateStockTransferStatus(stock_transfer_status: any, itt_id: any) {
    try {
       
        const updatestatusQuery = `UPDATE inventory_transfer_table
                    SET stock_transfer_status = $1 WHERE  itt_id = $2 RETURNING *;`
        console.log(updatestatusQuery,stock_transfer_status, itt_id)
        let updateStatus = await client.query(updatestatusQuery, [stock_transfer_status, itt_id]);

        return updateStatus
    } catch (error) {
        throw new Error(error)
    }

}

export async function updateitemStockTransferStatus(stock_item_transfer_status: any,item_id:any, itt_id: any) {
    try {
       
        const updatestatusQuery = `UPDATE inventory_transfer_rows_table
                    SET item_void_status = $1 WHERE  itt_id = $2 AND item_id =$3 RETURNING *;`
        console.log(updatestatusQuery,stock_item_transfer_status, itt_id)
        let updateStatus = await client.query(updatestatusQuery, [stock_item_transfer_status, itt_id,item_id]);


        const checkStatusQuery = `SELECT * FROM inventory_transfer_rows_table WHERE  itt_id = $1`

                    let checkStatusQueryResult = await client.query(checkStatusQuery, [itt_id]);

                    let stock_transfer_status = "partially cancelled"; // Default to "open" status

                    if (checkStatusQueryResult.rows.length > 0) {
                        const allDelivered = checkStatusQueryResult.rows.every(item => item.item_void_status === 'cancelled');
                        stock_transfer_status = allDelivered ? "cancelled" : "partially cancelled";
                    }

                    const result = updateStockTransferStatus(stock_transfer_status, itt_id)

    
    } catch (error) {
        throw new Error(error)
    }

}


export async function updateStoreInventorForVStockout(itemBatchDataofInventory: any,itemData:any, client:any) {
  try{
    for(let itemdata of itemData){
        for(let batch of itemBatchDataofInventory ){
            if(itemdata.item_id === batch.item_id){
                batch.item_uom_id = itemdata.item_uom_id
            }
        }
    }
    
    for (const item of itemBatchDataofInventory) {
        console.log("sssssss", item)
        const { item_id, item_batch_number, item_batch_quantity ,from_bin_location} = item;
        console.log(item_id, item_batch_number, typeof (item_batch_quantity))
       let item_quantity
        if(item.item_uom_id){
       
            const getUomQunatity =   await uomService.getUomGroupOfItems(item.item_uom_id)
            if(getUomQunatity.rows.length>0){
                
                item_quantity = getUomQunatity.rows[0].base_quantity * item.item_batch_quantity + getUomQunatity.rows[0].base_quantity * item.item_batch_free_quantity 
            }
              }

const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
    SET item_quantity = item_quantity - $1
    WHERE item_id = $2 AND item_batch_number = $3 AND item_rack_location = $4;`

      

        const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item_quantity, item_id, item_batch_number, from_bin_location]);
     


    }
}catch(error){
    throw new Error(error)
}
}

export async function updateStockUsedInBillingReturn(newItemsData:any) {
    try {
        await client.query('BEGIN');
        for (let item of newItemsData) {
            const { item_id, item_batch_number, item_quantity ,sot_id,item_rack_location} = item;
            
            const getOrderItemittId = `
            SELECT * FROM  order_items_list 
            WHERE sot_id = $1 AND item_id = $2  AND item_batch_number = $3 AND item_rack_location = $4 ;
        `;

        const getIdOfStockTransferResult =    await   client.query(getOrderItemittId, [sot_id,item_id,item_batch_number,item_rack_location])
        console.log(getIdOfStockTransferResult.rows,"2222222")
            // const getIdOfStockTransfer = `
            //     SELECT itt_id 
            //     FROM inventory_transfer_item_batches_table 
            //     WHERE item_id = $1 
            //     AND item_batch_number = $2
            //     ORDER BY created_date DESC 
            //     LIMIT 4
            // `;
            // const getIdOfStockTransferResult = await client.query(getIdOfStockTransfer, [item_id, item_batch_number]);
            if (getIdOfStockTransferResult.rows.length > 0 && getIdOfStockTransferResult.rows[0].stock_in_itt_id != null ) {
            
                const itt_id = getIdOfStockTransferResult.rows[0].stock_in_itt_id
               const item_id = item.item_id
            
                const updateVoidStatusStockItems = `
                    UPDATE inventory_transfer_rows_table 
                    SET item_quantity_used = item_quantity_used - $1
                    WHERE itt_id = $2 AND item_id = $3 RETURNING *;
                `;
              const  updateVoidStockItems = await client.query(updateVoidStatusStockItems, [item_quantity, itt_id,item_id])
              console.log(updateVoidStockItems.rows[0].item_quantity_used===0,typeof(updateVoidStockItems.rows[0].item_quantity_used),updateVoidStockItems.rows[0].item_quantity_used)
              if(parseInt(updateVoidStockItems.rows[0].item_quantity_used, 10) === 0){
                const updatestatusQuery = `UPDATE inventory_transfer_rows_table
                SET is_item_void_able = $1 WHERE  itt_id = $2 AND item_id = $3 RETURNING *;`
          const is_item_void_able = true
    console.log(updatestatusQuery,is_item_void_able, itt_id)
    let updateStatus = await client.query(updatestatusQuery, [is_item_void_able, itt_id,item_id]);
              }

    const checkStatusQuery = `SELECT * FROM inventory_transfer_rows_table WHERE  itt_id = $1`

                let checkStatusQueryResult = await client.query(checkStatusQuery, [itt_id]);

                let is_stock_in_void_able = false // Default to "open" status

                if (checkStatusQueryResult.rows.length > 0) {
                   
                    const allDelivered = checkStatusQueryResult.rows.every(item => item.is_item_void_able === true);
                    is_stock_in_void_able = allDelivered ? true : false;
                }

                const updateVoidStatusStockin = `
                UPDATE inventory_transfer_table 
                SET is_stock_in_void_able = $1
                WHERE itt_id = $2  RETURNING *;
            `;

       const updateStockinData =      await client.query(updateVoidStatusStockin,[is_stock_in_void_able,itt_id])
            console.log(is_stock_in_void_able,updateVoidStatusStockin,checkStatusQueryResult.rows,updateStockinData.rows)
            
            }
        }
        await client.query('COMMIT');
    }
    catch (error) {
        await client.query('ROLLBACK');
        console.error("Error updating stock used in billing and delivery: ", error);
        throw error;
    }
}