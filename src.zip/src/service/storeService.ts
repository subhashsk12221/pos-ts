import socket from '../sync/syncScript';
import client from '../util/database';


export async function addStoreAddress(addressData:any){
    try{

        const columns = Object.keys(addressData);
        const values = Object.values(addressData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO store_info_address_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);
        if(result.rows.length>0){
            const store_id = addressData.store_id
            const store_info_personal_details_tableQuery = `
            INSERT INTO store_info_personal_details_table (store_id)
            VALUES ($1)
        `;

        const store_info_firm_details_tableQuery = `
            INSERT INTO store_info_firm_details_table (store_id)
            VALUES ($1)
        `;
        
        const store_agreement_tableQuery = `
            INSERT INTO store_agreement_table (store_id)
            VALUES ($1)
        `;

        const store_info_payment_tableQuery = `
            INSERT INTO store_info_payment_table (store_id)
            VALUES ($1)
        `;

        const store_info_drug_license_tableQuery = `
            INSERT INTO store_info_drug_license_table (store_id)
            VALUES ($1)
        `;

        
        
       


        // Use Promise.all to parallelize the execution of the two queries
        await Promise.all([
            client.query(store_info_personal_details_tableQuery, [store_id]),
            client.query(store_info_firm_details_tableQuery, [store_id]),
            client.query(store_agreement_tableQuery, [store_id]),
            client.query(store_info_payment_tableQuery, [store_id]),
            client.query(store_info_drug_license_tableQuery, [store_id]),
           
        ]);
        }
    

        return result
    

    }catch(error){
              throw new Error(error)
    }
}

export async function addUpdateStoreAdress(PersonalData:any){
    try{

        const { store_id } = PersonalData
    


        const columnValuePairs = Object.entries(PersonalData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(PersonalData);

        const query = `
    UPDATE store_info_address_table
    SET ${columnValuePairs}
    WHERE store_id = $${Object.keys(PersonalData).length + 1}
    RETURNING *;`;
        console.log(values)

        const result = await client.query(query, [...values, store_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addStorePersonalDetails(PersonalData:any){
    try{

        const { store_id } = PersonalData
    


        const columnValuePairs = Object.entries(PersonalData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(PersonalData);

        const query = `
    UPDATE store_info_personal_details_table
    SET ${columnValuePairs}
    WHERE store_id = $${Object.keys(PersonalData).length + 1}
    RETURNING *;`;
        console.log(values)

        const result = await client.query(query, [...values, store_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function addStoreFirmDetails(firmData:any){
    try{
        

        const { store_id } = firmData
    


        const columnValuePairs = Object.entries(firmData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(firmData);

        const query = `
    UPDATE store_info_firm_details_table
    SET ${columnValuePairs}
    WHERE store_id = $${Object.keys(firmData).length + 1}
    RETURNING *;`;
        console.log(values)

        const result = await client.query(query, [...values, store_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addStoreAgreementDetails(AgrementData:any){
    try{
        


        const { store_id } = AgrementData
    


        const columnValuePairs = Object.entries(AgrementData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(AgrementData);

        const query = `
    UPDATE store_agreement_table
    SET ${columnValuePairs}
    WHERE store_id = $${Object.keys(AgrementData).length + 1}
    RETURNING *;`;
        console.log(values)

        const result = await client.query(query, [...values, store_id]);

        return result
    }catch(error){
              throw new Error(error)
    }
}

export async function addStorePaymentDetails(payementData:any){
    try{
        
        const { store_id } = payementData

        const columnValuePairs = Object.entries(payementData)
        .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
        .join(', ');
    // Extracting values from the updatedFields object
    const values = Object.values(payementData);

    const query = `
UPDATE store_info_payment_table
SET ${columnValuePairs}
WHERE store_id = $${Object.keys(payementData).length + 1}
RETURNING *;`;
    console.log(values)

    const result = await client.query(query, [...values, store_id]);

    return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addStoreDrugLicenseDetails(drugLicenseData:any){
    try{
        

        const { store_id } = drugLicenseData

        const columnValuePairs = Object.entries(drugLicenseData)
        .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
        .join(', ');
    // Extracting values from the updatedFields object
    const values = Object.values(drugLicenseData);

    const query = `
UPDATE store_info_drug_license_table
SET ${columnValuePairs}
WHERE store_id = $${Object.keys(drugLicenseData).length + 1}
RETURNING *;`;
    console.log(values)

    const result = await client.query(query, [...values, store_id]);

    return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getById(store_id:any){
    try{
        console.log(store_id)
        const GET_ORDER_DETAILS_QUERY = `
            SELECT *
            FROM
            store_info_address_table
            LEFT JOIN
            store_info_personal_details_table ON store_info_address_table.store_id = store_info_personal_details_table.store_id
            LEFT JOIN
            store_info_firm_details_table ON store_info_address_table.store_id = store_info_firm_details_table.store_id
            LEFT JOIN
            store_agreement_table ON store_info_address_table.store_id = store_agreement_table.store_id
            LEFT JOIN
            store_info_payment_table ON store_info_address_table.store_id = store_info_payment_table.store_id
            LEFT JOIN
            store_info_drug_license_table ON store_info_address_table.store_id = store_info_drug_license_table.store_id
            WHERE
            store_info_address_table.store_id = $1
          `;
        const findStoreDetails = await client.query(GET_ORDER_DETAILS_QUERY, [store_id]);
        findStoreDetails
        return findStoreDetails  

    }catch(error){
              throw new Error(error)
    }
}

export async function getStoreList(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, searchColumn, searchValue } = query;

        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';
        let joinClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND sa.created_date >= '${fromDate}' AND sa.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            orderByClause = `ORDER BY ${sortBy} ${sortOrder}`;
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY sa.created_date DESC';
        }

        // Add search condition for the specified column in all joined tables
        const searchCondition = searchColumn
        ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
        : '';

        joinClause = `
            LEFT JOIN store_info_personal_details_table pd ON sa.store_id = pd.store_id
            LEFT JOIN store_info_firm_details_table fd ON sa.store_id = fd.store_id
            LEFT JOIN store_agreement_table a ON sa.store_id = a.store_id
            LEFT JOIN store_info_payment_table pt ON sa.store_id = pt.store_id
            LEFT JOIN store_info_drug_license_table dl ON sa.store_id = dl.store_id
            
        `;

        const queryCount = `SELECT COUNT(*) FROM store_info_address_table sa ${joinClause} WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findQuery = `SELECT sa.*, fd.*, a.*,dl.*,pt.*,pd.*
            FROM store_info_address_table sa
            ${joinClause}
            WHERE 1=1 ${whereClause} ${searchCondition}
            ${orderByClause ? orderByClause : ''}
            OFFSET $1 LIMIT $2;`;

        const totalCount = await client.query(queryCount);
        const getStoreList = await client.query(findQuery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count;
        const storeList = getStoreList.rows;

        return { totalRowsCount, storeList };

    } catch (error) {
        console.log(error)
        throw new Error(error);
    }
}
export async function addStoreService(storeData: any) {
    const columns = Object.keys(storeData);
    const values = Object.values(storeData);
    const query = `INSERT INTO store_information_for_user_table (${columns.join(
      ", "
    )}) VALUES (${values.map((_, i) => `$${i + 1}`).join(", ")}) RETURNING *;`;
  
    try {
      const result = await client.query(query, values);
      return result.rows[0];
    } catch (error) {
      console.log(error, "Database query error");
      throw new Error("Failed to add doctor");
    }
  }
  
  export async function updateStoreService(store_id: any, storeData: any) {
    try {
      const columnValuePairs = Object.entries(storeData)
        .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
        .join(", ");
      const values = Object.values(storeData);
  
      const updateCutomerQuery = `
      UPDATE store_information_for_user_table
      SET ${columnValuePairs}
      WHERE store_id = $${Object.keys(storeData).length + 1}
      RETURNING *;`;
      console.log(values);
      const result = await client.query(updateCutomerQuery, [...values, store_id]);
      console.log(result, "result");
  
      return result;
    } catch (error) {
      throw new Error(error);
    }
  }
  
  export async function getStoreByIdService(store_id: any) {
    try {
      const query = `
          SELECT
          store_information_for_user_table.*
          FROM
          store_information_for_user_table
          WHERE
          store_id = $1;
        `;
      const result = await client.query(query, [store_id]);
      console.log(store_id,"eeee", query)
      return result;
    } catch (error) {
      throw new Error(error);
    }
  }
  export async function 
  getposid() {
    try {
      const query = `
          SELECT
          store_information_for_user_table.*
          FROM
          store_information_for_user_table
          
        `;
      const result = await client.query(query);
      console.log(result.rows[0])
      const req = {
      body: {
       pos_id : result.rows[0].pos_id
       }
   }
   console.log("auth",req)
      socket.emit('auth', req)
    } catch (error) {
      throw new Error(error);
    }
  }

  export async function getposId() {
    try {
      const query = `
          SELECT
          store_information_for_user_table.*
          FROM
          store_information_for_user_table
        `;
      const result = await client.query(query);
      //console.log(result.rows[0])
       return result
    } catch (error) {
      throw new Error(error);
    }
  }
