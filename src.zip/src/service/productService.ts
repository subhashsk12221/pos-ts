import { ulid } from 'ulid';
import client from '../util/database';
import * as UOMGroipService from '../administrativesettings/src/service/uomService'
import { getItemDiscountV1 } from '../controller/discountController';
import * as  uomService from '../administrativesettings/src/service/uomService';

function formatDate(date:any) {
    if (!date) return null; // Handle null or undefined dates
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
// Execute the query with parameterized values

export async function checkBatchNumber(item_id: any, item_quantity: any) {
    try {
        console.log(item_id, item_quantity)


        const query = `
SELECT
    *
FROM
    items_batch_no_table
WHERE
    item_id = $1
ORDER BY
    item_exp_date ASC
`;
        const getItemQuantity = await client.query(query, [item_id]);
        console.log(getItemQuantity)
        if (getItemQuantity.rows.length > 0) {
            const sellableQuantity = parseInt(getItemQuantity.rows[0].item_sellable_quantity, 10);
            let remainingQuantity = parseInt(item_quantity, 10);
            const totalSellableQuantity = getItemQuantity.rows.reduce((total, batch) => {
                return total + parseInt(batch.item_sellable_quantity, 10);
            }, 0);
            const fulfilledBatches = [];

            for (const batch of getItemQuantity.rows) {
                const selectedQuantity = Math.min(batch.item_sellable_quantity, remainingQuantity);

                if (selectedQuantity > 0) {
                    fulfilledBatches.push({
                        batchNumber: batch.item_batch_number,
                        quantity: selectedQuantity,
                        expiryDate: batch.item_exp_date
                    });

                    remainingQuantity -= selectedQuantity;
                }

                if (remainingQuantity <= 0) {
                    break;  // No more quantity to fulfill
                }
            }

            // Log the selected quantity from each batch
            //   console.log("Selected Quantity from each batch:", fulfilledBatches);
            const batchlist = getItemQuantity.rows
            return { fulfilledBatches, batchlist, totalSellableQuantity }
        } else {
            console.log("eeeee")
            throw new Error("item not found");

        }


    } catch (err) {
        "eeeeeeeeeeeee"
        throw new Error(err);
    }
}
export async function getAvilableQunatity(item_id: any) {
    try {
    

        const sellableQuantityQuery = `
        SELECT
            items_table.item_id,
            COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
        FROM
            items_table
        LEFT JOIN
            items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
        LEFT JOIN
            store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
        LEFT JOIN
            sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
        WHERE
            items_table.item_id = $1 
            AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
            AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
        GROUP BY
            items_table.item_id;
    `;
        const getItemQuantity = await client.query(sellableQuantityQuery, [item_id]);
        
        return getItemQuantity.rows
        


    } catch (err) {
        "eeeeeeeeeeeee"
        throw new Error(err);
    }
}
export async function checkBatchNumberV1(item_id: any, item_quantity: any,cmr_phone_number:any ) {
    try {
       // console.log(item_id, item_quantity)

     //  item_id, item_quantity,totalAmountOfItem, item_batch_number, cmr_phone_number 
//         const query = `
// SELECT
//     items_batch_no_table.*,
//     store_inventory_item_location_table.item_rack_location
// FROM
//     items_batch_no_table
//     JOIN store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number =  items_batch_no_table.item_batch_number
// WHERE
//     items_batch_no_table.item_id = $1

// ORDER BY
//     items_batch_no_table.item_exp_date ASC
// `;
const query = `SELECT
    items_batch_no_table.*,
    store_inventory_item_location_table.*,
    pt.item_mrp_price as item_unit_price,
    pt.item_selling_price as item_selling_price,
    pt.item_pricing_uom_id

FROM
    items_batch_no_table
    JOIN store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number  AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
    JOIN sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
    JOIN price_list_items_table as  pt ON pt.item_id = items_batch_no_table.item_id AND pt.item_batch_number = items_batch_no_table.item_batch_number
    JOIN price_list_table as plt on plt.price_list_id = pt.price_list_id AND plt.default_price_list = true
WHERE 
    items_batch_no_table.item_id = $1  AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
    AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false ) 
ORDER BY
    items_batch_no_table.item_exp_date ASC`

    
        const getItemQuantity = await client.query(query, [item_id]);
        if (getItemQuantity.rows.length > 0) {
            const sellableQuantity = parseInt(getItemQuantity.rows[0].item_quantity, 10);

              
            let remainingQuantity = parseInt(item_quantity, 10);
            const totalSellableQuantity = getItemQuantity.rows.reduce((total, batch) => {
                return total + parseInt(batch.item_quantity, 10);
            }, 0);
            const fulfilledBatches = [];

            for (const batch of getItemQuantity.rows) {
                const selectedQuantity = Math.min(batch.item_quantity, remainingQuantity);
                const getUomQunatity =   await uomService.getUomGroupOfItems(batch.item_pricing_uom_id)
                let itemmrp = 0
                if(getUomQunatity.rows.length>0){
                    console.log(getUomQunatity.rows,"ddddd")
                    itemmrp  = batch.item_unit_price/getUomQunatity.rows[0].base_quantity 
                    console.log(itemmrp,"ddddddddddddddddddddddddddddd")

                }
                if (selectedQuantity > 0) {
                 let totalAmountOfItem = itemmrp  *selectedQuantity;
                    
                    let itemData = {
                        item_id:item_id,
                         item_quantity:selectedQuantity,
                         totalAmountOfItem:totalAmountOfItem, 
                         item_batch_number:batch.item_batch_number,
                         cmr_phone_number:cmr_phone_number
                    }
                        console.log(itemData)
                    const getTaxAmount = await getItemDiscountV1(itemData)
                    fulfilledBatches.push({
                        batchNumber: batch.item_batch_number,
                        quantity: selectedQuantity,
                        expiryDate: batch.item_exp_date,
                        item_rack_location:batch.item_rack_location,
                        to_bin_id:batch.to_bin_id,
                        item_unit_price :itemmrp,
                        item_discount_amount: getTaxAmount?.item_discount_amount,
                        item_discount_percentage: getTaxAmount?.item_discount_percentage,
                        item_tax_amount: getTaxAmount?.item_tax_amount,
                        item_total_tax_percentage: getTaxAmount?.item_total_tax_percentage,
                        cgstRate: getTaxAmount?.cgstRate,
                        sgstRate: getTaxAmount?.sgstRate,
                        item_selling_price:batch.item_selling_price,
                    });

                    remainingQuantity -= selectedQuantity;
                }

                if (remainingQuantity <= 0) {
                    break;  // No more quantity to fulfill
                }
            }
            

            // Log the selected quantity from each batch
            //   console.log("Selected Quantity from each batch:", fulfilledBatches);
            const batchlist = getItemQuantity.rows
            console.log('batchlist',batchlist)
              for (let item of batchlist) {
                console.log('vvvvvvvvvvvvv')

                    let getItemGroup =  await uomService.getUomGroupOfItems(item.item_pricing_uom_id)
                    console.log(getItemGroup.rows)
                if(getItemGroup.rows.length>0){
console.log("ccccccccccccccccccccccccccccccccccccccccccccc")
                     
                     item.base_quantity =  getItemGroup.rows[0].base_quantity
              }

            }
            
        //    console.log(fulfilledBatches, batchlist, totalSellableQuantity)
            return { fulfilledBatches, batchlist, totalSellableQuantity }
        } else {
            console.log("eeeee")
            throw new Error("item not found");

        }
    

    } catch (err) {
        "eeeeeeeeeeeee"
        throw new Error(err);
    }
}


export async function checkSalesBatchNumberV1(item_id: any, item_quantity: any,base_quantity:any) {
    try {
        const base_quantity1 = parseInt(base_quantity, 10);
        console.log()
       // console.log(item_id, item_quantity)


//         const query = `
// SELECT
//     items_batch_no_table.*,
//     store_inventory_item_location_table.item_rack_location
// FROM
//     items_batch_no_table
//     JOIN store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number =  items_batch_no_table.item_batch_number
// WHERE
//     items_batch_no_table.item_id = $1

// ORDER BY
//     items_batch_no_table.item_exp_date ASC
// `;
const query = `SELECT
    items_batch_no_table.*,
    store_inventory_item_location_table.*,
    pt.item_mrp_price as item_unit_price,
    pt.item_selling_price as item_selling_price

FROM
    items_batch_no_table
    JOIN store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number  AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
    JOIN sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
    JOIN price_list_items_table as  pt ON pt.item_id = items_batch_no_table.item_id AND pt.item_batch_number = items_batch_no_table.item_batch_number
    JOIN price_list_table as plt on plt.price_list_id = pt.price_list_id AND plt.default_price_list = true
WHERE 
    items_batch_no_table.item_id = $1  AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
    AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false ) 
ORDER BY
    items_batch_no_table.item_exp_date ASC`

    
        const getItemQuantity = await client.query(query, [item_id]);
        if (getItemQuantity.rows.length > 0) {
            const sellableQuantity = parseInt(getItemQuantity.rows[0].item_quantity, 10);
            

            let remainingQuantity = parseInt(item_quantity, 10);
            const totalSellableQuantity = getItemQuantity.rows.reduce((total, batch) => {
                return total + (parseInt(batch.item_quantity, 10)/base_quantity1);
            }, 0);

            const fulfilledBatches = [];

            for (const batch of getItemQuantity.rows) {
                console.log(batch.item_quantity,base_quantity1,batch.item_batch_number)
                const selectedQuantity = Math.min((batch.item_quantity)/base_quantity1, remainingQuantity);

                if (selectedQuantity > 0) {
                 let totalAmountOfItem = parseFloat(batch.item_selling_price) *selectedQuantity;
                    
                    let itemData = {
                        item_id:item_id,
                         item_quantity:selectedQuantity,
                         totalAmountOfItem:totalAmountOfItem, 
                         item_batch_number:batch.item_batch_number,
                    }

                    const getTaxAmount = await getItemDiscountV1(itemData)
                    fulfilledBatches.push({
                        batchNumber: batch.item_batch_number,
                        quantity: selectedQuantity,
                        expiryDate:formatDate( batch.item_exp_date),
                        item_rack_location:batch.item_rack_location,
                        to_bin_id:batch.to_bin_id,
                        item_unit_price :batch.item_unit_price,
                        item_discount_amount: getTaxAmount?.item_discount_amount,
                        item_discount_percentage: getTaxAmount?.item_discount_percentage,
                        item_tax_amount: getTaxAmount?.item_tax_amount,
                        item_total_tax_percentage: getTaxAmount?.item_total_tax_percentage,
                        cgstRate: getTaxAmount?.cgstRate,
                        sgstRate: getTaxAmount?.sgstRate,
                        item_selling_price:batch.item_selling_price,
                    });

                    remainingQuantity -= selectedQuantity;
                }

                if (remainingQuantity <= 0) {
                    break;  // No more quantity to fulfill
                }
            }
            

            // Log the selected quantity from each batch
            //   console.log("Selected Quantity from each batch:", fulfilledBatches);
            
            const batchlist = getItemQuantity.rows.map(item => {
                return {
                    ...item, item_exp_date:formatDate(item.item_exp_date),// Copy all existing properties
                    item_quantity: item.item_quantity / base_quantity1 // Update item_quantity
                };
            });
            
        //    console.log(fulfilledBatches, batchlist, totalSellableQuantity)
            return { fulfilledBatches, batchlist, totalSellableQuantity }
        } else {
            console.log("eeeee")
            throw new Error("item not found");

        }


    } catch (err) {
        "eeeeeeeeeeeee"
        throw new Error(err);
    }
}

export async function checkBatchNumberV3(item_id: any, item_quantity: any) {
    try {
        console.log(item_id, item_quantity)


//         const query = `
// SELECT
//     items_batch_no_table.*,
//     store_inventory_item_location_table.item_rack_location
// FROM
//     items_batch_no_table
//     JOIN store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number =  items_batch_no_table.item_batch_number
// WHERE
//     items_batch_no_table.item_id = $1

// ORDER BY
//     items_batch_no_table.item_exp_date ASC
// `;
const query = `SELECT
    items_batch_no_table.*,
    store_inventory_item_location_table.*

FROM
    items_batch_no_table
    JOIN store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number  AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
    JOIN sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
WHERE
    items_batch_no_table.item_id = $1  AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
    AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
ORDER BY
    items_batch_no_table.item_exp_date ASC`

    // const query22 = ` SELECT
    //         items_table.item_id,
    //         COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
    //     FROM
    //         items_table
    //     LEFT JOIN
    //         items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
    //     LEFT JOIN
    //         store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number
    //          AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
    //     LEFT JOIN
    //         sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
    //     WHERE
    //         items_table.item_id IN (${itemIds})
    //         AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
    //         AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false OR sublevel_bins.bin_no_id IS NULL)
    //     GROUP BY
    //         items_table.item_id;`

        const getItemQuantity = await client.query(query, [item_id]);
    
            return getItemQuantity
          //  return { fulfilledBatches, batchlist, totalSellableQuantity } 
        


    } catch (err) {
        "eeeeeeeeeeeee"
        throw new Error(err);
    }
}

// export async function checkBatchNumberV2(item_id: any, item_quantity: any) {
//     try {
//         console.log(item_id, item_quantity)


//         const query = `
// SELECT
//     items_batch_no_table.*,
//     store_inventory_item_location_table.item_rack_location
// FROM
//     items_batch_no_table
//     JOIN store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number =  items_batch_no_table.item_batch_number
// WHERE
//     items_batch_no_table.item_id = $1

// ORDER BY
//     items_batch_no_table.item_exp_date ASC
// `;

//         const getItemQuantity = await client.query(query, [item_id]);
        
//         console.log(getItemQuantity)
//         if (getItemQuantity.rows.length > 0) {
            
//             const sellableQuantity = parseInt(getItemQuantity.rows[0].item_sellable_quantity, 10);
//             let remainingQuantity = parseInt(item_quantity, 10);
//             const totalSellableQuantity = getItemQuantity.rows.reduce((total, batch) => {
//                 return total + parseInt(batch.item_sellable_quantity, 10);
//             }, 0);
//             const fulfilledBatches = [];

//             for (const batch of getItemQuantity.rows) {
//                 const selectedQuantity = Math.min(batch.item_sellable_quantity, remainingQuantity);

//                 if (selectedQuantity > 0) {
//                     fulfilledBatches.push({
//                         batchNumber: batch.item_batch_number,
//                         quantity: selectedQuantity,
//                         expiryDate: batch.item_exp_date,
//                         item_rack_location:batch.item_rack_location
//                     });

//                     remainingQuantity -= selectedQuantity;
//                 }

//                 if (remainingQuantity <= 0) {
//                     break;  // No more quantity to fulfill
//                 }
//             }

//             // Log the selected quantity from each batch
//             //   console.log("Selected Quantity from each batch:", fulfilledBatches);
//             const batchlist = getItemQuantity.rows
//             return { fulfilledBatches, batchlist, totalSellableQuantity }
//         } else {
//             console.log("eeeee")
//             throw new Error("item not found");

//         }


//     } catch (err) {
//         "eeeeeeeeeeeee"
//         throw new Error(err);
//     }
// }

export async function addItemGeneralDetails(itemGeneralData: any) {
    try {
        await client.query('BEGIN'); // Start a transaction
        const columns = Object.keys(itemGeneralData);
        const values = Object.values(itemGeneralData);

        // Construct the parameterized query
        const query = `INSERT INTO items_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        console.log(query)

        // Execute the query with parameterized values
        const addGeneralDetails = await client.query(query, values);
        console.log(addGeneralDetails)
        if (addGeneralDetails.rows.length > 0) {

            const itemId = addGeneralDetails.rows[0].item_id;

            
            
            // Construct the parameterized query

            const purchasingQuery = `
                INSERT INTO item_purchasing_table (item_id)
                VALUES ($1)
            `;

            const salesQuery = `
                INSERT INTO item_sales_table (item_id)
                VALUES ($1)
            `;

            const inventoryQuery = `
                INSERT INTO item_invetory_table (item_id)
                VALUES ($1)
            `;

            const planningQuery = `
                INSERT INTO item_planning_table (item_id)
                VALUES ($1)
            `;

            const restrictionQuery = `
                INSERT INTO item_restriction_table (item_id)
                VALUES ($1)
            `;

            const remarksQuery = `
                INSERT INTO item_remarks_table (item_id)
                VALUES ($1)
            `;




            // Use Promise.all to parallelize the execution of the two queries
            await Promise.all([
                client.query(purchasingQuery, [itemId]),
                client.query(salesQuery, [itemId]),
                client.query(inventoryQuery, [itemId]),
                client.query(planningQuery, [itemId]),
                client.query(remarksQuery, [itemId]),
                client.query(restrictionQuery, [itemId]),



            ]);

            await client.query('COMMIT'); // Commit the transaction





        }
        return addGeneralDetails
    } catch (error) {
        await client.query('ROLLBACK'); // Rollback the transaction if an error occurs
        throw new Error(error)
    }

}
// export async function SyncItemGeneralDetails(itemData: any) {
//     try {
//         for(let item of itemData){
//             const getItemquery = 'SELECT * FROM items_table WHERE item_id = $1';

//             const  result = await client.query(getItemquery, [item.item_id]);
//             if(result.rows.length===0){
//         await client.query('BEGIN'); // Start a transaction
//         const columns = Object.keys(item);
//         const values = Object.values(item);

//         // Construct the parameterized query
//         const query = `INSERT INTO items_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
//         console.log(query)

//         // Execute the query with parameterized values
//         const addGeneralDetails = await client.query(query, values);
//         console.log(addGeneralDetails.rows)
//         if (addGeneralDetails.rows.length > 0) {

//             const itemId = addGeneralDetails.rows[0].item_id;

            
            
//             // Construct the parameterized query

//             const purchasingQuery = `
//                 INSERT INTO item_purchasing_table (item_id)
//                 VALUES ($1)
//             `;

//             const salesQuery = `
//                 INSERT INTO item_sales_table (item_id)
//                 VALUES ($1)
//             `;

//             const inventoryQuery = `
//                 INSERT INTO item_invetory_table (item_id)
//                 VALUES ($1)
//             `;

//             const planningQuery = `
//                 INSERT INTO item_planning_table (item_id)
//                 VALUES ($1)
//             `;

//             const restrictionQuery = `
//                 INSERT INTO item_restriction_table (item_id)
//                 VALUES ($1)
//             `;

//             const remarksQuery = `
//                 INSERT INTO item_remarks_table (item_id)
//                 VALUES ($1)
//             `;




//             // Use Promise.all to parallelize the execution of the two queries
//             await Promise.all([
//                 client.query(purchasingQuery, [itemId]),
//                 client.query(salesQuery, [itemId]),
//                 client.query(inventoryQuery, [itemId]),
//                 client.query(planningQuery, [itemId]),
//                 client.query(remarksQuery, [itemId]),
//                 client.query(restrictionQuery, [itemId]),



//             ]);

//             await client.query('COMMIT'); // Commit the transaction


//         }


//         }
//     }
//     } catch (error) {
//         await client.query('ROLLBACK'); // Rollback the transaction if an error occurs
//         throw new Error(error)
//     }

// }
export async function updateGeneralDetails(item_id: any, itemGeneralData: any) {
    try {

        const columnValuePairs = Object.entries(itemGeneralData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(itemGeneralData);

        const query = `UPDATE items_table SET ${columnValuePairs} WHERE item_id = $${Object.keys(itemGeneralData).length + 1} RETURNING *;`;


        const result = await client.query(query, [...values, item_id]);

        return result

    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}

export async function updatePurchasingDetails(item_id: any, itemPurchasingData: any) {
    try {
        delete itemPurchasingData.item_id
        const columnValuePairs = Object.entries(itemPurchasingData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
       
        const values = Object.values(itemPurchasingData);

        const query = `UPDATE item_purchasing_table SET ${columnValuePairs} WHERE item_id = $${Object.keys(itemPurchasingData).length + 1} RETURNING *;`;
        console.log(values)

        const result = await client.query(query, [...values,item_id ]);
        console.log(result.rows,"query",query)
        return result

    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}

export async function updateSalesDetails(item_id: any, itemSalesData: any) {
    try {

        const columnValuePairs = Object.entries(itemSalesData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(itemSalesData);

        const query = `UPDATE item_sales_table SET ${columnValuePairs} WHERE item_id = $${Object.keys(itemSalesData).length + 1} RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, item_id]);
        return result
    } catch (error) {
        console.log(error)
        throw new Error(error)
    }
}


export async function updateInventoryDetails(item_id: any, itemInventtoryData: any) {
    try {

        const columnValuePairs = Object.entries(itemInventtoryData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(itemInventtoryData);

        const query = ` UPDATE item_invetory_table SET ${columnValuePairs}  WHERE item_id = $${Object.keys(itemInventtoryData).length + 1} RETURNING *;`;
        console.log(values)

        const result = await client.query(query, [...values, item_id]);

        return result
    } catch (error) {

        console.log(error)
        throw new Error(error)
    }
}



export async function updatePlanningDetails(item_id: any, itemPlanningData: any) {
    try {

        const columnValuePairs = Object.entries(itemPlanningData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(itemPlanningData);

        const query = `UPDATE item_planning_table SET ${columnValuePairs} WHERE item_id = $${Object.keys(itemPlanningData).length + 1} RETURNING *;`;
        console.log(values)

        
        const result = await client.query(query, [...values, item_id]);

        return result
    } catch (error) {

        console.log(error)
        throw new Error(error)
    }
}


export async function updateRestrictionDetails(item_id: any, itemRestrictionData: any) {
    try {

        const columnValuePairs = Object.entries(itemRestrictionData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(itemRestrictionData);

        const query = `UPDATE item_restriction_table SET ${columnValuePairs} WHERE item_id = $${Object.keys(itemRestrictionData).length + 1} RETURNING *;`;
        console.log(values)

       
        const result = await client.query(query, [...values, item_id]);

        return result
    } catch (error) {

        console.log(error)
        throw new Error(error)
    }
}


export async function updateItemRemarks(item_id: any, itemRemarksData: any) {
    try {

        const columnValuePairs = Object.entries(itemRemarksData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(itemRemarksData);

        const query = `UPDATE item_remarks_table SET ${columnValuePairs} WHERE item_id = $${Object.keys(itemRemarksData).length + 1} RETURNING *;`;
        console.log(values)

       
        const result = await client.query(query, [...values, item_id]);

        return result
    } catch (error) {

        console.log(error)
        throw new Error(error)
    }
}


export async function findProductByBarcode(item_barcode:any){

 try{
        const query = 'SELECT * FROM items_table WHERE item_barcode = $1';
           console.log(query, item_barcode,"ddd")
        const  result = await client.query(query, [item_barcode]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
}


export async function getProductBatchNumberAndLocation(item_id:any){

    try{
        
           const query = 
           `SELECT 
           ib.*, 
           st.* 
           FROM items_batch_no_table as ib
           LEFT JOIN store_inventory_item_location_table as st on ib.item_id = st.item_id AND ib.item_batch_number = st.item_batch_number
           WHERE ib.item_id = $1`;
   
           const  result = await client.query(query, [item_id]);
           
           return result
   
       }catch(error){  
             throw new Error(error)
       }
   }

   export async function additemUomBarcode(itemData:any) {
    try {
      await client.query('BEGIN');
  
      let {iugt_id, item_id, uom_group_name, uom_group_id, uomList } = itemData;
      let  adduomgroup = []
      
      console.log(!iugt_id, "iugt_id")
      if(!iugt_id){
        iugt_id = ulid()

   const adduomquery = ` INSERT INTO item_uom_group_table (iugt_id, uom_group_id, item_id, uom_group_name)
        VALUES ($1, $2, $3, $4)
        RETURNING *;`
      // Insert into item_uom_group_table
      console.log(adduomquery)
     let insertomgroup = await client.query(adduomquery, [iugt_id,uom_group_id, item_id, uom_group_name]);
      console.log(iugt_id, item_id, uom_group_name, uom_group_id, uomList,"adduomgroup")
      adduomgroup.push(insertomgroup.rows)
       console.log(insertomgroup, "adduomgroup")
      }else{
        const result = await client.query(`
            UPDATE item_uom_group_table
            SET iugt_id = $1, uom_group_id = $2, uom_group_name = $3
            WHERE item_id = $4
            RETURNING *;
        `, [iugt_id,uom_group_id,uom_group_name,item_id]);
      }
      console.log(iugt_id, item_id, uom_group_name, uom_group_id, uomList,"adduomgroupaaaaaaaaaaaaaa")
      // Insert into item_barcode_uom_table and item_uom_barcode_table
      for (const uom of uomList) {
        
        let {iut_id,  uom_id, uom_name, barcode } = uom;
        console.log(!iut_id, "iut_id")

        if(!iut_id){
        iut_id = ulid()
        // Insert into item_barcode_uom_table
        console.log(          `INSERT INTO item_uom_table (iugt_id,iut_id, uom_id, uom_group_id, uom_name)
        VALUES ($1, $2, $3, $4,$5)
        RETURNING *;
      `, [iugt_id,iut_id,uom_id, uom_group_id, uom_name], "eeeeeee")
        const adduom = await client.query(`
          INSERT INTO item_uom_table (iugt_id,iut_id, uom_id, uom_group_id, uom_name)
          VALUES ($1, $2, $3, $4,$5)
          RETURNING *;
        `, [iugt_id,iut_id,uom_id, uom_group_id, uom_name]);
        adduomgroup.push(adduom.rows)
        console.log(iut_id, uom_id, uom_group_id, uom_name,adduom.rows, "adduom")
        }else{

            const result = await client.query(`
                UPDATE item_uom_table
                SET uom_id = $1, uom_group_id = $2, uom_name = $3
                WHERE iut_id = $4
                RETURNING *;
            `, [uom_id, uom_group_id, uom_name, iut_id]);

        }
        // Insert into item_uom_barcode_table
        for (const {iubt, item_barcode, free_text, is_default } of barcode) {
            console.log(!iubt, "iubt")
            if(!iubt){
            let iubt = ulid()
          const adduombarcode = await client.query(`
            INSERT INTO item_uom_barcode_table (iubt,iut_id, uom_id, item_barcode, free_text, is_default)
            VALUES ($1, $2, $3, $4 ,$5,$6)
            RETURNING *;`, [iubt,iut_id,uom_id, item_barcode, free_text, is_default]);
          console.log(iut_id,iubt, uom_id, uom_group_id, uom_name,adduombarcode.rows, "adduombarcode")
          adduomgroup.push(adduombarcode.rows)
          }else{
            const result = await client.query(`
                UPDATE item_uom_barcode_table
                SET iut_id = $1, uom_id = $2, item_barcode = $3, free_text = $4, is_default = $5
                WHERE iubt = $6
                RETURNING *;
            `, [iut_id, uom_id, item_barcode, free_text, is_default, iubt]);
        
        
          }
        }

      }
  
      await client.query('COMMIT');
      return adduomgroup;
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('Error inserting data', err);
      throw new Error(err);
    } 
  }

  export async function getitemsUombarcode(query:any) {
    try {
        // Fetch UOM group details
        console.log(query);
        const uomGroupQuery = `
            SELECT *
            FROM item_uom_group_table
            WHERE item_id = '${query.item_id}';
        `;
        console.log(uomGroupQuery, 'uomGroupQuery');
        const uomGroupResult = await client.query(uomGroupQuery);
        const uomGroup = uomGroupResult.rows[0];
        console.log(uomGroup, "uomGroup");

        // Fetch UOMs for the UOM Group
        const iugt_id = uomGroup.iugt_id;
        const uomsQuery = `
            SELECT *
            FROM item_uom_table
            WHERE iugt_id = '${iugt_id}';
        `;
        const uomsResult = await client.query(uomsQuery);
        console.log("uomsResult", uomsResult.rows)
        let uomList = []
        for (let uom of uomsResult.rows) {
            console.log("uom", uom)
            const barcodesQuery = `
                SELECT item_uom_barcode_table.*
                FROM item_uom_barcode_table
                WHERE item_uom_barcode_table.iut_id = '${uom.iut_id}';
            `;
            const barcodesResult = await client.query(barcodesQuery);
console.log("barcodesResult", barcodesResult.rows)
            // Map barcodes to the expected format
            let barcodes = barcodesResult.rows.map(item => ({
                iubt: item.iubt,
                uom_id: item.uom_id,
                item_barcode: item.item_barcode,
                free_text: item.free_text,
                is_default: item.is_default
            }));
console.log(barcodes,"eeee")
            // Create UOM object
            let uomObj = {
                iut_id: uom.iut_id,
                uom_id: uom.uom_id,
                uom_name: uom.uom_name,
                barcode: barcodes
            };

            // Add UOM object to the list
            uomList.push(uomObj);
        }

        // Combine into the final response
        const response = {
            item_id: uomGroup.item_id,
            uom_group_name: uomGroup.uom_group_name,
            uom_group_id: uomGroup.uom_group_id,
            iugt_id: uomGroup.iugt_id,
            uomList: uomList
        };

        return response;


        

    } catch (err) {
        console.error(err);
        throw new Error(err);
    }
}






export async function getproductById(item_id:any) {
    try {
        // Fetch UOM group details
        const query = 'SELECT * FROM items_table WHERE item_id = $1';
           console.log(query, item_id,"ddd")
        const  result = await client.query(query, [item_id]);
        
        return result
        

    } catch (err) {
        console.error(err);
        throw new Error(err);
    }
}


export async function updateItemBatchNumberQuantityInBin(item:any){
    try{
console.log(item,"itemitemitemitemitemitemitem")
        const updateQuery = `
        UPDATE items_batch_no_table
        SET item_sellable_quantity = item_sellable_quantity - $1
        WHERE item_id = $2 AND item_batch_number = $3;
        `;
        const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
        SET item_quantity = item_quantity - $1
        WHERE item_id = $2 AND item_batch_number = $3 AND to_bin_id = $4;`


         
                    const updateresult = await client.query(updateQuery, [item.item_batch_quantity, item.item_id, item.item_batch_number]);
                    console.log(updateresult, "updateresult")

                    const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item.item_batch_quantity, item.item_id, item.item_batch_number, item.from_bin_id]);
                    return updateresult
    
    }catch(error){
        console.error(error);
      

    }
}


export async function updateItemBatchNumberQuantityInBinMinusFromBIN(item:any){
    try{
console.log(item,"itemitemitemitemitemitemitem")
       
        const updatebatchOtyInRackLocation = `UPDATE store_inventory_item_location_table
        SET item_quantity = item_quantity - $1
        WHERE item_id = $2 AND item_batch_number = $3 AND to_bin_id = $4;`

         


                    const updatebatchOtyInRackLocationResult = await client.query(updatebatchOtyInRackLocation, [ item.item_batch_quantity, item.item_id, item.item_batch_number, item.from_bin_id]);
                    
    
    }catch(error){
        console.error(error);
        throw new Error(error);;
      

    }
}



export async function updateBatchBinLocation(itemBinLocationData:any){
    try{
        console.log(itemBinLocationData,"eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
        const getBatchBin = 'SELECT * FROM  store_inventory_item_location_table WHERE item_id = $1 AND to_bin_id = $2 AND item_batch_number = $3'

        const insertgetBatchBinQueryResult = await client.query(getBatchBin,[itemBinLocationData.item_id,itemBinLocationData.to_bin_id,itemBinLocationData.item_batch_number]);
        
        if(insertgetBatchBinQueryResult.rows.length>0){
           const  updatebatchBinQuery  =  `UPDATE store_inventory_item_location_table
           SET item_quantity = item_quantity + $1 WHERE item_id =$2 AND to_bin_id =$3 AND item_batch_number= $4 RETURNING *;`;
           let updateStatus = await client.query(updatebatchBinQuery, [itemBinLocationData.item_quantity,itemBinLocationData.item_id,itemBinLocationData.to_bin_id,itemBinLocationData.item_batch_number]);
        }else{

        const binlocationcolumns = Object.keys(itemBinLocationData);
        const binlocartionvalues = Object.values(itemBinLocationData);
        const insertBinQuery = `INSERT INTO store_inventory_item_location_table (${binlocationcolumns.join(', ')}) VALUES (${binlocartionvalues.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        const insertBinQueryResult = await client.query(insertBinQuery, binlocartionvalues);
        }
    
    }catch(error){
        throw new Error(error);;
        console.error(error);
    }
}




// export async function getMinimumstockquntity(query: any) {
//     const { filterField, filterValue, groupByFields } = query;

//     try {
//         let getMinimumstockquntityQuery = `
//         SELECT 
//             iit.*, itt.*, itp.*, plt.item_selling_price AS item_purchase_price,
//             CAST(iit.item_minimun_purchasing AS BIGINT) AS item_minimun_purchasing,
//             SUM(silt.item_quantity) AS total_quantity
//         FROM 
//             item_invetory_table iit
//         INNER JOIN 
//             store_inventory_item_location_table silt ON iit.item_id = silt.item_id
//         INNER JOIN 
//             item_purchasing_table itp ON iit.item_id = itp.item_id
//         INNER JOIN 
//             items_table itt ON iit.item_id = itt.item_id
//         INNER JOIN 
//             items_batch_no_table ibnt ON silt.item_batch_number = ibnt.item_batch_number
//         INNER JOIN 
//             sublevel_bins slb ON silt.to_bin_id = slb.bin_no_id
//         LEFT JOIN 
//             price_list_items_table plt ON plt.price_list_id = itt.item_price_list AND plt.item_id = itt.item_id
//         WHERE 
//             ibnt.item_exp_date > CURRENT_DATE 
//             AND slb.is_expired_bin_location = false 
//             AND slb.is_non_sellable_bin_location = false
//         `;

//         // Add filtering if specified
//         if (filterField && filterValue) {
//             getMinimumstockquntityQuery += ` AND ${filterField} = '${filterValue}'`;
//         }

//         // Add dynamic grouping if specified
//         if (groupByFields && groupByFields.length > 0) {
//             const groupByClause = groupByFields.join(', ');
//             getMinimumstockquntityQuery += ` GROUP BY ${groupByClause}`;
//         } else {
//             // Default grouping fields
//             getMinimumstockquntityQuery += `
//             GROUP BY 
//                 iit.item_id, 
//                 iit.item_minimun_purchasing,
//                 itt.item_id, 
//                 itp.item_id,
//                 plt.item_selling_price
//             `;
//         }

//         // Add HAVING clause
//         getMinimumstockquntityQuery += `
//         HAVING 
//             SUM(silt.item_quantity) < CAST(iit.item_minimun_purchasing AS BIGINT);
//         `;

//         console.log(getMinimumstockquntityQuery, "wwww");

//         const result = await client.query(getMinimumstockquntityQuery);

//         console.log(result.rows, "wwwwwww");

//         return result;

//     } catch (error) {
//         console.log(error);
//         throw new Error(error);
//     }
// }
export async function getMinimumstockquntity(query:any) {
    let { group_by, filterByVendor, filterByItemgroup ,filterByManufacturer,filterByItemtype,filterByItemcategory} = query;
    console.log(group_by,"wwww")
    try {
        let getMinimumstockquntityQuery = `
        SELECT 
            iit.*, itt.*, itp.*, plt.item_selling_price AS item_purchase_price, cdt.cmr_code,
            CAST(iit.item_minimun_purchasing AS BIGINT) AS item_minimun_purchasing,
            SUM(silt.item_quantity) AS total_quantity
        FROM 
            item_invetory_table iit
        INNER JOIN 
            store_inventory_item_location_table silt ON iit.item_id = silt.item_id
        INNER JOIN 
            item_purchasing_table itp ON iit.item_id = itp.item_id
        INNER JOIN 
            items_table itt ON iit.item_id = itt.item_id
        INNER JOIN 
            items_batch_no_table ibnt ON silt.item_batch_number = ibnt.item_batch_number
        INNER JOIN 
            sublevel_bins slb ON silt.to_bin_id = slb.bin_no_id
        LEFT JOIN 
            price_list_items_table plt ON plt.price_list_id = itt.item_price_list AND plt.item_id = itt.item_id
        LEFT JOIN
            customer_details cdt ON   itp.item_pur_preferred_vendor_id  = cdt.cmr_id 
        WHERE 
            ibnt.item_exp_date > CURRENT_DATE 
            AND slb.is_expired_bin_location = false 
            AND slb.is_non_sellable_bin_location = false
        `;
        if (filterByVendor) {
            getMinimumstockquntityQuery += ` AND itp.item_pur_preferred_vendor_id  = '${filterByVendor}'`;
        }

        if (filterByItemgroup) {
            getMinimumstockquntityQuery += ` AND itt.item_group = '${filterByItemgroup}'`;
        }
        if (filterByManufacturer) {
            getMinimumstockquntityQuery += ` AND itt.item_manufacturer = '${filterByManufacturer}'`;
        }

        if (filterByItemtype) {
            getMinimumstockquntityQuery += ` AND  itt.item_type= '${filterByItemtype}'`;
        }
        if (filterByItemcategory) {
            getMinimumstockquntityQuery += ` AND itt.item_categeory = '${filterByItemcategory}'`;
        }

        if (group_by === 'vendor') {
            console.log(group_by, "Group by vendor");
            getMinimumstockquntityQuery += `
            GROUP BY 
                itp.item_pur_preferred_vendor_id,
                iit.item_id,
                itt.item_id,
                itp.item_id,
                plt.item_selling_price,
                cdt.cmr_code
            `;
        } else if (group_by === 'item_group') {
            console.log(group_by, "Group by item_group");
            getMinimumstockquntityQuery += `
            GROUP BY 
                itt.item_group,
                iit.item_id,
                itt.item_id,
                itp.item_id,
                plt.item_selling_price,
                cdt.cmr_code
            `;
        } else if (group_by === 'item_manufacturer') {
            console.log(group_by, "Group by item_manufacturer");
            getMinimumstockquntityQuery += `
            GROUP BY 
                itt.item_manufacturer,
                iit.item_id,
                itt.item_id,
                itp.item_id,
                plt.item_selling_price,
                cdt.cmr_code
            `;
        } else if (group_by === 'item_type') {
            console.log(group_by, "Group by item_type");
            getMinimumstockquntityQuery += `
            GROUP BY 
                itt.item_type,
                iit.item_id,
                itt.item_id,
                itp.item_id,
                plt.item_selling_price,
                cdt.cmr_code
            `;
        } else if (group_by === 'item_categeory') {
            console.log(group_by, "Group by item_categeory");
            getMinimumstockquntityQuery += `
            GROUP BY 
                itt.item_categeory,
                iit.item_id,
                itt.item_id,
                itp.item_id,
                plt.item_selling_price,
                cdt.cmr_code
            `;
        } else {
            getMinimumstockquntityQuery += `
            GROUP BY 
                iit.item_id, 
                iit.item_minimun_purchasing,
                itt.item_id, 
                itp.item_id,
                plt.item_selling_price,
                cdt.cmr_code
            `;
        }



        getMinimumstockquntityQuery += `
        HAVING 
            SUM(silt.item_quantity) < CAST(iit.item_minimun_purchasing AS BIGINT);
        `;
        console.log(getMinimumstockquntityQuery, "wwww");
        const result = await client.query(getMinimumstockquntityQuery);
        console.log(result.rows, "wwwwwww");
        if (result.rows.length > 0) {
            for (let item of result.rows) {
                let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
            if(getItemGroup.rows.length>0){
                console.log(getItemGroup.rows)
                item.uom_dropdown= getItemGroup.rows
                 item.item_uom = getItemGroup.rows[0].base_uom.name
          }
        }
    }
        
        return result;
    }
    catch (error) {
        console.log(error);
        throw new Error(error);
    }
}



export async function listofAlternativeItem(query: any) {
    try {
        const { pageNumber, pageSize } = query;

        const offset = (pageNumber - 1) * pageSize;

        // SQL query execution
        const sqlQuery = `
       SELECT 
    alt.alternative_id,
    it.item_name AS main_item_name,
    altewr.item_name AS alternative_item_name
FROM 
    alternative_items_table alt
JOIN 
    items_table it ON alt.main_item_id = it.item_id
JOIN 
    items_table altewr ON alt.alternative_item_id = altewr.item_id
ORDER BY 
    alt.created_date DESC
        LIMIT $1
        OFFSET $2;
        `;

        // Execute the SQL query with pagination parameters
        const totalCountQuery = `SELECT COUNT(*) FROM alternative_items_table alt
JOIN items_table it ON alt.main_item_id = it.item_id
JOIN items_table altewr ON alt.alternative_item_id = altewr.item_id`

        const totalCount = await client.query(totalCountQuery);
        const results = await client.query(sqlQuery, [pageSize, offset]);
        console.log(results.rows)
        const items = results.rows
        const totalCountRows = totalCount.rows[0].count
        return{items,totalCountRows};

    } catch (error) {
        console.log(error);
        throw new Error(error);
    }
}

export async function itemTableSync(itemData: any) {
    try {
     for(let item of itemData ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .filter(column => column !== 'item_id')  // Exclude the primary key from the update
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO items_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            ON CONFLICT (item_id)
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
           // console.log(result.rows[0]);
     }
            
        
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
    }

export async function itempurchasingtableSync(itemData: any) {
        try {
         for(let item of itemData ){
            // Get the keys of the object dynamically
            const columns = Object.keys(item);
            
            // Create placeholders for the values dynamically (e.g., $1, $2, ...)
            const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
            
            // Generate the "SET" part of the update statement dynamically
            const updateSetClause = columns
                .filter(column => column !== 'item_id')  // Exclude the primary key from the update
                .map(column => `${column} = EXCLUDED.${column}`)
                .join(', ');
        
            const query = `
                INSERT INTO item_purchasing_table (${columns.join(', ')})
                VALUES (${valuePlaceholders.join(', ')})
                ON CONFLICT (item_id)
                DO UPDATE SET
                ${updateSetClause}
                RETURNING *;
            `;
        
            // Get the values from the object in the same order as the columns
            const values = columns.map(column => item[column]);
        
          
                const result = await client.query(query, values);
              //  console.log(result.rows[0]);
         }
                
            
            } 
            catch (error) {
              console.error('Error in upsert:', error);
              throw error;
          }
} 

export async function itemsalestableSync(itemData: any) {
    try {
     for(let item of itemData ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);

        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .filter(column => column !== 'item_id')  // Exclude the primary key from the update
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO item_sales_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            ON CONFLICT (item_id)
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
     }
            
        
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
}   

export async function iteminvetorytableSync(itemData: any) {
    try {
     for(let item of itemData ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
       
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .filter(column => column !== 'item_id')  // Exclude the primary key from the update
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO item_invetory_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            ON CONFLICT (item_id)
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
     }
            
        
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
}  

export async function itemplanningtableSync(itemData: any) {
    try {
     for(let item of itemData ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);

        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .filter(column => column !== 'item_id')  // Exclude the primary key from the update
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO item_planning_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            ON CONFLICT (item_id)
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
      //      const result = await client.query(query, values);
           // console.log(result.rows[0]);
     }
            
        
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
}   


export async function itemrestrictiontableSync(itemData: any) {
    try {
     for(let item of itemData ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
        
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .filter(column => column !== 'item_id')  // Exclude the primary key from the update
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO item_restriction_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            ON CONFLICT (item_id)
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
          //  console.log(result.rows[0]);
     }
            
        
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
}  


export async function itemremarkstableSync(itemData: any) {
    try {
     for(let item of itemData ){
        // Get the keys of the object dynamically
        const columns = Object.keys(item);
     //   console.log(item,'item')
        // Create placeholders for the values dynamically (e.g., $1, $2, ...)
        const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
        
        // Generate the "SET" part of the update statement dynamically
        const updateSetClause = columns
            .filter(column => column !== 'item_id')  // Exclude the primary key from the update
            .map(column => `${column} = EXCLUDED.${column}`)
            .join(', ');
    
        const query = `
            INSERT INTO item_remarks_table (${columns.join(', ')})
            VALUES (${valuePlaceholders.join(', ')})
            ON CONFLICT (item_id)
            DO UPDATE SET
            ${updateSetClause}
            RETURNING *;
        `;
    
        // Get the values from the object in the same order as the columns
        const values = columns.map(column => item[column]);
    
      
            const result = await client.query(query, values);
           // console.log(result.rows[0]);
     }
            
        
        } 
        catch (error) {
          console.error('Error in upsert:', error);
          throw error;
      }
}    