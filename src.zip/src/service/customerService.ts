import socket from '../sync/syncScript';
import client from '../util/database';
import { getposId } from './storeService';
export async function findCustomerByPhoneNumber(cmr_phone_number:any){
    try{

        const query = 'SELECT * FROM customer_details WHERE cmr_phone_number = $1';

        const  result = await client.query(query, [cmr_phone_number]);
        
        return result

    }catch(error){  
          throw new Error(error)
    }
          
}


export async function addCustomerData(customerData:any){
    try{

        const columns = Object.keys(customerData);
        const values = Object.values(customerData);

        // Construct the parameterized query
        const insertCustomerQuery = `INSERT INTO customer_details (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertCustomerQuery);

        // Execute the query with parameterized values
        const insertCustomerQueryResult = await client.query(insertCustomerQuery, values);

        return insertCustomerQueryResult

    }catch(error){
              throw new Error(error)
    }
}

export async function getCustomerNextSequenceCode(){
    try{

        const cmrNumberQuery = 'SELECT generate_cmr_number() AS cmr_number';
        const cmrNumberResult = await client.query(cmrNumberQuery);

        return cmrNumberResult

    }catch(error){
              throw new Error(error)
    }
}


export async function updateCustomer(cmr_id:any,customerData:any){
    try{

        const columnValuePairs = Object.entries(customerData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(customerData);

        const updateCutomerQuery = `
    UPDATE customer_details
    SET ${columnValuePairs}
    WHERE CMR_Id = $${Object.keys(customerData).length + 1}
    RETURNING *;`;
        console.log(values)
        const result = await client.query(updateCutomerQuery, [...values, cmr_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getCustomerById(cmr_id:any){
    try{

        const getCustomerQuery = `
        SELECT *
        FROM
          "customer_details" cd
        WHERE
          cd.cmr_id = $1;`;

          const result = await client.query(getCustomerQuery, [cmr_id]);
          return result

    }catch(error){
              throw new Error(error)
    }
}

export async function searchCustomerByPhoneNumber(cmr_phone_number:any){
    try{

        const SearchQuery = `
        SELECT
        customer_details.*
        FROM
        customer_details
        WHERE
          cmr_phone_number LIKE $1;
      `;

        const result = await client.query(SearchQuery, [`%${cmr_phone_number}%`]);
          return result

    }catch(error){
              throw new Error(error)
    }
}

export async function deleteCustomer(cmr_id:any){
    try{
        const deleteQuery = `
        DELETE FROM customer_details
        WHERE cmr_id = $1 ;`;
        const result = await client.query(deleteQuery, [cmr_id]);
        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function getCustomerByType(query: any) {
    try {
        const { sortfield, sortValue, field, value } = query;

        let whereClause = ``;

        // Add sorting to the ORDER BY clause if needed
        let orderByClause = '';
        if (sortfield && sortValue) {
            whereClause  = `c.${sortfield} = ${sortValue}`;
        }

        // Add search condition for the specified column
        const searchCondition = field
            ?  `AND (LOWER(c.${field}) ILIKE LOWER('%${value}%'))`
            : '';

        const totalOrderValueQuery = `
            SELECT
                c.*
            FROM
            customer_details AS c
            WHERE
                ${whereClause} ${searchCondition}
                ${orderByClause}
        `;
        console.log(totalOrderValueQuery); // For debugging purposes

        const result = await client.query(totalOrderValueQuery);
        console.log(result.rows); // For debugging purposes

        return result

    } catch (error) {
        throw new Error(error)
    }
}


export async function getCustomerList(query:any){
    try{
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, cmr_active_status, searchColumn, searchValue } =query;

      
        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            console.log(fromDate, toDate)
            whereClause += ` AND c.created_date >= '${fromDate}' AND c.created_date < '${toDate}'::date + interval '1 day'`;
        }

        // Add payment status filter to the WHERE clause
        if (cmr_active_status) {
            whereClause += ` AND c.cmr_active_status = '${cmr_active_status}'`;
        }

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'total_order_value') {
                // Sort by total_order_value
                orderByClause = `ORDER BY total_order_value ${sortOrder}`;
            } else {
                // Sort by a column in the customer_details table
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY c.created_date DESC';
        }

        // Add search condition for the specified column
        const searchCondition = searchColumn
            ? `AND (LOWER(c.${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';


        const totalOrderValueQuery = `
    SELECT
        c.cmr_phone_number,
        c.cmr_first_name,
        c.cmr_last_name,
        c.*,
        COALESCE(SUM(so.sot_total_amount), 0) AS total_order_value
    FROM
        customer_details c
    LEFT JOIN
        sales_order so ON c.cmr_phone_number = so.cmr_phone_number
    WHERE
        1=1 ${whereClause} ${searchCondition}
    GROUP BY
        c.cmr_phone_number, c.cmr_first_name, c.cmr_last_name, c.cmr_id
    ${orderByClause} OFFSET $1 LIMIT $2;
`;

        const queryCount = `
            SELECT COUNT(*) 
            FROM customer_details c 
            WHERE 1=1 ${whereClause} ${searchCondition};
        `;
        console.log(totalOrderValueQuery)
        console.log(queryCount)
        const totalCount = await client.query(queryCount);
        const getCustomerList = await client.query(totalOrderValueQuery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const customerList =  getCustomerList.rows
        return {totalRowsCount,customerList }

    }catch(error){
              throw new Error(error)
    }
}



export async function getStoreCustomerById(cmr_id:any){
    try{
        const query = `
        SELECT
        customer_details.*
        FROM
        customer_details
        WHERE
        cmr_id = $1;
      `;
        // Execute the query with parameterized values
        const result = await client.query(query, [cmr_id]);
        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addCustomerMasterDetails(customerData:any){
    try{

        const columns = Object.keys(customerData);
        const values = Object.values(customerData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO cmr_master_data_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}




export async function syncCustomerDataResult(cmr_id:any,customerData:any){
    try{

        const columnValuePairs = Object.entries(customerData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(customerData);

        const updateCutomerQuery = `
    UPDATE customer_details
    SET ${columnValuePairs}
    WHERE CMR_Id = $${Object.keys(customerData).length + 1}
    RETURNING *;`;
        console.log(values)
        const result = await client.query(updateCutomerQuery, [...values, cmr_id]);
console.log(result.rows)
        return result
    }catch(error){
              throw new Error(error)
    }
}




export async function getUnSyncedCustomer(){
    try{

        const getCustomerQuery = `
        SELECT *
        FROM
          customer_details 
        WHERE
          data_synced = false;`;

          const [result, posId]= await Promise.all([client.query(getCustomerQuery),   getposId()])
        //  console.log("datasynced" , result.rows)
          if(result.rows.length>0){
            const pos_id = posId.rows[0].pos_id
            result.rows = result.rows.map(item => ({
                ...item,
                pos_id :pos_id // Add the pos_id field
              }));
              
                socket.emit('customerUnSyncedData', result.rows)
            
          }
          
          return result

    }catch(error){
              console.log(error)
    }
}