import socket from "../sync/syncScript";
import client from "../util/database";

 
export async function generalaccountstableSync(accounts: any) {
  try {
    for(let item of accounts ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'account_id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO general_accounts_table (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (account_id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
       //   console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
} 


export async function generalaccountallocationtableSync(accounts: any) {
  try {
    for(let item of accounts ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'gcct_id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO general_account_allocation_table (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (gcct_id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
         // console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
} 


export async function salesaccountallocationtableSync(accounts: any) {
  try {
    for(let item of accounts ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'gcct_id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO sales_account_allocation_table (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (gcct_id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
         // console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}  


export async function purchaseaccountallocationtableSync(accounts: any) {
  try {
    for(let item of accounts ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'gcct_id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO purchase_account_allocation_table (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (gcct_id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
        //  console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}  

export async function inventoryaccountallocationtableSync(accounts: any) {
  try {
    for(let item of accounts ){
      // Get the keys of the object dynamically
      const columns = Object.keys(item);
      // Create placeholders for the values dynamically (e.g., $1, $2, ...)
      const valuePlaceholders = columns.map((_, idx) => `$${idx + 1}`);
      
      // Generate the "SET" part of the update statement dynamically
      const updateSetClause = columns
          .filter(column => column !== 'gcct_id')  // Exclude the primary key from the update
          .map(column => `${column} = EXCLUDED.${column}`)
          .join(', ');
  
      const query = `
          INSERT INTO inventory_account_allocation_table (${columns.join(', ')})
          VALUES (${valuePlaceholders.join(', ')})
          ON CONFLICT (gcct_id)
          DO UPDATE SET
          ${updateSetClause}
          RETURNING *;
      `;
  
      // Get the values from the object in the same order as the columns
      const values = columns.map(column => item[column]);
  
    
          const result = await client.query(query, values);
       //   console.log(result.rows[0]);
    }
// Return the inserted or updated row
      } 
      catch (error) {
        console.error('Error in upsert:', error);
        throw error;
    }
}  

export async function getUnSyncCustomerGLAccount(){
  try{
         const getUnsynedCustomerGlAccount = await client.query('SELECT * FROM general_accounts_table WHERE is_gl_account = false AND data_synced= false' )
         console.log(getUnsynedCustomerGlAccount.rows,"wowwwwwwwwwwwwwwwwwwwwwwww")
         return getUnsynedCustomerGlAccount.rows

  }catch(error){

    throw error;
  }
}


export async function getUnSyncedjournEntry() {
  try {
     
      const getVendorquery = `
      SELECT 
      jrt.*, 
      jrt.remarks AS jrt_remarks,
      jert.*,
      jert.remarks AS jert_remarks,
      gct.account_name,
      gct.account_code
  FROM 
      journal_entry_table AS jrt
  JOIN 
      journal_entry_rows_table AS jert ON jert.transcation_id = jrt.transcation_id
  JOIN 
      general_accounts_table AS gct ON gct.account_id = jert.account_id
  WHERE 
  jrt.data_synced = false 
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery);


      return result

  
} catch (error) {
      throw new Error(error)
  }
}



export async function journalEntrySync(journalEntryData: any, accountsData: any) {
  try {
      const req = {
       body: {
          "journalEntryData": journalEntryData,
          "accountsData": accountsData,
          "transaction_type":"journalEntrySync"
      }
  
  }

 // console.log(req,"34562345")
 
      socket.emit('journalEntrySync', req)
 
  } catch (error) {
      console.error('Error:', error);
  }
}

export async function asyncJouranlEntryDataResult(orderData: any, transcation_id: any) {
  try {
      delete orderData.itt_id
  
      const updateOrderFields = Object.entries(orderData)
          .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
          .join(', ');

      // Get the values for the updateSalesOrderQuery
      const orderValues = Object.values(orderData);

      // Construct the query to update the sales_order table
      const updateSalesOrderQuery = `
      UPDATE journal_entry_table
      SET ${updateOrderFields}
      WHERE transcation_id = $1
      RETURNING *;
      
    `;
console.log(updateSalesOrderQuery,orderValues,"w34")
      

      const salesOrderResult = await client.query(updateSalesOrderQuery, [transcation_id, ...orderValues]);
   //   console.log(salesOrderResult.rows,"qwewewwewe")
      return salesOrderResult

  } catch (error) {
     

      throw new Error(error)
  }
}


export async function customerGLSync( accountsData: any) {
  try {
      const req = {
       body: {
    
          "accountsData": accountsData,
          "transaction_type":"customerGLSync"
      }
  
  }

 // console.log(req,"34562345")
 
      socket.emit('customerGLSync', req)
 
  } catch (error) {
      console.error('Error:', error);
  }
}

export async function customerGLSyncDataResult(orderData: any, account_id: any) {
  try {
      delete orderData.account_id
  
      const updateOrderFields = Object.entries(orderData)
          .map(([columnName, value], index) => `"${columnName}" = $${index + 2}`)
          .join(', ');

      // Get the values for the updateSalesOrderQuery
      const orderValues = Object.values(orderData);

      // Construct the query to update the sales_order table
      const updateSalesOrderQuery = `
      UPDATE general_accounts_table
      SET ${updateOrderFields}
      WHERE account_id = $1
      RETURNING *;
      
    `;
console.log(updateSalesOrderQuery,orderValues,"w34")
      

      const salesOrderResult = await client.query(updateSalesOrderQuery, [account_id, ...orderValues]);
   //   console.log(salesOrderResult.rows,"qwewewwewe")
      return salesOrderResult

  } catch (error) {
     

      throw new Error(error)
  }
}