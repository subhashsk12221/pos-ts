import client from "../util/database";

export async function addDoctorService(doctorData: any) {
  const columns = Object.keys(doctorData);
  const values = Object.values(doctorData);
  const query = `INSERT INTO doctor_table (${columns.join(
    ", "
  )}) VALUES (${values.map((_, i) => `$${i + 1}`).join(", ")}) RETURNING *;`;

  try {
    const result = await client.query(query, values);
    return result.rows[0];
  } catch (error) {
    console.log(error, "Database query error");
    throw new Error("Failed to add doctor");
  }
}

export async function updateDoctorService(dr_id: any, doctorData: any) {
  try {
    const columnValuePairs = Object.entries(doctorData)
      .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
      .join(", ");
    const values = Object.values(doctorData);

    const updateCutomerQuery = `
    UPDATE doctor_table
    SET ${columnValuePairs}
    WHERE DR_Id = $${Object.keys(doctorData).length + 1}
    RETURNING *;`;
    console.log(values);
    const result = await client.query(updateCutomerQuery, [...values, dr_id]);
    console.log(result, "result");

    return result;
  } catch (error) {
    throw new Error(error);
  }
}

export async function getDoctorByIdService(dr_id: any) {
  try {
    const query = `
        SELECT
        doctor_table.*
        FROM
        doctor_table
        WHERE
        dr_id = $1;
      `;
    const result = await client.query(query, [dr_id]);
    return result;
  } catch (error) {
    throw new Error(error);
  }
}

export async function deleteDoctorService(dr_id: any) {
  try {
    const deleteQuery = `
        DELETE FROM doctor_table
        WHERE dr_id = $1 ;`;
    const result = await client.query(deleteQuery, [dr_id]);
    return result;
  } catch (error) {
    throw new Error(error);
  }
}

export async function getDoctorListService(query: any) {
    try {
      const {
        pageNumber,
        pageSize,
        sortBy,
        sortOrder,
        fromDate,
        toDate,
        searchColumn,
        searchValue,
      } = query;
  
      const offset = (pageNumber - 1) * pageSize;
      const limit = pageSize;
  
      let whereClause = "";
      let orderByClause = "";
  
      if (fromDate && toDate) {
        whereClause += ` AND ds.created_date >= '${fromDate}' AND ds.created_date < '${toDate}'::date + interval '1 day'`; // Specify the table alias
      }
  
      if (sortBy && sortOrder) {
        orderByClause = `ORDER BY ds.${sortBy} ${sortOrder}`; 
      } else {
        orderByClause = "ORDER BY ds.created_date DESC";
      }
  
      const searchCondition = searchColumn
        ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
        : "";
  
      const queryCount = `SELECT COUNT(*) FROM doctor_table ds WHERE 1=1 ${whereClause} ${searchCondition};`;
      const findquery: any = `SELECT ds.dr_id, ds.dr_name,ds.dr_specialization, ds.dr_registration_num, ds.dr_qualification, ds.dr_state , ds.dr_city FROM doctor_table ds
        WHERE 1=1 ${whereClause} ${searchCondition} ${
        orderByClause ? orderByClause : ""
      } OFFSET $1 LIMIT $2;`;
  
      console.log(query);
      const totalCount = await client.query(queryCount);
      const getDoctorList = await client.query(findquery, [offset, limit]);
      const totalRowsCount = totalCount.rows[0].count;
      const doctorList = getDoctorList.rows;
  
      return { totalRowsCount, doctorList };
    } catch (error) {
      throw new Error(error);
    }
  }
