import client from '../util/database';
import { ulid } from 'ulid';
import * as salesOrderService from '../service/salesOrderService'
import * as journalEntryService from '../service/journalEntryService'
import * as financialLegder from '../service/financialLedgerService'
import * as purchaseService from '../service/purchaseOrderService'

export async function addPaymentIn(paymentData: any, invoicePaymentData: any, paymentModeData: any) {
    try {
        await client.query('BEGIN');
        const pit_id = ulid();
        paymentData.pit_id = pit_id;
        paymentData.pit_order_status = 'paid';
        const columns = Object.keys(paymentData);
        const values = Object.values(paymentData);

        const query = `INSERT INTO payment_in_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;

        const orderResult = await client.query(query, values);

        if (orderResult.rows.length > 0) {
            try {
                // Adding invoicePaymentData
                const addInvoicePaymentData = await addInvoicePayment(invoicePaymentData, pit_id, client);

                // Adding paymentModeData
                const addPaymentMode = await addPaymentModes(paymentModeData, pit_id, client);

                // Adding payment in journal entry
                const addPaymentInJournalEntry = await journalEntryService.addPaymentInJournalEntry(paymentModeData, paymentData.pit_invoice_number, paymentData.pit_current_payment, paymentData.cmr_id, client);

                // Updating due amount
                const totalCurrentPayment = invoicePaymentData.reduce((sum: number, item: any) => sum + parseFloat(item.pdt_current_payment), 0);
                paymentData.pit_total_amount = totalCurrentPayment
                const updateDueAmount = await financialLegder.detectCustomerDueAmount(paymentData, client);

                let order = orderResult.rows[0];
                let item = addInvoicePaymentData.rows;

                await client.query('COMMIT');
                return { order, item };
            } catch (innerError) {
                await client.query('ROLLBACK');
                throw new Error(`Transaction failed: ${innerError.message}`);
            }
        } else {
            await client.query('ROLLBACK');
            throw new Error('No rows returned from initial insert.');
        }
    } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(`Transaction failed: ${error.message}`);
    }
}


export async function addInvoicePayment(invoicePaymentData:any, pit_id:any,client:any){
    try{

        await client.query('BEGIN');
    const newInvoicePaymentData = invoicePaymentData.map((item: any) => ({
        ...item,
        pit_id: pit_id
    }));
 
    const invoicePaymentColumns = Object.keys(newInvoicePaymentData[0]);
 
    const invoicePaymentColumnsValuesArray = newInvoicePaymentData.map((item: any) =>
        Object.values(item)
    );
   
    const valuesStrings = invoicePaymentColumnsValuesArray.map((innerArray: any) =>
        `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
    );

    console.log(valuesStrings)

    // Join the strings into a single string
    const resultString = valuesStrings.join(', ');

    const addingInvoicePaymentquery = `INSERT INTO payment_in_document_list_table (${invoicePaymentColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;



    // console.log(query)
    const addingInvoicePaymentResult = await client.query(addingInvoicePaymentquery);

    const updateInvoiceItem = await salesOrderService.updateInvoiceItemAmount(newInvoicePaymentData)

    await client.query('COMMIT');
    return addingInvoicePaymentResult

}catch(error){

    await client.query('ROLLBACK');
    throw new Error(error)
}


}


export async function addPaymentModes(paymentModeData:any, pit_id:any,client:any){
    try{

        await client.query('BEGIN');
    const newpaymentModeData = paymentModeData.map((item: any) => ({
        ...item,
        pmt_id : ulid(),
        pit_id: pit_id
    }));
 
    const invoicePaymentColumns = Object.keys(newpaymentModeData[0]);
 
    const invoicePaymentColumnsValuesArray = newpaymentModeData.map((item: any) =>
        Object.values(item)
    );
   
    const valuesStrings = invoicePaymentColumnsValuesArray.map((innerArray: any) =>
        `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
    );

    console.log(valuesStrings)

    // Join the strings into a single string
    const resultString = valuesStrings.join(', ');

    const addingPaymentModequery = `INSERT INTO payment_modes_table (${invoicePaymentColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
     
   

    // console.log(query)
    const addPaymentModeResult = await client.query(addingPaymentModequery);

   

    await client.query('COMMIT');

    return addPaymentModeResult

}catch(error){
    await client.query('ROLLBACK');
    throw new Error(error)
}


}


export async function addPaymentOut(paymentData:any,invoicePaymentData:any,paymentModeData:any) {
    try {

        await client.query('BEGIN');
        const pot_id = ulid()
        paymentData.pot_id = pot_id
        paymentData.pot_order_status = 'paid'
        const columns = Object.keys(paymentData);
        const values = Object.values(paymentData);

        const query = `INSERT INTO payment_out_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
        


        const orderResult = await client.query(query, values);
        // console.log(orderResult)
        if (orderResult.rows.length > 0) {

            //adding invoicePaymentData

            const addInvoicePaymentData = await addInvoicePaymentOut(invoicePaymentData,pot_id)

            const addPaymentMode = await addPaymentOutModes(paymentModeData,pot_id)

            const addPaymentInJournalEntry = await journalEntryService.addPaymentOutJournalEntry(paymentModeData,paymentData.pot_invoice_number,paymentData.pot_current_payment,paymentData.cmr_id)
            const totalCurrentPayment = invoicePaymentData.reduce((sum: number, item: any) => sum + parseFloat(item.podt_current_payment), 0);
            paymentData.pot_total_amount = totalCurrentPayment
            const updateDueAmount = await financialLegder.detectCustomerDueAmountforPaymentOut(paymentData)
            //adding paymentmode Data

            let order = orderResult.rows[0]
            let item = addInvoicePaymentData.rows

            await client.query('COMMIT');
            return { order, item }
        }
    } catch (error) {
    
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function addInvoicePaymentOut(invoicePaymentData:any, pot_id:any){
    try{

        await client.query('BEGIN');
    const newInvoicePaymentData = invoicePaymentData.map((item: any) => ({
        ...item,
        pot_id: pot_id
    }));
 
    const invoicePaymentColumns = Object.keys(newInvoicePaymentData[0]);
 
    const invoicePaymentColumnsValuesArray = newInvoicePaymentData.map((item: any) =>
        Object.values(item)
    );
   
    const valuesStrings = invoicePaymentColumnsValuesArray.map((innerArray: any) =>
        `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
    );

    console.log(valuesStrings)

    // Join the strings into a single string
    const resultString = valuesStrings.join(', ');

    const addingInvoicePaymentquery = `INSERT INTO payment_out_document_list_table (${invoicePaymentColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;



    // console.log(query)
    const addingInvoicePaymentResult = await client.query(addingInvoicePaymentquery);

    const updateInvoiceItem = await purchaseService.updateInvoiceItemAmount(newInvoicePaymentData)

    await client.query('COMMIT');
    return addingInvoicePaymentResult

}catch(error){

    await client.query('ROLLBACK');
    throw new Error(error)
}


}

export async function addPaymentOutModes(paymentModeData:any, pot_id:any){
    try{

        await client.query('BEGIN');
    const newpaymentModeData = paymentModeData.map((item: any) => ({
        ...item,
        pmt_id : ulid(),
        pot_id: pot_id
    }));
 
    const invoicePaymentColumns = Object.keys(newpaymentModeData[0]);
 
    const invoicePaymentColumnsValuesArray = newpaymentModeData.map((item: any) =>
        Object.values(item)
    );
   
    const valuesStrings = invoicePaymentColumnsValuesArray.map((innerArray: any) =>
        `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
    );

    console.log(valuesStrings)

    // Join the strings into a single string
    const resultString = valuesStrings.join(', ');

    const addingPaymentModequery = `INSERT INTO payment_out_modes_table (${invoicePaymentColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;
     
   

    // console.log(query)
    const addPaymentModeResult = await client.query(addingPaymentModequery);

   

    await client.query('COMMIT');

    return addPaymentModeResult

}catch(error){
    await client.query('ROLLBACK');
    throw new Error(error)
}


}

export async function addInvoicePaymentData(invoicePaymentData:any){
    try{

        await client.query('BEGIN');
 
 
    const invoicePaymentColumns = Object.keys(invoicePaymentData[0]);
 
    const invoicePaymentColumnsValuesArray = invoicePaymentData.map((item: any) =>
        Object.values(item)
    );
   
    const valuesStrings = invoicePaymentColumnsValuesArray.map((innerArray: any) =>
        `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
    );

    console.log(valuesStrings)

    // Join the strings into a single string
    const resultString = valuesStrings.join(', ');

    const addingInvoicePaymentquery = `INSERT INTO billing_invoice_payment_modes (${invoicePaymentColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

    

    // console.log(query)
    const addingInvoicePaymentResult = await client.query(addingInvoicePaymentquery);
    console.log(addingInvoicePaymentResult.rows)
    




    await client.query('COMMIT');
    return addingInvoicePaymentResult

}catch(error){

    await client.query('ROLLBACK');
    throw new Error(error)
}


}

export async function addCredNoteInvoicePaymentData(invoicePaymentData:any){
    try{

        await client.query('BEGIN');
 
 
    const invoicePaymentColumns = Object.keys(invoicePaymentData[0]);
 
    const invoicePaymentColumnsValuesArray = invoicePaymentData.map((item: any) =>
        Object.values(item)
    );
   
    const valuesStrings = invoicePaymentColumnsValuesArray.map((innerArray: any) =>
        `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
    );

    console.log(valuesStrings)

    // Join the strings into a single string
    const resultString = valuesStrings.join(', ');

    const addingInvoicePaymentquery = `INSERT INTO credit_note_invoice_payment_modes (${invoicePaymentColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

    

    console.log(addingInvoicePaymentquery)
    const addingInvoicePaymentResult = await client.query(addingInvoicePaymentquery);
    console.log(addingInvoicePaymentResult.rows,"ddddddddddwwwwwwwwww")
    




    await client.query('COMMIT');
    return addingInvoicePaymentResult

}catch(error){

    await client.query('ROLLBACK');
    throw new Error(error)
}


}

export async function getGlAccount(){
    try{
        const query = `
        SELECT
        general_accounts_table.account_id,
        general_accounts_table.account_code,
        general_accounts_table.account_name
        FROM
        general_accounts_table
        WHERE
        is_gl_account = true AND is_directory = false AND is_transaction_account = true
      `;
        // Execute the query with parameterized values
        const result = await client.query(query)
        return result

    }catch(error){

        throw new Error(error)
    }
}

export async function getAllPaymentIn(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus,  searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.pit_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM payment_in_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM payment_in_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }
}


export async function paymentInGetbyId(pit_id:any){
    try{
        const getQuerybyId = `
        SELECT
        pl.*,
        pd.*,
        pm.*
        FROM
        payment_in_table AS pl
        JOIN 
        payment_in_document_list_table AS pd ON pl.pit_id = pd.pit_id
        JOIN
        payment_modes_table AS pm ON  pl.pit_id = pm.pit_id
        WHERE
          pl.pit_id = $1
      `;
        // Execute the query with parameterized values
        const result = await client.query(getQuerybyId,[pit_id])
        return result

    }catch(error){

        throw new Error(error)
    }
}


export async function getAllPaymentOut(query: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, orderStatus,  searchColumn, searchValue } = query


        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = '';
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND so.created_date >= '${fromDate}' AND so.created_date < '${toDate}'::date + interval '1 day'`;  // Specify the table alias
        }

        // Add payment status filter to the WHERE clause
        if (orderStatus) {
            whereClause += ` AND so.pit_order_status = '${orderStatus}'`;  // Specify the table alias
        }

        // Add order status filter to the WHERE clause


        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            if (sortBy === 'cmr_first_name') {
                orderByClause = `ORDER BY c.${sortBy} ${sortOrder}`;  // Sort by cmr_first_name from customer_details
            } else {
                orderByClause = `ORDER BY so.${sortBy} ${sortOrder}`;  // Sort by other columns in sales_order
            }
        } else {
            // Default sorting by created_date in descending order if no sorting parameters provided
            orderByClause = 'ORDER BY so.created_date DESC';
        }



        // Add search condition for the specified column in both tables
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        const queryCount = `SELECT COUNT(*) FROM payment_out_table so  WHERE 1=1 ${whereClause} ${searchCondition};`;
        const findquery: any = `SELECT so.* FROM payment_out_table so WHERE 1=1 ${whereClause} ${searchCondition} ${orderByClause ? orderByClause : ''} OFFSET $1 LIMIT $2;`;

        console.log(query);
        const totalCount = await client.query(queryCount);
        const getOrderList = await client.query(findquery, [offset, limit]);
        const totalRowsCount = totalCount.rows[0].count
        const orderList = getOrderList.rows

        return { totalRowsCount, orderList }

    } catch (error) {
        throw new Error(error)
    }

}

export async function paymentOutGetbyId(pot_id:any){
    try{
        const getQuerybyId = `
        SELECT
        po.*,
        pd.*,
        pm.*
        FROM
        payment_out_table AS po
        LEFT JOIN 
        payment_out_document_list_table AS pd ON po.pot_id = pd.pot_id
        LEFT JOIN
        payment_out_modes_table AS pm ON  po.pot_id = pm.pot_id
        WHERE
          po.pot_id = $1
      `;
        // Execute the query with parameterized values
        const result = await client.query(getQuerybyId,[pot_id])

        return result

    }catch(error){

        throw new Error(error)
    }
}