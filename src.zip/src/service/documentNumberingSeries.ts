import client from '../util/database';
import { ulid } from 'ulid';




export async function addDocument(documentData:any){
    try{
        documentData.transaction_doc_id = ulid()
        const columns = Object.keys(documentData);
        const values = Object.values(documentData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO document_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;
        console.log(insertQuery);

        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function addSeriesToDocument(documentData:any){
    try{
        await client.query('BEGIN');

        documentData.series_id = ulid()
        documentData.series_default = true
        
        const columns = Object.keys(documentData);
        const values = Object.values(documentData);

        // Construct the parameterized query
        const insertQuery = `INSERT INTO document_numbering_series_table (${columns.join(', ')}) VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *;`;

        const updateQuery = `UPDATE document_numbering_series_table SET series_default = false WHERE transaction_doc_id = $1 AND series_default = true;`;

        await client.query(updateQuery, [documentData.transaction_doc_id]);


        console.log(insertQuery);
    
        // Execute the query with parameterized values
        const result = await client.query(insertQuery, values);
        await client.query('COMMIT');

        return result

    }catch(error){
        await client.query('ROLLBACK');
        throw new Error(error)
    }
}

export async function getSeriesToDocument(transaction_doc_id:any){
    try{

        let getQuery = 'SELECT * FROM document_numbering_series_table WHERE transaction_doc_id = $1 ORDER BY created_date ASC';


        // Execute the query with parameterized values
        const result = await client.query(getQuery, [transaction_doc_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}

export async function getInvoiceBillingNextNumber(){
    try{
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'invoice_billing' 
            AND dnst.series_default = TRUE;
        
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }


            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
            
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'invoice_billing'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}

export async function updateSeries(numbering_series_id:any,seriesData:any){
    try{

        const columnValuePairs = Object.entries(seriesData)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(seriesData);

        const query = `
    UPDATE document_numbering_series_table
    SET ${columnValuePairs}
    WHERE series_id = $${Object.keys(seriesData).length + 1}
    RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, numbering_series_id]);

        return result

    }catch(error){
              throw new Error(error)
    }
}


export async function getSaleOrderNextInvoiceNumber(){
    try{
       
          const getDocumentSeries = `WITH fiscal_year AS (
    SELECT 
        CASE 
            WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
            THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
            ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
        END AS fiscal_year
)
SELECT 
    dt.*, 
    dnst.*
FROM 
    document_table dt
JOIN 
    document_numbering_series_table dnst 
ON 
    dt.transaction_doc_id = dnst.transaction_doc_id
JOIN 
    fiscal_year fy 
ON 
    dnst.series_fyi_year = fy.fiscal_year
WHERE 
    dt.transaction_document_name = 'sales_order' 
    AND dnst.series_default = TRUE;

`
          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'sales_order'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getSalesDeliveryNextInvoiceNumber(){
    try{
          
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'delivery_order' 
            AND dnst.series_default = TRUE;
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'delivery_order'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getSalesInvoiceNextInvoiceNumber(){
    try{ 
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'sales_invoice' 
            AND dnst.series_default = TRUE;
        `
       

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'sales_invoice'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getSalesReturnNextInvoiceNumber(){
    try{
          
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'sales_return' 
            AND dnst.series_default = TRUE;
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'sales_return'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getSalesCreditNoteNextInvoiceNumber(){
    try{
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'sales_credit_note' 
            AND dnst.series_default = TRUE;
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'sales_credit_note'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getPurchaseOrderNextInvoiceNumber(){
    try{
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'purchase_order' 
            AND dnst.series_default = TRUE;
        `
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {

            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
          
       console.log(updateQuery,"invoice")
            const updateresult = await client.query(updateQuery, [series_increment, 'purchase_order'])

            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}

export async function getGORNextInvoiceNumber(){
    try{
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'goods_order_reciept' 
            AND dnst.series_default = TRUE;
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'goods_order_reciept'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getPurchaseInvoiceNextInvoiceNumber(){
    try{ 
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'purchase_invoice' 
            AND dnst.series_default = TRUE;
        `
       

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'purchase_invoice'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getPurchaseReturnNextInvoiceNumber(){
    try{
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'purchase_return' 
            AND dnst.series_default = TRUE;
        `
         
          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'purchase_return'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getPurchaseCreditNoteNextInvoiceNumber(){
    try{
          
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'purchase_credit_note' 
            AND dnst.series_default = TRUE;
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'purchase_credit_note'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getAllDocument(query:any) {
    try {
        // Calculate the offset based on the limit and page number
        const { pageNumber, pageSize } = query;
        const offset = (pageNumber - 1) * pageSize;
 

        // Update the query to include LIMIT and OFFSET
        let getQuery = `SELECT du.*,dms.*
                        FROM document_table AS du
                        JOIN document_numbering_series_table AS dms
                        ON dms.transaction_doc_id = du.transaction_doc_id
                        WHERE dms.series_default = true
                        LIMIT $1
                        OFFSET $2`;

        // Execute the query with parameterized values
        const result = await client.query(getQuery, [pageSize, offset]);

        return result
    } catch (error) {
        throw new Error(error);
    }
}


export async function getStockTransferNextInvoiceNumber(){
    try{
          
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'stock_transfer' 
            AND dnst.series_default = TRUE;
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'stock_transfer'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}


export async function getReturnInvoiceNextInvoiceNumber(){
    try{
          
        const getDocumentSeries = `WITH fiscal_year AS (
            SELECT 
                CASE 
                    WHEN EXTRACT(MONTH FROM CURRENT_DATE) >= 4 
                    THEN EXTRACT(YEAR FROM CURRENT_DATE) || '-' || (EXTRACT(YEAR FROM CURRENT_DATE) + 1)
                    ELSE (EXTRACT(YEAR FROM CURRENT_DATE) - 1) || '-' || EXTRACT(YEAR FROM CURRENT_DATE)
                END AS fiscal_year
        )
        SELECT 
            dt.*, 
            dnst.*
        FROM 
            document_table dt
        JOIN 
            document_numbering_series_table dnst 
        ON 
            dt.transaction_doc_id = dnst.transaction_doc_id
        JOIN 
            fiscal_year fy 
        ON 
            dnst.series_fyi_year = fy.fiscal_year
        WHERE 
            dt.transaction_document_name = 'return_invoice' 
            AND dnst.series_default = TRUE;
        `

          console.log(getDocumentSeries)
           const result = await client.query(getDocumentSeries);

           if(result.rows.length>0){


        async  function  generateInvoiceNumber(seriesConfig:any) {
            console.log(seriesConfig)
            const currentDate = new Date();
            const year = seriesConfig.series_include_year ? currentDate.getFullYear() : '';
            const month = seriesConfig.series_include_month ? ('0' + (currentDate.getMonth() + 1)).slice(-2) : '';
            const date = seriesConfig.series_include_date ? ('0' + currentDate.getDate()).slice(-2) : '';
        
            const prefix = seriesConfig.series_prefix;
            const separator = seriesConfig.series_separator;
            const suffix = seriesConfig.series_suffix;
            const currentDocumentNumber = seriesConfig.current_document_number
            const series_increment =seriesConfig.series_increment
            let invoiceNumber = `${prefix}${separator}${suffix}${separator}`;

            if( seriesConfig.series_include_date){
                invoiceNumber += `${date}`
            }

            if( seriesConfig.series_include_month){
                invoiceNumber += `${month}`
            }

            if( seriesConfig.series_include_year){
                invoiceNumber += `${year}`
            }
            

            const leadingZeros = seriesConfig.series_leading_spaces;
            const lastDigit = seriesConfig.series_last_digit;
        
            const paddedDocumentNumber = currentDocumentNumber.toString().padStart(leadingZeros, '0');
            invoiceNumber += `${paddedDocumentNumber}`;

        let updateQuery =  'UPDATE document_table SET current_document_number = current_document_number + $1 WHERE transaction_document_name = $2'
        
            console.log(updateQuery, typeof(series_increment), series_increment)
       
            const updateresult = await client.query(updateQuery, [series_increment, 'return_invoice'])
console.log(updateresult, "eeeeeeeeeeeeee")
            
        
            return invoiceNumber;
        }
        
const nextInvoicenumber = await  generateInvoiceNumber(result.rows[0])
        console.log(nextInvoicenumber,'eeeeeeeeeeeeeeeeeeeeeee')

        

        // Execute the query with parameterized values
        


        return nextInvoicenumber
    }

    }catch(error){
              throw new Error(error)
    }
}
