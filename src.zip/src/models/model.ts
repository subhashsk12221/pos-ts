import client from "../util/database";

export async function createTables() {
  const createTableQueries = [
    `CREATE OR REPLACE FUNCTION notify_price_change()
    RETURNS TRIGGER AS $$
    BEGIN
      PERFORM pg_notify(
        'price_change_event',
        json_build_object(
          'action', TG_OP, -- The type of operation
          'data', row_to_json(NEW)
        )::text
      );
      RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;`,

    `CREATE OR REPLACE TRIGGER item_selling_price_change
AFTER UPDATE OF item_selling_price ON price_list_items_table
FOR EACH ROW
EXECUTE FUNCTION notify_price_change();`,

    `CREATE OR REPLACE FUNCTION generate_sale_order_invoice_number(store_id VARCHAR)
RETURNS VARCHAR(20) AS $$
DECLARE
seq_val VARCHAR;
current_date_str VARCHAR;
BEGIN
SELECT nextval('sott_invoice_number') INTO seq_val;
SELECT TO_CHAR(CURRENT_DATE, 'YYYYMMDD') INTO current_date_str;

-- Calculate the length of store_id and adjust padding
RETURN 
    CASE 
        WHEN LENGTH(store_id) < 3 THEN store_id || current_date_str || LPAD(seq_val::TEXT, 7, '0')
        ELSE store_id || current_date_str || LPAD(seq_val::TEXT, 5, '0')
    END;
END;
$$ LANGUAGE plpgsql;
`,

    `CREATE TABLE IF NOT EXISTS "customer_details" (
    cmr_id VARCHAR(255) PRIMARY KEY,
    cmr_code VARCHAR(255),
    cmr_first_name VARCHAR(255),
    cmr_last_name VARCHAR(255),
    cmr_type VARCHAR(255),
    cmr_dob DATE,
    cmr_phone_number VARCHAR(255),
    cmr_group_id VARCHAR(255),
    cmr_rewards BIGINT,
    cmr_email VARCHAR(255),
    cmr_active_status BOOLEAN ,
    cmr_active_from DATE,
    cmr_inactive_from DATE,
    cmr_remarks TEXT,
    is_ecommerce_cmr BOOLEAN,
    is_vendor_cmr BOOLEAN,
    is_corporate_cmr BOOLEAN,
    is_store_cmr BOOLEAN,
    inter_company_sync BOOLEAN DEFAULT FALSE,
    update_sign VARCHAR(255),
    cmr_country VARCHAR(255),
    cmr_state VARCHAR(255),
    cmr_district VARCHAR(255),
    cmr_city VARCHAR(255),
    cmr_town VARCHAR(255),
    cmr_village VARCHAR(255),
    cmr_street1 VARCHAR(255),
    cmr_street2 VARCHAR(255),
    cmr_pincode VARCHAR(255),
    cmr_address TEXT,
    cmr_company VARCHAR(255),
    price_list_id VARCHAR(255),
    cmr_pan VARCHAR(255),
    cmr_sector VARCHAR(255),
    cmr_gstin VARCHAR(255),
    cmr_tax VARCHAR(255),
    cmr_business_type VARCHAR(255),
    cmr_balance BIGINT ,
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

    `CREATE TABLE IF NOT EXISTS "sales_order" (
    sot_id VARCHAR(255) PRIMARY KEY,
    sot_return_status  VARCHAR(255),
    cmr_phone_number VARCHAR(255),
    store_id VARCHAR(255),
    sot_invoice_number VARCHAR(255),
    sot_total_gst DECIMAL(10,2),
    sot_total_discount DECIMAL(10,2),
    sot_sub_total DECIMAL(10,2),
    sot_payment_status VARCHAR(50),
    sot_order_status VARCHAR(50),
    sot_transaction_id VARCHAR(255),
    sot_payment_method VARCHAR(50),
    sot_billing_address TEXT,
    sot_total_amount DECIMAL(10,2),
    doctor_name VARCHAR(255),
    cmr_id VARCHAR(50),
    data_synced BOOLEAN DEFAULT FALSE,
    is_draft_order BOOLEAN DEFAULT FALSE,
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

    `CREATE TABLE IF NOT EXISTS "billing_invoice_payment_modes" (
     sot_id VARCHAR(255) ,
     payment_mode_name VARCHAR(255),
     payment_amount DECIMAL(10,2),
     FOREIGN KEY (sot_id) REFERENCES sales_order(sot_id),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

    `CREATE TABLE IF NOT EXISTS "order_items_list" (
    item_id VARCHAR(255),
    sot_id VARCHAR(255) ,
    item_code VARCHAR(255),
    item_generic_name VARCHAR(255),
    item_price_wiithout_tax DECIMAL(10,2),
    item_name VARCHAR(255),
    item_pack_size VARCHAR(50),
    item_unit_price DECIMAL(10,2),
    item_batch_number VARCHAR(50),
    item_open_quantity INT,
    item_quantity INT,
    item_exp_date DATE,
    item_mfg_date DATE,
    item_uom VARCHAR(255),
    item_rack_location VARCHAR(50),
    item_schedule VARCHAR(255),
    item_discount_amount DECIMAL(10,2),
    item_discount_percentage DECIMAL(10,2),
    item_tax_amount DECIMAL(10,2) ,
    item_total_tax_percentage DECIMAL(10,2),
    item_total_amount DECIMAL(10,2),
    item_gst  DECIMAL(10,2),
    item_sgst DECIMAL(10,2),
    item_cgst DECIMAL(10,2),
    item_igst DECIMAL(10,2),
    FOREIGN KEY (sot_id) REFERENCES sales_order(sot_id),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS "invoice_credit_note" (
     icn_id VARCHAR(255) PRIMARY KEY,
     cmr_phone_number VARCHAR(255),
     store_id VARCHAR(255),
     icn_invoice_number VARCHAR(255),
     icn_total_gst DECIMAL(10,2),
     icn_total_discount DECIMAL(10,2),
     icn_sub_total DECIMAL(10,2),
     icn_payment_status VARCHAR(50),
     icn_order_status VARCHAR(50),
     icn_transaction_id VARCHAR(255),
     icn_payment_method VARCHAR(50),
     icn_billing_address TEXT,
     icn_total_amount DECIMAL(10,2),
     cmr_id  VARCHAR(50),
     doctor_name VARCHAR(255),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

  `CREATE TABLE IF NOT EXISTS "invoice_credit_note_item_list" (
    item_id VARCHAR(255),
    sot_id VARCHAR(255),
    icn_id VARCHAR(255) ,
    item_code VARCHAR(255),
    item_generic_name VARCHAR(255),
    item_price_wiithout_tax DECIMAL(10,2),
    item_name VARCHAR(255),
    item_pack_size VARCHAR(50),
    item_unit_price DECIMAL(10,2),
    item_batch_number VARCHAR(50),
    item_open_quantity INT,
    item_quantity INT,
    item_exp_date DATE,
    item_mfg_date DATE,
    item_uom VARCHAR(255),
    item_rack_location VARCHAR(50),
    item_schedule VARCHAR(255),
    item_discount_amount DECIMAL(10,2),
    item_discount_percentage DECIMAL(10,2),
    item_tax_amount DECIMAL(10,2) ,
    item_total_tax_percentage DECIMAL(10,2),
    item_total_amount DECIMAL(10,2),
    item_gst  DECIMAL(10,2),
    item_sgst DECIMAL(10,2),
    item_cgst DECIMAL(10,2),
    item_igst DECIMAL(10,2),
    FOREIGN KEY (icn_id) REFERENCES invoice_credit_note(icn_id),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

  `CREATE TABLE IF NOT EXISTS "credit_note_invoice_payment_modes" (
    icn_id VARCHAR(255) ,
    payment_mode_name VARCHAR(255),
    payment_amount DECIMAL(10,2),
    FOREIGN KEY (icn_id) REFERENCES invoice_credit_note(icn_id),
   update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
   created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS "store_inventory_table" (
    pot_id VARCHAR(255) REFERENCES purchase_order_transaction_table(pot_id),
    item_id VARCHAR(255) PRIMARY KEY,
    store_id VARCHAR(255),
    item_code VARCHAR(255),
    item_quantity INT,
    item_generic_name VARCHAR(255),
    item_name VARCHAR(255),
    item_pack_size VARCHAR(50),
    item_schedule VARCHAR(255),
    item_UOM VARCHAR(50),
    item_mfg_by VARCHAR(50),
    item_unit_price DECIMAL(10,2),
    item_rack_location VARCHAR(50),
    item_categeory VARCHAR(50),
    item_received_quantity INT,
    item_gst  DECIMAL(10,2),
    item_sgst DECIMAL(10,2),
    item_cgst DECIMAL(10,2),
    item_discount  DECIMAL(10,2),
    item_discount_amount DECIMAL(10,2),
    item_discount_percentage DECIMAL(10,2),
    item_tax_amount DECIMAL(10,2) ,
    item_total_tax_percentage DECIMAL(10,2),
    item_total_amount DECIMAL(10,2),
    item_barcode VARCHAR(255),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

    `CREATE TABLE IF NOT EXISTS "items_batch_no_table"(
    item_id VARCHAR(255) ,
    item_batch_number VARCHAR(50) ,
    item_sellable_quantity BIGINT CHECK (item_sellable_quantity >= 0),
    item_non_sellable_quantity BIGINT CHECK (item_non_sellable_quantity >= 0),
    item_exp_date DATE,
    item_mfg_date DATE,
    FOREIGN KEY (item_id) REFERENCES store_inventory_table(item_id),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP

  )`,

  `CREATE TABLE IF NOT EXISTS store_inventory_item_location_table (
    item_id VARCHAR(255),
    store_id VARCHAR(255),
    item_code VARCHAR(255),
    item_quantity INT,
    item_batch_number VARCHAR(50),
    to_bin_id VARCHAR(50),
    from_bin_id VARCHAR(50),
    item_rack_location VARCHAR(50),
    CONSTRAINT unique_item_batch_location UNIQUE (item_batch_number, item_rack_location),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);`,

    `CREATE TABLE IF NOT EXISTS "discount_table" (
    discount_slab_id VARCHAR(255) PRIMARY KEY,
    item_category VARCHAR(255),
    min_order_value BIGINT NOT NULL,
    discount_percentage BIGINT NOT NULL
  )`,

    `CREATE TABLE IF NOT EXISTS "doctor_table" (
    dr_id VARCHAR(255) PRIMARY KEY,
    dr_name VARCHAR(255),
    dr_specialization VARCHAR(255),
    dr_registration_num VARCHAR(255),
    dr_qualification VARCHAR(255),
    dr_pincode VARCHAR(255),
    dr_state VARCHAR(255),
    dr_city VARCHAR(255),
    dr_street1 VARCHAR(255),
    dr_street2 VARCHAR(255),
    dr_email VARCHAR(255),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

    `CREATE TABLE IF NOT EXISTS tax_table (
    tax_id VARCHAR(255) PRIMARY KEY,
    cgst_rate DECIMAL(5, 2),
    sgst_rate DECIMAL(5, 2),
    igst_rate DECIMAL(5, 2),
    item_category VARCHAR(255)
)`,

    `CREATE TABLE IF NOT EXISTS items_table(
item_id  VARCHAR(255) PRIMARY KEY,
item_type VARCHAR(255) ,
item_name VARCHAR(255) ,
item_category VARCHAR(255) ,
item_price_list VARCHAR(255) ,
item_price_list_id VARCHAR(255),
item_generic_name VARCHAR(255) ,
item_group VARCHAR(255) ,
item_barcode VARCHAR(255) ,
item_uom  VARCHAR(255) ,
item_unit_price BIGINT,
item_description VARCHAR(255) ,
manage_item_by VARCHAR(255) ,
item_manufacturer VARCHAR(255) ,
item_shipping_type VARCHAR(255) ,
item_sector VARCHAR(255) ,
item_schedule VARCHAR(255),
item_GSTIN VARCHAR(255) ,
item_exp_date DATE,
item_HSN VARCHAR(255) ,
item_GST VARCHAR(255) ,
item_categeory VARCHAR(255) ,
item_remarks VARCHAR(255) ,
country VARCHAR(255) ,
item_code  VARCHAR(255),
item_active_from DATE ,
item_inactive_from DATE ,
is_inventory_item BOOLEAN,
is_purchase_item BOOLEAN,
is_sales_item BOOLEAN,
active_from DATE,
active_to DATE,
inactive_from DATE,
inactive_to DATE,
is_active BOOLEAN,
item_tax_category VARCHAR(255),
item_tax_name VARCHAR(255),
is_draft BOOLEAN DEFAULT FALSE,
update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS alternative_items_table(
  alternative_id VARCHAR(255) PRIMARY KEY,
  alternative_item_id VARCHAR(255),
  main_item_id VARCHAR(255),
  alternative_item_code VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS item_purchasing_table(
  item_id VARCHAR(255) PRIMARY KEY,
  item_pur_preferred_vendor VARCHAR(255),
  item_pur_mfg_catalog_no VARCHAR(255),
  item_pur_purchasing_uom_name VARCHAR(255),
  item_pur_per_purchasing_unit VARCHAR(255),
  item_pur_packing_uom_name VARCHAR(255),
  item_pur_quantity_per_package VARCHAR(255),
  item_pur_length VARCHAR(255),
  item_pur_width VARCHAR(255),
  item_pur_height VARCHAR(255),
  item_pur_volume VARCHAR(255),
  item_pur_weight VARCHAR(255),
  item_pur_customs_group VARCHAR(255),
  item_pur_measurement_unit VARCHAR(255),
  item_pur_factor_1 VARCHAR(255),
  item_pur_factor_2 VARCHAR(255),
  item_pur_factor_3 VARCHAR(255),
  item_pur_factor_4 VARCHAR(255),
  is_draft BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (item_id) REFERENCES items_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS item_sales_table(
  item_id VARCHAR(255) PRIMARY KEY,
  item_sales_uom_name VARCHAR(255),
  item_sales_uom_name_id VARCHAR(255),
  item_sales_packing_uom_name VARCHAR(255),
  item_sales_quantity_per_package VARCHAR(255),
  item_per_sales_unit VARCHAR(255),
  item_sales_length VARCHAR(255),
  item_sales_width  VARCHAR(255),
  item_sales_height VARCHAR(255),
  item_sales_volume VARCHAR(255),
  item_sales_weight VARCHAR(255),
  item_sales_measurement_unit VARCHAR(255),
  item_sales_factor_1 VARCHAR(255),
  item_sales_factor_2 VARCHAR(255),
  item_sales_factor_3 VARCHAR(255),
  item_sales_factor_4 VARCHAR(255),
  is_draft BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (item_id) REFERENCES items_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

 
    `CREATE TABLE IF NOT EXISTS item_invetory_table(
  item_id VARCHAR(255) PRIMARY KEY,
  item_set_gl_account VARCHAR(255),
  item_uom_name VARCHAR(255),
  item_valuation_method VARCHAR(255),
  item_cost VARCHAR(255),
  item_weight VARCHAR(255),
  item_purchasing_uom VARCHAR(255) ,
  item_minimun_purchasing BIGINT,
  item_maximum_purchasing BIGINT,
  manage_inventory_by_warehouse BOOLEAN,
  is_draft BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (item_id) REFERENCES items_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,
    `CREATE TABLE IF NOT EXISTS item_planning_table(
  item_id VARCHAR(255) PRIMARY KEY,
  item_order_interval VARCHAR(255),
  item_order_multiple VARCHAR(255),
  item_minimum_order_quantity VARCHAR(255),
  item_checking_rule VARCHAR(255),
  is_draft BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (item_id) REFERENCES items_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS item_restriction_table(
  item_id VARCHAR(255) PRIMARY KEY,
  item_sales_invoice BOOLEAN ,
  item_sales_returns BOOLEAN ,
  item_purchase_request BOOLEAN ,
  item_discontiue BOOLEAN ,
  item_purchasing_order BOOLEAN,
  item_credit_note BOOLEAN ,
  item_debit_note BOOLEAN ,
  item_stock_in BOOLEAN ,
  item_stock_out BOOLEAN ,
  is_draft BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (item_id) REFERENCES items_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS item_remarks_table(
  item_id VARCHAR(255) PRIMARY KEY,
  item_remarks TEXT,
  FOREIGN KEY (item_id) REFERENCES items_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS item_uom_group_table(
    uom_group_id  VARCHAR(255) ,
    item_id  VARCHAR(255),
    uom_group_name  VARCHAR(255),
    item_number  VARCHAR(255),
    iugt_id  VARCHAR(255) PRIMARY KEY,
  FOREIGN KEY (item_id) REFERENCES items_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

 `CREATE TABLE IF NOT EXISTS item_uom_table(
  iut_id  VARCHAR(255) PRIMARY KEY,
  iugt_id  VARCHAR(255) , 
  uom_id  VARCHAR(255) ,
  uom_group_id  VARCHAR(255) ,
  uom_name  VARCHAR(255) , 
  FOREIGN KEY (iugt_id) REFERENCES item_uom_group_table(iugt_id),
   update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
   created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,
`CREATE TABLE IF NOT EXISTS item_uom_barcode_table(
     uom_id   VARCHAR(255) ,
    item_barcode   VARCHAR(255) ,
    free_text   VARCHAR(255) ,
    is_default boolean,
    iubt   VARCHAR(255) ,
    iut_id   VARCHAR(255) ,
    FOREIGN KEY (iut_id) REFERENCES item_uom_table(iut_id),
   update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
   created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,


    `CREATE TABLE IF NOT EXISTS store_info_address_table (
  store_id VARCHAR(255) PRIMARY KEY,
  store_code VARCHAR(255),
  store_type VARCHAR(255),
  relationship_manager VARCHAR(255),
  reapproval_remarks TEXT,
  addres_remarks TEXT,
  shop_address VARCHAR(255),
  shop_area VARCHAR(255),
  shop_landmark VARCHAR(255),
  shop_town_or_village VARCHAR(255),
  shop_city VARCHAR(255),
  shop_state VARCHAR(255),
  shop_pin_code VARCHAR(255),
  shop_country_region VARCHAR(255),
  store_rent_per_month DECIMAL(20,2),
  store_duration_concurrently VARCHAR(255),
  store_sale_per_day BIGINT,
  store_medicine_sale BIGINT,
  store_otc_sale BIGINT,
  store_latitude VARCHAR(255),
  store_longitude VARCHAR(255),
  tab_remarks TEXT,
  shop_images TEXT[],
  shop_image_1 TEXT,
  shop_image_2 TEXT,
  shop_image_3 TEXT,
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

`,

    `CREATE TABLE IF NOT EXISTS store_info_personal_details_table (
  store_id VARCHAR(255) PRIMARY KEY,
  store_status VARCHAR(255),
  authorised_person_name VARCHAR(255),
  gender VARCHAR(255),
  phone_number VARCHAR(255),
  qualifications VARCHAR(255),
  experience VARCHAR(255),
  email VARCHAR(255),
  adhar_number VARCHAR(255),
  date_of_birth VARCHAR(255),
  adhar_front_pic VARCHAR(255),
  adhar_back_pic VARCHAR(255),
  FOREIGN KEY (store_id) REFERENCES store_info_address_table(store_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
`,

    `CREATE TABLE IF NOT EXISTS store_info_firm_details_table(
    store_id VARCHAR(255) PRIMARY KEY,
    firm_name  VARCHAR(255),
    firm_type  VARCHAR(255),
    firm_authorised_person  VARCHAR(255),
    designation  VARCHAR(255),
    can_change_firm_name BOOLEAN ,
    firm_address  VARCHAR(255),
    firm_area  VARCHAR(255),
    firm_landmark  VARCHAR(255),
    firm_town_or_village  VARCHAR(255),
    firm_city  VARCHAR(255),
    firm_state  VARCHAR(255),
    firm_pin_code  VARCHAR(255),
    firm_country_region  VARCHAR(255),
    firm_agreement_with_davaindia_conditions BOOLEAN ,
    pan_type  VARCHAR(255),
    pan_number  VARCHAR(255),
    pan_pic_front  VARCHAR(255),
    pan_pic_back  VARCHAR(255),
    FOREIGN KEY (store_id) REFERENCES store_info_address_table(store_id),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS store_agreement_table(
        store_id VARCHAR(255) PRIMARY KEY,
        agreement_witness VARCHAR(255),
        store_agreement_remarks TEXT,
        store_agreement_is_approve BOOLEAN,
        FOREIGN KEY (store_id) REFERENCES store_info_address_table(store_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

 `CREATE TABLE IF NOT EXISTS store_information_for_user_table(
        store_id VARCHAR(255) PRIMARY KEY,
        company VARCHAR(255),
        company_area VARCHAR(255),
        company_landmark VARCHAR(255),
        company_city VARCHAR(255),
        company_state VARCHAR(255),
        company_pincode VARCHAR(255),
        company_address VARCHAR(255),
        company_alias_name VARCHAR(255),
        company_email VARCHAR(255),
        company_telephone1 VARCHAR(255),
        company_telephone2 VARCHAR(255),
        company_gstn VARCHAR(255),  
        company_licence VARCHAR(255),
        pos_id VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS store_info_payment_table(
          store_id VARCHAR(255) PRIMARY KEY,
          store_type VARCHAR(255),
          payment_method VARCHAR(255),
          amount decimal(20,2),
          transaction_id VARCHAR(255),
          remaining_amount  decimal(20,2),
          received_amount decimal(20,2),
          payment_recevie_time DATE,
          payment_receipt VARCHAR(255),
          payer_name_as_per_bank VARCHAR(255),
          payer_bank_name VARCHAR(255),
          payer_bank_account_no VARCHAR(255),
          payer_remaining_amount VARCHAR(255),
          payee_name_as_per_bank VARCHAR(255),
          payee_bank_name VARCHAR(255),
          payee_bank_account_no VARCHAR(255),
          isfc_code VARCHAR(255),
          extra_payee VARCHAR(255),
          gst_number VARCHAR(255),
          payment_table_remarks TEXT,
          FOREIGN KEY (store_id) REFERENCES store_info_address_table(store_id),
          update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
          created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS store_info_drug_license_table(
            store_id VARCHAR(255) PRIMARY KEY,
            dl_apply_date DATE, 
            dl_chalan_receipt VARCHAR(255),
            dl_is_approve BOOLEAN,
            dl_address VARCHAR(255),
            dl_area VARCHAR(255),
            dl_landmark VARCHAR(255),
            dl_town_or_village VARCHAR(255),
            dl_city VARCHAR(255),
            dl_state VARCHAR(255),
            dl_pin_code VARCHAR(255),
            dl_country_region VARCHAR(255),
            dl_valid_upto VARCHAR(255),
            dl_no_20_20B VARCHAR(255),
            dl_no_21_21B VARCHAR(255),
            dl_no_21C VARCHAR(255),
            dl_no_21F VARCHAR(255),
            dl_no_name VARCHAR(255),
            dl_store_sq_ft decimal(20,2),
            FOREIGN KEY (store_id) REFERENCES store_info_address_table(store_id),
            update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
            created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS uom_group_table(
              uom_group_id VARCHAR(255) PRIMARY KEY,
              uom_group_name VARCHAR(255),
              update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
              created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS uom_table(
                uom_group_id VARCHAR(255) ,
                uom_id VARCHAR(255) PRIMARY KEY,
                uom_name VARCHAR(255),
                FOREIGN KEY (uom_group_id) REFERENCES uom_group_table(uom_group_id),
                update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

   

    ` CREATE TABLE IF NOT EXISTS roles_table (
                role_id VARCHAR(255) PRIMARY KEY,
                role_name VARCHAR(255) UNIQUE,
                description VARCHAR(255),
                update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
            )`,
    ` CREATE TABLE IF NOT EXISTS department_table (
              department_id VARCHAR(255) PRIMARY KEY,
              department_name VARCHAR(255) UNIQUE,
              description VARCHAR(255),
              update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
              created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
          )`,

    `CREATE TABLE IF NOT EXISTS users_table(
    user_id  VARCHAR(255) PRIMARY KEY,
    user_name  VARCHAR(255),
    user_role_id VARCHAR(255),
    user_role  VARCHAR(255),
    user_email  VARCHAR(255),
    user_password  VARCHAR(255),
    user_store_id VARCHAR(255),
    user_phone_number VARCHAR(255),
    user_department VARCHAR(255),
    change_password_next_login BOOLEAN DEFAULT false,
    password_never_expires BOOLEAN DEFAULT false,
    password_expiry_date DATE,
    pos_id VARCHAR(255),
    FOREIGN KEY (user_role_id) REFERENCES roles_table(role_id),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
     )`,

    `CREATE TABLE IF NOT EXISTS users_permission_table(
      permission_id VARCHAR(255) PRIMARY KEY,
      module_name VARCHAR(255),
      module_id VARCHAR(255),
      user_id  VARCHAR(255),
      "create"  BOOLEAN DEFAULT false,
      "update"  BOOLEAN DEFAULT false,
      "delete"  BOOLEAN DEFAULT false,
      "print"   BOOLEAN DEFAULT false,
      "export"  BOOLEAN DEFAULT false,
      "send"   BOOLEAN DEFAULT false,
      "read"   BOOLEAN DEFAULT true,
      "all" BOOLEAN DEFAULT false,
      FOREIGN KEY (user_id) REFERENCES users_table(user_id),
      update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  )`,

    ` CREATE TABLE IF NOT EXISTS module_table (
        module_id VARCHAR(255) PRIMARY KEY,
        module_name VARCHAR(255) UNIQUE,
        description VARCHAR(255),
        main_module_id VARCHAR(255),
        FOREIGN KEY (main_module_id) REFERENCES main_module_table(main_module_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    ` CREATE TABLE IF NOT EXISTS main_module_table (
  main_module_id VARCHAR(255) PRIMARY KEY,
  main_module_name VARCHAR(255) UNIQUE,
  description VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS bank_list_table (
  bank_id VARCHAR(255) PRIMARY KEY,
  bank_name VARCHAR(255) ,
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS price_list_table (
  price_list_id VARCHAR(255) PRIMARY KEY,
  price_list_name VARCHAR(255) UNIQUE,
  default_base_price_list_id VARCHAR(255),
  default_base_price_list VARCHAR(255),
  default_factor DECIMAL(10,2),
  margin_factor DECIMAL(10,2),
  rounding_method VARCHAR(255),
  rounding_rule VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS price_list_items_table (
  item_id VARCHAR(255),
  price_list_id VARCHAR(255),
  is_manual BOOLEAN DEFAULT FALSE,
  item_base_price DECIMAL(10,2),
  item_selling_price DECIMAL(10,2),
  item_inventory_uom VARCHAR(255),
  item_pricing_uom VARCHAR(255),
  FOREIGN KEY (price_list_id) REFERENCES price_list_table(price_list_id),
  FOREIGN KEY (item_id) REFERENCES store_inventory_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS period_volume_discount_table (
  price_list_id VARCHAR(255) PRIMARY KEY,
  from_date DATE,
  to_date DATE,
  FOREIGN KEY (price_list_id) REFERENCES price_list_table(price_list_id),     
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,
    `CREATE TABLE IF NOT EXISTS period_volume_discount_items_table (
  period_discount_item_id  VARCHAR(255) PRIMARY KEY,
  item_id VARCHAR(255),
  price_list_id VARCHAR(255),
  FOREIGN KEY (price_list_id) REFERENCES price_list_table(price_list_id),     
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS items_period_validity_table (
  period_validity_id VARCHAR(255) PRIMARY KEY,
  period_discount_item_id VARCHAR(255),
  from_date DATE,
  to_date DATE, 
  effective_price DECIMAL(10,2),
  discount_percentage DECIMAL(10,2),
  FOREIGN KEY (period_discount_item_id) REFERENCES period_volume_discount_items_table(period_discount_item_id),   
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS items_volume_validity_table (
  volume_validity_id VARCHAR(255) PRIMARY KEY,
  period_validity_id VARCHAR(255),
  item_quantity DECIMAL(10,2),
  volume_effective_price DECIMAL(10,2),
  volume_discount_percentage DECIMAL(10,2),
  FOREIGN KEY (period_validity_id) REFERENCES items_period_validity_table(period_validity_id),   
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS item_group_table (
  item_group_id VARCHAR(255) PRIMARY KEY,
  item_group_name VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS  customer_group_table (
  customer_group_id VARCHAR(255) PRIMARY KEY,
  customer_group_name VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS  discount_type_table (
  discount_type_id VARCHAR(255) PRIMARY KEY,
  discount_type_name VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS discount_group_table (
  discount_group_id  VARCHAR(255) PRIMARY KEY,
  discount_type_id  VARCHAR(255),
  customer_group_id  VARCHAR(255),
  from_date DATE,
  to_date DATE,
  item_group_name VARCHAR(255),
  is_active BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (discount_type_id) REFERENCES discount_type_table(discount_type_id),
  FOREIGN KEY (customer_group_id) REFERENCES customer_group_table(customer_group_id),    
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS manufacture_group_table (
  manufacture_group_id VARCHAR(255) PRIMARY KEY,
  manufacture_group_name VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS  items_group_discount_group_table (
     discount_group_id VARCHAR(255),
     item_group_id VARCHAR(255),
     discount_percentage  DECIMAL(10,2),
     FOREIGN KEY (discount_group_id) REFERENCES discount_group_table(discount_group_id),  
     update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
     created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
 )`,

    `CREATE TABLE IF NOT EXISTS  manufactures_group_discount_group_table (
  discount_group_id VARCHAR(255),
  manufacture_group_id VARCHAR(255),
  discount_percentage  DECIMAL(10,2),
  FOREIGN KEY (discount_group_id) REFERENCES discount_group_table(discount_group_id),  
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS  items_discount_group_table (
  discount_group_id VARCHAR(255),
  item_id  VARCHAR(255) PRIMARY KEY,
  discount_percentage  DECIMAL(10,2),
  FOREIGN KEY (discount_group_id) REFERENCES discount_group_table(discount_group_id),  
  FOREIGN KEY (item_id) REFERENCES store_inventory_table(item_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS  warehouses_table (
  warehouse_id  VARCHAR(255) PRIMARY KEY,
  warehouse_code VARCHAR(10) ,
  warehouse_name VARCHAR(100) ,
  tax_code VARCHAR(20),
  warehouse_location VARCHAR(100) ,
  bin_location_enabled BOOLEAN DEFAULT FALSE,
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS bin_location_table (
  warehouse_id  VARCHAR(255) PRIMARY KEY,
  bin_location_code_separator VARCHAR(255),
  default_bin_location  VARCHAR(50),
  auto_alloc_on_issue VARCHAR(50),
  auto_alloc_on_receipt VARCHAR(50),
  enable_receiving_bin_location BOOLEAN DEFAULT FALSE,
  enforce_default_bin_location  BOOLEAN DEFAULT FALSE,
  receive_up_to_max_quantity BOOLEAN DEFAULT FALSE,
  receive_up_to_max_weight BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (warehouse_id) REFERENCES warehouses_table(warehouse_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS sublevel_table (
  sublevel_id   VARCHAR(255) PRIMARY KEY,
  sublevel_no BIGINT ,
  warehouse_id  VARCHAR(255),
  FOREIGN KEY (warehouse_id) REFERENCES warehouses_table(warehouse_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS sublevel_bins (
  bin_no_id VARCHAR(255) PRIMARY KEY,
  sublevel_id VARCHAR(255),
  bin_location_no VARCHAR(255),
  is_expired_bin_location BOOLEAN DEFAULT FALSE,
  is_sellable_bin_location BOOLEAN DEFAULT FALSE,
  is_non_sellable_bin_location BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (sublevel_id) REFERENCES sublevel_table(sublevel_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "sales_order_transaction_table" (
  sott_id VARCHAR(255) PRIMARY KEY,
  cmr_phone_number VARCHAR(255),
  cmr_code VARCHAR(255),
  cmr_name VARCHAR(255),
  cmr_id VARCHAR(255),
  sott_order_date DATE,
  sott_document_date DATE,
  sott_delivery_date DATE,
  store_id VARCHAR(255),
  sott_invoice_number VARCHAR(255),
  sott_total_gst DECIMAL(10,2),
  sott_total_discount DECIMAL(10,2),
  sott_payment_status VARCHAR(50),
  sott_order_status VARCHAR(50) ,
  sott_transaction_id VARCHAR(255),
  sott_payment_method VARCHAR(50),
  sott_billing_address TEXT,
  sott_sub_total DECIMAL(10,2),
  sott_total_amount DECIMAL(10,2),
  remarks VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "sales_order_items_list" (
  item_id VARCHAR(255),
  sott_id VARCHAR(255) REFERENCES sales_order_transaction_table(sott_id),
  item_code VARCHAR(255),
  base_ref VARCHAR(255) ,
  item_generic_name VARCHAR(255),
  item_name VARCHAR(255),
  item_pack_size VARCHAR(50),
  item_unit_price DECIMAL(10,2),
  item_uom VARCHAR(50),
  item_quantity INT,
  item_to_be_delivered INT CHECK(item_to_be_delivered >= 0) ,
  item_invoice_open_quantity INT CHECK(item_invoice_open_quantity >= 0),
  item_exp_date DATE,
  item_mfg_date DATE,
  item_rack_location VARCHAR(50),
  item_schedule VARCHAR(255),
  item_discount_amount DECIMAL(10,2),
  item_discount_percentage DECIMAL(10,2),
  item_tax_amount DECIMAL(10,2) ,
  item_total_tax_percentage DECIMAL(10,2),
  item_total_amount DECIMAL(10,2),
  item_gst  DECIMAL(10,2),
  item_sgst DECIMAL(10,2),
  item_cgst DECIMAL(10,2),
  item_igst DECIMAL(10,2),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "sales_order_document_list" (
  sott_id VARCHAR(255),
  sodtt_id VARCHAR(255) UNIQUE,
  soit_id VARCHAR(255) UNIQUE,
  FOREIGN KEY (sott_id) REFERENCES sales_order_transaction_table(sott_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "sales_order_delivery_transaction_table" (
  sodtt_id VARCHAR(255) PRIMARY KEY,
  cmr_phone_number VARCHAR(255),
  cmr_id VARCHAR(255),
  cmr_code VARCHAR(255),
  cmr_name VARCHAR(255),
  sodtt_order_date DATE,
  sodtt_document_date DATE,
  sodtt_delivery_date DATE,
  store_id VARCHAR(255),
  sodtt_invoice_number VARCHAR(255),
  sodtt_total_gst DECIMAL(10,2),
  sodtt_total_discount DECIMAL(10,2),
  sodtt_sub_total DECIMAL(10,2),
  sodtt_payment_status VARCHAR(50),
  sodtt_order_status VARCHAR(50),
  sodtt_transaction_id VARCHAR(255),
  sodtt_payment_method VARCHAR(50),
  sodtt_billing_address TEXT,
  sodtt_total_amount DECIMAL(10,2),
  remarks VARCHAR(255),
  is_invoice_created BOOLEAN DEFAULT FALSE,
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "sale_order_delivery_items_list" (
  item_id VARCHAR(255),
  sodtt_id VARCHAR(255) REFERENCES sales_order_delivery_transaction_table(sodtt_id),
  item_code VARCHAR(255),
  base_ref VARCHAR(255) ,
  item_generic_name VARCHAR(255),
  item_name VARCHAR(255),
  item_pack_size VARCHAR(50),
  item_unit_price DECIMAL(10,2),
  item_batch_number VARCHAR(50),
  item_quantity INT,
  item_delivered_quantity INT,
  item_exp_date DATE,
  item_mfg_date DATE,
  item_rack_location VARCHAR(50),
  item_schedule VARCHAR(255),
  is_item_invoice_created BOOLEAN DEFAULT FALSE,
  item_to_be_delivered INT CHECK (item_to_be_delivered >= 0),
  item_return_open_quantity INT CHECK (item_return_open_quantity >= 0),
  item_discount_amount DECIMAL(10,2),
  item_discount_percentage DECIMAL(10,2),
  item_tax_amount DECIMAL(10,2),
  item_total_tax_percentage DECIMAL(10,2),
  item_total_amount DECIMAL(10,2),
  item_gst  DECIMAL(10,2),
  item_sgst DECIMAL(10,2),
  item_cgst DECIMAL(10,2),
  item_igst DECIMAL(10,2),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "sale_order_delivery_document_list" (
  sodtt_id VARCHAR(255),
  srt_id VARCHAR(255) UNIQUE,
  soit_id VARCHAR(255) UNIQUE,
  FOREIGN KEY (sodtt_id) REFERENCES sales_order_delivery_transaction_table(sodtt_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "sale_order_delivery_items_batches_list" (
  item_id VARCHAR(255),
  sodtt_id VARCHAR(255) REFERENCES sales_order_delivery_transaction_table(sodtt_id),
  item_batch_number VARCHAR(50),
  item_batch_quantity INT,
  item_exp_date DATE,
  item_mfg_date DATE,
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "purchase_order_transaction_table" (
  cmr_id VARCHAR(255) ,
  pot_id VARCHAR(255) PRIMARY KEY,
  cmr_phone_number VARCHAR(255),
  cmr_code VARCHAR(255),
  cmr_name VARCHAR(255),
  pot_order_date DATE,
  pot_document_date DATE,
  pot_delivery_date DATE,
  store_id VARCHAR(255),
  pot_invoice_number VARCHAR(255),
  pot_total_gst DECIMAL(10,2),
  pot_total_discount DECIMAL(10,2),
  pot_payment_status VARCHAR(50),
  pot_order_status VARCHAR(50),
  pot_sub_total DECIMAL(10,2),
  pot_transaction_id VARCHAR(255),
  pot_payment_method VARCHAR(50),
  pot_billing_address TEXT,
  pot_total_amount DECIMAL(10,2),
  remarks VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "purchase_order_items_list" (
  item_id VARCHAR(255),
  pot_id VARCHAR(255) REFERENCES purchase_order_transaction_table(pot_id),
  item_code VARCHAR(255),
  item_generic_name VARCHAR(255),
  item_name VARCHAR(255),
  item_pack_size VARCHAR(50),
  item_unit_price DECIMAL(10,2),
  item_uom VARCHAR(50),
  item_batch_number VARCHAR(50),
  item_quantity INT,
  item_to_be_received INT CHECK (item_to_be_received >= 0),
  item_invoice_open_quantity INT CHECK (item_invoice_open_quantity >= 0),
  item_exp_date DATE,
  base_ref_no VARCHAR(50),
  item_mfg_date DATE,
  item_rack_location VARCHAR(50),
  item_schedule VARCHAR(255),
  item_discount_amount DECIMAL(10,2),
  item_discount_percentage DECIMAL(10,2),
  item_tax_amount DECIMAL(10,2) ,
  item_total_tax_percentage DECIMAL(10,2),
  item_total_amount DECIMAL(10,2),
  item_gst  DECIMAL(10,2),
  item_sgst DECIMAL(10,2),
  item_cgst DECIMAL(10,2),
  item_igst DECIMAL(10,2),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "purchase_order_document_list" (
  pot_id VARCHAR(255),
  gort_id VARCHAR(255) UNIQUE ,
  poit_id VARCHAR(255) UNIQUE ,
  FOREIGN KEY (pot_id) REFERENCES purchase_order_transaction_table(pot_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "goods_order_receipt_table" (
  cmr_id VARCHAR(255) ,
  gort_id VARCHAR(255) PRIMARY KEY,
  cmr_phone_number VARCHAR(255),
  cmr_code VARCHAR(255),
  cmr_name VARCHAR(255),
  gort_order_date DATE,
  gort_document_date DATE,
  gort_delivery_date DATE,
  store_id VARCHAR(255),
  gort_invoice_number VARCHAR(255),
  gort_total_gst DECIMAL(10,2),
  gort_total_discount DECIMAL(10,2),
  gort_payment_status VARCHAR(50),
  gort_order_status VARCHAR(50),
  gort_transaction_id VARCHAR(255),
  gort_payment_method VARCHAR(50),
  gort_billing_address TEXT,
  gort_total_amount DECIMAL(10,2),
  gort_sub_total DECIMAL(10,2),
  remarks VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "good_order_receipt_items_list" (
  item_id VARCHAR(255),
  pot_id VARCHAR(255) ,
  gort_id VARCHAR(255) REFERENCES goods_order_receipt_table(gort_id),
  item_code VARCHAR(255),
  item_generic_name VARCHAR(255),
  item_name VARCHAR(255),
  item_pack_size VARCHAR(50),
  item_unit_price DECIMAL(10,2),
  item_uom VARCHAR(50),
  item_batch_number VARCHAR(50),
  item_quantity INT,
  item_received_quantity INT,
  item_to_be_received INT CHECK (item_to_be_received >= 0),
  item_return_open_quantity INT CHECK (item_return_open_quantity >= 0),
  item_exp_date DATE,
  base_ref_no VARCHAR(50),
  item_mfg_date DATE,
  item_rack_location VARCHAR(50),
  item_schedule VARCHAR(255),
  item_discount_amount DECIMAL(10,2),
  item_discount_percentage DECIMAL(10,2),
  item_tax_amount DECIMAL(10,2) ,
  item_total_tax_percentage DECIMAL(10,2),
  item_total_amount DECIMAL(10,2),
  item_gst  DECIMAL(10,2),
  item_sgst DECIMAL(10,2),
  item_cgst DECIMAL(10,2),
  item_igst DECIMAL(10,2),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "good_order_receipt_items_batches_list" (
  item_id VARCHAR(255),
  gort_id VARCHAR(255) REFERENCES goods_order_receipt_table(gort_id),
  item_batch_number VARCHAR(50),
  item_quantity INT,
  item_exp_date DATE,
  item_mfg_date DATE,
  item_sellable_quantity DECIMAL(10,2),
  item_non_sellable_quantity DECIMAL(10,2),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "goods_order_document_list" (
  gort_id VARCHAR(255),
  prt_id VARCHAR(255) UNIQUE,
  poit_id VARCHAR(255) UNIQUE,
  FOREIGN KEY (gort_id) REFERENCES goods_order_receipt_table(gort_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "general_accounts_table"(
  account_id VARCHAR(255) PRIMARY KEY,
  account_code  VARCHAR(255),
  account_name  VARCHAR(255),
  current_balance  DECIMAL(20,2),
  opening_balance  DECIMAL(20,2),
  cmr_open_balance DECIMAL(20,2) DEFAULT 0 ,
  main_group VARCHAR(255),
  account_status BOOLEAN DEFAULT FALSE,
  account_level INT,
  account_category VARCHAR(255),
  is_gl_account BOOLEAN DEFAULT FALSE ,
  account_type VARCHAR(255),
  parent_account_key VARCHAR(255),
  external_code VARCHAR(255),
  user_sign VARCHAR(255),
  is_directory BOOLEAN DEFAULT false,
  account_title BOOLEAN DEFAULT FALSE,
  is_file BOOLEAN DEFAULT FALSE,
  capital_account BOOLEAN DEFAULT FALSE,
  year_transfer BOOLEAN DEFAULT FALSE,
  is_transaction_account BOOLEAN DEFAULT FALSE,
  system_reconciliation_no  DECIMAL(20,2),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "journal_entry_table"(
  transcation_id VARCHAR(255) PRIMARY KEY,
  journal_entry_no VARCHAR(255),
  origin_id VARCHAR(255),
  origin_type VARCHAR(255),
  remarks VARCHAR(255),
  batch_num VARCHAR(255),
  user_sign VARCHAR(255),
  trans_curr VARCHAR(255),
  due_date DATE,
  document_date DATE,
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,
    `CREATE TABLE IF NOT EXISTS "journal_entry_rows_table"(
  account_id VARCHAR(255),
  transcation_id VARCHAR(255),
  debit_amount DECIMAL(20,2),
  credit_amount  DECIMAL(20,2),
  user_sign VARCHAR(255),
  remarks VARCHAR(255),
  FOREIGN KEY (transcation_id) REFERENCES journal_entry_table(transcation_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,
    `CREATE TABLE IF NOT EXISTS "general_account_allocation_table"(
gcct_id VARCHAR(255)  PRIMARY KEY,
period_category VARCHAR(255),
beginning_of_financial_year  VARCHAR(255),
financial_year DATE ,
posting_date_from DATE ,
posting_date_to DATE ,
due_date_from DATE ,
due_date_to DATE ,
document_date_from DATE ,
document_date_to  DATE ,
log_instance VARCHAR(255),
date_of_update DATE ,
user_signature VARCHAR(255),
domestic_accounts_receivable   VARCHAR(255),
checks_received   VARCHAR(255),
cash_on_hand  VARCHAR(255),
account_sales_tax_account  VARCHAR(255),
customers_deduction_at_source  VARCHAR(255),
credit_card_deposit_fee  VARCHAR(255),
purchase_tax  VARCHAR(255),
foreign_accounts_receivable  VARCHAR(255),
domestic_accounts_payable  VARCHAR(255),
foreign_accounts_payable  VARCHAR(255),
bank_transfer  VARCHAR(255),
tax_payable  VARCHAR(255),
tax_definition  VARCHAR(255),
equipment_and_assets  VARCHAR(255),
withholding_tax  VARCHAR(255),
advances_on_corp_income_tax  VARCHAR(255),
opening_balance_account  VARCHAR(255),
revenue_account  VARCHAR(255),
tax_exempt_revenue_account  VARCHAR(255),
expense_account  VARCHAR(255),
update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP

)`,

    `CREATE TABLE IF NOT EXISTS "sales_account_allocation_table"(
  gcct_id VARCHAR(255)  PRIMARY KEY,
  period_category VARCHAR(255),
  beginning_of_financial_year  VARCHAR(255),
  financial_year DATE ,
  posting_date_from DATE ,
  posting_date_to DATE ,
  due_date_from DATE ,
  due_date_to DATE ,
  document_date_from DATE ,
  document_date_to  DATE ,
  log_instance VARCHAR(255),
  date_of_update DATE ,
  user_signature VARCHAR(255),
  domestic_accounts_receivable   VARCHAR(255),
  checks_received   VARCHAR(255),
  cash_on_hand  VARCHAR(255),
  account_sales_tax_account  VARCHAR(255),
  customers_deduction_at_source  VARCHAR(255),
  credit_card_deposit_fee  VARCHAR(255),
  purchase_tax  VARCHAR(255),
  foreign_accounts_receivable  VARCHAR(255),
  domestic_accounts_payable  VARCHAR(255),
  foreign_accounts_payable  VARCHAR(255),
  bank_transfer  VARCHAR(255),
  tax_payable  VARCHAR(255),
  tax_definition  VARCHAR(255),
  equipment_and_assets  VARCHAR(255),
  withholding_tax  VARCHAR(255),
  advances_on_corp_income_tax  VARCHAR(255),
  opening_balance_account  VARCHAR(255),
  revenue_account  VARCHAR(255),
  tax_exempt_revenue_account  VARCHAR(255),
  expense_account  VARCHAR(255),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  
  )`,

    `CREATE TABLE IF NOT EXISTS "purchase_account_allocation_table"(
    gcct_id VARCHAR(255)  PRIMARY KEY,
    period_category VARCHAR(255),
    beginning_of_financial_year  VARCHAR(255),
    financial_year DATE ,
    posting_date_from DATE ,
    posting_date_to DATE ,
    due_date_from DATE ,
    due_date_to DATE ,
    document_date_from DATE ,
    document_date_to  DATE ,
    log_instance VARCHAR(255),
    date_of_update DATE ,
    user_signature VARCHAR(255),
    domestic_accounts_receivable   VARCHAR(255),
    checks_received   VARCHAR(255),
    cash_on_hand  VARCHAR(255),
    account_sales_tax_account  VARCHAR(255),
    customers_deduction_at_source  VARCHAR(255),
    credit_card_deposit_fee  VARCHAR(255),
    purchase_tax  VARCHAR(255),
    foreign_accounts_receivable  VARCHAR(255),
    domestic_accounts_payable  VARCHAR(255),
    foreign_accounts_payable  VARCHAR(255),
    bank_transfer  VARCHAR(255),
    tax_payable  VARCHAR(255),
    tax_definition  VARCHAR(255),
    equipment_and_assets  VARCHAR(255),
    withholding_tax  VARCHAR(255),
    advances_on_corp_income_tax  VARCHAR(255),
    opening_balance_account  VARCHAR(255),
    revenue_account  VARCHAR(255),
    tax_exempt_revenue_account  VARCHAR(255),
    expense_account  VARCHAR(255),
    update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    
    )`,

    `CREATE TABLE IF NOT EXISTS "inventory_account_allocation_table"(
      gcct_id VARCHAR(255)  PRIMARY KEY,
      period_category VARCHAR(255),
      user_signature VARCHAR(255),
      inventory_account   VARCHAR(255),
      cost_of_goods_sold_account VARCHAR(255),
      allocation_account VARCHAR(255),
      variance_account VARCHAR(255),
      price_differnce_account VARCHAR(255),
      negative_invetory_adj_acct VARCHAR(255),
      inventory_offset_decr_acct VARCHAR(255),
      inventory_offset_incr_acct VARCHAR(255),
      sales_returns_account VARCHAR(255),
      exhange_rate_differencee_account VARCHAR(255),
      goods_clearing_account VARCHAR(255),
      gl_decrease_account VARCHAR(255),
      gl_increase_account VARCHAR(255),
      wip_inventory_account VARCHAR(255),
      wip_inventory_variance VARCHAR(255),
      wip_offet_p_and_l_account VARCHAR(255),
      inventory_offset_p_and_Laccount VARCHAR(255),
      expense_clearing_account VARCHAR(255),
      stock_in_transit_account VARCHAR(255),
      shipped_goods_account VARCHAR(255),
      tax_account VARCHAR(255),
      update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_order_invoice_table" (
        soit_id VARCHAR(255) PRIMARY KEY,
        cmr_phone_number VARCHAR(255),
        cmr_code VARCHAR(255),
        cmr_name VARCHAR(255),
        cmr_id VARCHAR(255),
        soit_order_date DATE,
        soit_document_date DATE,
        soit_delivery_date DATE,
        store_id VARCHAR(255),
        soit_invoice_number VARCHAR(255),
        soit_total_gst DECIMAL(10,2),
        soit_total_discount DECIMAL(10,2),
        soit_payment_status VARCHAR(50),
        soit_order_status VARCHAR(50),
        soit_transaction_id VARCHAR(255),
        soit_payment_method VARCHAR(50),
        soit_billing_address TEXT,
        soit_sub_total DECIMAL(10,2),
        soit_due_amount DECIMAL(10,2),
        soit_total_amount DECIMAL(10,2),
        is_credit_note_created BOOLEAN DEFAULT FALSE,
        remarks VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_order_invoice_items_list"(
        item_id VARCHAR(255),
        soit_id VARCHAR(255) ,
        base_ref VARCHAR(255) ,
        sott_id   VARCHAR(255),
        sodtt_id  VARCHAR(255),
        item_code VARCHAR(255),
        item_generic_name VARCHAR(255),
        item_name VARCHAR(255),
        item_pack_size VARCHAR(50),
        item_unit_price DECIMAL(10,2),
        item_batch_number VARCHAR(50),
        item_quantity INT,
        item_credit_quanity_remaining INT CHECK (item_credit_quanity_remaining >= 0),
        item_due_amount DECIMAL(10,2),
        item_exp_date DATE,
        item_mfg_date DATE,
        item_rack_location VARCHAR(50),
        item_schedule VARCHAR(255),
        item_discount_amount DECIMAL(10,2),
        item_discount_percentage DECIMAL(10,2),
        item_tax_amount DECIMAL(10,2) ,
        item_total_tax_percentage DECIMAL(10,2),
        item_total_amount DECIMAL(10,2),
        item_gst  DECIMAL(10,2),
        item_sgst DECIMAL(10,2),
        item_cgst DECIMAL(10,2),
        item_igst DECIMAL(10,2),
        is_item_credit_note_created BOOLEAN DEFAULT FALSE,
        FOREIGN KEY (soit_id) REFERENCES sales_order_invoice_table(soit_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_order_invoice_items_batches_list" (
        item_id VARCHAR(255),
        soit_id VARCHAR(255) ,
        item_batch_number VARCHAR(50),
        item_batch_quantity INT,
        item_exp_date DATE,
        item_mfg_date DATE,
        FOREIGN KEY (soit_id) REFERENCES sales_order_invoice_table(soit_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_order_invoice_document_list" (
        soit_id VARCHAR(255) ,
        sct_id VARCHAR(255) UNIQUE,
        FOREIGN KEY (soit_id) REFERENCES sales_order_invoice_table(soit_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_return_table" (
        srt_id VARCHAR(255) PRIMARY KEY,
        cmr_phone_number VARCHAR(255),
        cmr_code VARCHAR(255),
        cmr_name VARCHAR(255),
        cmr_id VARCHAR(255),
        sort_order_date DATE,
        srt_document_date DATE,
        srt_delivery_date DATE,
        store_id VARCHAR(255),
        srt_invoice_number VARCHAR(255),
        srt_total_gst DECIMAL(10,2),
        srt_total_discount DECIMAL(10,2),
        srt_payment_status VARCHAR(50),
        srt_order_status VARCHAR(50),
        srt_transaction_id VARCHAR(255),
        srt_payment_method VARCHAR(50),
        srt_billing_address TEXT,
        srt_sub_total DECIMAL(10,2),
        srt_total_amount DECIMAL(10,2),
        remarks VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_return_items_list"(
        item_id VARCHAR(255),
        soit_id VARCHAR(255) ,
        base_ref VARCHAR(255) ,
        srt_id  VARCHAR(255),
        sott_id   VARCHAR(255),
        sodtt_id  VARCHAR(255),
        item_code VARCHAR(255),
        item_generic_name VARCHAR(255),
        item_name VARCHAR(255),
        item_pack_size VARCHAR(50),
        item_unit_price DECIMAL(10,2),
        item_batch_number VARCHAR(50),
        item_quantity INT,
        item_exp_date DATE,
        item_mfg_date DATE,
        item_rack_location VARCHAR(50),
        item_credit_quanity_remaining INT CHECK (item_credit_quanity_remaining >= 0),
        item_schedule VARCHAR(255),
        item_discount_amount DECIMAL(10,2),
        item_discount_percentage DECIMAL(10,2),
        item_tax_amount DECIMAL(10,2) ,
        item_total_tax_percentage DECIMAL(10,2),
        item_total_amount DECIMAL(10,2),
        item_gst  DECIMAL(10,2),
        item_sgst DECIMAL(10,2),
        item_cgst DECIMAL(10,2),
        item_igst DECIMAL(10,2),
        FOREIGN KEY (srt_id) REFERENCES sales_return_table(srt_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_return_items_batches_list" (
        item_id VARCHAR(255),
        srt_id VARCHAR(255) ,
        item_batch_number VARCHAR(50),
        item_batch_quantity INT,
        item_exp_date DATE,
        item_mfg_date DATE,
        FOREIGN KEY (srt_id) REFERENCES sales_return_table(srt_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_return_document_list" (
        srt_id VARCHAR(255) ,
        sct_id VARCHAR(255) UNIQUE,
        FOREIGN KEY (srt_id) REFERENCES sales_return_table(srt_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_credit_table" (
        sct_id VARCHAR(255) PRIMARY KEY,
        cmr_phone_number VARCHAR(255),
        cmr_code VARCHAR(255),
        cmr_name VARCHAR(255),
        cmr_id VARCHAR(255),
        sct_order_date DATE,
        sct_document_date DATE,
        sct_delivery_date DATE,
        store_id VARCHAR(255),
        sct_invoice_number VARCHAR(255),
        sct_total_gst DECIMAL(10,2),
        sct_total_discount DECIMAL(10,2),
        sct_payment_status VARCHAR(50),
        sct_order_status VARCHAR(50),
        sct_transaction_id VARCHAR(255),
        sct_payment_method VARCHAR(50),
        sct_billing_address TEXT,
        sct_sub_total DECIMAL(10,2),
        sct_total_amount DECIMAL(10,2),
        remarks VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_credit_items_list_table"(
        item_id VARCHAR(255),
        base_ref VARCHAR(255) ,
        sct_id  VARCHAR(255),
        srt_id VARCHAR(255),
        soit_id VARCHAR(255),
        item_code VARCHAR(255),
        item_generic_name VARCHAR(255),
        item_name VARCHAR(255),
        item_pack_size VARCHAR(50),
        item_unit_price DECIMAL(10,2),
        item_batch_number VARCHAR(50),
        item_quantity INT,
        item_credit_quantity INT,
        item_rack_location VARCHAR(50),
        item_schedule VARCHAR(255),
        item_discount_amount DECIMAL(10,2),
        item_discount_percentage DECIMAL(10,2),
        item_tax_amount DECIMAL(10,2) ,
        item_total_tax_percentage DECIMAL(10,2),
        item_total_amount DECIMAL(10,2),
        item_gst  DECIMAL(10,2),
        item_sgst DECIMAL(10,2),
        item_cgst DECIMAL(10,2),
        item_igst DECIMAL(10,2),
        FOREIGN KEY (sct_id) REFERENCES sales_credit_table(sct_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "sales_credit_items_batches_list" (
        item_id VARCHAR(255),
        sct_id VARCHAR(255) ,
        item_batch_number VARCHAR(50),
        item_batch_quantity INT,
        item_exp_date DATE,
        item_mfg_date DATE,
        FOREIGN KEY (sct_id) REFERENCES sales_credit_table(sct_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_order_invoice_table" (
        poit_id VARCHAR(255) PRIMARY KEY,
        cmr_phone_number VARCHAR(255),
        cmr_code VARCHAR(255),
        cmr_name VARCHAR(255),
        cmr_id VARCHAR(255),
        poit_order_date DATE,
        poit_document_date DATE,
        poit_delivery_date DATE,
        store_id VARCHAR(255),
        poit_invoice_number VARCHAR(255),
        poit_total_gst DECIMAL(10,2),
        poit_total_discount DECIMAL(10,2),
        poit_payment_status VARCHAR(50),
        poit_order_status VARCHAR(50),
        poit_transaction_id VARCHAR(255),
        poit_payment_method VARCHAR(50),
        poit_billing_address TEXT,
        poit_sub_total DECIMAL(10,2),
        poit_total_amount DECIMAL(10,2),
        poit_due_amount  DECIMAL(10,2),
        remarks VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_order_invoice_items_list"(
        item_id VARCHAR(255),
        poit_id VARCHAR(255) ,
        base_ref VARCHAR(255) ,
        pot_id   VARCHAR(255),
        gort_id  VARCHAR(255),
        item_code VARCHAR(255),
        item_generic_name VARCHAR(255),
        item_name VARCHAR(255),
        item_pack_size VARCHAR(50),
        item_unit_price DECIMAL(10,2),
        item_batch_number VARCHAR(50),
        item_quantity INT,
        item_credit_quanity_remaining INT CHECK (item_credit_quanity_remaining >= 0),
        item_exp_date DATE,
        item_mfg_date DATE,
        item_rack_location VARCHAR(50),
        item_schedule VARCHAR(255),
        item_discount_amount DECIMAL(10,2),
        item_discount_percentage DECIMAL(10,2),
        item_tax_amount DECIMAL(10,2) ,
        item_total_tax_percentage DECIMAL(10,2),
        item_total_amount DECIMAL(10,2),
        item_gst  DECIMAL(10,2),
        item_sgst DECIMAL(10,2),
        item_cgst DECIMAL(10,2),
        item_igst DECIMAL(10,2),
        FOREIGN KEY (poit_id) REFERENCES purchase_order_invoice_table(poit_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_order_invoice_document_list" (
  poit_id VARCHAR(255) ,
  pct_id VARCHAR(255) UNIQUE,
  FOREIGN KEY (poit_id) REFERENCES purchase_order_invoice_table(poit_id),
  update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
)`,

    `CREATE TABLE IF NOT EXISTS "purchase_order_invoice_items_batches_list" (
      item_id VARCHAR(255),
      poit_id VARCHAR(255),
      item_batch_number VARCHAR(50),
      item_quantity INT,
      item_exp_date DATE,
      item_mfg_date DATE,
      item_sellable_quantity DECIMAL(10,2),
      item_non_sellable_quantity DECIMAL(10,2),
      FOREIGN KEY (poit_id) REFERENCES purchase_order_invoice_table(poit_id),
      update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_return_table" (
        prt_id VARCHAR(255) PRIMARY KEY,
        cmr_phone_number VARCHAR(255),
        cmr_code VARCHAR(255),
        cmr_name VARCHAR(255),
        cmr_id VARCHAR(255),
        sort_order_date DATE,
         prt_document_date DATE,
         prt_delivery_date DATE,
        store_id VARCHAR(255),
         prt_invoice_number VARCHAR(255),
         prt_total_gst DECIMAL(10,2),
         prt_total_discount DECIMAL(10,2),
         prt_payment_status VARCHAR(50),
         prt_order_status VARCHAR(50),
         prt_transaction_id VARCHAR(255),
         prt_payment_method VARCHAR(50),
         prt_billing_address TEXT,
         prt_sub_total DECIMAL(10,2),
         prt_total_amount DECIMAL(10,2),
        remarks VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_return_items_list"(
        item_id VARCHAR(255),
        base_ref VARCHAR(255),
        prt_id  VARCHAR(255),
        item_code VARCHAR(255),
        gort_id VARCHAR(255),
        item_generic_name VARCHAR(255),
        item_name VARCHAR(255),
        item_pack_size VARCHAR(50),
        item_unit_price DECIMAL(10,2),
        item_batch_number VARCHAR(50),
        item_quantity INT,
        item_exp_date DATE,
        item_mfg_date DATE,
        item_credit_quanity_remaining INT CHECK (item_credit_quanity_remaining >= 0),
        item_rack_location VARCHAR(50),
        item_schedule VARCHAR(255),
        item_discount_amount DECIMAL(10,2),
        item_discount_percentage DECIMAL(10,2),
        item_tax_amount DECIMAL(10,2) ,
        item_total_tax_percentage DECIMAL(10,2),
        item_total_amount DECIMAL(10,2),
        item_gst  DECIMAL(10,2),
        item_sgst DECIMAL(10,2),
        item_cgst DECIMAL(10,2),
        item_igst DECIMAL(10,2),
        FOREIGN KEY (prt_id) REFERENCES purchase_return_table(prt_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_return_items_batches_list" (
        item_id VARCHAR(255),
        prt_id VARCHAR(255) ,
        item_batch_number VARCHAR(50),
        item_sellable_quantity DECIMAL(10,2),
        item_non_sellable_quantity DECIMAL(10,2),
        item_exp_date DATE,
        item_mfg_date DATE,
        FOREIGN KEY (prt_id) REFERENCES purchase_return_table(prt_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_return_document_list" (
        prt_id VARCHAR(255) ,
        pct_id VARCHAR(255) UNIQUE,
        FOREIGN KEY (prt_id) REFERENCES purchase_return_table (prt_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_credit_table" (
        pct_id VARCHAR(255) PRIMARY KEY,
        cmr_phone_number VARCHAR(255),
        cmr_code VARCHAR(255),
        cmr_name VARCHAR(255),
        cmr_id VARCHAR(255),
        pct_order_date DATE,
        pct_document_date DATE,
        pct_delivery_date DATE,
        store_id VARCHAR(255),
         pct_invoice_number VARCHAR(255),
         pct_total_gst DECIMAL(10,2),
         pct_total_discount DECIMAL(10,2),
         pct_payment_status VARCHAR(50),
         pct_order_status VARCHAR(50),
         pct_transaction_id VARCHAR(255),
         pct_payment_method VARCHAR(50),
         pct_billing_address TEXT,
         pct_sub_total DECIMAL(10,2),
         pct_total_amount DECIMAL(10,2),
        remarks VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_credit_items_list_table"(
        item_id VARCHAR(255),
        base_ref VARCHAR(255) ,
        pct_id  VARCHAR(255),
        prt_id VARCHAR(255),
        poit_id VARCHAR(255),
        item_code VARCHAR(255),
        item_generic_name VARCHAR(255),
        item_name VARCHAR(255),
        item_pack_size VARCHAR(50),
        item_unit_price DECIMAL(10,2),
        item_batch_number VARCHAR(50),
        item_quantity INT,
        item_credit_quantity INT,
        item_rack_location VARCHAR(50),
        item_schedule VARCHAR(255),
        item_discount_amount DECIMAL(10,2),
        item_discount_percentage DECIMAL(10,2),
        item_tax_amount DECIMAL(10,2) ,
        item_total_tax_percentage DECIMAL(10,2),
        item_total_amount DECIMAL(10,2),
        item_gst  DECIMAL(10,2),
        item_sgst DECIMAL(10,2),
        item_cgst DECIMAL(10,2),
        item_igst DECIMAL(10,2),
        FOREIGN KEY ( pct_id) REFERENCES purchase_credit_table( pct_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "purchase_credit_items_batches_list" (
        item_id VARCHAR(255),
        pct_id VARCHAR(255) ,
        item_batch_number VARCHAR(50),
        item_sellable_quantity DECIMAL(10,2),
        item_non_sellable_quantity DECIMAL(10,2),
        item_exp_date DATE,
        item_mfg_date DATE,
        FOREIGN KEY ( pct_id) REFERENCES purchase_credit_table( pct_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "document_table" (
        transaction_doc_id VARCHAR(255) PRIMARY KEY ,
        transaction_document_name VARCHAR(255),
        current_document_number INT DEFAULT 0,
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "document_numbering_series_table" (
        series_id VARCHAR(255) PRIMARY KEY,
        series_name VARCHAR(255),
        series_prefix VARCHAR(255),
        series_suffix VARCHAR(255),
        series_first_digit VARCHAR(255),
        series_last_digit  VARCHAR(255),
        series_separator VARCHAR(255),
        series_default BOOLEAN DEFAULT FALSE,
        series_increment INT,
        series_include_year BOOLEAN DEFAULT FALSE,
        series_include_month BOOLEAN DEFAULT FALSE,
        series_include_date BOOLEAN DEFAULT FALSE,
        series_leading_spaces INT DEFAULT 0,
        series_fyi_year VARCHAR(255),
        transaction_doc_id VARCHAR(255),
        FOREIGN KEY (transaction_doc_id) REFERENCES document_table (transaction_doc_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "payment_in_table" (
        pit_id VARCHAR(255) PRIMARY KEY ,
        cmr_id VARCHAR(255),
        cmr_name VARCHAR(255),
        cmr_code  VARCHAR(255),
        pit_posting_date DATE,
        pit_invoice_number VARCHAR(255),
        pit_order_status  VARCHAR(255),
        pit_due_date DATE,
        pit_doc_date DATE,
        pit_remarks  VARCHAR(500),
        pit_total_amount DECIMAL(10,2),
        pit_current_payment DECIMAL(10,2),
        pit_add_to_account_amount  DECIMAL(10,2),
        pit_open_balance DECIMAL(10,2),
        payment_journal_remarks VARCHAR(500),
        pit_applied_amount  DECIMAL(10,2),
        pit_cmr_amount_paid DECIMAL(10,2),
        update_sign   VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "payment_in_document_list_table" (
        soit_id VARCHAR(255),
        soit_invoice_number VARCHAR(255),
        pit_id VARCHAR(255),
        pdt_due_days INT,
        pdt_balance_due DECIMAL(10,2),
        pdt_total_amount DECIMAL(10,2),
        pdt_current_payment DECIMAL(10,2),
        pdt_doc_date DATE,
        pdt_due_date DATE,
        update_sign  VARCHAR(255),
        FOREIGN KEY (pit_id) REFERENCES payment_in_table (pit_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "payment_modes_table" (
        pmt_id VARCHAR(255) PRIMARY KEY,
        pit_id VARCHAR(255),
        pmt_mode_name VARCHAR(255),
        account_id VARCHAR(255) ,
        account_code  VARCHAR(255),
        account_name VARCHAR(255),
        pmt_total_amount  DECIMAL(10,2),
        bank_reference_number VARCHAR(255) ,
        date_of_transfer DATE,
        payment_id VARCHAR(255) , 
        card_number VARCHAR(255) ,
        expiry_date DATE,
        cheque_number VARCHAR(255) ,
        date_of_cheque DATE,
        upi_referernce VARCHAR(255),
        update_sign VARCHAR(255),
        FOREIGN KEY (pit_id) REFERENCES payment_in_table (pit_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "payment_out_table" (
       pot_id VARCHAR(255) PRIMARY KEY ,
       cmr_id VARCHAR(255),
       cmr_name VARCHAR(255),
       cmr_code  VARCHAR(255),
       pot_posting_date DATE,
       pot_invoice_number VARCHAR(255),
       pot_order_status  VARCHAR(255),
       pot_due_date DATE,
       pot_doc_date DATE,
       pot_remarks  VARCHAR(500),
       pot_total_amount DECIMAL(10,2),
       pot_current_payment DECIMAL(10,2),
       pot_add_to_account_amount  DECIMAL(10,2),
       payment_journal_remarks VARCHAR(500),
       pot_applied_amount  DECIMAL(10,2),
       pot_cmr_amount_paid DECIMAL(10,2),
       pot_open_balance DECIMAL(10,2),
       update_sign   VARCHAR(255),
       update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
       created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "payment_out_document_list_table" (
        poit_id VARCHAR(255) PRIMARY KEY ,
        poit_invoice_number VARCHAR(255) ,
        pot_id VARCHAR(255) ,
        podt_due_days INT,
        podt_balance_due DECIMAL(10,2),
        podt_total_amount DECIMAL(10,2),
        podt_current_payment DECIMAL(10,2),
        podt_doc_date DATE,
        podt_due_date DATE,
        update_sign VARCHAR(255),
        FOREIGN KEY (pot_id) REFERENCES payment_out_table (pot_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "payment_out_modes_table" (
        pmt_id VARCHAR(255) PRIMARY KEY,
        pot_id VARCHAR(255),
        pmt_mode_name VARCHAR(255),
        account_id VARCHAR(255) ,
        account_code  VARCHAR(255),
        account_name VARCHAR(255),
        pmt_total_amount  DECIMAL(10,2),
        update_sign  VARCHAR(255),
        FOREIGN KEY (pot_id) REFERENCES payment_out_table (pot_id),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "inventory_transfer_table" (
        itt_id VARCHAR(255) PRIMARY KEY,
        warehouse_id VARCHAR(255),
        warehouse_name VARCHAR(255),
        transfer_date VARCHAR(255) ,
        stock_management_action VARCHAR(255) ,
        posting_date  VARCHAR(255),
        from_warehouse_id VARCHAR(255),
        from_warehouse_name  VARCHAR(255),
        to_warehouse_id  VARCHAR(255),
        to_warehouse_name  VARCHAR(255),
        stock_transfer_doc_number VARCHAR(255),
        stock_transfer_reason VARCHAR(255),
        is_stock_in_void_able BOOLEAN DEFAULT TRUE,
        update_sign  VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "inventory_transfer_rows_table" (
        itrt_id  VARCHAR(255)PRIMARY KEY,
        itt_id VARCHAR(255),
        item_id VARCHAR(255),
        item_code VARCHAR(255),
        item_name VARCHAR(255),
        from_bin_location VARCHAR(255),
        to_bin_location VARCHAR(255),
        from_warehouse_id VARCHAR(255),
        from_warehouse_name  VARCHAR(255),
        to_warehouse_id  VARCHAR(255),
        to_warehouse_name  VARCHAR(255),
        item_uom_source VARCHAR(255),
        item_uom_destination VARCHAR(255),
        item_uom VARCHAR(255),
        item_quantity_used BIGINT,
        item_quantity INT,
        is_item_void_able BOOLEAN DEFAULT TRUE,
        FOREIGN KEY (itt_id) REFERENCES inventory_transfer_table (itt_id),
        update_sign  VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

    `CREATE TABLE IF NOT EXISTS "inventory_transfer_item_batches_table" (
      itt_id VARCHAR(255),
      item_id VARCHAR(255),
      item_batch_number VARCHAR(255),
      from_bin_location VARCHAR(255),
      to_bin_location VARCHAR(255),
      from_warehouse_id VARCHAR(255),
      from_warehouse_name  VARCHAR(255),
      to_warehouse_id  VARCHAR(255),
      to_warehouse_name  VARCHAR(255),
      to_bin_id VARCHAR(255),
      from_bin_id VARCHAR(255),
      item_batch_quantity INT,
      update_sign  VARCHAR(255),
      FOREIGN KEY (itt_id) REFERENCES inventory_transfer_table (itt_id),
      update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    )`,

    `CREATE TABLE IF NOT EXISTS "all_store_details_table" (
        warehouse_id  VARCHAR(255) PRIMARY KEY,
        warehouse_name  VARCHAR(255),
        warehouse_IP_address VARCHAR(255),
        warehouse_addresss VARCHAR(255),
        update_sign  VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

      `CREATE TABLE IF NOT EXISTS "payment_type_table" (
        payment_type_id VARCHAR(36) PRIMARY KEY,
        store_id VARCHAR(36),
        payment_type VARCHAR(255),
        mid VARCHAR(255),
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,

      `CREATE TABLE IF NOT EXISTS "Favorite" (
        name VARCHAR(36) PRIMARY KEY,
        query text ,
        selectedColumns TEXT[],
        update_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        created_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
      )`,


 

      `DO $$
BEGIN
    -- Check if the column 'is_stock_in_void_able' exists in the 'inventory_transfer_table'
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_table' 
        AND column_name = 'is_stock_in_void_able'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE inventory_transfer_table 
        ADD COLUMN  is_stock_in_void_able BOOLEAN DEFAULT TRUE;
    END IF;

    -- Check if the column 'item_quantity_used' exists in the 'inventory_transfer_rows_table'
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_rows_table' 
        AND column_name = 'item_quantity_used'
    ) THEN
        -- Add the 'item_quantity_used' column with BIGINT type
        ALTER TABLE inventory_transfer_rows_table 
        ADD COLUMN  item_quantity_used BIGINT  DEFAULT 0 ;
    END IF;
     
    -- Check if the column 'is_stock_in_void_able' exists in the 'inventory_transfer_rows_table'
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_rows_table' 
        AND column_name = 'is_item_void_able'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE inventory_transfer_rows_table 
        ADD COLUMN  is_item_void_able BOOLEAN DEFAULT TRUE;
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE inventory_transfer_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'users_table' 
        AND column_name = 'pos_id'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE users_table 
        ADD COLUMN  pos_id VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_table' 
        AND column_name = 'stock_transfer_status'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE inventory_transfer_table 
       ADD COLUMN stock_transfer_status VARCHAR(255) DEFAULT 'success';
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_table' 
        AND column_name = 'stock_transfer_parent_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE inventory_transfer_table 
        ADD COLUMN  stock_transfer_parent_id VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_rows_table' 
        AND column_name = 'item_void_status'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE inventory_transfer_rows_table 
        ADD COLUMN  item_void_status VARCHAR(255) DEFAULT 'success';
    END IF;
    

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_rows_table' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE inventory_transfer_rows_table 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

     IF EXISTS (
        SELECT 1 
        FROM pg_constraint
        WHERE conname = 'unique_item_batch_location' 
        AND conrelid = 'store_inventory_item_location_table'::regclass
    ) THEN
        ALTER TABLE store_inventory_item_location_table 
        DROP CONSTRAINT unique_item_batch_location;
    END IF;

    

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sales_order_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_transaction_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE sales_order_transaction_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_transaction_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE purchase_order_transaction_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

             IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_delivery_transaction_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE sales_order_delivery_transaction_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;


IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sale_order_delivery_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

                 IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE sales_order_invoice_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;
   

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE sales_return_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

    
   
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE sales_credit_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;
    

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'goods_order_receipt_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE goods_order_receipt_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE purchase_order_invoice_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

    

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE purchase_return_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;
    

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE purchase_credit_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;
    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'journal_entry_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE journal_entry_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;
    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'general_accounts_table' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE general_accounts_table 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;
   
    
    

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sales_order_invoice_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sales_order_invoice_items_list 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;

       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sale_order_delivery_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sale_order_delivery_items_list 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;


      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sales_return_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_list' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sales_return_items_list 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sales_credit_items_list_table 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE sales_credit_items_list_table 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;


      
        IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_order_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_order_items_list 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;

          IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE good_order_receipt_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_list' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE good_order_receipt_items_list 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_order_invoice_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_list' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_order_invoice_items_list 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;
    

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_return_items_list 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_list' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_return_items_list 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_list_table' 
        AND column_name = 'item_uom_id'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_credit_items_list_table 
        ADD COLUMN  item_uom_id VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_list_table' 
        AND column_name = 'item_uom'
    ) THEN
        -- Add the 'is_stock_in_void_able' column with BOOLEAN type and default value
        ALTER TABLE purchase_credit_items_list_table 
        ADD COLUMN  item_uom VARCHAR(255);
    END IF;
    
    

END $$;
`,
`DO $$
BEGIN
    -- Check if the column 'sot_remarks' exists in the 'sales_order' table
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order' 
        AND column_name = 'sot_remarks'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE sales_order 
        ADD COLUMN sot_remarks VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'order_items_list' 
        AND column_name = 'stock_in_itt_id'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE order_items_list 
        ADD COLUMN stock_in_itt_id VARCHAR(255);
    END IF;
    
      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'customer_details' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE customer_details 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order' 
        AND column_name = 'data_synced'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE sales_order 
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;

    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'from_bin_location'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE good_order_receipt_items_batches_list 
        ADD COLUMN from_bin_location VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'from_bin_id'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE good_order_receipt_items_batches_list 
        ADD COLUMN from_bin_id VARCHAR(255);
    END IF;


         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'to_bin_id'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE good_order_receipt_items_batches_list 
        ADD COLUMN to_bin_id VARCHAR(255);
    END IF;

       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'to_bin_location'
    ) THEN
        -- Add the 'sot_remarks' column with a VARCHAR type and specified length
        ALTER TABLE good_order_receipt_items_batches_list 
        ADD COLUMN to_bin_location VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_preferred_vendor_id'
    ) THEN
        -- Add the 'item_purchasing_table' column with a VARCHAR type and specified length
        ALTER TABLE item_purchasing_table 
        ADD COLUMN item_pur_preferred_vendor_id VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_uom_name_id'
    ) THEN
        -- Add the 'item_purchasing_table' column with a VARCHAR type and specified length
        ALTER TABLE item_sales_table 
        ADD COLUMN   item_sales_uom_name_id VARCHAR(255);
    END IF;

     IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'items_table' 
        AND column_name = 'item_unit_price') != 'DECIMAL(10,2)' THEN
        ALTER TABLE items_table
        ALTER COLUMN item_unit_price SET DATA TYPE DECIMAL(10,2);
    END IF;

    


       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_purchasing_uom_name_id'
    ) THEN
        -- Add the 'item_purchasing_table' column with a VARCHAR type and specified length
        ALTER TABLE item_purchasing_table 
        ADD COLUMN item_pur_purchasing_uom_name_id VARCHAR(255);
    END IF;
    

       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'store_information_for_user_table' 
        AND column_name = 'company_logo'
    ) THEN
        -- Add the 'item_purchasing_table' column with a VARCHAR type and specified length
        ALTER TABLE store_information_for_user_table 
        ADD COLUMN company_logo VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'store_information_for_user_table' 
        AND column_name = 'pos_id'
    ) THEN
        -- Add the 'item_purchasing_table' column with a VARCHAR type and specified length
        ALTER TABLE store_information_for_user_table 
        ADD COLUMN pos_id VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'items_batch_no_table' 
        AND column_name = 'item_batch_id'
    ) THEN
        -- Add the 'item_purchasing_table' column with a VARCHAR type and specified length
        ALTER TABLE items_batch_no_table 
        ADD COLUMN item_batch_id VARCHAR(255);
    END IF;

    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'invoice_credit_note_item_list' 
        AND column_name = 'item_price_wiithout_tax') != 'DECIMAL(10,2)' THEN
        ALTER TABLE invoice_credit_note_item_list
        ALTER COLUMN item_price_wiithout_tax SET DATA TYPE DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'invoice_credit_note' 
        AND column_name = 'icn_remarks'
    ) THEN
        -- Add the 'icn_remarks' column with a VARCHAR type and specified length
        ALTER TABLE invoice_credit_note 
        ADD COLUMN icn_remarks VARCHAR(255);
    END IF;

    
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'price_list_table' 
        AND column_name = 'default_price_list'
    ) THEN
        ALTER TABLE price_list_table 
        ADD COLUMN default_price_list BOOLEAN DEFAULT FALSE;
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'store_information_for_user_table' 
        AND column_name = 'cpos_ip_address'
    ) THEN
        ALTER TABLE  store_information_for_user_table
        ADD COLUMN cpos_ip_address VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_purchase_rate'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_purchase_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  good_order_receipt_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'order_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  order_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;

    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'invoice_credit_note_item_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  invoice_credit_note_item_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'price_list_items_table' 
        AND column_name = 'item_batch_number'
    ) THEN
        ALTER TABLE  price_list_items_table
        ADD COLUMN item_batch_number VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'price_list_items_table' 
        AND column_name = 'item_batch_final_purchase_rate'
    ) THEN
        ALTER TABLE  price_list_items_table
        ADD COLUMN item_batch_final_purchase_rate  DECIMAL(10,2);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'price_list_items_table' 
        AND column_name = 'item_mrp_price'
    ) THEN
        ALTER TABLE  price_list_items_table
        ADD COLUMN item_mrp_price  DECIMAL(10,2);
    END IF;

    



     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'price_list_table' 
        AND column_name = 'margin_factor'
    ) THEN
        ALTER TABLE  price_list_table
        ADD COLUMN  margin_factor DECIMAL(10,2);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'period_volume_discount_items_table' 
        AND column_name = 'item_batch_number'
    ) THEN
        ALTER TABLE  period_volume_discount_items_table
        ADD COLUMN item_batch_number VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_purchase_rate'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_purchase_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_item_batches_table' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  inventory_transfer_item_batches_table
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_item_batches_table' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  inventory_transfer_item_batches_table
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_item_batches_table' 
        AND column_name = 'item_batch_purchase_rate'
    ) THEN
        ALTER TABLE  inventory_transfer_item_batches_table
        ADD COLUMN item_batch_purchase_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'inventory_transfer_rows_table' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  inventory_transfer_rows_table
        ADD COLUMN item_free_quantity BIGINT;
    END IF;

    

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_purchase_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;



     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_purchase_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  purchase_return_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;



     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_purchase_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_list_table' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  purchase_credit_items_list_table
        ADD COLUMN item_free_quantity BIGINT;
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_final_purchase_rate'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_final_purchase_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_batch_total_purchase_rate'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_batch_total_purchase_rate DECIMAL(10,2);
    END IF;


    


      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_final_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_final_purchase_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_total_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN item_batch_total_purchase_rate DECIMAL(10,2);
    END IF;







      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_final_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_final_purchase_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'item_batch_total_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN item_batch_total_purchase_rate DECIMAL(10,2);
    END IF;










       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_final_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_final_purchase_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'item_batch_total_purchase_rate'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN item_batch_total_purchase_rate DECIMAL(10,2);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_list_table' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  purchase_credit_items_list_table
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_list_table' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  purchase_credit_items_list_table
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_list_table' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  purchase_credit_items_list_table
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;

    


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'to_bin_location'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN to_bin_location  VARCHAR(255);
    END IF;

    
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_credit_items_batches_list' 
        AND column_name = 'to_bin_id'
    ) THEN
        ALTER TABLE  purchase_credit_items_batches_list
        ADD COLUMN to_bin_id  VARCHAR(255);
    END IF;
    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  purchase_return_items_list
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  purchase_return_items_list
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  purchase_return_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'to_bin_location'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN to_bin_location  VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_return_items_batches_list' 
        AND column_name = 'to_bin_id'
    ) THEN
        ALTER TABLE  purchase_return_items_batches_list
        ADD COLUMN to_bin_id  VARCHAR(255);
    END IF;
    
    




       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_list
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_list
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;

    

 IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  good_order_receipt_items_list

        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  good_order_receipt_items_list

        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  good_order_receipt_items_list

        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_list' 
        AND column_name = 'prt_id'
    ) THEN
        ALTER TABLE  good_order_receipt_items_list

        ADD COLUMN prt_id  VARCHAR(255);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'goods_order_receipt_table' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  goods_order_receipt_table

        ADD COLUMN pos_id  VARCHAR(255);
    END IF;




    

    


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'to_bin_location'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN to_bin_location  VARCHAR(255);
    END IF;

    

    
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'to_bin_id'
    ) THEN
        ALTER TABLE  purchase_order_invoice_items_batches_list
        ADD COLUMN to_bin_id  VARCHAR(255);
    END IF;
    
    

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'prt_id'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN prt_id VARCHAR(255);
    END IF;










     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'from_bin_location'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN from_bin_location  VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'from_bin_id'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN from_bin_id  VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;
    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_final_sales_rate'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_final_sales_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_total_sales_rate'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_total_sales_rate DECIMAL(10,2);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_sales_rate'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_sales_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;
    

             IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_list
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_list
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;









    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'from_bin_location'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN from_bin_location  VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'from_bin_id'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN from_bin_id  VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;
    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_final_sales_rate'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_final_sales_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_total_sales_rate'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_total_sales_rate DECIMAL(10,2);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_sales_rate'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_sales_rate DECIMAL(10,2);
    END IF;


    
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;
    

             IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_list
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_list
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;






    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'from_bin_location'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN from_bin_location  VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'from_bin_id'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN from_bin_id  VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;
    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_final_sales_rate'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_final_sales_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_total_sales_rate'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_total_sales_rate DECIMAL(10,2);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_sales_rate'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_sales_rate DECIMAL(10,2);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  sales_credit_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_free_quantity BIGINT;
    END IF;
    

             IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;




        IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'from_bin_location'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN from_bin_location  VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'from_bin_id'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN from_bin_id  VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_free_quantity'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_free_quantity BIGINT;
    END IF;
    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_discount_amount'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_discount_amount DECIMAL(10,2);
    END IF;

         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_discount_percentage'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_discount_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_tax_percentage'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_tax_percentage DECIMAL(10,2);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_tax_amount'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_tax_amount DECIMAL(10,2);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_final_sales_rate'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_final_sales_rate DECIMAL(10,2);
    END IF;
      

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_total_sales_rate'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_total_sales_rate DECIMAL(10,2);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_sales_rate'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_sales_rate DECIMAL(10,2);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_batches_list' 
        AND column_name = 'item_batch_unit_price'
    ) THEN
        ALTER TABLE  sales_return_items_batches_list
        ADD COLUMN item_batch_unit_price DECIMAL(10,2);
    END IF;




       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_list' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  sales_return_items_list
        ADD COLUMN item_free_quantity BIGINT;
    END IF;
    

             IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  sales_return_items_list
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  sales_return_items_list
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_return_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  sales_return_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;



     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_free_quantity'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_free_quantity BIGINT;
    END IF;
    

             IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_credit_items_list_table' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  sales_credit_items_list_table
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;



        IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  purchase_order_items_list
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  purchase_order_items_list
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  purchase_order_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;

       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'order_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  order_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;
   

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'invoice_credit_note_item_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  invoice_credit_note_item_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;

      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_return_availability'
    ) THEN
        ALTER TABLE  purchase_order_items_list
        ADD COLUMN item_return_availability  VARCHAR(255);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_maximum_purchasing'
    ) THEN
        ALTER TABLE  purchase_order_items_list
        ADD COLUMN item_maximum_purchasing  VARCHAR(255);
    END IF;


    
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_items_list' 
        AND column_name = 'item_minimun_purchasing'
    ) THEN
        ALTER TABLE  purchase_order_items_list
        ADD COLUMN item_minimun_purchasing  VARCHAR(255);
    END IF;





    
      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_return_availability'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN item_return_availability  VARCHAR(255);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_maximum_purchasing'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN item_maximum_purchasing  VARCHAR(255);
    END IF;


    
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_minimun_purchasing'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN item_minimun_purchasing  VARCHAR(255);
    END IF;


      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_requested_quantity'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN item_requested_quantity BIGINT;
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'pot_id'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN pot_id VARCHAR(255);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_transaction_table' 
        AND column_name = 'pot_id'
    ) THEN
        ALTER TABLE  sales_order_transaction_table
        ADD COLUMN pot_id VARCHAR(255);
    END IF;


    
    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_transaction_table' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  sales_order_transaction_table
        ADD COLUMN pos_id VARCHAR(255);
    END IF;


                 IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN item_manufacturer_name  VARCHAR(255);
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN item_manufacturer_id  VARCHAR(255);
    END IF;



    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'item_hsn'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN item_hsn  VARCHAR(255);
    END IF;




      IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_items_list' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  sales_order_items_list
        ADD COLUMN pos_id VARCHAR(255);
    END IF;

    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_delivery_transaction_table' 
        AND column_name = 'pot_id'
    ) THEN
        ALTER TABLE  sales_order_delivery_transaction_table
        ADD COLUMN pot_id VARCHAR(255);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_delivery_transaction_table' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  sales_order_delivery_transaction_table
        ADD COLUMN pos_id VARCHAR(255);
    END IF;





     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'pot_id'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_list
        ADD COLUMN pot_id VARCHAR(255);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_list
        ADD COLUMN pos_id VARCHAR(255);
    END IF;




         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_table' 
        AND column_name = 'pot_id'
    ) THEN
        ALTER TABLE  sales_order_invoice_table
        ADD COLUMN pot_id VARCHAR(255);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_table' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  sales_order_invoice_table
        ADD COLUMN pos_id VARCHAR(255);
    END IF;


    
         IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'pot_id'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_list
        ADD COLUMN pot_id VARCHAR(255);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sales_order_invoice_items_list' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  sales_order_invoice_items_list
        ADD COLUMN pos_id VARCHAR(255);
    END IF;


    
       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'sale_order_delivery_items_list' 
        AND column_name = 'srt_id'
    ) THEN
        ALTER TABLE  sale_order_delivery_items_list
        ADD COLUMN srt_id VARCHAR(255);
    END IF;



     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'invoice_credit_note' 
        AND column_name = 'data_synced'
    ) THEN
        ALTER TABLE  invoice_credit_note
        ADD COLUMN data_synced BOOLEAN DEFAULT FALSE;
    END IF;


           IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'invoice_credit_note_item_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  invoice_credit_note_item_list
        ADD COLUMN item_manufacturer_id VARCHAR(255);
    END IF;

       IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'invoice_credit_note_item_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  invoice_credit_note_item_list
        ADD COLUMN item_manufacturer_name VARCHAR(255);
    END IF;

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'order_items_list' 
        AND column_name = 'item_manufacturer_id'
    ) THEN
        ALTER TABLE  order_items_list
        ADD COLUMN item_manufacturer_id VARCHAR(255);
    END IF;


     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'order_items_list' 
        AND column_name = 'item_manufacturer_name'
    ) THEN
        ALTER TABLE  order_items_list
        ADD COLUMN item_manufacturer_name VARCHAR(255);
    END IF;


    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_table' 
        AND column_name = 'pos_id'
    ) THEN
        ALTER TABLE  purchase_order_invoice_table
        ADD COLUMN pos_id VARCHAR(255);
    END IF;




IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'customer_details' 
        AND column_name = 'inter_company_sync'
    ) THEN
        ALTER TABLE  customer_details
        ADD COLUMN inter_company_sync BOOLEAN DEFAULT FALSE;
    END IF;
      
    

    IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'price_list_table' 
        AND column_name = 'is_margin_percentage'
    ) THEN
        ALTER TABLE  price_list_table
        ADD COLUMN is_margin_percentage BOOLEAN DEFAULT FALSE;
    END IF;

  IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'store_information_for_user_table' 
        AND column_name = 'store_code'
    ) THEN
        ALTER TABLE  store_information_for_user_table
        ADD COLUMN store_code VARCHAR(255);
    END IF;

    

     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'price_list_items_table' 
        AND column_name = 'item_pricing_uom_id'
    ) THEN
        ALTER TABLE  price_list_items_table
        ADD COLUMN item_pricing_uom_id VARCHAR(255);
    END IF;

            IF EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_quantity'
    ) THEN
        -- Drop the 'item_quantity' column
        ALTER TABLE good_order_receipt_items_batches_list 
        DROP COLUMN item_quantity;
    END IF;

     IF EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'purchase_order_invoice_items_batches_list' 
        AND column_name = 'item_quantity'
    ) THEN
        -- Drop the 'item_quantity' column
        ALTER TABLE purchase_order_invoice_items_batches_list 
        DROP COLUMN item_quantity;
    END IF;



    
    

    
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_uom_id'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_uom_id VARCHAR(255);
    END IF;


      
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'good_order_receipt_items_batches_list' 
        AND column_name = 'item_uom'
    ) THEN
        ALTER TABLE  good_order_receipt_items_batches_list
        ADD COLUMN item_uom VARCHAR(255);
    END IF;



  
     IF NOT EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_name = 'order_items_list' 
        AND column_name = 'item_open_free_quantity'
    ) THEN
        ALTER TABLE  order_items_list
        ADD COLUMN item_open_free_quantity BIGINT;
    END IF;
    
END $$;




`,




`DO $$
BEGIN
    -- Check and alter 'sot_total_gst' column
    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_per_purchasing_unit') != 'VARCHAR(255)' THEN
        ALTER TABLE item_purchasing_table
        ALTER COLUMN item_pur_per_purchasing_unit SET DATA TYPE VARCHAR(255);
    END IF;

    -- Check and alter 'sot_total_discount' column
 IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_quantity_per_package') != 'VARCHAR(255)' THEN
        ALTER TABLE item_purchasing_table
        ALTER COLUMN item_pur_quantity_per_package SET DATA TYPE VARCHAR(255);
    END IF;

    -- Check and alter 'sot_total_amount' column
 IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_length') != 'VARCHAR(255)' THEN
        ALTER TABLE item_purchasing_table
        ALTER COLUMN item_pur_length SET DATA TYPE VARCHAR(255);
    END IF;

        -- Check and alter 'sot_total_amount' column
 IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_width') != 'VARCHAR(255)' THEN
        ALTER TABLE item_purchasing_table
        ALTER COLUMN item_pur_width SET DATA TYPE VARCHAR(255);
    END IF;
 IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_height') != 'VARCHAR(255)' THEN
        ALTER TABLE item_purchasing_table
        ALTER COLUMN item_pur_height SET DATA TYPE VARCHAR(255);
    END IF;

 IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_volume') != 'VARCHAR(255)' THEN
        ALTER TABLE item_purchasing_table
        ALTER COLUMN item_pur_volume SET DATA TYPE VARCHAR(255);
    END IF;
   IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_purchasing_table' 
        AND column_name = 'item_pur_weight') != 'VARCHAR(255)' THEN
        ALTER TABLE item_purchasing_table
        ALTER COLUMN item_pur_weight SET DATA TYPE VARCHAR(255);
    END IF;
       IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_quantity_per_package') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_sales_quantity_per_package SET DATA TYPE VARCHAR(255);
    END IF;

    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_per_sales_unit') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_per_sales_unit SET DATA TYPE VARCHAR(255);
    END IF;

    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_per_sales_unit') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_per_sales_unit SET DATA TYPE VARCHAR(255);
    END IF;

    
    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_quantity_per_package') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_sales_quantity_per_package SET DATA TYPE VARCHAR(255);
    END IF;
    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_length') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_sales_length SET DATA TYPE VARCHAR(255);
    END IF;

      IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_width') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_sales_width SET DATA TYPE VARCHAR(255);
    END IF;

     IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_height') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_sales_height SET DATA TYPE VARCHAR(255);
    END IF;

    
     IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_weight') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_sales_weight SET DATA TYPE VARCHAR(255);
    END IF;

    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_sales_table' 
        AND column_name = 'item_sales_volume') != 'VARCHAR(255)' THEN
        ALTER TABLE item_sales_table
        ALTER COLUMN item_sales_volume SET DATA TYPE VARCHAR(255);
    END IF;

     IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_planning_table' 
        AND column_name = 'item_order_interval') != 'VARCHAR(255)' THEN
        ALTER TABLE item_planning_table
        ALTER COLUMN item_order_interval SET DATA TYPE VARCHAR(255);
    END IF;

       IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_planning_table' 
        AND column_name = 'item_order_multiple') != 'VARCHAR(255)' THEN
        ALTER TABLE item_planning_table
        ALTER COLUMN item_order_multiple SET DATA TYPE VARCHAR(255);
    END IF;

       IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_planning_table' 
        AND column_name = 'item_minimum_order_quantity') != 'VARCHAR(255)' THEN
        ALTER TABLE item_planning_table
        ALTER COLUMN item_minimum_order_quantity SET DATA TYPE VARCHAR(255);
    END IF;

    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_invetory_table' 
        AND column_name = 'item_cost') != 'VARCHAR(255)' THEN
        ALTER TABLE item_invetory_table
        ALTER COLUMN item_cost SET DATA TYPE VARCHAR(255);
    END IF;

      IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_invetory_table' 
        AND column_name = 'item_weight') != 'VARCHAR(255)' THEN
        ALTER TABLE item_invetory_table
        ALTER COLUMN item_weight SET DATA TYPE VARCHAR(255);
    END IF;

    IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_invetory_table' 
        AND column_name = 'item_minimun_purchasing') != 'VARCHAR(255)' THEN
        ALTER TABLE item_invetory_table
        ALTER COLUMN item_minimun_purchasing SET DATA TYPE VARCHAR(255);
    END IF;

     IF (SELECT data_type 
        FROM information_schema.columns 
        WHERE table_name = 'item_invetory_table' 
        AND column_name = 'item_maximum_purchasing') != 'VARCHAR(255)' THEN
        ALTER TABLE item_invetory_table
        ALTER COLUMN item_maximum_purchasing SET DATA TYPE VARCHAR(255);
    END IF;


    


END $$;
`

   
  ];

  try {
    for (const query of createTableQueries) {
     client.query(query);
    // console.log(tables.rows,query)
    }

    console.log("Tables created successfully");
  } catch (error) {
    console.error("Error creating tables:", error);
  }
}