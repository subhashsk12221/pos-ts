/**
 * Server entry-point.
 */

import express from "express";
import expressJoiValidation from "express-joi-validation"
import {createTables} from './models/model'
import * as dotenv from 'dotenv';
import cors from 'cors'
import bodyParser from 'body-parser';
import expFileUpload from "express-fileupload";
import path from 'path';
import * as  insertData from './scripts/script'
import { fileURLToPath } from 'url';
const app = express();
import axios from 'axios';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { routes  } from './routes/routes';
import * as  dataChangeEvent from './scripts/databaseEventLisnter'
import * as scipt from './scripts/script'
import { initializeWebSocket } from "./helper/itemsync";
// import { createTables } from "./models/model";
import { generateResponse } from "./util/genRes";
import { io } from 'socket.io-client';
import { addItemGeneralDetails } from "./service/productService";
import { getUnSyncedCustomer, syncCustomerDataResult } from "./service/customerService";
import { syncOrderDataResult } from "./service/orderService";
import { getUnSynOrder } from "./controller/orderController";
import socket, { sync } from "./sync/syncScript";
import syncScript from "./sync/syncScript"
// { initializeSocket } from "./sync/syncScript";

 syncScript
 sync()

dotenv.config();

// Connect to the CPOS server (ensure you use the correct URL)
// const socket = io('http://120.138.10.236:8001', {
//   transports: ['websocket'],
//   reconnection: true,
//   reconnectionAttempts: Infinity,
//   reconnectionDelay: 1000,
//   reconnectionDelayMax: 5000,
//   randomizationFactor: 0.5
// });
// console.log(socket,"erter")
// socket.on('connect', () => {
//   console.log("ertertert")
//   console.log('Connected to CPOS server', socket.id);
//   socket.emit('sync', { message: 'POS data to sync' });
//   getUnSyncedCustomer()
//   getUnSynOrder()

// });
//   // Send sync data to CPOS
 

// socket.on('itemSync', (data:any) => {
//   console.log('Received update from CPOS:', data);
//   addItemGeneralDetails(data.body.itemData)
// });

// socket.on('disconnect', () => {
//   console.log('Disconnected from CPOS server');
// });

// socket.on('sync-acknowledgment', (data:any) => {
  
//   console.log('synced from CPOS server',data);
//  let   customerData = {
//        cmr_id: data.cmr_id,
//        data_synced: data.sync

//    }
   
//    syncCustomerDataResult(customerData.cmr_id,customerData)
  

// });

// socket.on('biiling_order_sync-acknowledgment', (data:any) => {
  
//   console.log('synced from CPOS server',data);
  
//   let   orderData = {
//     sot_id: data.sot_id,
//     data_synced: data.sync

// }

// syncOrderDataResult(orderData,orderData.sot_id)
// //  let   customerData = {
// //        cmr_id: data.cmr_id,
// //        data_synced: data.sync

// //    }
   
// //    syncCustomerDataResult(customerData.cmr_id,customerData)
  

// });

const validator = expressJoiValidation.createValidator({
  passError: true,
});
const currentFileUrl = import.meta.url;
                // Convert the file URL to a file path
                const currentFilePath = fileURLToPath(currentFileUrl);
                // Use path.dirname to get the directory name
                const currentDir = path.dirname(currentFilePath);

/**
 * Express configuration(s).
 */


/**
 * CORS.
 */
app.use(cors());
app.use((_req: express.Request, res: express.Response, next: express.NextFunction) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();

});
app.use(expFileUpload());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use('/api/image', express.static(path.join(currentDir, 'uploads')));









/**
 * Primary app route(s).
 */


/**
 * Start Express server.
 */

app.use(express.json());
console.log("ssssss")
routes(app);

// Apply main repository routes with /api prefix




// app.use((err:any,_req: express.Request, res: express.Response )=> {
//   if (err && err.error && err.error.isJoi) {
//   return   res.send(generateResponse( false, err.error.message,400,  null));
//   }
//   throw new Error('Unexpected error occurred.'); 
// });
app.use( ( _req: express.Request, res: express.Response, _next: express.NextFunction) =>{
  return   res.send(generateResponse(false, "Page not found",500,  null));
}
);


const port = 8000;
createTables().then(result=>{
  console.log(result)
})
//initializeWebSocket()

  app.listen(port, () => {
    console.log('App is now running at port ', port)
  })

 // export default socket