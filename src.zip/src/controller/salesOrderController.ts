
import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as salesOrderService from '../service/salesOrderService'
import * as nextInvoicenumber  from '../service/documentNumberingSeries'
import { getItemTax } from './discountController';
import * as UOMGroipService from '../administrativesettings/src/service/uomService';
//import { CreditNote,SalesInvoice,DN } from '../helper/pdfhelper';
function formatDate(date:any) {
    if (!date) return null; // Handle null or undefined dates
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
import { CreditNote,DN,ReturnInvoice} from '../helper/pdfhelper';
export async function addSalesOrder(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getSaleOrderNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
    
        orderData.sott_invoice_number = getNextInvoiceNumber;


        if (orderData && itemData) {
            const addOrder = await salesOrderService.addSalesOrder(orderData, itemData)
            if (addOrder) {
               
                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function getSalesProduct(req: any, res: any) {

    try {
        const { field, value } = req.query
        console.log(req.query)
        const query = `
        SELECT
        itt.*,
        iit.*,
        itp.*,
        mt.name as item_manufacturer_name
        FROM
        items_table as itt
          INNER JOIN 
            item_invetory_table iit  ON iit.item_id = itt.item_id
        INNER JOIN 
            item_sales_table itp ON itt.item_id = itp.item_id
        LEFT JOIN  manufacturer mt ON itt.item_manufacturer = mt.id 
        WHERE
        LEFT(${field}, 10) ILIKE $1 AND itt.is_active = true ;
      `;



        console.log(query, field, value)
        if (field && value) {
            const getItemsList = await client.query(query, [`%${value}%`]);
            // console.log(result)
            if (getItemsList.rows.length > 0) {
                for (let item of getItemsList.rows) {
                    let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
                if(getItemGroup.rows.length>0){
                    console.log(getItemGroup.rows)
                    item.uom_dropdown= getItemGroup.rows
                     item.item_uom = getItemGroup.rows[0].base_uom.name
              }
              
            }

             // Extract item_ids from the result
             const itemIds = getItemsList.rows.map((item: any) => `'${item.item_id}'`).join(', ');
        
             // Second query to get the total_sellable_quantity for the fetched items
             const sellableQuantityQuery = `
                 SELECT
                     items_table.item_id,
                     COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
                 FROM
                     items_table
                 LEFT JOIN
                     items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
                 LEFT JOIN
                     store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
                 LEFT JOIN
                     sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id   
                 WHERE
                     items_table.item_id IN (${itemIds})
                     AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
                     AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
                 GROUP BY
                     items_table.item_id;
             `;
         
             // Execute the second query
             const sellableQuantities = await client.query(sellableQuantityQuery);
         
             // Map sellable quantities to item IDs
             const quantitiesMap = new Map(sellableQuantities.rows.map((row: any) => [row.item_id, row.total_sellable_quantity]));
         
             // Merge sellable quantities with the original item data
             let finalItemsList = getItemsList.rows.map((item: any) => ({
                 ...item,
                 total_sellable_quantity: quantitiesMap.get(item.item_id) || 0
             }));
         
         
                 // console.log(query, field, value)
                 // if (field && value) {
                 //     const result = await client.query(query, [`%${value}%`]);
                     // console.log(result)
                     if (finalItemsList.length > 0) {
                         console.log('Customers found:', finalItemsList);
                     //     for (let item of finalItemsList) {
                     //         let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
                     //     if(getItemGroup.rows.length>0){
                     //         console.log(getItemGroup.rows)
                     //         item.uom_dropdown= getItemGroup.rows
                     //          item.item_uom = getItemGroup.rows[0].base_uom.name
                     //   }
                     // }
                 
                         return res.send(
                             generateResponse(true, "product fetched succesfully", 200, finalItemsList))

            } else {
                return res.send(
                    generateResponse(false, "product not found", 400, null))
            }
        }
        else {
            return res.send(
                generateResponse(false, "product not found", 400, null))
        }
    }
}
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesOrderList(req: any, res: any) {
    try {

        const getOrderList = await salesOrderService.getSalesOrderList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesOrderById(req: any, res: any) {
    try {
        const { sott_id } = req.query

        if (sott_id) {

            const orderDetailsResult = await salesOrderService.getSalesOrderById(sott_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {

                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }

        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await salesOrderService.getVendorDetails(queryParams[0].sott_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await salesOrderService.getSalesitemsList(queryParams[i])
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                // Convert grouped items to an array
                resultArray.push(orderDetailsResult.rows)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addSaleDelivery(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id



        const getNextInvoiceNumber = await nextInvoicenumber.getSalesDeliveryNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        const cmr_phone_number = orderData.cmr_phone_number
        orderData.sodtt_invoice_number = getNextInvoiceNumber


        if (orderData && itemData) {
            const addOrder = await salesOrderService.addSaleDeliveryOrder(orderData, itemData, itemBatchData)
            if (addOrder) {
                // const smspath = `https://smsnotify.one/SMSApi/send?userid=davaindia&password=Dava@123&sendMethod=quick&mobile=${cmr_phone_number}&msg=Thank%20you,%20for%20connecting%20with%20Davaindia%20Generic%20Pharmacy,%20your%20login%20One%20Time%20Password%20(OTP)%20is%20Ajay%20Pandey.%20davaindia%20generic%20pharmacy.&senderid=DAVAIN&msgType=text&format=text`
                // const sendSMS = axios.post(`${smspath}` ).then(function (response) {

                //     console.log(response, "sms");
                //   })
                //   .catch(function (error) {

                //     console.log(error,"sms");
                //   })

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function getSaleDelivery(req: any, res: any) {
    try {

        const getGopOrderList = await salesOrderService.getSaleDelivery(req.query)

        if (getGopOrderList) {
            return res.status(200).send(generateResponse(true, "gop ordeer fetched successfully", 200, {
                totalCount: getGopOrderList.totalRowsCount,
                orderList: getGopOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "gop order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getDeliveryitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await salesOrderService.getDeliveryVendorDetails(queryParams[0].sodtt_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await salesOrderService.getDeliveryitemsList(queryParams[i])
            const getinvoiceORReturnitemBatchData = await salesOrderService.getinvoiceOrReturnitemBatchData(queryParams[i])

            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
console.log(getinvoiceORReturnitemBatchData.returnorder, "weeeeeeeeeeeee")
let item = orderDetailsResult.rows
if (getinvoiceORReturnitemBatchData.invoice.length > 0) {
    let invoiceItems = getinvoiceORReturnitemBatchData.invoice;

    for (let i = 0; i < invoiceItems.length; i++) {
        for (let j = 0; j < item.length; j++) {
            if (
                invoiceItems[i].item_id === item[j].item_id &&
                invoiceItems[i].sodtt_id === item[j].sodtt_id &&
                invoiceItems[i].item_batch_number === item[j].item_batch_number
            ) {
                item[j].item_batch_quantity -= invoiceItems[i].item_batch_quantity;
                console.log(item[j].item_batch_quantity, item[j], "invoice");
            }
        }
    }
}

if (getinvoiceORReturnitemBatchData.returnorder.length > 0) {
    let returnItems = getinvoiceORReturnitemBatchData.returnorder;

    for (let i = 0; i < returnItems.length; i++) {
        for (let j = 0; j < item.length; j++) {
            console.log(returnItems[i].item_id === item[j].item_id &&
                returnItems[i].sodtt_id === item[j].sodtt_id &&
                returnItems[i].item_batch_number === item[j].item_batch_number,"qwwwwww")
            if (
                returnItems[i].item_id === item[j].item_id &&
                returnItems[i].sodtt_id === item[j].sodtt_id &&
                returnItems[i].item_batch_number === item[j].item_batch_number
            ) {
                item[j].item_batch_quantity -= returnItems[i].item_batch_quantity;
                console.log(item[j].item_batch_quantity, item[j], "return");
            }
        }
    }
}
                 

                // Convert grouped items to an array
                const processedItems = new Set(); // Initialize a Set to keep track of processed items

                const formattedResponse = item.reduce((acc, item) => {
                  // Check if the item has already been processed
                    if (!processedItems.has(item.sodtt_id + item.item_id)) {
                        // Add the item to the set of processed items
                        processedItems.add(item.sodtt_id + item.item_id);

                        // Find all batches for the current item
                        const itemBatchData = orderDetailsResult.rows
                            .filter(batch => batch.sodtt_id === item.sodtt_id && batch.item_id === item.item_id &&  batch.item_batch_quantity !== 0 )
                            .map(({ item_id, item_batch_number, item_batch_quantity, item_exp_date,
                                from_bin_location,
                                from_bin_id,
                                item_batch_free_quantity,
                                item_batch_unit_price,
                                item_batch_discount_amount,
                                item_batch_discount_percentage,
                                item_batch_tax_percentage,
                                item_batch_tax_amount,
                                item_batch_sales_rate,
                                item_batch_total_sales_rate,
                                item_batch_final_sales_rate,
                              

                             }) => {

                                const salesRate = parseFloat(item_batch_sales_rate) || 0; // Default to 0 if undefined or null
                                const discountPercentage = parseFloat(item_batch_discount_percentage) || 0;
                                const taxPercentage = parseFloat(item_batch_tax_percentage) || 0;
                                const sellableQuantity = parseInt(item_batch_quantity) || 0;
                                   console.log(salesRate,discountPercentage,taxPercentage,sellableQuantity)
                                // Perform calculations
                                let discountAmount = salesRate * (discountPercentage / 100)
                             let    discountedRate = salesRate - discountAmount
                          // let  discountedRate =  salesRate - (salesRate * (discountPercentage / 100))
                             //   const discountedRate = salesRate - (discountPercentage / 100) * salesRate;
                             
                                const taxAmount = discountedRate - ( discountedRate * (100 / (100+taxPercentage)));
                                const finalSaleRate = discountedRate + taxAmount;
                                const totalTaxAmount = sellableQuantity *taxAmount
                                const totalSaleRate = sellableQuantity * finalSaleRate;
                                console.log(discountedRate,taxAmount,totalTaxAmount)
                              return   {
                                item_id,
                                item_batch_number,
                                item_batch_quantity,
                                item_exp_date:formatDate(item_exp_date),
                                from_bin_location,
                                item_batch_unit_price,
                                from_bin_id,
                                item_batch_free_quantity,
                                item_batch_discount_amount,
                                item_batch_discount_percentage,
                                item_batch_tax_percentage,
                                item_batch_tax_amount: parseFloat(totalTaxAmount.toFixed(2)),
                                item_batch_sales_rate,
                                item_batch_total_sales_rate :parseFloat(totalSaleRate.toFixed(2)),
                                item_batch_final_sales_rate: parseFloat(finalSaleRate.toFixed(2)),

                            }});

                            const { itemSellableQuantitySum, itemBatchFreeQuantitySum, itemBatchTotalTaxRateSum, itemTotalAmount } = itemBatchData.reduce((totals, batch) => {
                                totals.itemSellableQuantitySum += parseInt(batch.item_batch_quantity) || 0;
                                totals.itemBatchFreeQuantitySum += parseInt(batch.item_batch_free_quantity) || 0;
                                totals.itemBatchTotalTaxRateSum += batch.item_batch_tax_amount || 0;
                                totals.itemTotalAmount += batch.item_batch_total_sales_rate || 0;  // Same as itemBatchTotalPurchaseRateSum
                                return totals;
                            }, {
                                itemSellableQuantitySum: 0,
                                itemBatchFreeQuantitySum: 0,
                                itemBatchTotalTaxRateSum: 0,
                                itemTotalAmount: 0
                            });
                    

                        // Add the formatted item to the accumulator
                        acc.push({ ...item, item_quantity:itemSellableQuantitySum,
                            item_free_quantity:itemBatchFreeQuantitySum,
                            item_total_amount:itemTotalAmount,
                            item_tax_amount:itemBatchTotalTaxRateSum.toFixed(2),
                            item_cgst:(itemBatchTotalTaxRateSum/2).toFixed(2),
                            item_sgst: (itemBatchTotalTaxRateSum/2).toFixed(2),
                            itemBatchData });
                    }
                    return acc;
                }, []);

                console.log(formattedResponse);


                resultArray.push(formattedResponse)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);
            

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }

    
       

    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getDeliveryOrderById(req: any, res: any) {
    try {
        const { sodtt_id } = req.query

        if (sodtt_id) {

            const orderDetailsResult = await salesOrderService.getDeliveryOrderById(sodtt_id)
            console.log(orderDetailsResult)
            if (orderDetailsResult.length > 0) {
                console.log(orderDetailsResult, "ssssss")

                //console.log(resultArray,"ddd", resultArray['orderData'])



                return res.send(generateResponse(true, "delivery fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "delivery not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "delivery not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addSalesOrderInvoice(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getSalesInvoiceNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        orderData.soit_invoice_number = getNextInvoiceNumber

        if (orderData && itemData) {
            const addOrder = await salesOrderService.addSalesOrderInvoice(orderData, itemData, itemBatchData)
            if (addOrder) {

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function getSalesOrderInvoiceList(req: any, res: any) {
    try {

        const getOrderList = await salesOrderService.getSalesOrderInvoiceList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales invoice ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesOrderInvoiceById(req: any, res: any) {
    try {
        const { soit_id } = req.query

        if (soit_id) {

            const orderDetailsResult = await salesOrderService.getSalesOrderInvoiceById(soit_id)
            console.log(orderDetailsResult)
            if (orderDetailsResult.length > 0) {

                //console.log(resultArray,"ddd", resultArray['orderData'])



                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addSalesReturnInvoice(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getSalesReturnNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        orderData.srt_invoice_number = getNextInvoiceNumber

        if (orderData && itemData) {
            const addOrder = await salesOrderService.addSalesReturnInvoice(orderData, itemData, itemBatchData)
            if (addOrder) {

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function getSalesReturnInvoiceList(req: any, res: any) {
    try {

        const getOrderList = await salesOrderService.getSalesReturnInvoiceList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales invoice ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesReturnInvoiceById(req: any, res: any) {
    try {
        const { srt_id } = req.query

        if (srt_id) {

            const orderDetailsResult = await salesOrderService.getSalesReturnInvoiceById(srt_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {


                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSaleReturnitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await salesOrderService.getSaleReturnVendorDetails(queryParams[0].srt_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await salesOrderService.getSaleReturnitemsList(queryParams[i])
            const getinvoiceORReturnitemBatchData = await salesOrderService.getReturnitemBatchData(queryParams[i])
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {

                let item = orderDetailsResult.rows
if (getinvoiceORReturnitemBatchData.returnorder.length > 0) {
    let invoiceItems = getinvoiceORReturnitemBatchData.returnorder

    for (let i = 0; i < invoiceItems.length; i++) {
        for (let j = 0; j < item.length; j++) {
            if (
                invoiceItems[i].item_id === item[j].item_id &&
                invoiceItems[i].srt_id === item[j].srt_id &&
                invoiceItems[i].item_batch_number === item[j].item_batch_number
            ) {
                item[j].item_batch_quantity -= invoiceItems[i].item_batch_quantity;
                console.log(item[j].item_batch_quantity, item[j], "invoice");
            }
        }
    }
}


              
                // Convert grouped items to an array
                const processedItems = new Set(); // Initialize a Set to keep track of processed items

                const formattedResponse = orderDetailsResult.rows.reduce((acc, item) => {
                    // Check if the item has already been processed
                    if (!processedItems.has(item.srt_id + item.item_id)) {
                        // Add the item to the set of processed items
                        processedItems.add(item.srt_id + item.item_id);

                        // Find all batches for the current item
                        const itemBatchData = orderDetailsResult.rows
                            .filter(batch => batch.srt_id === item.srt_id && batch.item_id === item.item_id  &&  batch.item_batch_quantity !== 0)
                            .map(({ item_id, item_batch_number, item_batch_quantity, item_exp_date,
                                from_bin_location,
                                from_bin_id,
                                item_batch_free_quantity,
                                item_batch_discount_amount,
                                item_batch_discount_percentage,
                                item_batch_tax_percentage,
                                item_batch_tax_amount,
                                item_batch_sales_rate,
                                item_batch_total_sales_rate,
                                item_batch_final_sales_rate,
                              

                             }) => {

                                const salesRate = parseFloat(item_batch_sales_rate) || 0; // Default to 0 if undefined or null
                                const discountPercentage = parseFloat(item_batch_discount_percentage) || 0;
                                const taxPercentage = parseFloat(item_batch_tax_percentage) || 0;
                                const sellableQuantity = parseInt(item_batch_quantity) || 0;
                            
                                // Perform calculations
                                const discountedRate = salesRate - (discountPercentage / 100) * salesRate;
                                const taxAmount = discountedRate - ( discountedRate * (100 / (100+taxPercentage)));
                                const finalSaleRate = discountedRate + taxAmount;
                                const totalTaxAmount = sellableQuantity *taxAmount
                                const totalSaleRate = sellableQuantity * finalSaleRate;
                                
                              return   {
                                item_id,
                                item_batch_number,
                                item_batch_quantity,
                                item_exp_date:formatDate(item_exp_date),
                                from_bin_location,
                                from_bin_id,
                                item_batch_free_quantity,
                                item_batch_discount_amount,
                                item_batch_discount_percentage,
                                item_batch_tax_percentage,
                                item_batch_tax_amount: parseFloat(totalTaxAmount.toFixed(2)),
                                item_batch_sales_rate,
                                item_batch_total_sales_rate :parseFloat(totalSaleRate.toFixed(2)),
                                item_batch_final_sales_rate: parseFloat(totalSaleRate.toFixed(2)),

                            }});

                            const { itemSellableQuantitySum, itemBatchFreeQuantitySum, itemBatchTotalTaxRateSum, itemTotalAmount } = itemBatchData.reduce((totals, batch) => {
                                totals.itemSellableQuantitySum += parseInt(batch.item_batch_quantity) || 0;
                                totals.itemBatchFreeQuantitySum += parseInt(batch.item_batch_free_quantity) || 0;
                                totals.itemBatchTotalTaxRateSum += batch.item_batch_tax_amount || 0;
                                totals.itemTotalAmount += batch.item_batch_total_sales_rate || 0;  // Same as itemBatchTotalPurchaseRateSum
                                return totals;
                            }, {
                                itemSellableQuantitySum: 0,
                                itemBatchFreeQuantitySum: 0,
                                itemBatchTotalTaxRateSum: 0,
                                itemTotalAmount: 0
                            });
                    

                        // Add the formatted item to the accumulator
                        acc.push({ ...item, item_quantity:itemSellableQuantitySum,
                            item_free_quantity:itemBatchFreeQuantitySum,
                            item_total_amount:itemTotalAmount,
                            item_tax_amount:itemBatchTotalTaxRateSum.toFixed(2),
                            item_cgst:(itemBatchTotalTaxRateSum/2).toFixed(2),
                            item_sgst: (itemBatchTotalTaxRateSum/2).toFixed(2),
                            itemBatchData });
                    }
                    return acc;
                }, []);

                console.log(formattedResponse);


                resultArray.push(formattedResponse)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);



            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addSalesCreditNote(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getSalesCreditNoteNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        orderData.sct_invoice_number = getNextInvoiceNumber;

        if (orderData && itemData) {
            const addOrder = await salesOrderService.addSalesCreditNote(orderData, itemData, itemBatchData)
            if (addOrder) {

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function getSalesCreditNoteList(req: any, res: any) {
    try {

        const getOrderList = await salesOrderService.getSalesCreditNoteList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales invoice ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesCreditNoteById(req: any, res: any) {
    try {
        const { sct_id } = req.query

        if (sct_id) {

            const orderDetailsResult = await salesOrderService.getSalesCreditNoteById(sct_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {

                //console.log(resultArray,"ddd", resultArray['orderData'])



                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesCreditNoteByIdHTML(req: any, res: any) {
    try {
        const { sct_id } = req.query
        console.log(sct_id);
        if (sct_id) {

            const orderDetailsResult = await salesOrderService.getSalesCreditNoteById(sct_id)
            const storeDetails=await salesOrderService.getStoreDetails();
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0 && storeDetails.length>0) {

                //console.log(resultArray,"ddd", resultArray['orderData'])
                const html=await CreditNote(orderDetailsResult,storeDetails);
                console.log(html);
                if(html){
                    return res.send(generateResponse(true, "Invoice fetched successfully", 200, html));
                }
                else{
                    return res.send(generateResponse(false, "Invoice not found", 400, null));
                }
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function updateSalesOrder(req: any, res: any) {
    try {
        // Destructure orderData and itemData from the request body
        const { orderData, itemData } = req.body;
        console.log(orderData)


        // Extract the sot_id from orderData    
        const sott_id = orderData.sott_id;


        // Start a database transaction
        await client.query('BEGIN');


        // Update sales_order
        const updateSalesOrder = await salesOrderService.updateSalesOrderData(orderData, sott_id)

        // Fetch existing items for the order
        const existingItemsResult = await salesOrderService.existingItemsResult(sott_id)

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const updatedItem = itemData.find((item: { item_id: any; }) => item.item_id === existingItem.item_id);
            
          
            if (updatedItem) {
                updatedItem.item_to_be_delivered = updatedItem.item_quantity
                updatedItem.item_invoice_open_quantity = updatedItem.item_quantity
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await salesOrderService.updatedItem(updatedItem, sott_id)
                itemResults.push(updateItemResult.rows[0]);

            } else {
                // Item does not exist in the updated itemData, construct the query to remove it

                const removeItemResult = await salesOrderService.removeItem(sott_id, existingItem.item_id)
                // itemResults.push(removeItemResult.rows[0]);
            }
        }

        // Check for new items to be added
        const newItems = itemData.filter((item: { item_id: any; }) => !existingItems.find(existingItem => existingItem.item_id === item.item_id));

        // Iterate through new items 
        for (const newItem of newItems) {
            // Construct the field names for the INSERT query
            newItem.item_to_be_delivered = newItem.item_quantity
            newItem.item_invoice_open_quantity = newItem.item_quantity
            newItem.sott_id = sott_id
            const addItemResult = await salesOrderService.addItem(newItem)

            itemResults.push(addItemResult.rows[0]);
        }

        // Commit the transaction
        await client.query('COMMIT');

        // Send the response with the updated orderData and itemResults
        return res.status(200).send(
            generateResponse(true, "Draft order updated successfully", 200, { orderData: updateSalesOrder.rows[0], itemData: itemResults })
        )

    } catch (err) {
        // Rollback the transaction in case of an error
        await client.query('ROLLBACK');

        // Log the error and send a 500 Internal Server Error response
        console.error(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function getInvoiceitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await salesOrderService.getInvoiceVendorDetails(queryParams[0].soit_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await salesOrderService.getInvoiceitemsList(queryParams[i])
            const getinvoiceORReturnitemBatchData = await salesOrderService.getReturnInvoiceitemBatchData(queryParams[i])
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {

                let item = orderDetailsResult.rows
                if (getinvoiceORReturnitemBatchData.returnorder.length > 0) {
                    let invoiceItems = getinvoiceORReturnitemBatchData.returnorder
                
                    for (let i = 0; i < invoiceItems.length; i++) {
                        for (let j = 0; j < item.length; j++) {
                            if (
                                invoiceItems[i].item_id === item[j].item_id &&
                                invoiceItems[i].soit_id === item[j].soit_id &&
                                invoiceItems[i].item_batch_number === item[j].item_batch_number
                            ) {
                                item[j].item_batch_quantity -= invoiceItems[i].item_batch_quantity;
                                console.log(item[j].item_batch_quantity, item[j], "invoice");
                            }
                        }
                    }
                }
                // Convert grouped items to an array
                const processedItems = new Set(); // Initialize a Set to keep track of processed items

                const formattedResponse = orderDetailsResult.rows.reduce((acc, item) => {
                    // Check if the item has already been processed
                    if (!processedItems.has(item.soit_id + item.item_id)) {
                        // Add the item to the set of processed items
                        processedItems.add(item.soit_id + item.item_id);

                        // Find all batches for the current item
                        const itemBatchData = orderDetailsResult.rows
                            .filter(batch => batch.soit_id === item.soit_id && batch.item_id === item.item_id)
                            .map(({ item_id, item_batch_number, item_batch_quantity, item_exp_date,
                                from_bin_location,
                                from_bin_id,
                                item_batch_free_quantity,
                                item_batch_discount_amount,
                                item_batch_discount_percentage,
                                item_batch_tax_percentage,
                                item_batch_tax_amount,
                                item_batch_sales_rate,
                                item_batch_total_sales_rate,
                                item_batch_final_sales_rate,
                              

                             }) => {

                                const salesRate = parseFloat(item_batch_sales_rate) || 0; // Default to 0 if undefined or null
                                const discountPercentage = parseFloat(item_batch_discount_percentage) || 0;
                                const taxPercentage = parseFloat(item_batch_tax_percentage) || 0;
                                const sellableQuantity = parseInt(item_batch_quantity) || 0;
                            
                                // Perform calculations
                                const discountedRate = salesRate - (discountPercentage / 100) * salesRate;
                                const taxAmount = discountedRate - ( discountedRate * (100 / (100+taxPercentage)));
                                const finalSaleRate = discountedRate + taxAmount;
                                const totalTaxAmount = sellableQuantity *taxAmount
                                const totalSaleRate = sellableQuantity * finalSaleRate;
                                
                              return   {
                                item_id,
                                item_batch_number,
                                item_batch_quantity,
                                item_exp_date:formatDate(item_exp_date),
                                from_bin_location,
                                from_bin_id,
                                item_batch_free_quantity,
                                item_batch_discount_amount,
                                item_batch_discount_percentage,
                                item_batch_tax_percentage,
                                item_batch_tax_amount: parseFloat(totalTaxAmount.toFixed(2)),
                                item_batch_sales_rate,
                                item_batch_total_sales_rate :parseFloat(totalSaleRate.toFixed(2)),
                                item_batch_final_sales_rate: parseFloat(totalSaleRate.toFixed(2)),

                            }});

                            const { itemSellableQuantitySum, itemBatchFreeQuantitySum, itemBatchTotalTaxRateSum, itemTotalAmount } = itemBatchData.reduce((totals, batch) => {
                                totals.itemSellableQuantitySum += parseInt(batch.item_batch_quantity) || 0;
                                totals.itemBatchFreeQuantitySum += parseInt(batch.item_batch_free_quantity) || 0;
                                totals.itemBatchTotalTaxRateSum += batch.item_batch_tax_amount || 0;
                                totals.itemTotalAmount += batch.item_batch_total_sales_rate || 0;  // Same as itemBatchTotalPurchaseRateSum
                                return totals;
                            }, {
                                itemSellableQuantitySum: 0,
                                itemBatchFreeQuantitySum: 0,
                                itemBatchTotalTaxRateSum: 0,
                                itemTotalAmount: 0
                            });
                    

                        // Add the formatted item to the accumulator
                        acc.push({ ...item, item_quantity:itemSellableQuantitySum,
                            item_free_quantity:itemBatchFreeQuantitySum,
                            item_total_amount:itemTotalAmount,
                            item_tax_amount:itemBatchTotalTaxRateSum.toFixed(2),
                            item_cgst:(itemBatchTotalTaxRateSum/2).toFixed(2),
                            item_sgst: (itemBatchTotalTaxRateSum/2).toFixed(2),
                            itemBatchData });
                    }
                    return acc;
                }, []);

                console.log(formattedResponse);


                resultArray.push(formattedResponse)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function updateDeliveryOrder(req: any, res: any) {

    try {
        const orderData = req.body

        const updateSalesOrder = await salesOrderService.updateDeliveryOrder(orderData)
        console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {
            const orderDetailsResult = await salesOrderService.getDeliveryOrderById(orderData.sodtt_id)

            if (orderDetailsResult.length > 0) {

                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, { orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData })
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }

    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function updateSalesOrderInvoice(req: any, res: any) {

    try {
        const orderData = req.body

        const updateSalesOrder = await salesOrderService.updateSalesOrderInvoice(orderData)
        console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {
            const orderDetailsResult = await salesOrderService.getSalesOrderInvoiceById(orderData.soit_id)
            if (orderDetailsResult.length > 0) {

                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, {
                        orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData
                    })
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }

    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function updateSalesReturnInvoice(req: any, res: any) {

    try {
        const orderData = req.body

        const updateSalesOrder = await salesOrderService.updateSalesReturnInvoice(orderData)
        console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {
            const orderDetailsResult = await salesOrderService.getSalesReturnInvoiceById(orderData.srt_id)
            if (orderDetailsResult.length > 0) {
                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, { orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData })
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }

    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function updateSalesCreditInvoice(req: any, res: any) {

    try {
        const orderData = req.body

        const updateSalesOrder = await salesOrderService.updateSalesCreditInvoice(orderData)
        console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {

            const orderDetailsResult = await salesOrderService.getSalesCreditNoteById(orderData.sct_id)
            if (orderDetailsResult.length > 0) {

                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, { orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData })
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }
    }

    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function voidSaleOrder(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const sott_id = req.body.sott_id;

        let sott_order_status = 'closed'
        const [getOrderById, getdocumentsListofSalesOrder] = await Promise.all([salesOrderService.getSalesOrderById(sott_id), salesOrderService.getdocumentsListofSalesOrder(sott_id)])
        if (getdocumentsListofSalesOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the sales order", 200, getdocumentsListofSalesOrder.rows)
            )
        } else {

            const insertCancelOrder = await salesOrderService.insertCancelOrder(getOrderById[0].orderData, getOrderById[0].itemData)
            const updateSalesOrder = await salesOrderService.updateSaleOrderStatus(sott_order_status, sott_id)

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {
                await client.query('COMMIT');



                // Send the response with the updated orderData and itemResults
                return res.status(200).send(
                    generateResponse(true, "order updated successfully", 200, updateSalesOrder)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order updated unsuccesfully", 400, null)
                )
            }
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidDeliveryOrder(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const sodtt_id = req.body.sodtt_id;

        let sodtt_order_status = 'closed'
        const [getOrderById, getdocumentsListofDeliveryOrder] = await Promise.all([salesOrderService.getDeliveryOrderById(sodtt_id), salesOrderService.getdocumentsListofDeliveryOrder(sodtt_id)])
        if (getdocumentsListofDeliveryOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the delivery order", 200, getdocumentsListofDeliveryOrder.rows)
            )
        } else {

            const insertCancelOrder = await salesOrderService.insertCancelDeliveryOrder(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder,resetDeliveryOpenQuantity] = await Promise.all([salesOrderService.updateDeliveryOrderStatus(sodtt_order_status, sodtt_id),salesOrderService.resetDeliveryOpenQuantity(getOrderById[0].itemData)])

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {
                const deleteinvoiceDoccuments = await salesOrderService.deleteSalesDocumentlist(sodtt_id)
                await client.query('COMMIT');


                // Send the response with the updated orderData and itemResults
                return res.status(200).send(
                    generateResponse(true, "order updated successfully", 200, updateSalesOrder)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order updated unsuccesfully", 400, null)
                )
            }
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidInvoice(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const soit_id = req.body.soit_id;

        let soit_order_status = 'closed'
        const [getOrderById, getdocumentsListofDeliveryOrder] = await Promise.all([salesOrderService.getSalesOrderInvoiceById(soit_id), salesOrderService.getdocumentsListofInvoice(soit_id)])
        console.log(getdocumentsListofDeliveryOrder.rows)
        if (getdocumentsListofDeliveryOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the invoice order", 200, getdocumentsListofDeliveryOrder.rows)
            )
        } else {

            const insertCancelOrder = await salesOrderService.insertCancelInvoice(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder,resetInvoiceOpenQuantity] = await  Promise.all([salesOrderService.updateSalesInvoiceStatus(soit_order_status, soit_id),salesOrderService.resetInvoiceOpenQuantity(getOrderById[0].itemData)])

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {
                const deleteinvoiceDoccuments = await salesOrderService.deleteInvoiceDocumentlist(soit_id)
                await client.query('COMMIT');


                return res.status(200).send(
                    generateResponse(true, "order updated successfully", 200, null)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order updated unsuccesfully", 400, null)
                )
            }
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidsalesCreditNote(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const sct_id = req.body.sct_id;

        let sct_order_status = 'closed'
        const getOrderById = await salesOrderService.getSalesCreditNoteById(sct_id)
        console.log(getOrderById)
        if (getOrderById.length > 0) {

            const insertCancelOrder = await salesOrderService.insertCancelCreditNote(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder, resetOpenQuantity] = await Promise.all([salesOrderService.updateSalesCreditNoteStatus(sct_order_status, sct_id), salesOrderService.resetCreditOpenQuantity(getOrderById[0].itemData)])

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {

                const deleteCreditNote = await salesOrderService.deleteCreditNote(sct_id)
                await client.query('COMMIT');
                return res.status(200).send(
                    generateResponse(true, "order void successfully", 200, null)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order void unsuccesfully", 400, null)
                )
            }
        } else {

            return res.status(400).send(
                generateResponse(false, "order void unsuccesfully", 400, null)
            )
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidSalesReturnInvoice(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const srt_id = req.body.srt_id;

        let srt_order_status = 'closed'
        const [getOrderById, getdocumentsListReturnOrder] = await Promise.all([salesOrderService.getSalesReturnInvoiceById(srt_id), salesOrderService.getdocumentsListofReturn(srt_id)])

        console.log(getOrderById)
        if (getdocumentsListReturnOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the return order", 200, getdocumentsListReturnOrder.rows)
            )
        } else {

            const insertCancelOrder = await salesOrderService.insertCancelReturnInvoice(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder,resetSaleReturnQuantity] = await  Promise.all([salesOrderService.updateSalesReturnInvoicStatus(srt_order_status, srt_id),salesOrderService.resetSaleReturnQuantity(getOrderById[0].itemData)]) 

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {

                const deleteCreditNote = await salesOrderService.deleteSaleReturnDocument(srt_id)
                await client.query('COMMIT');
                return res.status(200).send(
                    generateResponse(true, "order void successfully", 200, null)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order void unsuccesfully", 400, null)
                )
            }
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}



export async function getSalesInvoiceList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

      
        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await salesOrderService.getSalesInvoiceList(queryParams[i].soit_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                // Convert grouped items to an array
                const processedItems = new Set(); // Initialize a Set to keep track of processed items

                resultArray.push(orderDetailsResult.rows[0])
                //console.log(resultArray,"ddd", resultArray['orderData'])
            
        
        if (resultArray.length > 0) {
          

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, resultArray));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    }
}




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getSalesInvoiceListSearch(req: any, res: any) {
    try {
        
console.log()
            const [getInvoiceListResult,getOpenBalance] = await Promise.all([salesOrderService.getSalesInvoiceListSearch(req.query),salesOrderService.getOpenBalanceOfCMR(req.query.value)])
            console.log(getInvoiceListResult.rows)
            if (getInvoiceListResult.rows.length > 0) {
            return res.status(200).send(generateResponse(true, "Invoice fetched successfully", 200, {getInvoiceResult:getInvoiceListResult.rows,cmrOpenBalance:getOpenBalance.rows[0]}));
        } else {
            return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
        }
    





    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}




export async function getUnSyncedSalesOrder(){
    try{
      const getUnSyncedSalesOrder = await salesOrderService.getUnSyncedSalesOrder()
      if (getUnSyncedSalesOrder.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedSalesOrder.rows) {
                  const orderId = item.sott_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                        orderData: {
                            sott_id: item.sott_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            sott_total_gst: item.sott_total_gst,
                            sott_total_discount: item.sott_total_discount,
                            sott_payment_status: item.sott_payment_status,
                            sott_transaction_id: item.sott_transaction_id,
                            sott_order_status: item.sott_order_status,
                            sott_payment_method: item.sott_payment_method,
                            sott_billing_address: item.sott_billing_address,
                            sott_total_amount: item.sott_total_amount,
                            sott_delivery_date: item.created_date,
                            sott_document_date: item.created_date,
                            sott_invoice_number:item.sott_invoice_number,
                            remarks: item.remarks,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                
            
                    groupedOrders[orderId].itemData.push({
                        sott_id: item.sott_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_invoice_open_quantity: item.item_invoice_open_quantity,
                        item_to_be_delivered: item.item_to_be_delivered,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
    
                    });
                  }
          
                
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
              
                    
                
                  
  
               console.log(JSON.stringify(order, null, 2), 'Processing Order after rrrrr');
  
                const syncedResult = await salesOrderService.syncSalesOrder(order.orderData,newItemsData,);
              }
            }
    }catch(error){
  
    }
  }

  export async function getUnSyncedSaleDelivery(){
    try{
      const getUnSyncedStockTransfer = await salesOrderService.getUnSyncedSaleDelivery()
      if (getUnSyncedStockTransfer.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedStockTransfer.rows) {
                  const orderId = item.sodtt_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                      orderData: {
                        sodtt_id: item.sodtt_id,
                        store_id: item.store_id,
                        cmr_phone_number: item.cmr_phone_number,
                        sodtt_total_gst: item.sodtt_total_gst,
                        sodtt_invoice_number:item.sodtt_invoice_number,
                        sodtt_total_discount: item.sodtt_total_discount,
                        sodtt_payment_status: item.sodtt_payment_status,
                        sodtt_transaction_id: item.sodtt_transaction_id,
                        sodtt_order_status: item.sodtt_order_status,
                        sodtt_sub_total: item.sodtt_sub_total,
                        sodtt_payment_method: item.sodtt_payment_method,
                        sodtt_billing_address: item.sodtt_billing_address,
                        sodtt_total_amount: item.sodtt_total_amount,
                        sodtt_delivery_date: item.sodtt_delivery_date,
                        sodtt_document_date: item.sodtt_document_date,
                        is_invoice_created: item.is_invoice_created,
                        cmr_code: item.cmr_code,
                        cmr_name: item.cmr_name,
                        cmr_id: item.cmr_id,
                        remarks: item.remarks,
                        created_date: item.created_date,
                        update_date: item.update_date,
                      },
                      itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        sodtt_id: item.sodtt_id,
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: formatDate( item.item_exp_date),                       
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_unit_price:item.item_batch_unit_price,
                        from_bin_location:item.from_bin_location,
                        item_batch_sales_rate:item.item_batch_sales_rate,
                        from_bin_id:item.from_bin_id,
                       item_batch_free_quantity:item.item_batch_free_quantity,
                       item_batch_discount_amount:item.item_batch_discount_amount,
                       item_batch_discount_percentage:item.item_batch_discount_percentage,
                       item_batch_tax_percentage :item.item_batch_tax_percentage,
                       item_batch_tax_amount :item.item_batch_tax_amount,
                       item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                       item_batch_final_sales_rate:item.item_batch_final_sales_rate
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        sodtt_id: item.sodtt_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        sott_id:item.sott_id,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        is_item_invoice_created: item.is_item_invoice_created,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_free_quantity:item.item_free_quantity,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                       item_manufacturer_name:item.item_manufacturer_name,
 
                      itemBatchData: [
                        {
                            sodtt_id: item.sodtt_id,
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date: formatDate( item.item_exp_date),                       
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            from_bin_location:item.from_bin_location,
                            item_batch_sales_rate:item.item_batch_sales_rate,
                            from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate
                        },
                      ],
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
            //    console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await salesOrderService.syncSalesDelivery(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }




  export async function getUnSyncedSaleInvoice(){
    try{
      const getUnSyncedSaleInvoice = await salesOrderService.getUnSyncedSaleInvoice()
      if (getUnSyncedSaleInvoice.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedSaleInvoice.rows) {
                  const orderId = item.soit_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                        orderData: {
                            soit_id: item.soit_id,
                            store_id: item.store_id,
                            cmr_id: item.cmr_id,
                            cmr_phone_number: item.cmr_phone_number,
                            soit_total_gst: item.soit_total_gst,
                            soit_invoice_number:item.soit_invoice_number,
                            soit_total_discount: item.soit_total_discount,
                            soit_payment_status: item.soit_payment_status,
                            soit_transaction_id: item.soit_transaction_id,
                            soit_order_status: item.soit_order_status,
                            soit_payment_method: item.soit_payment_method,
                            soit_billing_address: item.soit_billing_address,
                            soit_total_amount: item.soit_total_amount,
                            soit_sub_total: item.soit_sub_total,
                            soit_delivery_date: item.soit_delivery_date,
                            soit_document_date: item.soit_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            remarks: item.remarks,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                      // Initialize payment data to avoid undefined errors
                    
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        soit_id: item.soit_id,
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: formatDate( item.item_exp_date),                       
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_unit_price:item.item_batch_unit_price,
                        from_bin_location:item.from_bin_location,
                        item_batch_sales_rate:item.item_batch_sales_rate,
                        from_bin_id:item.from_bin_id,
                       item_batch_free_quantity:item.item_batch_free_quantity,
                       item_batch_discount_amount:item.item_batch_discount_amount,
                       item_batch_discount_percentage:item.item_batch_discount_percentage,
                       item_batch_tax_percentage :item.item_batch_tax_percentage,
                       item_batch_tax_amount :item.item_batch_tax_amount,
                       item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                       item_batch_final_sales_rate:item.item_batch_final_sales_rate
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        soit_id: item.soit_id,
                        item_id: item.item_id,
                        sodtt_id: item.sodtt_id,
                        sott_id:item.sott_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        item_credit_quanity_remaining:item.item_credit_quanity_remaining,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_free_quantity:item.item_free_quantity,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                       item_manufacturer_name:item.item_manufacturer_name,
 
                        itemBatchData: [{
                            soit_id: item.soit_id,
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date:formatDate( item.item_exp_date),                       
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            from_bin_location:item.from_bin_location,
                            item_batch_sales_rate:item.item_batch_sales_rate,
                            from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate
                        }]
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
               // console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await salesOrderService.syncSalesInvoice(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }


  export async function getUnSyncedSaleReturn(){
    try{
      const getUnSyncedSaleInvoice = await salesOrderService.getUnSyncedSaleReturn()
      if (getUnSyncedSaleInvoice.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedSaleInvoice.rows) {
                  const orderId = item.srt_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                        orderData: {
                            srt_id: item.srt_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            srt_total_gst: item.srt_total_gst,
                            srt_total_discount: item.srt_total_discount,
                            srt_payment_status: item.srt_payment_status,
                            srt_transaction_id: item.srt_transaction_id,
                            srt_invoice_number:item.srt_invoice_number,
                            srt_order_status: item.srt_order_status,
                            srt_payment_method: item.srt_payment_method,
                            srt_billing_address: item.srt_billing_address,
                            srt_total_amount: item.srt_total_amount,
                            srt_sub_total: item.srt_sub_total,
                            srt_delivery_date: item.srt_delivery_date,
                            srt_document_date: item.srt_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            remarks: item.remarks,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                      // Initialize payment data to avoid undefined errors
                    
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        srt_id: item.srt_id,
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: formatDate( item.item_exp_date),                       
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_unit_price:item.item_batch_unit_price,
                        from_bin_location:item.from_bin_location,
                        item_batch_sales_rate:item.item_batch_sales_rate,
                        from_bin_id:item.from_bin_id,
                       item_batch_free_quantity:item.item_batch_free_quantity,
                       item_batch_discount_amount:item.item_batch_discount_amount,
                       item_batch_discount_percentage:item.item_batch_discount_percentage,
                       item_batch_tax_percentage :item.item_batch_tax_percentage,
                       item_batch_tax_amount :item.item_batch_tax_amount,
                       item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                       item_batch_final_sales_rate:item.item_batch_final_sales_rate
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        srt_id: item.srt_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        sodtt_id: item.sodtt_id,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_free_quantity:item.item_free_quantity,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                       item_manufacturer_name:item.item_manufacturer_name,
 
                        itemBatchData: [{
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date: formatDate( item.item_exp_date),                       
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            from_bin_location:item.from_bin_location,
                            item_batch_sales_rate:item.item_batch_sales_rate,
                            from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate
                        }]
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
             //   console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await salesOrderService.syncSalesReturn(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }



  export async function getUnSyncedSaleCreditNote(){
    try{
      const getUnSyncedSaleInvoice = await salesOrderService.getUnSyncedSaleCreditNote()
      if (getUnSyncedSaleInvoice.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedSaleInvoice.rows) {
                  const orderId = item.sct_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                        orderData: {
                            sct_id: item.sct_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            sct_total_gst: item.sct_total_gst,
                            sct_invoice_number:item.sct_invoice_number,
                            sct_total_discount: item.sct_total_discount,
                            sct_payment_status: item.sct_payment_status,
                            sct_transaction_id: item.sct_transaction_id,
                            sct_order_status: item.sct_order_status,
                            sct_payment_method: item.sct_payment_method,
                            sct_billing_address: item.sct_billing_address,
                            sct_total_amount: item.sct_total_amount,
                            sct_sub_total: item.sct_sub_total,
                            sct_delivery_date: item.sct_delivery_date,
                            sct_document_date: item.sct_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            cmr_id: item.cmr_id,
                            remarks: item.remarks,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        itemData: [],
                    };
                      // Initialize payment data to avoid undefined errors
                    
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        sct_id: item.sct_id,
                        item_batch_number: item.item_batch_number,
                        item_id: item.item_id,
                        item_batch_quantity: item.item_batch_quantity,
                        item_exp_date:  formatDate( item.item_exp_date),                       
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_unit_price:item.item_batch_unit_price,
                        from_bin_location:item.from_bin_location,
                        item_batch_sales_rate:item.item_batch_sales_rate,
                        from_bin_id:item.from_bin_id,
                       item_batch_free_quantity:item.item_batch_free_quantity,
                       item_batch_discount_amount:item.item_batch_discount_amount,
                       item_batch_discount_percentage:item.item_batch_discount_percentage,
                       item_batch_tax_percentage :item.item_batch_tax_percentage,
                       item_batch_tax_amount :item.item_batch_tax_amount,
                       item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                       item_batch_final_sales_rate:item.item_batch_final_sales_rate
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        sct_id: item.sct_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity: item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_batch_number: item.item_batch_number,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_batch_quantity: item.item_batch_quantity,
                        srt_id: item.srt_id,
                        soit_id: item.soit_id,
                        item_exp_date: item.item_exp_date,
                        item_gst: item.item_gst,
                        item_sgst: item.item_sgst,
                        item_cgst: item.item_cgst,
                        item_igst: item.item_igst,
                        item_free_quantity:item.item_free_quantity,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                       item_manufacturer_name:item.item_manufacturer_name,
 
                        itemBatchData: [{
                            sct_id: item.sct_id,
                            item_batch_number: item.item_batch_number,
                            item_id: item.item_id,
                            item_batch_quantity: item.item_batch_quantity,
                            item_exp_date:  formatDate( item.item_exp_date),                       
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_unit_price:item.item_batch_unit_price,
                            from_bin_location:item.from_bin_location,
                            item_batch_sales_rate:item.item_batch_sales_rate,
                            from_bin_id:item.from_bin_id,
                           item_batch_free_quantity:item.item_batch_free_quantity,
                           item_batch_discount_amount:item.item_batch_discount_amount,
                           item_batch_discount_percentage:item.item_batch_discount_percentage,
                           item_batch_tax_percentage :item.item_batch_tax_percentage,
                           item_batch_tax_amount :item.item_batch_tax_amount,
                           item_batch_total_sales_rate:item.item_batch_total_sales_rate,
                           item_batch_final_sales_rate:item.item_batch_final_sales_rate
                        }]
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
            //    console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await salesOrderService.syncSalesCreditNote(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }
  

  export async function getDeliveryOrderByIdHTML(req: any, res: any) {
    try {
        const { sodtt_id } = req.query

        if (sodtt_id) {

            const orderDetailsResult = await salesOrderService.getDeliveryOrderById(sodtt_id)
            const storeDetails=await salesOrderService.getStoreDetails();
            const taxinfo=await salesOrderService.TaxInfoDN(sodtt_id);
            console.log(orderDetailsResult)
            if (orderDetailsResult.length > 0  && storeDetails.length>0) {
                console.log(orderDetailsResult, "ssssss")
                const html=await DN(orderDetailsResult,storeDetails,taxinfo);
                if(html){
                    return res.send(generateResponse(true, "Invoice fetched successfully", 200, html));
                }
                else{
                    return res.send(generateResponse(false, "Invoice not found", 400, null));
                }


                return res.send(generateResponse(true, "delivery fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "delivery not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "delivery not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesOrderInvoiceByIdHTML(req: any, res: any) {
    try {
        const { soit_id } = req.query

        if (soit_id) {

            const orderDetailsResult = await salesOrderService.getSalesOrderInvoiceById(soit_id)
            const storeDetails=await salesOrderService.getStoreDetails()
            const taxinfo=await salesOrderService.TaxInfo(soit_id);
            console.log(orderDetailsResult)
            if (orderDetailsResult.length > 0) {

                const html=await DN(orderDetailsResult,storeDetails,taxinfo,"INV");
                if(html){
                    return res.send(generateResponse(true, "Invoice fetched successfully", 200, html));
                }
                else{
                    return res.send(generateResponse(false, "Invoice not found", 400, null));
                }



                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSalesReturnInvoiceByIdHTML(req: any, res: any) {
    try {
        const { srt_id } = req.query

        if (srt_id) {

            const orderDetailsResult = await salesOrderService.getSalesReturnInvoiceById(srt_id)
            const storeDetails=await salesOrderService.getStoreDetails()
            console.log(orderDetailsResult.rows)
            const html=await ReturnInvoice(orderDetailsResult,storeDetails);
            if(html){
                return res.send(generateResponse(true, "Invoice fetched successfully", 200, html));
            }
                else{
                    return res.send(generateResponse(false, "Invoice not found", 400, null));
            }

        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}
 
