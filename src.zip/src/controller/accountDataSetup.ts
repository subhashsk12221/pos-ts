import * as accountSyncService from  '../service/accountSyncService'
export async function accountDataSetup(data:any) {

  try {
  
         const accountData = data.accountData
         if(accountData){
          const [ ]= await Promise.all([
            accountSyncService.generalaccountstableSync(accountData.general_accounts_table), 
            accountSyncService.generalaccountallocationtableSync(accountData.general_account_allocation_table),
            accountSyncService.salesaccountallocationtableSync(accountData.sales_account_allocation_table) ,
            accountSyncService.purchaseaccountallocationtableSync(accountData.purchase_account_allocation_table) ,
            accountSyncService.inventoryaccountallocationtableSync(accountData.inventory_account_allocation_table)
          ])

         }
         
      }
  
  catch (error) {
      console.log(error)
      
  }
}


export async function  asyncCustomerAccountSync(data:any) {

  try {
  
         const accountData = data.accountData
         if(accountData){
          const [ ]= await Promise.all([
            accountSyncService.generalaccountstableSync(accountData.general_accounts_table), 
            accountSyncService.generalaccountallocationtableSync(accountData.general_account_allocation_table),
            accountSyncService.salesaccountallocationtableSync(accountData.sales_account_allocation_table) ,
            accountSyncService.purchaseaccountallocationtableSync(accountData.purchase_account_allocation_table) ,
            accountSyncService.inventoryaccountallocationtableSync(accountData.inventory_account_allocation_table)
          ])

         }
         
      }
  
  catch (error) {
      console.log(error)
      
  }
}


export async function getUnSyncjournEntry() {

  try {
    
       const getGeneralAccount = await accountSyncService.getUnSyncedjournEntry()
          if (getGeneralAccount.rows.length > 0) {
              
              const groupedOrders:any = {};
            

              for (let item of getGeneralAccount.rows) {
                const orderId = item.transcation_id;

                if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                      journalEntryData: {
                        transcation_id: item.transcation_id,
                        journal_entry_no: item.journal_entry_no,
                        origin_id: item.origin_id,
                        origin_type: item.origin_type,
                        remarks: item.jrt_remarks,
                        batch_num: item.batch_num,
                        due_date: item.due_date,
                        document_date: item.document_date,
                        created_date: item.created_date,
                        update_date: item.update_date,
                    },
                    accountsData: [],
                    };
                }

                // Push item data if it doesn't already exist
              
              
                    groupedOrders[orderId].accountsData.push({
                      transcation_id: item.transcation_id,
                      account_id: item.account_id,
                      debit_amount: item.debit_amount,
                      credit_amount: item.credit_amount,
                      remarks: item.jert_remarks,
                    });
                

                // Push payment data if it doesn't already exist
                

               
            }

              // Convert grouped items to an array
            //  const resultArray: any = Object.values(groupedOrders);
              for (let orderId in groupedOrders) {
                const order = groupedOrders[orderId];
             //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
              
               

           //    console.log(JSON.stringify(order, null, 2), 'Processing Order after rrrrr');

              const syncedResult = await accountSyncService.journalEntrySync(order.journalEntryData,order.accountsData)
            }
      }
    }
  catch (error) {
      console.log(error)

  }
}

export async function getUnSyncCustomerGLAccount() {

  try {
    
       const getGeneralAccount = await accountSyncService.getUnSyncCustomerGLAccount()
          if (getGeneralAccount.length > 0) {
              
            

              // Convert grouped items to an array
            //  const resultArray: any = Object.values(groupedOrders);
              for (let item of getGeneralAccount) {
            console.log(item)
             //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
              
               

            //   console.log(JSON.stringify(item, null, 2), 'Processing Order after rrrrr');

              const syncedResult = await accountSyncService.customerGLSync(item)
            }
      }
    }
  catch (error) {
      console.log(error)

  }
}




