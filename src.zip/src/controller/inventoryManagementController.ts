import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import  * as inventoryManagementServive from '../service/inventoryManagmentService'



export async function   createWarehouse (req:any,res:any){
    try{
        const wareHouseData = req.body

        wareHouseData.warehouse_id = ulid()


            if(wareHouseData){

                const createWareHouse = await inventoryManagementServive.createWareHouse(wareHouseData)
                if(createWareHouse.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "store address added successfully", 200, createWareHouse.rows[0])
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "store address adding unsuccessfull", 400,null)
                    );
                }
            }else{
                return res.status(400).send(
                    generateResponse(false, "send correcr data", 400,null)
                );
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

export async function   addBinLocation(req:any,res:any){
    try{
        const binLocationData = req.body

     
            if(binLocationData){

                const addBinLocation = await inventoryManagementServive.addBinLocation(binLocationData)
                if(addBinLocation.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "store address added successfully", 200, addBinLocation.rows[0])
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "store address adding unsuccessfull", 400,null)
                    );
                }
            }else{
                return res.status(400).send(
                    generateResponse(false, "send correcr data", 400,null)
                );
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

function generateBinLocation(sublevel:any, from:any, to:any,separator:any) {
    let binLocations = [];

    // Generate bin locations within the range
    for (let i = from; i <= to; i++) {
        const alphanumeric = convertToAlphaNumeric(i);
        const binLocation = `${sublevel}${separator}${alphanumeric}${separator}${alphanumeric}`;
        binLocations.push(binLocation);
    }

    return binLocations;
}

function convertToAlphaNumeric(number:any) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let result = '';

    // Handle cases where number exceeds 26 (number of letters in the alphabet)
    while (number > 0) {
        const remainder = (number - 1) % 26; // Subtract 1 to start from 'A' instead of 'B'
        result = alphabet[remainder] + result;
        number = Math.floor((number - remainder) / 26);
    }

    return result;
}

export async function generateWareHouseBinLocation(req:any,res:any){
    try{

    const sublevel = req.body.sublevel
    const from = req.body.from
    const to = req.body.to
    const separator = ""
    const binLocations = generateBinLocation(sublevel, from, to, separator);

    const addSubLevelObj = {
        sublevel_id  : ulid(),
        sublevel_no : req.body.sublevel ,
        warehouse_id : req.body.warehouse_id
    }

    const addSublevel = await inventoryManagementServive.addSublevel(addSubLevelObj)
let binObj = []
    for(let i = 0; i<=binLocations.length-1;i++){
        
        const obj = {
            bin_no_id :ulid(),
            sublevel_id :addSubLevelObj.sublevel_id,
            bin_location_no :binLocations[i],
        }
        console.log(obj)
        binObj.push(obj)
    }

    const addSubLevelBin = await inventoryManagementServive.addSubLevelBin(binObj)
    if (addSubLevelBin.rows.length > 0) {
        console.log('Customers found:', addSubLevelBin.rows);
        return res.status(200).send(
            generateResponse(true, "added sublevel succesfully ", 200, addSubLevelBin.rows))
    } else {
        return res.status(400).send(
            generateResponse(false, "added sublevel unsuccessfully ", 400, null))
    }
  
}catch(error){
    console.log(error, "error");
    return res.status(400).send(generateResponse(false, error.message, 400, null));

}
}

export async function   getWarehouse(req:any,res:any){
    try{
        

                const addBinLocation = await inventoryManagementServive.getWarehouse(req.query.warehouse_id)
                if(addBinLocation.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "store address added successfully", 200, addBinLocation.rows[0])
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "store address adding unsuccessfull", 400,null)
                    );
                }
            
    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function   getNextSublevel(req:any,res:any){
    try{
        

                const addBinLocation = await inventoryManagementServive.getNextSublevel(req.query.warehouse_id)
                if(addBinLocation.rows.length>0){
                    let next_sublevel_no 
                    if(addBinLocation.rows[0].next_sublevel_no === null){
                        next_sublevel_no = 1
                    }else{
                        next_sublevel_no = addBinLocation.rows[0].next_sublevel_no
                    }

                    return res.status(200).send(
                        generateResponse(true, "fetched next sublevel successfully", 200,{next_sublevel_no:next_sublevel_no} )
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "store address adding unsuccessfull", 400,null)
                    );
                }
            
    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function   getByWareHouseCode(req:any,res:any){
    try{
        

                const getByWareHouseCode = await inventoryManagementServive.getByWareHouseCode(req.query.warehouse_code)
                if(getByWareHouseCode.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "fetched warehouse successfully", 200, getByWareHouseCode.rows)
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "fetching warehouse unsuccessfull", 400,null)
                    );
                }
            
    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function   getAllBinLocation(req:any,res:any){
    try{
        

                const getByWareHouseCode = await inventoryManagementServive.getAllBinLocation('01HTGZMBQVA5JRMJ8NHVVD2Y7P')
             //   console.log(getByWareHouseCode.rows)
                if(getByWareHouseCode.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "fetched warehouse successfully", 200, getByWareHouseCode.rows)
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "fetching warehouse unsuccessfull", 400,null)
                    );
                }
            
    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}