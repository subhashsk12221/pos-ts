import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as discountService from '../service/discountService'
import { roundValue } from '../helper/helper';
import * as customerService from '../service/customerService'
export async function addDiscount(req: any, res: any) {
    try {
        const discountObj = req.body

        discountObj.discount_slab_id = ulid()

        if (!discountObj) {
            return res.send(generateResponse(false, "discount details are  is required", 400, null));
        }

        const columns = Object.keys(discountObj);
        const values = Object.values(discountObj);

        const query = `INSERT INTO discount_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;

        const discountResult = await client.query(query, values);

        if (discountResult.rows.length > 0) {

            return res.send(
                generateResponse(true, "discount add  succesfully", 200, discountResult.rows)
            )

        } else {
            return res.send(
                generateResponse(false, "discount add  unsuccesfully", 400, null)
            )

        }

    } catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getDiscount(req: any, res: any) {
    try {

        const { totalAmountOfItem } = req.query

        console.log(totalAmountOfItem)
        if (totalAmountOfItem) {
            console.log(totalAmountOfItem, "totalAmountOfItem")
            const getdiscount = await discountService.getDiscount(totalAmountOfItem)

            if (getdiscount) {

                console.log(getdiscount, "eeeeeeeeee")

                return res.send(
                    generateResponse(true, "fetched discount and tax succesfully", 200, getdiscount)
                )

            } else {

            }
            return res.send(
                generateResponse(false, "discount is not applicable", 400, null)
            )
        }

    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addPricelist(req: any, res: any) {
    try {
        await client.query('BEGIN');
        const pricelistObj = req.body
        pricelistObj.price_list_id = ulid()


        const addPriceList = await discountService.addPricelist(pricelistObj)

        if (addPriceList.rows.length > 0) {
            const { default_base_price_list_id } = req.body
            const getallItemofPricelist = await discountService.getPricelistItems(default_base_price_list_id)
            console.log(getallItemofPricelist.rows)
            
           
            if (getallItemofPricelist.rows.length > 0) {
                const multipliedItems = getallItemofPricelist.rows.map(item => {
                    console.log(item)
                    let  item_selling_priceee
                    if(pricelistObj.is_margin_percentage){
                        
                        item_selling_priceee =    item.item_batch_final_purchase_rate +  ( item.item_batch_final_purchase_rate * pricelistObj.margin_factor / 100)
                        console.log(item_selling_priceee,item.item_batch_final_purchase_rate,pricelistObj.margin_factor)
                    }else{
                        item_selling_priceee = item.item_selling_price -  (item.item_selling_price * pricelistObj.default_factor/100)
                        console.log(item_selling_priceee,item.item_selling_price,pricelistObj.default_factor)
                    }
                    return {
                        item_id: item.item_id,
                        item_base_price: item.item_selling_price,
                        price_list_id: pricelistObj.price_list_id,
                        item_selling_price:parseFloat(item_selling_priceee).toFixed(2),
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_number:item.item_batch_number,
                        item_mrp_price :item.item_mrp_price ,
                        item_pricing_uom_id:item.item_pricing_uom_id,
                        item_pricing_uom:item.item_pricing_uom// Assuming pricelistObj.multiplying_factor contains the multiplying factor of the new price list
                    };
                    console.log( {item_id: item.item_id,
                        item_base_price: item.item_selling_price,
                        price_list_id: pricelistObj.price_list_id,
                        item_selling_price:item_selling_priceee,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_number:item.item_batch_number,
                        item_mrp_price :item.item_mrp_price })
                });
                console.log(multipliedItems, "sdddd")
                const additems = await discountService.addItems(multipliedItems)
                if (additems.rows.length > 0) {
                    await client.query('COMMIT');
                    return res.status(200).send(
                        generateResponse(true, "priclist created succesfully", 200, addPriceList.rows)
                    )
                }
            } else {
                return res.status(400).send(
                    generateResponse(false, "pricelist creation unsuccesfull", 400, null)
                )
            }

        } else {
            return res.status(400).send(
                generateResponse(false, "pricelist creation unsuccesfull", 400, null)
            )

        }
    } catch (error) {
        await client.query('ROLLBACK');
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getByIdPricelist(req: any, res: any) {
    try {

        const getpricelist = await discountService.getPricelist(req.query.price_list_id)

        if (getpricelist.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "fetched priclist succesfully", 200, getpricelist.rows[0])
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "fetching priclist unsuccesfull", 400, null)
            )


        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getAllPricelist(req: any, res: any) {
    try {

        const getPriceList = await discountService.getAllPricelist(req.query)

        if (getPriceList.getPricelist.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "fetched priclist succesfully", 200, { pricelist: getPriceList.getPricelist.rows, totalCount: getPriceList.totalCount.rows[0].count })
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "fetching priclist unsuccesfull", 400, null)
            )


        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addItems(req: any, res: any) {
    try {

        const { itemData: itemData } = req.body
        console.log(itemData)

        const addItems = await discountService.addItems(itemData)

        if (addItems.rows.length > 0) {



            return res.status(200).send(
                generateResponse(true, "items added succesfully", 200, addItems.rows)
            )

        } else {

        }
        return res.status(400).send(
            generateResponse(false, "adding items unsuccesfull", 400, null)
        )

    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

// export async function  getPricelistItems(req: any, res: any) {
//     try {



//                     const getPriceList = await discountService.getPricelistItems(req.query)
//                     if(getPriceList.rows.length>0){
//                         return res.status(200).send(
//                            generateResponse(true, "fetched priclist succesfully", 200,getPriceList.rows)
//                        )

//                }else{
//                 return res.status(400).send(
//                     generateResponse(false, "fetching priclist unsuccesfull", 400, null)
//                 )

//                        }
//                     }
//                     else{
//                         return res.status(400).send(
//                             generateResponse(false, "price_list_id is required", 400, null)
//                         )

//                   }


//     }catch(error){
//         console.log(error)
//         return res.send(generateResponse(false, error.message, 400, null));
//     }
// }

export async function updatePricelist(req: any, res: any) {
    try {

        const pricelistObj = req.body
        const price_list_id = req.body.price_list_id


        const updatePriceList = await discountService.updatePriceList(price_list_id, pricelistObj)


        if (updatePriceList.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "priclist updated succesfully", 200, updatePriceList.rows)
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "pricelist updated unsuccesfull", 400, null)
            )

        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function deletePricelist(req: any, res: any) {
    try {

        const pricelistObj = req.body
        const price_list_id = req.body.price_list_id

        const deletePriceList = await discountService.deletePriceList(price_list_id)


        if (deletePriceList.rows.length === 0) {

            return res.status(200).send(
                generateResponse(true, "priclist delete succesfully", 200, null)
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "pricelist delete unsuccesfull", 400, null)
            )

        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}
export async function updateItemsofPricelist(req: any, res: any) {
    try {
        await client.query('BEGIN');
        const { itemData: itemData } = req.body
        let updatedObj = []
        if (itemData) {
            for (let item of itemData) {
                const { item_id, price_list_id } = item
             
                    const updateitem = await discountService.updateitem(item_id, price_list_id, item)
                    updatedObj.push(updateitem.rows)
              

                }
            
            if (updatedObj.length > 0) {
                await client.query('COMMIT');
                return res.status(200).send(
                    generateResponse(true, "contact details updated succesfully", 200, updatedObj)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "contact detail update unsuccesfully", 400, null)
                )
            }
        }

    } catch (error) {
        console.log(error)
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getSelectedItems(req: any, res: any) {
    try {
        const [getitemsList, getpricelist] = await Promise.all([discountService.getSelectedItems(req.query), discountService.getPricelistById(req.query.price_list_id)
        ])
        let roundedItemsList
        if (getitemsList.result.rows.length > 0) {
            roundedItemsList = getitemsList.result.rows.map(item => ({
                ...item,
                item_selling_price: roundValue(item.item_selling_price, item.rounding_method, item.rounding_rule),
                // Add other properties to round if needed
            }));
        }


        if (roundedItemsList) {
            return res.status(200).send(
                generateResponse(true, "fetched items succesfully", 200, { itemslist: roundedItemsList, totalCount: getitemsList.totalCount, pricelist: getpricelist.rows[0] }
                ))

        } else {
            return res.status(400).send(
                generateResponse(false, "fetching items unsuccesfull", 400, null)
            )

        }



    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}



export async function addPeriodDiscountItems(req: any, res: any) {
    try {
        const { itemData: itemData } = req.body
        console.log(itemData)

        const addItems = await discountService.addPeriodDiscountItems(itemData)

        if (addItems.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "items added succesfully", 200, addItems.rows)
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "adding items unsuccesfull", 400, null)
            )

        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updatePeriodDiscountItems(req: any, res: any) {
    try {
        const { itemData: itemData } = req.body
        console.log(itemData)
        let updatedObj = []

        if (itemData) {
            for (let item of itemData) {
                const { item_id } = item
                if (item_id) {
                    const updatePayaddress = await discountService.updatePeriodDiscountItems(item_id, item)
                    console.log(updatePayaddress.rows)
                    if (updatePayaddress.rows.length > 0) {
                        updatedObj.push(updatePayaddress.rows)
                    }
                }
            }


            if (updatedObj.length > 0) {
                return res.status(200).send(
                    generateResponse(true, "items updated succesfully", 200, updatedObj)
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "updatec items unsuccesfull", 400, null)
                )

            }
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPeriodDiscountItems(req: any, res: any) {
    try {

        const getPeriodDiscountItems = await discountService.getPeriodDiscountItems(req.query)
        if (getPeriodDiscountItems.getPeriodDiscountItems.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "fetched period discounted items succesfully", 200, { periodDiscountItems: getPeriodDiscountItems.getPeriodDiscountItems.rows, totalCount: getPeriodDiscountItems.totalCount.rows[0].count })
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "fetching period discounted items unsuccesfull", 400, null)
            )
        }

    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getpricelistWithoutPageniation(req: any, res: any) {
    try {

        const getPriceList = await discountService.getpricelistWithoutPageniation()

        if (getPriceList.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "fetched priclist succesfully", 200, getPriceList.rows)
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "fetching priclist unsuccesfull", 400, null)
            )


        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}



export async function addItemsGroup(req: any, res: any) {
    try {
      //  await client.query('BEGIN');
        let discount_group_id: any
        let newItemsGroupData
        const { DiscountGroupData: DiscountGroupData, ItemGroupData: ItemGroupData } = req.body;
        const {customer_group_id} = DiscountGroupData
         const getDiscountGroup = await discountService.getDiscountGroup(DiscountGroupData);

        if (getDiscountGroup.rows.length > 0) {
            discount_group_id = getDiscountGroup.rows[0].discount_group_id
            newItemsGroupData = ItemGroupData.map((item: any) => ({
                ...item,
                discount_group_id: discount_group_id
            }));
            const updateDiscount = await discountService.updateDiscountGroup(discount_group_id, DiscountGroupData)
        } else {
            
            DiscountGroupData.discount_group_id = ulid();
            const addDiscountGroup = await discountService.addDiscountGroup(DiscountGroupData);
console.log(addDiscountGroup.rows)
            if (addDiscountGroup.rows.length > 0) {
                discount_group_id = DiscountGroupData.discount_group_id;
                newItemsGroupData = ItemGroupData.map((item: any) => ({
                    ...item,
                    discount_group_id: discount_group_id
                }));
            }
       }

        const existingItemsResult = await discountService.existingItemsGroupResult(customer_group_id)

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const updatedItem = ItemGroupData.find((item: { item_group_id: any; }) => item.item_group_id === existingItem.item_group_id);

            if (updatedItem) {
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await discountService.updatedItemGroup(updatedItem, updatedItem.item_group_id, customer_group_id)
                itemResults.push(updateItemResult.rows);

            } else {
                // Item does not exist in the updated itemData, construct the query to remove it
                const removeItemResult = await discountService.removeItemGroup(existingItem.item_group_id, customer_group_id)
            }
        }
       

        // Check for new items to be added
        const newItems = ItemGroupData.filter((item: { item_group_id: any; }) => !existingItems.find(existingItem => existingItem.item_group_id === item.item_group_id));
    
        // Iterate through new items 
        for (const newItem of newItems) {
            // Construct the field names for tche INSERT query
            console.log(customer_group_id,'customer_group_id')
            newItem.customer_group_id = customer_group_id
            console.log(newItem,"vvv")
            const addItemResult = await discountService.addItemGroupData(newItem);

            itemResults.push(addItemResult.rows);
        }
        console.log(itemResults, "itemResults")
        if (itemResults.length > 0) {

            return res.status(200).send({
                success: true,
                message: "item group saved successfully",
                data: itemResults
            });
        } else {

            return res.status(400).send({
                success: false,
                message: "Pricelist creation unsuccessful",
                data: null
            });
        }
    } catch (error) {
      
        console.error("An error occurred:", error);
        return res.status(400).send({
            success: false,
            message: error.message,
            data: null
        });
    }
}


export async function addItemGroupTable(req: any, res: any) {
    try {


        const additemgroupTable = req.body
        additemgroupTable.item_group_id = ulid()


        const addItemGroupData = await discountService.addItemGroupTable(additemgroupTable)

        if (addItemGroupData.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "itemGroup created succesfully", 200, addItemGroupData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "itemGroup creation unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getItemsGroupTable(req: any, res: any) {
    try {

        const getItemGroupData = await discountService.getItemGroupTable()

        if (getItemGroupData.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "itemGroup created succesfully", 200, getItemGroupData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "itemGroup creation unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function addManufacturesGroup(req: any, res: any) {
    try {


        const addManufactureTable = req.body
        addManufactureTable.manufacture_group_id = ulid()


        const addManufacturesGroup = await discountService.addManufacturesGroup(addManufactureTable)

        if (addManufacturesGroup.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "itemGroup created succesfully", 200, addManufacturesGroup.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "itemGroup creation unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getManufacturesGroup(req: any, res: any) {
    try {

        const getItemGroupData = await discountService.getManufacturesGroup()

        if (getItemGroupData.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "itemGroup created succesfully", 200, getItemGroupData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "itemGroup creation unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function addCustomerGroup(req: any, res: any) {
    try {


        const addCustomerGroupObj = req.body
        addCustomerGroupObj.customer_group_id = ulid()


        const addCustomerGroup = await discountService.addCustomerGroup(addCustomerGroupObj)

        if (addCustomerGroup.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "CustomerGroup created succesfully", 200, addCustomerGroup.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "customerGroup creation unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getCustomerGroup(req: any, res: any) {
    try {

        const getCustomerGroupData = await discountService.getCustomerGroup()

        if (getCustomerGroupData.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "fetched customergroup succesfully", 200, getCustomerGroupData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "fetched customergroup unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function addDiscountType(req: any, res: any) {
    try {


        const addDiscountTypeObj = req.body
        addDiscountTypeObj.discount_type_id = ulid()


        const addDiscountType = await discountService.addDiscountType(addDiscountTypeObj)

        if (addDiscountType.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "discounttype created succesfully", 200, addDiscountType.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "discounttype creation unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getDiscountType(req: any, res: any) {
    try {

        const getCustomerGroupData = await discountService.getDiscountType()

        if (getCustomerGroupData.rows.length > 0) {

            return res.status(200).send(
                generateResponse(true, "fetched discounttype succesfully", 200, getCustomerGroupData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "fetched discounttype unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getDiscountGroupByCustomer(req: any, res: any) {
    try {

        const { discount_type_id, customer_group_id, requestTab } = req.query

        let response: any

        if (requestTab === 'itemsGroupTab') {
            const result = await discountService.getitemsGroup(customer_group_id)
            if (result.rows.length > 0) {
                const groupedRows: { [key: string]: any } = {}; // Using 'any' temporarily
                result.rows.forEach(row => {
                    const discountGroupId = row.discount_group_id;
                    if (!groupedRows[discountGroupId]) {
                        groupedRows[discountGroupId] = {
                            discount_group_id: row.discount_group_id,
                            discount_type_id: row.discount_type_id,
                            customer_group_id: row.customer_group_id,
                            from_date: row.from_date,
                            to_date: row.to_date,
                            is_active: row.is_active,
                            item_groups: []
                        };
                    }
                    // Add the item group to the respective discount group
                    (groupedRows[discountGroupId].item_groups as any[]).push({
                        item_group_name: row.name,
                        update_date: row.update_date,
                        created_date: row.created_date,
                        item_group_id: row.item_group_id,
                        discount_percentage: row.discount_percentage
                    });
                });

                // Convert grouped rows to an array
                const formattedResponse = Object.values(groupedRows);


                response = formattedResponse
            }

        } else if (requestTab === 'manufactureTab') {
            const result = await discountService.getDiscountManufacturesGroup( customer_group_id)
            console.log(result.rows)
            if (result.rows.length > 0) {
                const groupedRows: { [key: string]: any } = {}; // Using 'any' temporarily
                result.rows.forEach(row => {
                    const discountGroupId = row.discount_group_id;
                    if (!groupedRows[discountGroupId]) {
                        groupedRows[discountGroupId] = {
                            discount_group_id: row.discount_group_id,
                            discount_type_id: row.discount_type_id,
                            customer_group_id: row.customer_group_id,
                            from_date: row.from_date,
                            to_date: row.to_date,
                            is_active: row.is_active,
                            manufacture_groups: []
                        };
                    }
                    // Add the item group to the respective discount group
                    (groupedRows[discountGroupId].manufacture_groups as any[]).push({
                        manufacture_group_name: row.name,
                        update_date: row.update_date,
                        created_date: row.created_date,
                        manufacture_group_id: row.manufacture_group_id,
                        discount_percentage: row.discount_percentage
                    });
                });

                // Convert grouped rows to an array
                const formattedResponse = Object.values(groupedRows);


                response = formattedResponse
            }

        } else if (requestTab === 'itemsTab') {
            const result = await discountService.getDiscountGroupItems(discount_type_id, customer_group_id)
            if (result.rows.length > 0) {
                const groupedRows: { [key: string]: any } = {}; // Using 'any' temporarily
                result.rows.forEach(row => {
                    const discountGroupId = row.discount_group_id;
                    if (!groupedRows[discountGroupId]) {
                        groupedRows[discountGroupId] = {
                            discount_group_id: row.discount_group_id,
                            discount_type_id: row.discount_type_id,
                            customer_group_id: row.customer_group_id,
                            from_date: row.from_date,
                            to_date: row.to_date,
                            is_active: row.is_active,
                            items: []
                        };
                    }
                    // Add the item group to the respective discount group
                    (groupedRows[discountGroupId].items as any[]).push({
                        item_name: row.item_name,
                        item_code: row.item_code,
                        update_date: row.update_date,
                        created_date: row.created_date,
                        item_id: row.item_id,
                        discount_percentage: row.discount_percentage
                    });
                });

                // Convert grouped rows to an array
                const formattedResponse = Object.values(groupedRows);


                response = formattedResponse

            }
        }

        console.log(response)
        if (response) {

            return res.status(200).send(
                generateResponse(true, "fetched data succesfully", 200, response)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "fetched discounttype unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function addDiscountManufactureGroup(req: any, res: any) {
    try {
        await client.query('BEGIN');
        let discount_group_id: any
        let newItemsGroupData
        const { DiscountGroupData: DiscountGroupData, ManufactureGroupData: ManufactureGroupData } = req.body;
        const {customer_group_id} = DiscountGroupData
        const getDiscountGroup = await discountService.getDiscountGroup(DiscountGroupData);
        if (getDiscountGroup.rows.length > 0) {
            discount_group_id = getDiscountGroup.rows[0].discount_group_id
            newItemsGroupData = ManufactureGroupData.map((item: any) => ({
                ...item,
                discount_group_id: discount_group_id
            }));
            const updateDiscount = await discountService.updateDiscountGroup(discount_group_id, DiscountGroupData)
        } else {
            DiscountGroupData.discount_group_id = ulid();
            const addDiscountGroup = await discountService.addDiscountGroup(DiscountGroupData);

            if (addDiscountGroup.rows.length > 0) {
                discount_group_id = DiscountGroupData.discount_group_id;
                newItemsGroupData = ManufactureGroupData.map((item: any) => ({
                    ...item,
                    discount_group_id: discount_group_id
                }));
            }
        }

        const existingItemsResult = await discountService.existingManufactureGroupResult(customer_group_id)

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const updatedItem = ManufactureGroupData.find((item: { manufacture_group_id: any; }) => item.manufacture_group_id === existingItem.manufacture_group_id);

            if (updatedItem) {
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await discountService.updatedManufactureGroup(updatedItem, updatedItem.manufacture_group_id, customer_group_id)
                itemResults.push(updateItemResult.rows);

            } else {
                // Item does not exist in the updated itemData, construct the query to remove it
                const removeItemResult = await discountService.removeManufactureGroup(existingItem.manufacture_group_id, customer_group_id)
            }
        }

        // Check for new items to be added
        const newItems = ManufactureGroupData.filter((item: { manufacture_group_id: any; }) => !existingItems.find(existingItem => existingItem.manufacture_group_id === item.manufacture_group_id));

        // Iterate through new items 
        for (const newItem of newItems) {
            console.log(newItem)
            // Construct the field names for the INSERT query
            newItem.customer_group_id = customer_group_id
            const addItemResult = await discountService.addManufactureGroupData(newItem);

            itemResults.push(addItemResult.rows);
        }
        console.log(itemResults, "itemResults")
        if (itemResults.length > 0) {
            await client.query('COMMIT');
            return res.status(200).send({
                success: true,
                message: "manufacture group saved successfully",
                data: itemResults
            });
        } else {
            await client.query('ROLLBACK');
            return res.status(400).send({
                success: false,
                message: "manufacture group save unsuccessful",
                data: null
            });
        }
    } catch (error) {
        await client.query('ROLLBACK');
        console.error("An error occurred:", error);
        return res.status(400).send({
            success: false,
            message: error.message,
            data: null
        });
    }
}

export async function addDiscountGroupItems(req: any, res: any) {
    try {
        await client.query('BEGIN');
        let discount_group_id: any
        let newItemsGroupData
        const { DiscountGroupData: DiscountGroupData, ItemsData: ItemsData } = req.body;
        const {customer_group_id} = DiscountGroupData
        const getDiscountGroup = await discountService.getDiscountGroup(DiscountGroupData);
        if (getDiscountGroup.rows.length > 0) {
            discount_group_id = getDiscountGroup.rows[0].discount_group_id
            newItemsGroupData = ItemsData.map((item: any) => ({
                ...item,
                discount_group_id: discount_group_id
            }));
            const updateDiscount = await discountService.updateDiscountGroup(discount_group_id, DiscountGroupData)
        } else {
            DiscountGroupData.discount_group_id = ulid();
            const addDiscountGroup = await discountService.addDiscountGroup(DiscountGroupData);

            if (addDiscountGroup.rows.length > 0) {
                discount_group_id = DiscountGroupData.discount_group_id;
                newItemsGroupData = ItemsData.map((item: any) => ({
                    ...item,
                    discount_group_id: discount_group_id
                }));
            }
        }

        const existingItemsResult = await discountService.existingDiscountGroupItems(customer_group_id)

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const updatedItem = newItemsGroupData.find((item: { item_id: any; }) => item.item_id === existingItem.item_id);
            console.log(updatedItem)
            if (updatedItem) {
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await discountService.updatedDiscountGroupItems(updatedItem, updatedItem.item_id, customer_group_id)
                itemResults.push(updateItemResult.rows);

            } else {
                // Item does not exist in the updated itemData, construct the query to remove it
                const removeItemResult = await discountService.removeDiscountGroupItems(existingItem.item_id, customer_group_id)
            }
        }

        // Check for new items to be added
        const newItems = newItemsGroupData.filter((item: { item_id: any; }) => !existingItems.find(existingItem => existingItem.item_id === item.item_id));

        // Iterate through new items 
        for (const newItem of newItems) {
            console.log(newItem)
            // Construct the field names for the INSERT query
            const addItemResult = await discountService.addDiscountGroupItems(newItem);

            itemResults.push(addItemResult.rows);
        }
        console.log(itemResults, "itemResults")
        if (itemResults.length > 0) {
            await client.query('COMMIT');
            return res.status(200).send({
                success: true,
                message: "items saved successfully",
                data: itemResults
            });
        } else {
            await client.query('ROLLBACK');
            return res.status(400).send({
                success: false,
                message: "items group save unsuccessful",
                data: null
            });
        }
    } catch (error) {
        await client.query('ROLLBACK');
        console.error("An error occurred:", error);
        return res.status(400).send({
            success: false,
            message: error.message,
            data: null
        });
    }
}

export async function getDiscountGroupSelectedItems(req: any, res: any) {
    try {
        const [getSelectItems, getItemsFromDiscount] = await Promise.all([discountService.getSelectedItemsFromStoreInvetory(req.query), discountService.getDiscountGroupItems(req.query.discount_type_id, req.query.customer_group_id)
        ])

        const itemInDiscountGroup = getItemsFromDiscount.rows.map(item => item.item_id);

        // Filter out items from the store inventory that are not in the discount group
        const itemsNotInDiscountGroup = getSelectItems.rows.filter(item => !itemInDiscountGroup.includes(item.item_id));
        if (itemsNotInDiscountGroup.length > 0) {
            return res.status(200).send(
                generateResponse(true, "fetched items succesfully", 200, itemsNotInDiscountGroup))
        } else {
            return res.status(400).send(
                generateResponse(false, "fetching items unsuccesfull", 400, null)
            )

        }


    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addPeriodAndVolumeItems(req: any, res: any) {
    try {
        await client.query('BEGIN');
        let price_list_id: any
        let newItemsGroupData
        const { priceListData: priceListData, ItemsData: ItemsData } = req.body;

        const getDiscountGroup = await discountService.getPeriodAndVolumeDiscountOfPriceList(priceListData.price_list_id);
        if (getDiscountGroup.rows.length > 0) {
            price_list_id = getDiscountGroup.rows[0].price_list_id
            newItemsGroupData = ItemsData.map((item: any) => ({
                ...item,
                price_list_id: price_list_id
            }));
            const updateDiscount = await discountService.updatePeriodAndVolumePriclist(price_list_id, priceListData)
        } else {
            const addPeriodAndVoulmeItems = await discountService.addPeriodAndVolumePricelist(priceListData);

            if (addPeriodAndVoulmeItems.rows.length > 0) {
                price_list_id = addPeriodAndVoulmeItems.rows[0].price_list_id
                newItemsGroupData = ItemsData.map((item: any) => ({
                    ...item,
                    price_list_id: price_list_id
                }));
            }
        }

        const existingItemsResult = await discountService.existingPeriodAndVoulmeItems(price_list_id)

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            console.log(existingItem)
            // Check if the existing item is in the updated itemData
            const updatedItem = newItemsGroupData.find((item: { item_id: any; }) => item.item_id === existingItem.item_id);
            console.log(updatedItem)
            if (updatedItem) {
                console.log(updatedItem, "eeeee")
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await discountService.updatedPeriodAndVoulmeItems(updatedItem, updatedItem.item_id, price_list_id)
                itemResults.push(updateItemResult.rows);

            } else {
                // Item does not exist in the updated itemData, construct the query to remove it
                const removeItemResult = await discountService.removePeriodAndVoulmeItems(existingItem.item_id, price_list_id)
            }
        }

        // Check for new items to be added

        const newItems = newItemsGroupData.filter((item: { item_id: any; }) => !existingItems.find(existingItem => existingItem.item_id === item.item_id));

        // Iterate through new items 
        for (const newItem of newItems) {
            console.log(newItem)
            newItem.period_discount_item_id = ulid()
            // Construct the field names for the INSERT query
            const addItemResult = await discountService.addPeriodAndVolumeItems(newItem);
            if (addItemResult.rows.length > 0) {
                let itemDataObj = {
                    period_validity_id: ulid(),
                    period_discount_item_id: addItemResult.rows[0].period_discount_item_id
                }
                const addPeriodValidity = await discountService.addPeriodItems(itemDataObj);
            }
            itemResults.push(addItemResult.rows);
        }
        console.log(itemResults, "itemResults")
        if (itemResults.length > 0) {
            await client.query('COMMIT');
            return res.status(200).send({
                success: true,
                message: "items saved successfully",
                data: itemResults
            });
        } else {
            await client.query('ROLLBACK');
            return res.status(400).send({
                success: false,
                message: "items  save unsuccessful",
                data: null
            });
        }
    } catch (error) {
        await client.query('ROLLBACK');
        console.error("An error occurred:", error);
        return res.status(400).send({
            success: false,
            message: error.message,
            data: null
        });
    }
}

export async function getPeriodAndVolumeselecteditems(req: any, res: any) {
    try {
        const [getSelectItems, getItemsFromPeriodAndVolume] = await Promise.all([discountService.getPeriodAndVolumeSelectedItems(req.query), discountService.existingPeriodAndVoulmeItems(req.query.price_list_id)
        ])

        const itemInDiscountGroup = getItemsFromPeriodAndVolume.rows.map(item => item.item_id);

        // Filter out items from the store inventory that are not in the discount group
        const itemsNotInDiscountGroup = getSelectItems.rows.filter(item => !itemInDiscountGroup.includes(item.item_id));
        if (itemsNotInDiscountGroup.length > 0) {
            return res.status(200).send(
                generateResponse(true, "fetched items succesfully", 200, itemsNotInDiscountGroup))
        } else {
            return res.status(400).send(
                generateResponse(false, "fetching items unsuccesfull", 400, null)
            )

        }


    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getPeriodAndVolumePricelistItems(req: any, res: any) {
    try {
        const result = await discountService.getPeriodAndVolumePricelistItems(req.query)
        console.log(result.rows)
        let response
        if (result.rows.length > 0) {
            const groupedRows: { [key: string]: any } = {}; // Using 'any' temporarily
            result.rows.forEach(row => {
                const discountGroupId = row.discount_group_id;
                if (!groupedRows[discountGroupId]) {
                    groupedRows[discountGroupId] = {
                        price_list_name: row.price_list_name,
                        price_list_id: row.price_list_id,
                        from_date: row.from_date,
                        to_date: row.to_date,
                        items: []
                    };
                }
                // Add the item group to the respective discount group
                (groupedRows[discountGroupId].items as any[]).push({
                    period_discount_item_id: row.period_discount_item_id,
                    item_id: row.item_id,
                    item_code: row.item_code,
                    item_name: row.item_name,
                    item_base_price: row.item_base_price,
                    item_selling_price: row.item_selling_price,
                    base_price_list: row.base_price_list,
                    default_factor: row.default_factor,
                    discount_percentage: row.discount_percentage,
                    update_date: row.update_date,
                    created_date: row.created_date,
                    item_inventory_uom: row.item_inventory_uom,
                    item_pricing_uom: row.item_pricing_uom
                });
            });

            // Convert grouped rows to an array
            const formattedResponse = Object.values(groupedRows);


            response = formattedResponse
        }
        if (response) {
            return res.status(200).send(
                generateResponse(true, "fetched items succesfully", 200, response))
        } else {
            return res.status(400).send(
                generateResponse(false, "fetching items unsuccesfull", 400, null)
            )

        }


    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function addItemPeriod(req: any, res: any) {
    try {
        await client.query('BEGIN');

        const { itemPeriodData } = req.body;

        const period_discount_item_id = itemPeriodData[0].period_discount_item_id;

        const existingItemsResult = await discountService.existingItemPeriod(period_discount_item_id);

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const updatedItem = itemPeriodData.find((item: { period_validity_id: any; }) => item.period_validity_id === existingItem.period_validity_id);
            if (updatedItem) {
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await discountService.updatedItemPeriod(updatedItem, updatedItem.period_validity_id);
                itemResults.push(updateItemResult.rows);
            } else {
                // Item does not exist in the updated itemData, construct the query to remove it
                const removeItemResult = await discountService.removeItemPeriod(existingItem.period_validity_id);
                itemResults.push(removeItemResult.rows);
            }
        }

        // Check for new items to be added
        const newItems = itemPeriodData.filter((item: { period_validity_id: any; }) => !existingItems.find(existingItem => existingItem.period_validity_id === item.period_validity_id));

        // Iterate through new items
        for (const newItem of newItems) {
            // Generate period_validity_id for new item
            newItem.period_validity_id = ulid();
            // Construct the field names for the INSERT query
            const addItemResult = await discountService.addPeriodItems(newItem);

            itemResults.push(addItemResult.rows);
        }

        if (itemResults.length > 0) {
            await client.query('COMMIT');
            return res.status(200).send({
                success: true,
                message: "Items saved successfully",
                data: itemResults
            });
        } else {
            await client.query('ROLLBACK');
            return res.status(400).send({
                success: false,
                message: "Items save unsuccessful",
                data: null
            });
        }
    } catch (error) {
        await client.query('ROLLBACK');
        console.error("An error occurred:", error);
        return res.status(400).send({
            success: false,
            message: error.message,
            data: null
        });
    }
}


export async function addItemVolume(req: any, res: any) {
    try {
        await client.query('BEGIN');

        const { itemVolumeData } = req.body;

        const period_validity_id = itemVolumeData[0].period_validity_id;

        const existingItemsResult = await discountService.existingItemVolume(period_validity_id);

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const updatedItem = itemVolumeData.find((item: { volume_validity_id: any; }) => item.volume_validity_id === existingItem.volume_validity_id);
            if (updatedItem) {
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await discountService.updatedItemVolume(updatedItem, updatedItem.volume_validity_id);
                itemResults.push(updateItemResult.rows);
            } else {
                // Item does not exist in the updated itemData, construct the query to remove it
                const removeItemResult = await discountService.removeItemVoulme(existingItem.volume_validity_id);
                itemResults.push(removeItemResult.rows);
            }
        }

        // Check for new items to be added
        const newItems = itemVolumeData.filter((item: { volume_validity_id: any; }) => !existingItems.find(existingItem => existingItem.volume_validity_id === item.volume_validity_id));

        // Iterate through new items
        for (const newItem of newItems) {
            // Generate period_validity_id for new item
            newItem.volume_validity_id = ulid();
            // Construct the field names for the INSERT query
            const addItemResult = await discountService.addItemVolume(newItem);
            itemResults.push(addItemResult.rows);
        }

        if (itemResults.length > 0) {
            await client.query('COMMIT');
            return res.status(200).send({
                success: true,
                message: "Items saved successfully",
                data: itemResults
            });
        } else {
            await client.query('ROLLBACK');
            return res.status(400).send({
                success: false,
                message: "Items save unsuccessful",
                data: null
            });
        }
    } catch (error) {
        await client.query('ROLLBACK');
        console.error("An error occurred:", error);
        return res.status(400).send({
            success: false,
            message: error.message,
            data: null
        });
    }
}


export async function getItemPeriod(req: any, res: any) {
    try {

        const getItemPeriod = await discountService.getItemPeriod(req.query.period_discount_item_id)
        console.log(getItemPeriod.rows)
        let response
        if (getItemPeriod.rows.length > 0) {
            if (getItemPeriod.rows.length > 0) {
                const groupedRows: { [key: string]: any } = {}; // Using 'any' temporarily
                getItemPeriod.rows.forEach(row => {
                    const period_validity_id = row.period_validity_id;
                    if (!groupedRows[period_validity_id]) {
                        groupedRows[period_validity_id] = {
                            period_validity_id: row.period_validity_id,
                            period_discount_item_id: row.period_discount_item_id,
                            from_date: row.from_date,
                            to_date: row.to_date,
                            effective_price: row.effective_price,
                            discount_percentage: row.discount_percentage,
                            update_date: row.update_date,
                            created_date: row.created_date,
                            item_selling_price: row.item_selling_price,
                            itemVolumeData: []
                        };
                    }
                    // Add the item group to the respective discount group
                    (groupedRows[period_validity_id].itemVolumeData as any[]).push({
                        volume_effective_price: row.volume_effective_price,
                        volume_discount_percentage: row.volume_discount_percentage,
                        item_quantity: row.item_quantity,
                        volume_validity_id: row.volume_validity_id
                    });
                });

                // Convert grouped rows to an array
                const formattedResponse = Object.values(groupedRows);


                response = formattedResponse
            }
            if (response){
                return res.status(200).send(
                    generateResponse(true, "fetched period discount succesfully", 200, response)
                )

        } else {
            const getItemPeriod = await discountService.getSellingPriceofItem(req.query.period_discount_item_id)
            return res.status(400).send(
                generateResponse(false, "fetching period discount unsuccesfull", 400, getItemPeriod.rows)
            )


        }
    } 
}catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getItemVolume(req: any, res: any) {
    try {

        const getItemVolume = await discountService.getItemVolume(req.query.period_validity_id)

        if (getItemVolume.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "fetched volume discount succesfully", 200, getItemVolume.rows)
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "fetching volume discount unsuccesfull", 400, null)
            )


        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}




export async function addItemPeriodAndVolume(req: any, res: any) {

    try {

        const { itemPeriodData } = req.body;
        const period_discount_item_id = itemPeriodData[0].period_discount_item_id;

        const existingItemsResult = await discountService.existingItemPeriod(period_discount_item_id);

        const existingItems = existingItemsResult.rows;

        // Handle items

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const removeItem = itemPeriodData.find((item: { period_validity_id: any; }) => item.period_validity_id !== existingItem.period_validity_id);
            if (removeItem) {
                // Item exists, construct the SET clause for updating the item
                // Item does not exist in the updated itemData, construct the query to remove it
                console.log(removeItem)
                const removeItemVolume = await discountService.removeItemVoulmeByperiodValidityId(existingItem.period_validity_id)
                const removeItemResult = await discountService.removeItemPeriod(existingItem.period_validity_id);
        
            }
        }
        let response = []
        
        for (const itemData of itemPeriodData) {
            const { itemVolumeData } = itemData;
            let itemDataObj = {
                period_validity_id: itemData.period_validity_id || ulid(), // Assign ulid() if period_validity_id is not provided
                period_discount_item_id: itemData.period_discount_item_id,
                from_date: itemData.from_date,
                to_date: itemData.to_date,
                discount_percentage: itemData.discount_percentage,
                effective_price: itemData.effective_price
            };

            const existingItem = await discountService.getItemPeriodValidity(itemDataObj.period_validity_id);
            if (existingItem.rows.length === 0) {
                const addPeriodValidity = await discountService.addPeriodItems(itemDataObj);
                response.push(addPeriodValidity.rows)
            } else  {
                const updateItemResult = await discountService.updatedItemPeriod(itemDataObj, itemDataObj.period_validity_id);
                response.push(updateItemResult.rows)
            } 
            const existingItemsResult = await discountService.existingItemVolume(itemDataObj.period_validity_id);

            const existingItems = existingItemsResult.rows;

            // Handle items
            const itemResults = [];
            if(itemVolumeData.length>0){
            const newitemVolumeData = itemVolumeData.map((item: any) => ({
                ...item,
                period_validity_id: itemDataObj.period_validity_id
            }));
            // Iterate through existing items to check for updates or removals
            for (const existingItem of existingItems) {

                // Check if the existing item is in the updated itemData
                const updatedItem = newitemVolumeData.find((item: { volume_validity_id: any; }) => item.volume_validity_id === existingItem.volume_validity_id);
                if (updatedItem) {
                    // Item exists, construct the SET clause for updating the item
                    console.log(updatedItem)
                    const updateItemResult = await discountService.updatedItemVolume(updatedItem, updatedItem.volume_validity_id);

                } else {
                    // Item does not exist in the updated itemData, construct the query to remove it
                    console.log(existingItem)
                    const removeItemResult = await discountService.removeItemVoulme(existingItem.volume_validity_id);

                }
            }

            // Check for new items to be added
            const newItems = newitemVolumeData.filter((item: { volume_validity_id: any; }) => !existingItems.find(existingItem => existingItem.volume_validity_id === item.volume_validity_id));

            // Iterate through new items
            for (const newItem of newItems) {
                console.log(newItem, "newItem")
                // Generate period_validity_id for new item
                newItem.volume_validity_id = ulid();
                // Construct the field names for the INSERT query
                const addItemResult = await discountService.addItemVolume(newItem);
                itemResults.push(addItemResult.rows);
            }
        }


        }

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals


        if (response.length > 0) {
            return res.status(200).send(
                generateResponse(true, "period and volume validity saved succesfully", 200, response)
            )

        } else {
            return res.status(400).send(
                generateResponse(false, "period and volume validity saved unsuccesfull", 400, null)
            )


        }

    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }

}

export async function getItemDiscount(req: any, res: any) {
    try {
        const { item_id, item_quantity,totalAmountOfItem, cmr_phone_number,batchNumber } = req.query
        let price_list_id 
        let resultObj
        let discount_percentage :any = 0
        let  discountAmount = 0
        let cmr_group_id 
        
        const findPricelistOfCustomer  = await customerService.findCustomerByPhoneNumber(cmr_phone_number)
        if(findPricelistOfCustomer.rows.length>0){
            price_list_id = findPricelistOfCustomer.rows[0].price_list_id
            cmr_group_id = findPricelistOfCustomer.rows[0].cmr_group_id
            // discount_percentage  = 10
            // discountAmount = (totalAmountOfItem * discount_percentage) / 100
        }
        console.log(price_list_id)
        const[ getItemDiscount,getItemPricelistDiscount,taxResult,discountgroup] = await Promise.all([discountService.getItemDiscount(price_list_id, item_id,batchNumber),discountService.getItemPricelistDiscount(price_list_id, item_id,batchNumber) ,discountService.getTaxAmount(item_id),discountService.getGroupDiscount(cmr_group_id,item_id)])
        console.log(getItemDiscount?.rows,taxResult.rows, discountgroup ,"weee")
     if(discountgroup.discount_group_apply)   {
        discount_percentage = discountgroup.discount_percentage
     }else if (getItemDiscount.rows.length > 0) {
            console.log(getItemDiscount.rows,"wwwww")
            for (let item of getItemDiscount.rows) {
                console.log(item_quantity > item.item_quantity, typeof(item_quantity), typeof(item.item_quantity), item.item_quantity !== null && parseInt(item_quantity )>parseInt( item.item_quantity) ,"eeeeeeeeeeeeeffffffffffff")
                console.log(parseInt(item_quantity ), parseInt( item.item_quantity))
                if (item.item_quantity !== null && parseInt(item_quantity )>=parseInt( item.item_quantity)) {
                     console.log(item.volume_discount_percentage,item_quantity,"discountvolume")
                    discount_percentage = item.volume_discount_percentage;
                    
                } else if(discount_percentage===0){
                    console.log("ddfsdfdfdfdf")
                   discount_percentage = getItemDiscount.rows[0].discount_percentage
                  
                }

            }
console.log(discount_percentage,"rfrrrrrrrrrrrffffff")
        }else if (getItemPricelistDiscount.rows.length>0){
          console.log(getItemPricelistDiscount.rows, 'eeeeeee')

            discount_percentage = getItemPricelistDiscount.rows[0].discount_percentage
        }

       discountAmount = (totalAmountOfItem * parseInt(discount_percentage)) / 100
        if (taxResult.rows.length > 0) {
            var cgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
            var sgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
         //   var igstRate = parseInt(taxResult.rows[0] || 0;
            var taxPercentage = cgstRate + sgstRate 

            var discountedAmount = totalAmountOfItem - discountAmount
            var taxAmount = discountedAmount - (discountedAmount* ( 100 / (100+taxPercentage)))

             resultObj = {
                item_discount_amount: parseFloat(discountAmount.toFixed(2)),
                item_discount_percentage:discount_percentage,
                item_tax_amount: parseFloat(taxAmount.toFixed(2)),
                item_total_tax_percentage: parseFloat(taxPercentage.toFixed(2)),
                cgstRate: parseFloat(cgstRate.toFixed(2)),
                sgstRate: parseFloat(sgstRate.toFixed(2))
              //  igstRate: parseInt(igstRate.toFixed(2))
            }
            console.log(resultObj)



    
            return res.status(200).send(
                generateResponse(true, "discount is applicable", 200,resultObj)
            )

        } 

        
        resultObj = {
            item_discount_amount: 0,
            item_discount_percentage: 0,
            item_tax_amount: 0,
            item_total_tax_percentage: 0,
            cgstRate: 0,
            sgstRate: 0
          //  igstRate: parseInt(igstRate.toFixed(2))
        }

            
        
            return res.status(400).send(
                generateResponse(false, "tax is not found ",400,resultObj )
            )
        
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }


}

export async function getSalesItemDiscount(req: any, res: any) {
    try {
        const { item_id, item_quantity,totalAmountOfItem, cmr_phone_number,item_batch_number } = req.query
        let price_list_id 
        let resultObj
        let discount_percentage :any = 0
        let  discountAmount = 0
        let cmr_group_id 
        
        const findPricelistOfCustomer  = await customerService.findCustomerByPhoneNumber(cmr_phone_number)
        if(findPricelistOfCustomer.rows.length>0){
            price_list_id = findPricelistOfCustomer.rows[0].price_list_id
            cmr_group_id = findPricelistOfCustomer.rows[0].cmr_group_id
            // discount_percentage  = 10
            // discountAmount = (totalAmountOfItem * discount_percentage) / 100
        }
        console.log(price_list_id)
        const[ getItemDiscount,getItemPricelistDiscount,taxResult,discountgroup] = await Promise.all([discountService.getItemDiscount(price_list_id, item_id,item_batch_number),discountService.getItemPricelistDiscount(price_list_id, item_id,item_batch_number) ,discountService.getTaxAmount(item_id),discountService.getGroupDiscount(cmr_group_id,item_id)])
        console.log(getItemDiscount?.rows,taxResult.rows, discountgroup ,"weee")
     if(discountgroup.discount_group_apply)   {
        discount_percentage = discountgroup.discount_percentage
     }else if (getItemDiscount.rows.length > 0) {
            console.log(getItemDiscount.rows,"wwwww")
            for (let item of getItemDiscount.rows) {
                console.log(item_quantity > item.item_quantity, typeof(item_quantity), typeof(item.item_quantity), item.item_quantity !== null && parseInt(item_quantity )>parseInt( item.item_quantity) ,"eeeeeeeeeeeeeffffffffffff")
                console.log(parseInt(item_quantity ), parseInt( item.item_quantity))
                if (item.item_quantity !== null && parseInt(item_quantity )>=parseInt( item.item_quantity)) {
                     console.log(item.volume_discount_percentage,item_quantity,"discountvolume")
                    discount_percentage = item.volume_discount_percentage;
                    
                } else if(discount_percentage===0){
                    console.log("ddfsdfdfdfdf")
                   discount_percentage = getItemDiscount.rows[0].discount_percentage
                  
                }

            }
console.log(discount_percentage,"rfrrrrrrrrrrrffffff")
        }else if (getItemPricelistDiscount.rows.length>0){
          // console.log(getItemPricelistDiscount.rows, 'eeeeeee')

            discount_percentage = getItemPricelistDiscount.rows[0].discount_percentage
        }

        discountAmount = (totalAmountOfItem * parseInt(discount_percentage)) / 100
        console.log(discountAmount,"eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")
        if (taxResult.rows.length > 0) {
            var cgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
            var sgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
         //   var igstRate = parseInt(taxResult.rows[0] || 0;
            var taxPercentage = cgstRate + sgstRate 

            var discountedAmount = totalAmountOfItem - discountAmount
            console.log(discountedAmount,"ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd")
            var taxAmount = discountedAmount  + (discountedAmount* ( taxPercentage / 100))
              console.log(taxAmount,"ddddddddddddddddddddddddddddccccccccccccccccccccccccccccc")
             resultObj = {
                item_discount_amount: parseFloat(discountAmount.toFixed(2)),
                item_discount_percentage:discount_percentage,
                item_tax_amount: parseFloat(taxAmount.toFixed(2)),
                item_total_tax_percentage: parseFloat(taxPercentage.toFixed(2)),
                cgstRate: parseFloat(cgstRate.toFixed(2)),
                sgstRate: parseFloat(sgstRate.toFixed(2))
              //  igstRate: parseInt(igstRate.toFixed(2))
            }
            console.log(resultObj)



    
            return res.status(200).send(
                generateResponse(true, "discount is applicable", 200,resultObj)
            )

        } 

        
        resultObj = {
            item_discount_amount: 0,
            item_discount_percentage: 0,
            item_tax_amount: 0,
            item_total_tax_percentage: 0,
            cgstRate: 0,
            sgstRate: 0
          //  igstRate: parseInt(igstRate.toFixed(2))
        }

            
        
            return res.status(400).send(
                generateResponse(false, "tax is not found ",400,resultObj )
            )
        
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }


}


export async function addBulkDiscount(req:any, res:any){
    try{
    const {itemsdata} = req.body

    let response = []
    for(let item of itemsdata){

        const existingItemsResult = await discountService.existingItemPeriod(item.period_discount_item_id)

        if(existingItemsResult.rows.length>0){
            let updateObj = {
                period_discount_item_id: item.period_discount_item_id,
                from_date: item.from_date,
                to_date: item.to_date,
                discount_percentage: item.discount_percentage,
                effective_price: item.effective_price
            }

           const updateDiscountofItem = await  discountService.bulkUpdatedItemPeriod(updateObj)
           if(updateDiscountofItem.rows.length>0){
           response.push(updateDiscountofItem.rows)
           }
        }else{

    let itemDataObj = {
        period_validity_id:  ulid(), // Assign ulid() if period_validity_id is not provided
        period_discount_item_id: item.period_discount_item_id,
        from_date: item.from_date,
        to_date: item.to_date,
        discount_percentage: item.discount_percentage,
        effective_price: item.effective_price
    };

    const addPeriodValidity = await discountService.addPeriodItems(itemDataObj);
    if(addPeriodValidity.rows.length>0){
    response.push(addPeriodValidity.rows)
    }
    
    }

}       

if (response.length > 0) {
    return res.status(200).send(
        generateResponse(true, "period and volume validity saved succesfully", 200, response)
    )

} else {
    return res.status(400).send(
        generateResponse(false, "period and volume validity saved unsuccesfull", 400, null)
    )


}
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}
export async function getItemTax(item_id: any, totalAmountOfItem: any) {
    try {
        console.log(item_id , totalAmountOfItem, 'tax')
        let price_list_id 
        let resultObj
        let discount_percentage = 0
        let  discountAmount = 0
        
       
        
        const[taxResult] = await Promise.all([ discountService.getTaxAmount(item_id)])
       // console.log(getItemDiscount.rows,taxResult.rows,"weee")
        // if (getItemDiscount.rows.length > 0) {
        //     console.log(getItemDiscount,"wwwww")
        //     for (let item of getItemDiscount.rows) {
        //         if (item.item_quantity !== null && item_quantity > item.item_quantity) {
        //             discount_percentage = item.volume_discount_percentage;
        //             break
        //         } else {
        //            discount_percentage = getItemDiscount.rows[0].discount_percentage
                  
        //         }

        //     }
        //       discountAmount = (totalAmountOfItem * discount_percentage) / 100
        // }
        
        if (taxResult.rows.length > 0) {
            var cgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
            var sgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
         //   var igstRate = parseInt(taxResult.rows[0] || 0;
            var taxPercentage = cgstRate + sgstRate 

            var discountedAmount = totalAmountOfItem - discountAmount
            var taxAmount = discountedAmount - (discountedAmount* ( 100 / (100+taxPercentage)))

             resultObj = {
                item_discount_amount: parseFloat(discountAmount.toFixed(2)),
                item_discount_percentage:discount_percentage,
                item_tax_amount: parseFloat(taxAmount.toFixed(2)),
                item_total_tax_percentage: parseFloat(taxPercentage.toFixed(2)),
                cgstRate: parseFloat(cgstRate.toFixed(2)),
                sgstRate: parseFloat(sgstRate.toFixed(2))
              //  igstRate: parseInt(igstRate.toFixed(2))
            }
            console.log(resultObj)

           return resultObj 

    
            // return res.status(200).send(
            //     generateResponse(true, "discount is applicable", 200,resultObj)
            // )

        } 

        
        resultObj = {
            item_discount_amount: 0,
            item_discount_percentage: 0,
            item_tax_amount: 0,
            item_total_tax_percentage: 0,
            cgstRate: 0,
            sgstRate: 0
          //  igstRate: parseInt(igstRate.toFixed(2))
        }

            
        
            // return res.status(400).send(
            //     generateResponse(false, "tax is not found ",400,resultObj )
            // )
            return resultObj
        
    } catch (error) {
        console.log(error)
      //  return res.send(generateResponse(false, error.message, 400, null));
    }


}

export async function discountDataSetupSync(data:any) {

    try {
    
           const itemData = data.discountData
         console.log(itemData, "discount sync cpos to pos")
           
           if(itemData){
            const [ ]= await Promise.all([
             discountService.pricelisttableSync(itemData.price_list_table), 
             discountService.pricelistitemstableSync(itemData.price_list_items_table), 
            //   discountService.periodvolumediscounttableSync(itemData.period_volume_discount_table),
            //   discountService.periodvolumediscountitemstableSync(itemData.period_volume_discount_items_table) ,
            //   discountService.itemsperiodvaliditytableSync(itemData.items_period_validity_table) ,
            //   discountService.itemsvolumevaliditytableSync(itemData.items_volume_validity_table) ,
            //   discountService.customergrouptableSync(itemData.customer_group_table) ,
            //   discountService.discounttypetableSync(itemData.discount_type_table),
            //   discountService.manufacturegrouptableSync(itemData.manufacture_group_table),
            //   discountService.itemsgroupdiscountgrouptableSync(itemData.items_group_discount_group_table) ,
            //   discountService.manufacturesgroupdiscountgrouptableSync(itemData.manufactures_group_discount_group_table) ,
            //   discountService.itemsdiscountgrouptableSync(itemData.items_discount_group_table)
  
            ])
  
           }
           
        }
    
    catch (error) {
        console.log(error)
        
    }
  }

  
  export async function getItemDiscountV1(itemData:any) {
    try {
        const { item_id, item_quantity,totalAmountOfItem, item_batch_number, cmr_phone_number } = itemData
        let price_list_id 
        let resultObj
        let discount_percentage :any = 0
        let  discountAmount = 0
        let cmr_group_id 
        
        const findPricelistOfCustomer  = await customerService.findCustomerByPhoneNumber(cmr_phone_number)
        if(findPricelistOfCustomer.rows.length>0){
            price_list_id = findPricelistOfCustomer.rows[0].price_list_id
            cmr_group_id = findPricelistOfCustomer.rows[0].cmr_group_id
            // discount_percentage  = 10
            // discountAmount = (totalAmountOfItem * discount_percentage) / 100
        }
        console.log(price_list_id, item_id, item_quantity,totalAmountOfItem, item_batch_number, cmr_phone_number,"rtttytrdff")
        const[ getItemDiscount,getItemPricelistDiscount,taxResult,discountgroup] = await Promise.all([discountService.getItemDiscount(price_list_id, item_id,item_batch_number),discountService.getItemPricelistDiscount(price_list_id, item_id,item_batch_number) ,discountService.getTaxAmount(item_id),discountService.getGroupDiscount(cmr_group_id,item_id)])
        console.log(getItemDiscount?.rows,taxResult.rows, discountgroup ,"weee")
     if(discountgroup.discount_group_apply)   {
        discount_percentage = discountgroup.discount_percentage
     }else if (getItemDiscount.rows.length > 0) {
            console.log(getItemDiscount.rows,"wwwww")
            for (let item of getItemDiscount.rows) {
                console.log(item_quantity > item.item_quantity, typeof(item_quantity), typeof(item.item_quantity), item.item_quantity !== null && parseInt(item_quantity )>parseInt( item.item_quantity) ,"eeeeeeeeeeeeeffffffffffff")
                console.log(parseInt(item_quantity ), parseInt( item.item_quantity))
                if (item.item_quantity !== null && parseInt(item_quantity )>=parseInt( item.item_quantity)) {
                     console.log(item.volume_discount_percentage,item_quantity,"discountvolume")
                    discount_percentage = item.volume_discount_percentage;
                    
                } else if(discount_percentage===0){
                    console.log("ddfsdfdfdfdf")
                   discount_percentage = getItemDiscount.rows[0].discount_percentage
                  
                }

            }
console.log(discount_percentage,"rfrrrrrrrrrrrffffff")
        }else if (getItemPricelistDiscount.rows.length>0){
           console.log(getItemPricelistDiscount.rows, 'eeeeeee')
                if(getItemPricelistDiscount.rows[0].discount_percentage>0){
            discount_percentage = getItemPricelistDiscount.rows[0].discount_percentage
                }
        }

        discountAmount = (totalAmountOfItem * parseInt(discount_percentage)) / 100
        
        if (taxResult.rows.length > 0) {
            var cgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
            var sgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
         //   var igstRate = parseInt(taxResult.rows[0] || 0;
            var taxPercentage = cgstRate + sgstRate 

            var discountedAmount = totalAmountOfItem - discountAmount
            var taxAmount = discountedAmount - (discountedAmount* ( 100 / (100+taxPercentage)))
            console.log(taxPercentage,discountAmount,discountedAmount,taxAmount,"ddddddddddddddfgfdddddddddddddddddddddddddddddddddd")
             resultObj = {
                item_discount_amount: parseFloat(discountAmount.toFixed(2)),
                item_discount_percentage:discount_percentage,
                item_tax_amount: parseFloat(taxAmount.toFixed(2)),
                item_total_tax_percentage: parseFloat(taxPercentage.toFixed(2)),
                cgstRate: parseFloat(cgstRate.toFixed(2)),
                sgstRate: parseFloat(sgstRate.toFixed(2))
              //  igstRate: parseInt(igstRate.toFixed(2))
            }
            console.log(resultObj)



    
           return resultObj

        } 

        
        resultObj = {
            item_discount_amount: 0,
            item_discount_percentage: 0,
            item_tax_amount: 0,
            item_total_tax_percentage: 0,
            cgstRate: 0,
            sgstRate: 0
          //  igstRate: parseInt(igstRate.toFixed(2))
        }

            
        
            return resultObj
        
    } catch (error) {
        console.log(error)
        //return res.send(generateResponse(false, error.message, 400, null));
    }


}