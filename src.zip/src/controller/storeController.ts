import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as storeService from '../service/storeService'


export async function   addStoreAddress (req:any,res:any){
    try{
            const addressData = req.body
             console.log(addressData,addressData.length)
             if(addressData.shop_images){
                if(addressData.shop_images[0]){
                addressData.shop_image_1 = addressData.shop_images[0]
                }
                if(addressData.shop_images[1]){
                    addressData.shop_image_2 = addressData.shop_images[1]
                    }

                    if(addressData.shop_images[2]){
                        addressData.shop_image_2 = addressData.shop_images[2]
                        }
              
             }

            if(addressData){
                
                addressData.store_id =   ulid();

                const addStoreAddress = await storeService.addStoreAddress(addressData)
                if(addStoreAddress.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "store address added successfully", 200, addStoreAddress.rows[0])
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "store address adding unsuccessfull", 400,null)
                    );
                }
            }else{
                return res.status(400).send(
                    generateResponse(false, "send correcr data", 400,null)
                );
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

export async function   updateStoreAddress (req:any,res:any){
    try{
            const addressData = req.body
             console.log(addressData,addressData.length)
             if(addressData.shop_images){
                if(addressData.shop_images[0]){
                addressData.shop_image_1 = addressData.shop_images[0]
                }
                if(addressData.shop_images[1]){
                    addressData.shop_image_2 = addressData.shop_images[1]
                    }

                    if(addressData.shop_images[2]){
                        addressData.shop_image_2 = addressData.shop_images[2]
                        }
              
             }

            if(addressData){
                
               

                const addStoreAddress = await storeService.addUpdateStoreAdress(addressData)
                if(addStoreAddress.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "store address updated successfully", 200, addStoreAddress.rows[0])
                    );
            }else{    
                    return res.status(400).send(
                        generateResponse(false, "store address update unsuccessfull", 400,null)
                    );
                }
            }else{
                return res.status(400).send(
                    generateResponse(false, "send correcr data", 400,null)
                );
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

export async function   addStorePersonalDetails (req:any,res:any){
    try{
            const personalData = req.body
             
            if(!personalData){
                return res.status(400).send(
                    generateResponse(false, "please send correct data", 400, null)
                )
            }else{        
                const addStoreAddress = await storeService.addStorePersonalDetails(personalData)
                if(addStoreAddress.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "personal details added successfully", 200, addStoreAddress.rows[0])
                    );
                }else{
                    return res.status(400).send(
                        generateResponse(false, "store details adding unsuccessfull", 400,null)
                    );
                }
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

export async function   addStoreFirmDetails (req:any,res:any){
    try{
            const firmData = req.body
             
            if(!firmData){
                return res.status(400).send(
                    generateResponse(false, "please send correct data", 400, null)
                )
            }else{        
                const result = await storeService.addStoreFirmDetails(firmData)
                if(result.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "firm details added successfully", 200, result.rows[0])
                    );
                }else{
                    return res.status(400).send(
                        generateResponse(false, "firm details adding unsuccessfull", 400,null)
                    );
                }
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

export async function   addStoreAgreementDetails (req:any,res:any){
    try{
            const agrementData = req.body
             
            if(!agrementData){
                return res.status(400).send(
                    generateResponse(false, "please send correct data", 400, null)
                )
            }else{        
                const result = await storeService.addStoreAgreementDetails(agrementData)
                if(result.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "agreement details added successfully", 200, result.rows[0])
                    );
                }else{
                    return res.status(400).send(
                        generateResponse(false, "agreement details adding unsuccessfull", 400,null)
                    );
                }
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

export async function   addStorePaymentDetails (req:any,res:any){
    try{
            const paymentData = req.body
             
            if(!paymentData){
                return res.status(400).send(
                    generateResponse(false, "please send correct data", 400, null)
                )
            }else{        
                const result = await storeService.addStorePaymentDetails(paymentData)
                if(result.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "payement details added successfully", 200, result.rows[0])
                    );
                }else{
                    return res.status(400).send(
                        generateResponse(false, "payment details adding umsuccessfull", 400,null)
                    );
                }
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 

export async function   addStoreDrugLicenseDetails (req:any,res:any){
    try{
            const drugLicenseDataData = req.body
             
            if(!drugLicenseDataData){
                return res.status(400).send(
                    generateResponse(false, "please send correct data", 400, null)
                )
            }else{        
                const result = await storeService.addStoreDrugLicenseDetails(drugLicenseDataData)
                if(result.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "drug license details added successfully", 200, result.rows[0])
                    );
                }else{
                    return res.status(400).send(
                        generateResponse(false, "drug license details adding umsuccessfull", 400,null)
                    );
                }
            }

    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 






















export async function getById(req:any,res:any){
    try{

        const {store_id}= req.query
        console.log(store_id)

        if(store_id){
            const findStoreDetails = await storeService.getById(store_id)
            console.log(findStoreDetails)
            if(findStoreDetails.rows.length>0){
                const shop_images = [findStoreDetails.rows[0].shop_image_1,findStoreDetails.rows[0].shop_image_2,findStoreDetails.rows[0].shop_image_3]
                findStoreDetails.rows.push(shop_images)
                return res.status(200).send(
                    generateResponse(true, "store details fetched successfully", 200, findStoreDetails.rows)
                );
            }else{
                return res.status(400).send(
                    generateResponse(false, "store details fetching  unsuccessfull", 200,null)
                );
            }
        }
        
       

    }catch(error){
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getStoreList(req:any,res:any){
    try{

            const getStoreList = await storeService.getStoreList(req.query)
            console.log(getStoreList)
            if(getStoreList){
                return res.status(200).send(
                    generateResponse(true, "store details fetched successfully", 200, {
                        totalCount:getStoreList.totalRowsCount,
                        storeList:getStoreList.storeList
                    })
                );
            }else{
                return res.status(400).send(
                    generateResponse(false, "store details fetching  unsuccessfull", 200,null)
                );
            }
        
        
       

    }catch(error){
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function addStoreService(req: any, res: any) {
    try {
      const storeData = req.body;
      
      if (storeData) {
        const result = await storeService.addStoreService(storeData);
        if (result) {
          return res.send(
            generateResponse(true, "store added successfully", 200, result)
          );
        } else {
          return res.send(
            generateResponse(false, "store adding unsuccessful", 400, null)
          );
        }
      }
    } catch (error) {
      console.log(error, "errr");
      return res.send(generateResponse(false, error.message, 400, null));
    }
  }
  
export async function updateStoreService(req: any, res: any) {
    try {
      const { store_id } = req.body;
      if (store_id) {
        const updateStoreService = await storeService.updateStoreService(
            store_id,
          req.body
        );
        if (updateStoreService.rows.length > 0) {
          return res
            .status(200)
            .send(
              generateResponse(
                true,
                "store updated succesfully",
                200,
                updateStoreService.rows[0]
              )
            );
        } else {
          return res
            .status(400)
            .send(
              generateResponse(true, "storee update unsuccesfully", 400, null)
            );
        }
      }
    } catch (error) {
      return res
        .status(400)
        .send(generateResponse(false, error.message, 400, null));
    }
  }
  
export async function getStoreByIdService(req: any, res: any) {
      try {
          const  store_id = req.query.store_id
          console.log(req.query)
          if (store_id) {
            console.log(store_id,"eeeee")
              const getStoreByIdService = await storeService.getStoreByIdService(store_id)
              if (getStoreByIdService.rows.length > 0) {
                  return res.status(200).send(
                      generateResponse(true, "store fetched succesfully ", 200, getStoreByIdService.rows[0]))
              } else {
                  return res.status(400).send(
                      generateResponse(false, "store not found", 400, null))
              }
          }
      }
      catch (error) {
          return res.status(400).send(generateResponse(false, error.message, 400, null));
      }
  }
  


