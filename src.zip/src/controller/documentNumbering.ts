import { generateResponse } from '../util/genRes';
import * as documentNumberingService from '../service/documentNumberingSeries'
import { ulid } from 'ulid';
import {addDocumentSeries} from '../validateModels/documentSeries'
export async function addDocument(req: any, res: any) {
    try {
                
            const addDocument = await documentNumberingService.addDocument(req.body)
            if (addDocument.rows.length > 0) {
                console.log('Customers found:', addDocument.rows);
                return res.status(200).send(
                    generateResponse(true, "customer fetched succesfully ", 200, addDocument.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer not found", 400, null))
            }
        }
    
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function addSeriesToDocument(req: any, res: any) {
    try { 
        const { error, value } = addDocumentSeries.validate(req.body);
        if (error) {
            return res.status(400).json({ error: error.details[0].message });
        }
    
            const addDocument = await documentNumberingService.addSeriesToDocument(req.body)
            if (addDocument.rows.length > 0) {
                console.log('Customers found:', addDocument.rows);
                return res.status(200).send(
                    generateResponse(true, "customer fetched succesfully ", 200, addDocument.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer not found", 400, null))
            }
        }
    
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}



export async function getSeriesToDocument(req: any, res: any) {
    try {
                
            const getDocument = await documentNumberingService.getSeriesToDocument(req.query.transaction_doc_id)
            if (getDocument.rows.length > 0) {
                console.log('Customers found:', getDocument.rows);
                return res.status(200).send(
                    generateResponse(true, "document fetched succesfully ", 200, getDocument.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "document not found", 400, null))
            }
        }
    
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updateDocumentSeries(req: any, res: any) {

    try {
        const { series_id } = req.body
        if(series_id){
        const updateSeries = await documentNumberingService.updateSeries(series_id, req.body)
        if (updateSeries.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "series updated succesfully", 200, updateSeries.rows[0])
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "series update unsuccesfully", 400, null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}





export async function getAllDocument(req: any, res: any) {
    try {
                
            const getDocument = await documentNumberingService.getAllDocument(req.query)
            if (getDocument.rows.length > 0) {

                return res.status(200).send(
                    generateResponse(true, "document fetched succesfully ", 200, getDocument.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "document not found", 400, null))
            }
        }
    
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


