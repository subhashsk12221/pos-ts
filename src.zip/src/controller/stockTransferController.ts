import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as discountService from '../service/discountService'
import * as stockTransfer from '../service/stockTransferService'

import * as productService from '../service/productService'
import * as inventoryManagementServive from '../service/inventoryManagmentService';


export async function createStockTransfer(req: any, res: any) {

    try {
        const { stockTransferData: stockTransferData, itemData: itemData, itemBatchData:itemBatchData } = req.body
        console.log(Object.keys(itemBatchData[0]),"wererewertrwerert")
     let  getbasepricelist = await  discountService.getPricelistById('01HS5HJYWZ5DG2CW4EHX2W7A8V')
      

            if(stockTransferData.stock_management_action === 'stock_in' && itemBatchData.length>0){
              const newitemData = itemData.map((item: any) => ({
                item_code: item.item_code,
                item_id: item.item_id,
                item_name:item.item_name
            }));
           //   const checkBatchNumber = await purchaseOrderService.getBatchNumber(itemBatchData)
           //  const addProductToInventory =   await purchaseOrderService.additemToInventory(newitemData)
             

            //   const multipliedItems = await Promise.all(itemData.map(async (item: { item_id: any; item_batch_number:any;item_unit_price: any; item_selling_price: number; }) => {
            //     const getitem = await productService.getproductById(item.item_id);
            //     if (getitem.rows.length > 0) {
            //         const itemObj = {
            //             item_id: item.item_id,
            //             item_batch_number:item.item_batch_number,
            //             item_base_price: getitem.rows[0].item_unit_price,
            //             price_list_id: getbasepricelist.rows[0].price_list_id,
            //             item_selling_price: getitem.rows[0].item_unit_price * getbasepricelist.rows[0].default_factor // Assuming pricelistObj.multiplying_factor contains the multiplying factor of the new price list
            //         };
            //         console.log(itemObj, "wwwwwwww");
            
            //         return itemObj;
            //     }
            //     return null; // Return null if no item is found
            // }));

            const multipliedItems = itemBatchData.map((item: { item_id: any; item_batch_unit_price: any; item_selling_price: number;item_batch_number:any }) => {
              return {
                  item_id: item.item_id,
                  item_base_price: item.item_batch_unit_price,
                  price_list_id: getbasepricelist.rows[0].price_list_id,
                  item_batch_number:item.item_batch_number,
                  item_selling_price: item.item_batch_unit_price * getbasepricelist.rows[0].default_factor // Assuming pricelistObj.multiplying_factor contains the multiplying factor of the new price list
              };
          });
            
            // Filter out any null values
            const validItems = multipliedItems.filter((item: null) => item !== null);
            
            if (validItems.length > 0) {
                console.log(validItems, "sdddd");
               const additems = await discountService.addItemsToBasePriceList(validItems);
            }
            
            
               }
           if(stockTransferData.stock_management_action === 'in_store_transfer' && itemBatchData.length>0){
               
                const batcheSegregationIntoExpAndDamageBin = SegregationIntoExpAndDamageBin(itemBatchData)
            }
               const addStockTransfer = await stockTransfer.addStockTransfer(stockTransferData, itemData ,itemBatchData)
                
            if (addStockTransfer){

             
              
                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addStockTransfer.order, items: addStockTransfer.item })
                )

        } else {
            return res.status(400).send(
                generateResponse(false, "order placing unsuccesfully", 400, null)
            )

        }
    
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function addWareHouse(req: any, res: any) {
    try {
      const addWareHouseData = req.body;
    
      if (addWareHouseData) {
        const result = await stockTransfer.addWareHouse(addWareHouseData);
        if (result) {
          return res.send(
            generateResponse(true, "wareHouse added successfully", 200, result)
          );
        } else {
          return res.send(
            generateResponse(false, "wareHouuse adding unsuccessful", 400, null)
          );
        }
      }
    } catch (error) {
      console.log(error, "errr");
      return res.send(generateResponse(false, error.message, 400, null));
    }
  }

 export async function getWareHouseList(req: any, res: any) {
    try {

    
     const result = await stockTransfer.getWareHouseList();
        if (result) {
          return res.send(
            generateResponse(true, "wareHouse fetched successfully", 200, result)
          );
        } else {
          return res.send(
            generateResponse(false, "wareHouuse fetched unsuccessful", 400, null)
          );
        }
      
    } catch (error) {
      console.log(error, "errr");
      return res.send(generateResponse(false, error.message, 400, null));
    }
  }

  export async function getStockTransferList(req: any, res: any) {
    try {

        const getOrderList = await stockTransfer.getStockTransferList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "stock transfer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "stock transfer fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getStockTransferById(req: any, res: any) {
  try {

  
   const result = await stockTransfer.getStockTransferById(req.query.itt_id);
      if (result) {
        return res.send(
          generateResponse(true, "stock transfer fetched successfully", 200, result[0])
        );
      } else {
        return res.send(
          generateResponse(false, "stock transfer fetched unsuccessful", 400, null)
        );
      }
    
  } catch (error) {
    console.log(error, "errr");
    return res.send(generateResponse(false, error.message, 400, null));
  }
}
 export async function SegregationIntoExpAndDamageBin(itemBatchData:any){
       try{
        for(let item of itemBatchData){
          const itemBinLocationData = {
            item_batch_number :item.item_batch_number,
            item_quantity:item.item_batch_quantity,
            item_id:item.item_id,
            to_bin_id:item.to_bin_id,
            item_rack_location :item.to_bin_location 
            }

            const updateBatchBinLocation = await productService.updateBatchBinLocation(itemBinLocationData)

           let getExpireyBin = await inventoryManagementServive.getBinLocation(item.to_bin_id)
           if(getExpireyBin.rows[0].is_expired_bin_location === true || getExpireyBin.rows[0].is_non_sellable_bin_location === true ){
           
            const updateItemBatchNumberQuantityInBin  = await productService.updateItemBatchNumberQuantityInBin(item)
            console.log("wwwr",updateItemBatchNumberQuantityInBin)
           }else{
            const updateItemBatchNumberQuantityInBinMinusFromBIN  = await productService.updateItemBatchNumberQuantityInBinMinusFromBIN(item)
            console.log("wwwr",updateItemBatchNumberQuantityInBinMinusFromBIN)  
           }
        }

       }catch(error){
        console.log(error)
       }
 }


export async function voidStockTranferRocordLevel(req: any, res: any){
  try{
    const result = await stockTransfer.getStockTransferById(req.body.itt_id);

    if(result.length>0){
      console.log(result,JSON.stringify(result[0].itemData, null, 2))
      result[0].stocktransferData.stock_transfer_parent_id = req.body.itt_id
      const voidstockTransfer = await stockTransfer.voidStockTransfer(result[0].stocktransferData, result[0].itemData)
      if (voidstockTransfer){
        let stock_transfer_status = 'cancelled'
        const updateStockTransferStatus = await stockTransfer.updateStockTransferStatus(stock_transfer_status,req.body.itt_id)
        return res.status(200).send(
            generateResponse(true, "order void succesfully", 200, null)
        )

} else {
    return res.status(400).send(
        generateResponse(false, "order void unsuccesfully", 400, null)
    )

}

    }else {
      return res.status(400).send(
          generateResponse(false, "order void unsuccesfully", 400, null)
      )
  
  }

  }catch(error){
    console.log(error, "errr");
    return res.send(generateResponse(false, error.message, 400, null));
  }
}

export async function voidStockTranferSubRocordLevel(req: any, res: any){
  try{
    const result = await stockTransfer.getStockTransferByIdANDItem_id(req.body.itt_id,req.body.item_id);

    if(result.length>0){
    //  console.log(result,JSON.stringify(result[0].itemData, null, 2))
    result[0].stocktransferData.stock_transfer_parent_id = req.body.itt_id
      const voidstockTransfer = await stockTransfer.voidStockTransfer(result[0].stocktransferData, result[0].itemData)
      if (voidstockTransfer){
        let stock_transfer_status = 'partially cancelled'
        let item_void_status = 'cancelled'

         await Promise.all([
          stockTransfer.updateStockTransferStatus(stock_transfer_status,req.body.itt_id),
          stockTransfer.updateitemStockTransferStatus(item_void_status,req.body.item_id, req.body.itt_id)
        ])
        return res.status(200).send(
            generateResponse(true, "order void succesfully", 200, null)
        )

} else {
    return res.status(400).send(
        generateResponse(false, "order void unsuccesfully", 400, null)
    )

}

    }else {
      return res.status(400).send(
          generateResponse(false, "order void unsuccesfully", 400, null)
      )
  
  }

  }catch(error){
    console.log(error, "errr");
    return res.send(generateResponse(false, error.message, 400, null));
  }
}

export async function getUnSyncedStockTransfer(){
  try{
    const getUnSyncedStockTransfer = await stockTransfer.getUnSyncedStockTransfer()
    if (getUnSyncedStockTransfer.rows.length > 0) {
   //   console.log(getUnSyncedStockTransfer.rows)
      const groupedOrders:any = {};

            // Group orders by sot_id
            for (let item of getUnSyncedStockTransfer.rows) {
                const orderId = item.itt_id;

                if (!groupedOrders[orderId]) {
                  groupedOrders[orderId] = {
                    stocktransferData: {
                      itt_id: item.itt_id,
                      warehouse_id: item.warehouse_id,
                      warehouse_name: item.warehouse_name,
                      transfer_date: item.transfer_date,
                      stock_management_action: item.stock_management_action,
                      posting_date: item.posting_date,
                      from_warehouse_id: item.from_warehouse_id,
                      from_warehouse_name: item.from_warehouse_name,
                      to_warehouse_id: item.to_warehouse_id,
                      to_warehouse_name: item.to_warehouse_name,
                      stock_transfer_doc_number: item.stock_transfer_doc_number,
                      stock_transfer_reason: item.stock_transfer_reason,
                      is_stock_in_void_able: item.is_stock_in_void_able,
                    },
                    itemData: [],
                    // Initialize payment data to avoid undefined errors
                  };
                }
        
                // Check if the item already exists in itemData
                const existingItem = groupedOrders[orderId].itemData.find(
                  (i: { item_id: any }) => i.item_id === item.item_id
                );
        
                if (existingItem) {
                  existingItem.itemBatchData.push({
                    item_id: item.item_id,
                    itt_id: item.itt_id,
                    item_batch_number: item.item_batch_number,
                    from_bin_location: item.from_bin_location,
                    to_bin_location: item.to_bin_location,
                    item_exp_date: item.item_exp_date,
                    from_warehouse_id: item.from_warehouse_id,
                    from_warehouse_name: item.from_warehouse_name,
                    to_warehouse_id: item.to_warehouse_id,
                    to_bin_id: item.to_bin_id,
                    from_bin_id: item.from_bin_id,
                    to_warehouse_name: item.to_warehouse_name,
                    item_batch_quantity: item.item_batch_quantity,
                  });
                } else {
                  groupedOrders[orderId].itemData.push({
                    itrt_id:item.itrt_id,
                    itt_id: item.itt_id,
                    item_id: item.item_id,
                    item_name: item.item_name,
                    item_uom_source: item.item_uom_source,
                    item_uom_destination: item.item_uom_destination,
                    item_uom: item.item_uom,
                    item_quantity: item.item_quantity,
                    is_item_void_able: item.is_item_void_able,
                    itemBatchData: [
                      {
                        item_id: item.item_id,
                        itt_id: item.itt_id,
                        item_batch_number: item.item_batch_number,
                        from_bin_location: item.from_bin_location,
                        to_bin_location: item.to_bin_location,
                        item_exp_date: item.item_exp_date,
                        from_warehouse_id: item.from_warehouse_id,
                        from_warehouse_name: item.from_warehouse_name,
                        to_warehouse_id: item.to_warehouse_id,
                        to_bin_id: item.to_bin_id,
                        from_bin_id: item.from_bin_id,
                        to_warehouse_name: item.to_warehouse_name,
                        item_batch_quantity: item.item_batch_quantity,
                      },
                    ],
                  });
                }
        
              }
        
                // Push payment data if it doesn't already exist
               
            

            // Now you can process each grouped order
            for (let orderId in groupedOrders) {
                const order = groupedOrders[orderId];
             //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                const { itemBatchData } = order.itemData
                const newItemsData = order.itemData.map((item: any) => {
                  // Destructure item to extract specific properties and the rest
                  const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
              //console.log(itemBatchData)
                  // Filter out properties with null values
                  const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                      if (value !== null) {
                          acc[key] = value;
                      }
                      return acc;
                  }, {} as { [key: string]: any });
              
                  // Return the new item object with additional properties
                  return {
                      ...filteredItem,
                     
                  
                  };
              });
             
              //console.log(newItemsData, 'rrrrr')
            
              const extractedBatchData :any= []
              order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                  // Check if itemBatchData exists and is an array
                  
                  if (Array.isArray(item.itemBatchData)) {
                    // Push each itemBatchData object into the extractedBatchData array
                    item.itemBatchData.forEach(batchData => {
                      extractedBatchData.push(batchData);
                    });
                  }
                });
  
              
  
              
                  const formatDateString = (dateString: string | number | Date) => {
                      const date = new Date(dateString);
                      return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                  };
  
                  const newBatchItemsData = extractedBatchData.map((item: any) => {
                      // Filter out properties with null values
                      const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                          if (value !== null) {
                              acc[key] = value;
                          }
                          return acc;
                      }, {} as { [key: string]: any });
  
                      // Return the new item object with additional properties
                      return {
                          ...filteredItem,
                          item_exp_date: formatDateString(item.item_exp_date),
                        
                      };
                  });
                  
              
                

              //  console.log(order.stocktransferData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');

               const syncedResult = await stockTransfer.syncStockTransferDocument(order.stocktransferData,newItemsData, newBatchItemsData);
            }
          }
  }catch(error){

  }
}


export async function getInverntorySync(){
  try{
    const getUnSyncedStockTransfer = await stockTransfer.getItemInventory()
   
  }catch(error){

  }
}


