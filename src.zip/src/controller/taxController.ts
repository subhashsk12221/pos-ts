import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as nextInvoicenumber  from '../service/documentNumberingSeries'
import { getStoreByIdService } from './storeController';
import * as storeService from "../service/storeService"
export async function addTax(req: any, res: any) {
    try {
          const taxObj = req.body

          taxObj.tax_id = ulid()

          if(!taxObj){
            return res.send(generateResponse(false, "tax details are  is required", 400, null));
          }
          
          const columns = Object.keys(taxObj);
          const values = Object.values(taxObj);

          const query = `INSERT INTO tax_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
            
          const discountResult = await client.query(query, values);

          if (discountResult.rows.length > 0) {

            return res.send(
                generateResponse(true, "tax add  succesfully", 200, discountResult.rows)
            )

        } else {
            return res.send(
                generateResponse(false, "tax add  unsuccesfully", 400, null)
            )

        }

    }catch(error){
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function  gettaxAmount(req: any, res: any) {
    try {

        const {totalAmountOfItem, item_category} = req.query
console.log(totalAmountOfItem)
        
            const query = `
            SELECT *
            FROM tax_table
            WHERE item_category = $1;

        `;
        console.log(item_category, typeof(item_category))

        const Medical = 'Medical'

const taxResult = await client.query(query,[Medical]);



if(taxResult.rows.length>0){
const cgstRate = parseInt(taxResult.rows[0].cgst_rate || 0);
const sgstRate = parseInt(taxResult.rows[0].sgst_rate || 0);
const igstRate = parseInt(taxResult.rows[0].igst_rate || 0);
const taxPercentage = cgstRate + sgstRate + igstRate;


        const taxAmount = (totalAmountOfItem*taxPercentage)/100
        console.log(typeof(cgstRate) )
        if(!taxAmount){
            return res.send(
                generateResponse(false, "cannot able not calculate taxAmount", 400, null)
            )
        }

        console.log(taxAmount)

        return res.send(
            generateResponse(true, "fetched discount succesfully", 200,{taxAmount:taxAmount,taxPercentage:taxPercentage, })
        )

}
return res.send(
    generateResponse(false, "tax is not applicable", 400, null)
)
        
    }catch(error){
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function  getStoreId(req: any, res: any) {

    return res.send(
        generateResponse(true, "fetched storeId  succesfully", 200,{store_id:"STR0001"})
    )
}

export async function  getPaymentMode(req: any, res: any) {
    const paymentMode = [
        {
        id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
        paymentType : "Cash"
         },

        {
            id:"01HKCTERKGNNSE6M0CXXDBG142",
        paymentType : "UPI"
        } ,

        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ61",
        paymentType : "Card"
        }
 ]
    return res.send(
        generateResponse(true, "fetched PaymentModes  succesfully", 200,{paymentModes:paymentMode})
    )

 
}


export async function  itemCategory(req: any, res: any) {
    const itemCategory = [
        {
        id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
        itemCategory : "CARDIAC"
         },

        {
            id:"01HKCTERKGNNSE6M0CXXDBG142",
            itemCategory : "DERMO"
        } ,

        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ61",
            itemCategory : "AYURVEDIC"
        },
        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ62",
            itemCategory : "PRIVATE LABEL"
        }
 ]
    return res.send(
        generateResponse(true, "fetched itemCategory  succesfully", 200,{itemCategory:itemCategory})
    )

 
}


export async function  itemgroup(req: any, res: any) {
    const itemgrouplist = [
        {
        id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
        itemgroup : "Patent"
         },

        {
            id:"01HKCTERKGNNSE6M0CXXDBG142",
            itemgroup : "Other"
        } 

 ]
    return res.send(
        generateResponse(true, "fetched itemgroup succesfully", 200,{itemgrouplist:itemgrouplist})
    )

 
}

export async function  getUom(req: any, res: any) {
    const query = 'SELECT * FROM item_group ';

    const  result = await client.query(query,);
    
    return result

 
    return res.send(
        generateResponse(true, "fetched uom  succesfully", 200,{uom:result})
    )

 
}


export async function  taxCategory(req: any, res: any) {
    const taxlist = [
        {
        id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
        taxCategory : "Nil/Exempted Tax"
         },

        {
            id:"01HKCTERKGNNSE6M0CXXDBG142",
            taxCategory : "Zero-rated Tax:"
        } ,

        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ61",
            taxCategory : "Cess Tax"
        },
        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ23",
            taxCategory : "GST"
        },
        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ23",
            taxCategory : "Regular"
        },
     

 ]
    return res.send(
        generateResponse(true, "fetched taxCategory  succesfully", 200,{taxlist:taxlist})
    )

 
}



export async function  getManufacturers(req: any, res: any) {
    const manufacturers = [
        {
        id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
        manufacturer : "PharmaWell Industries"
         },

        {
            id:"01HKCTERKGNNSE6M0CXXDBG142",
            manufacturer : "LifeCure Pharmaceuticals"
            

        } ,

        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ61",
            manufacturer : "Zotahealthcare"
        },
        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ23",
            manufacturer : "Safeway Pharmaceuticals"
        },
        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ23",
            manufacturer : "Sun Pharmaceuticals"
        },
        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ23",
            manufacturer : "King Pharmaceuticals"
        }

 ]
    return res.send(
        generateResponse(true, "fetched list succesfully", 200,{manufacturers:manufacturers})
    )

 
}



export async function  getPricelist(req: any, res: any) {
    const pricelist = [
        {
        id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
        pricelist: "Baseprice"
         }

    

 ]
    return res.send(
        generateResponse(true, "fetched pricelist  succesfully", 200,{pricelist:pricelist})
    )

 
}


export async function  getshippingtype(req: any, res: any) {
    const shippingtype = [
        {
        id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
        shippingtype : "Standard Shipping"
         },

        {
            id:"01HKCTERKGNNSE6M0CXXDBG142",
            shippingtype : "Express Shipping"
            

        } ,

        {
            id:"01HKHN8KZ2SSWYBNPNMBVSTQ61",
            shippingtype : "International Shipping"
        }
       

 ]
    return res.send(
        generateResponse(true, "fetched shippingtype  succesfully", 200,{shippingtype:shippingtype})
    )

 
}

export async function getSector(req:any, res:any){

    const sector = [
        {
            id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
            sector: "Pharma"
             },

         {
            id:"01HKCTDNDJWAHD43GSX3W5P6W2",
            sector: "Non-Pharma"
         }    
    ]

    return res.send(
        generateResponse(true, "fetched sector  succesfully", 200,{sector:sector})
    )
}





export async function getValuationMethod(req:any, res:any){

    const  scheduleList = [
        {
            id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
            valuationMethod:"FIFO"
             },

         {
            id:"01HKCTDNDJWAHD43GSX3W5P6W2",
            valuationMethod:"LIFO"
         },  
         {
            id:"01HKCTDNDJWAHD43GSX3W5P6W2",
            valuationMethod:"WAC(Weighted Average Cost)"
         }      
    ]

    return res.send(
        generateResponse(true, "fetched  list succesfully", 200,{scheduleList:scheduleList})
    )
}

export async function  getVendors(req: any, res: any) {
    const getVendorquery = `
    SELECT
        customer_details.cmr_id as id ,
        customer_details.cmr_first_name as vendors
    FROM
        customer_details
    WHERE
         is_vendor_cmr = 'true';
`;

console.log(getVendorquery); // Check the generated SQL query

// Execute the query with the value as a parameter
const result = await client.query(getVendorquery);

    return res.send(
        generateResponse(true, "fetched list succesfully", 200,{vendors:result.rows})
    )

}




export async function  addUomGroup(req: any, res: any) {
  
    try {

        const uomData = req.body

        uomData.uom_group_id = ulid()
        //   console.log(result,"result")
        if (uomData) {
            const columns = Object.keys(uomData);
            const values = Object.values(uomData);

            // Construct the parameterized query
            const query = `INSERT INTO uom_group_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
            console.log(query)

            // Execute the query with parameterized values
            const result = await client.query(query, values);
            if (result) {
                return res.send(
                    generateResponse(true, "uom added succesfully", 200, result.rows[0])
                )
            } else {
                return res.send(
                    generateResponse(false, "uom adding unsuccesfully", 400, result)
                )
            }



        }

    } catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } finally {
        // release the pool when done

    }
 
}


export async function  addUom(req: any, res: any) {
  
    try {

        const uomData = req.body

        uomData.uom_id = ulid()
        //   console.log(result,"result")
        if (uomData) {
            const columns = Object.keys(uomData);
            const values = Object.values(uomData);

            // Construct the parameterized query
            const query = `INSERT INTO uom_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
            console.log(query)

            // Execute the query with parameterized values
            const result = await client.query(query, values);
            if (result) {
                return res.send(
                    generateResponse(true, "uom added succesfully", 200, result.rows[0])
                )
            } else {
                return res.send(
                    generateResponse(false, "uom adding unsuccesfully", 400, result)
                )
            }



        }

    } catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } finally {
        // release the pool when done

    }
 
}

export async function getUomList (req: any, res: any) {
  
    try {
      const {uom_group_id} = req.query
        const query = `
        SELECT *
        FROM
        uom_table
        WHERE uom_group_id = $1`
            // Execute the query with parameterized values
            const result = await client.query(query,[uom_group_id]);
            if (result.rows.length>0) {
                return res.status(200).send(
                    generateResponse(true, "fetched uom group succesfully", 200, result.rows)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "fetching uom group unsuccesfully", 400, result)
                )
            }



        }

    catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } 
    
}

export async function   getUomGroupList (req: any, res: any) {
  
    try {

        const query = `
        SELECT *
        FROM
        uom_group_table`
            // Execute the query with parameterized values
            console.log(query,"wwwwww")
            const result = await client.query(query);
            if (result.rows.length>0) {
                return res.status(200).send(
                    generateResponse(true, "fetched uom group succesfully", 200, result.rows)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "fetching uom group unsuccesfully", 400, result)
                )
            }



        }

    catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } 
    
}


export async function getId(req:any, res:any){
    try{
            const  id =   ulid()
        if (id) {
            return res.status(200).send(
                generateResponse(true, "fetched id succesfully", 200, id)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "fetching id unsuccesfully", 400, id)
            )
        }




    }catch(error){
        return res.send(generateResponse(false, error.message, 400, null));
    }
}



export async function  getStoreDetails(req: any, res: any) {


const getStoreInfo =  await   storeService.getStoreByIdService('STR0002')
  if(getStoreInfo.rows.length>0){
    const store_name = getStoreInfo.rows[0].company
     const address = getStoreInfo.rows[0].company_address
    const phonenumber = ''
    const FSSAI = '0'
    const gstno = '36AAIFU3532H1Z4'
    const panno = 'BDRE34567'
    const dlno = 'GJ-SUJ-202076'
    const termandcondtion = ['The medicne is dispensed as per prescription only.', 'All prices of the medicines are inclusive of the all taxes.']
    const return_policy  = ['Full strip only can returned.', 'Bill and prescription are necessary.', 'Medicines requiring refrigeration cannot be returned.' ,'No return can be on Sundays.' ,'Return must be made within 30 days of purchase ']
    const store_logo = getStoreInfo.rows[0].company_logo
    const store_sign = 'https://dev.zotanextech.com/api/image/sign.png'
  
 
    return res.send(
        generateResponse(true, "fetched  succesfully", 200,{store_address:address,store_phone_numnber:phonenumber, store_fssai:FSSAI, store_gst_no:gstno,store_pan_no:panno,store_dl_no:dlno , store_terms_condition:termandcondtion, return_policy:return_policy, store_name:store_name,store_logo:store_logo,store_sign:store_sign})
    )
}

 
}


export async function  addbank(req: any, res: any) {
  
    try {

        const bankData = req.body

        bankData.bank_id = ulid()
        //   console.log(result,"result")
        if (bankData) {
            const columns = Object.keys(bankData);
            const values = Object.values(bankData);

            // Construct the parameterized query
            const query = `INSERT INTO bank_list_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
            console.log(query)

            // Execute the query with parameterized values
            const result = await client.query(query, values);
            if (result) {
                return res.send(
                    generateResponse(true, "bank added succesfully", 200, result.rows[0])
                )
            } else {
                return res.send(
                    generateResponse(false, "bank adding unsuccesfully", 400, result)
                )
            }



        }

    } catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } finally {
        // release the pool when done

    }
 
}

export async function getbanklist (req: any, res: any) {
  
    try {
      const {uom_group_id} = req.query
        const query = `
        SELECT *
        FROM
        bank_list_table`
            // Execute the query with parameterized values
            const result = await client.query(query);
            if (result.rows.length>0) {
                return res.status(200).send(
                    generateResponse(true, "bank list fetched succesfully", 200, result.rows)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "bank list group unsuccesfully", 400, result)
                )
            }
        }

    catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } 
    
}
