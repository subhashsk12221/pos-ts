
import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as purchaseOrderService from '../service/purchaseOrderService'
import * as nextInvoicenumber from '../service/documentNumberingSeries'
import * as discountService from '../service/discountService'
import * as UOMGroipService from '../administrativesettings/src/service/uomService'
import { getItemTax } from './discountController';
import { getposId } from '../service/storeService';
import socket from '../sync/syncScript';
//import { GRN } from '../helper/pdfhelper';
import { types } from 'pg';


function formatDate(date:any) {
    if (!date) return null; // Handle null or undefined dates
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
import { DebitNote, GRN,} from '../helper/pdfhelper';
import * as fs from 'fs';
export async function addPurchaseorder(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        // const getNextInvoiceNumber =  await nextInvoicenumber.getPurchaseOrderNextInvoiceNumber()
        // console.log(getNextInvoiceNumber);

        // if (!getNextInvoiceNumber) {
        //     return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        // }
        // const cmr_phone_number = orderData.cmr_phone_number
        // orderData.pot_invoice_number = getNextInvoiceNumber



        if (orderData && itemData) {
            const addOrder = await purchaseOrderService.addPurchaseOrder(orderData, itemData)
            if (addOrder) {
                // const smspath = `https://smsnotify.one/SMSApi/send?userid=davaindia&password=Dava@123&sendMethod=quick&mobile=${cmr_phone_number}&msg=Thank%20you,%20for%20connecting%20with%20Davaindia%20Generic%20Pharmacy,%20your%20login%20One%20Time%20Password%20(OTP)%20is%20Ajay%20Pandey.%20davaindia%20generic%20pharmacy.&senderid=DAVAIN&msgType=text&format=text`
                // const sendSMS = axios.post(`${smspath}` ).then(function (response) {

                //     console.log(response, "sms");
                //   })
                //   .catch(function (error) {

                //     console.log(error,"sms");
                //   })

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function getPurchaseorderProduct(req: any, res: any) {

    try {
        const { field, value } = req.query
        console.log(req.query)
        const query = `
       WITH RankedBatches AS (
    SELECT 
        itt.*,
        iit.*,
        itp.*,
        irt.*,
        mt.name AS item_manufacturer_name,
        grnb.item_batch_purchase_rate,
        grnb.created_date,
        ROW_NUMBER() OVER (PARTITION BY itt.item_id ORDER BY grnb.created_date DESC) AS rank
    FROM
        items_table AS itt
    INNER JOIN 
        item_invetory_table AS iit ON iit.item_id = itt.item_id
    INNER JOIN 
        item_purchasing_table AS itp ON itt.item_id = itp.item_id
    INNER JOIN 
        item_restriction_table AS irt ON irt.item_id = itt.item_id
    LEFT JOIN 
        manufacturer AS mt ON itt.item_manufacturer = mt.id
    LEFT JOIN 
        good_order_receipt_items_batches_list AS grnb ON grnb.item_id = itt.item_id
    WHERE 
        LEFT(itt.${field}, 10) ILIKE $1 AND itt.is_active = true
 AND COALESCE(grnb.item_batch_purchase_rate, 40) IS NOT NULL
)
SELECT *
FROM RankedBatches
WHERE rank = 1;
;
  ;
      `;


        console.log(query, field, value)
        if (field && value) {
            const getItemsList = await client.query(query, [`%${value}%`]);
            // console.log(result)
            if (getItemsList.rows.length > 0) {

                for (let item of getItemsList.rows) {
                    let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
                 if(getItemGroup.rows.length>0){
                    console.log(getItemGroup.rows)
                    item.uom_dropdown= getItemGroup.rows
                     item.item_uom = getItemGroup.rows[0].base_uom.name
              }
            }
            
            // Extract item_ids from the result
            const itemIds = getItemsList.rows.map((item: any) => `'${item.item_id}'`).join(', ');
        
            // Second query to get the total_sellable_quantity for the fetched items
            const sellableQuantityQuery = `
                SELECT
                    items_table.item_id,
                    COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
                FROM
                    items_table
                LEFT JOIN
                    items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id   
                WHERE
                    items_table.item_id IN (${itemIds})
                    AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
                    AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
                GROUP BY
                    items_table.item_id;
            `;
        
            // Execute the second query
            const sellableQuantities = await client.query(sellableQuantityQuery);
        
            // Map sellable quantities to item IDs
            const quantitiesMap = new Map(sellableQuantities.rows.map((row: any) => [row.item_id, row.total_sellable_quantity]));
        
            // Merge sellable quantities with the original item data
            let finalItemsList = getItemsList.rows.map((item: any) => ({
                ...item,
                total_sellable_quantity: quantitiesMap.get(item.item_id) || 0
            }));
        
        
                // console.log(query, field, value)
                // if (field && value) {
                //     const result = await client.query(query, [`%${value}%`]);
                    // console.log(result)
                    if (finalItemsList.length > 0) {
                        console.log('Customers found:', finalItemsList);
                    //     for (let item of finalItemsList) {
                    //         let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
                    //     if(getItemGroup.rows.length>0){
                    //         console.log(getItemGroup.rows)
                    //         item.uom_dropdown= getItemGroup.rows
                    //          item.item_uom = getItemGroup.rows[0].base_uom.name
                    //   }
                    // }
                
                        return res.send(
                            generateResponse(true, "product fetched succesfully", 200, finalItemsList))
                    } else {
                        return res.send(
                            generateResponse(false, "product not found", 400, null))
                    }
                }else {
                return res.send(
                    generateResponse(false, "product not found", 400, null))
            }
        }
    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseorderOrderList(req: any, res: any) {
    try {

        const getOrderList = await purchaseOrderService.getPurchasesOrderList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await purchaseOrderService.getVendorDetails(queryParams[0].pot_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await purchaseOrderService.getPurchaseitemsList(queryParams[i])
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                // Convert grouped items to an array
                resultArray.push(orderDetailsResult.rows)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseOrderById(req: any, res: any) {
    try {
        const { pot_id } = req.query

        if (pot_id) {

            const orderDetailsResult = await purchaseOrderService.getPurchaseOrderById(pot_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {


                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getVendor(req: any, res: any) {

    try {

        const searchCustomerByPhoneNumber = await purchaseOrderService.getVendor(req.query)
        if (searchCustomerByPhoneNumber.rows.length > 0) {
            console.log('Customers found:', searchCustomerByPhoneNumber.rows);
            return res.status(200).send(
                generateResponse(true, "customer fetched succesfully ", 200, searchCustomerByPhoneNumber.rows))
        } else {
            return res.status(400).send(
                generateResponse(false, "customer not found", 400, null))
        }
    }

    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updatePurchaseOrder(req: any, res: any) {
    try {
        // Destructure orderData and itemData from the request body
        const { orderData, itemData } = req.body;
        console.log(orderData)


        // Extract the sot_id from orderData
        const pot_id = orderData.pot_id;


        // Start a database transaction                   
        await client.query('BEGIN');


        // Update sales_order
        const updateSalesOrder = await purchaseOrderService.updateOrderData(orderData, pot_id)
        console.log(updateSalesOrder, "mmmmmmmm");


        // Fetch existing items for the order
        const existingItemsResult = await purchaseOrderService.existingItemsResult(pot_id)

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults = [];

        // Iterate through existing items to check for updates or removals
        for (const existingItem of existingItems) {
            // Check if the existing item is in the updated itemData
            const updatedItem = itemData.find((item: { item_id: any; }) => item.item_id === existingItem.item_id);

            if (updatedItem) {
                updatedItem.item_to_be_received = updatedItem.item_quantity
                updatedItem.item_invoice_open_quantity = updatedItem.item_quantity
                // Item exists, construct the SET clause for updating the item
                const updateItemResult = await purchaseOrderService.updatedItem(updatedItem, pot_id)
                itemResults.push(updateItemResult.rows[0]);

            } else {
                // Item does not exist in the updated itemData, construct the query to remove it

                const removeItemResult = await purchaseOrderService.removeItem(pot_id, existingItem.item_id)
                // itemResults.push(removeItemResult.rows);
            }
        }

        // Check for new items to be added
        const newItems = itemData.filter((item: { item_id: any; }) => !existingItems.find((existingItem: { item_id: any; }) => existingItem.item_id === item.item_id));

        // Iterate through new items 
        for (const newItem of newItems) {
            newItem.item_to_be_received = newItem.item_quantity
            newItem.item_invoice_open_quantity = newItem.item_quantity
            newItem.pot_id = pot_id


            // Construct the field names for the INSERT query
            const addItemResult = await purchaseOrderService.addItem(newItem)

            itemResults.push(addItemResult.rows[0]);
        }

        // Commit the transaction
        await client.query('COMMIT');

        // Send the response with the updated orderData and itemResults
        return res.status(200).send(
            generateResponse(true, "purchase order updated successfully", 200, { orderData: updateSalesOrder.rows[0], itemData: itemResults })
        )

    } catch (err) {
        // Rollback the transaction in case of an error
        await client.query('ROLLBACK');

        // Log the error and send a 500 Internal Server Error response
        console.error(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function addGOp(req: any, res: any) {
    try {
        await client.query('BEGIN'); 
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body

        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getGORNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        const cmr_phone_number = orderData.cmr_phone_number
        orderData.gort_invoice_number = getNextInvoiceNumber
        if (orderData && itemData) {

             const [addOrder, getbasepricelist] = await Promise.all([purchaseOrderService.addGopOrder(orderData, itemData, itemBatchData,client), discountService.getPricelistById('01HS5HJYWZ5DG2CW4EHX2W7A8V')])

            if (getbasepricelist.rows.length > 0) {

                const multipliedItems = itemBatchData.map((item: { item_id: any; item_batch_unit_price: any; item_selling_price: number;item_batch_number:any,item_batch_final_purchase_rate:any
                    item_uom_id:any,item_uom:any
                 }) => {
                    let  item_selling_priceee
                    if(getbasepricelist.rows[0].is_margin_percentage){
                        
                        item_selling_priceee =   parseFloat( item.item_batch_final_purchase_rate )+  ( parseFloat(item.item_batch_final_purchase_rate) * parseFloat(getbasepricelist.rows[0].margin_factor) / 100)
                    
                        console.log(item_selling_priceee,item.item_batch_final_purchase_rate,getbasepricelist.rows[0].margin_factor)
                    }else{
                        item_selling_priceee = item.item_batch_unit_price-  (item.item_batch_unit_price *  getbasepricelist.rows[0].default_factor/100)
                        console.log(item_selling_priceee,item.item_selling_price, getbasepricelist.rows[0].default_factor)
                    }
                    return {
                        item_id: item.item_id,
                        item_base_price: item.item_batch_unit_price,
                        price_list_id: getbasepricelist.rows[0].price_list_id,
                        item_batch_number:item.item_batch_number, 
                        item_selling_price: item.item_batch_unit_price,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_mrp_price :item.item_batch_unit_price, 
                        item_pricing_uom_id:item.item_uom_id,
                        item_pricing_uom:item.item_uom // Assuming pricelistObj.multiplying_factor contains the multiplying factor of the new price list
                    };
                });
                console.log(multipliedItems, "sdddd")
                const additems = await discountService.addItemsToBasePriceListV1(multipliedItems,client)
              
            }

            if (itemBatchData.length > 0) {
                const additemBatches = await purchaseOrderService.additemBatchNumber(itemBatchData,itemData,client)
            }
            if (addOrder?.order.length > 0) {
                 // 
                const additemstopricelistlink = discountService.additemstopricelistlink(itemBatchData,client)
                await client.query('COMMIT');
                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder?.order, itemData: addOrder?.item })
                )

            } else {
                await client.query('ROLLBACK'); 
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        }

    } catch (err) {
        await client.query('ROLLBACK'); 
        console.error(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));

    }
}


export async function updateGop(req: any, res: any) {

    try {
        await client.query('BEGIN'); 
        const orderData = req.body
console.log(orderData,"wwwwwww")
let gort_order_statuss = orderData.gort_order_status
        const updateSalesOrder = await purchaseOrderService.updateGop(orderData)
       console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {
            const orderDetailsResult = await purchaseOrderService.getGopOrderById(orderData.gort_id)
           
            if (orderDetailsResult.length > 0) {
                console.log(gort_order_statuss)
                if(gort_order_statuss == 'draft'){
                let  getbasepricelist  = await    discountService.getPricelistById('01HS5HJYWZ5DG2CW4EHX2W7A8V')
                    for(let item of orderDetailsResult[0].itemData ){
                        item.item_received_quantity = item.item_quantity
                        let itemData = item
                        itemData.item_received_quantity = item.item_quantity
                        let itemBatchData = item.itemBatchData
                        const multipliedItems = itemBatchData.map((item: { item_id: any; item_batch_unit_price: any; item_selling_price: number;
                            item_batch_number:any,
                            item_batch_final_purchase_rate:any ,
                            item_uom_id:any,item_uom:any
                        }) => {
                            return {
                                item_id: item.item_id,
                                item_base_price: item.item_batch_unit_price,
                                price_list_id: getbasepricelist.rows[0].price_list_id,
                                item_batch_number:item.item_batch_number, 
                                item_selling_price: item.item_batch_final_purchase_rate * getbasepricelist.rows[0].margin_factor,
                                item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                                item_mrp_price :item.item_batch_unit_price,
                                item_pricing_uom_id:item.item_uom_id,
                                item_pricing_uom:item.item_uom  // Assuming pricelistObj.multiplying_factor contains the multiplying factor of the new price list
                            };
                        });
                        console.log(multipliedItems, "sdddd")
                        const additems = await discountService.addItemsToBasePriceListV1(multipliedItems,client)
                       console.log(itemBatchData,itemData,"sssssssssssssssss")
                       let itemda = [itemData]

                        const additemBatches = await purchaseOrderService.additemBatchNumber(itemBatchData,itemda,client)
                       
                        
                        purchaseOrderService.updatePurchaseOrderFn(itemda)
                    }

                }

                await client.query('COMMIT');

                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, { orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData })
                )
            } else {
                await client.query('ROLLBACK'); 
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            await client.query('ROLLBACK'); 
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }

    }
    catch (error) {
        await client.query('ROLLBACK'); 
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getGopOrderList(req: any, res: any) {
    try {

        const getGopOrderList = await purchaseOrderService.getGopOrderList(req.query)

        if (getGopOrderList) {
            return res.status(200).send(generateResponse(true, "gop ordeer fetched successfully", 200, {
                totalCount: getGopOrderList.totalRowsCount,
                orderList: getGopOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "gop order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getGopitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await purchaseOrderService.getGopVendorDetails(queryParams[0].gort_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await purchaseOrderService.getGopitemsList(queryParams[i])
            const getGOPitemBatchData = await purchaseOrderService.getGOPitemBatchData(queryParams[i])

            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                let item = orderDetailsResult.rows
                if (getGOPitemBatchData.invoice.length > 0) {
                    let invoiceItems = getGOPitemBatchData.invoice;

                    for (let i = 0; i < invoiceItems.length; i++) {
                        for (let j = 0; j < item.length; j++) {
                            if (
                                invoiceItems[i].item_id === item[j].item_id &&
                                invoiceItems[i].gort_id === item[j].gort_id &&
                                invoiceItems[i].item_batch_number === item[j].item_batch_number
                            ) {
                                item[j].item_sellable_quantity -= invoiceItems[i].item_sellable_quantity;
                                console.log(item[j].item_batch_quantity, item[j], "invoice");
                            }
                        }
                    }
                }

                if (getGOPitemBatchData.returnorder.length > 0) {
                    let returnItems = getGOPitemBatchData.returnorder;

                    for (let i = 0; i < returnItems.length; i++) {
                        for (let j = 0; j < item.length; j++) {
                            console.log(returnItems[i].item_id === item[j].item_id &&
                                returnItems[i].gort_id === item[j].gort_id &&
                                returnItems[i].item_batch_number === item[j].item_batch_number, "qwwwwww")
                            if (
                                returnItems[i].item_id === item[j].item_id &&
                                returnItems[i].gort_id === item[j].gort_id &&
                                returnItems[i].item_batch_number === item[j].item_batch_number
                            ) {
                                item[j].item_sellable_quantity -= returnItems[i].item_sellable_quantity;
                                console.log(item[j].item_sellable_quantity, item[j], "return");
                            }
                        }
                    }
                }
                // Convert grouped items to an array
                const processedItems = new Set(); // Initialize a Set to keep track of processed items

                const formattedResponse = orderDetailsResult.rows.reduce((acc, item) => {
                    // Check if the item has already been processed
                    if (!processedItems.has(item.gort_id + item.item_id)) {
                        // Add the item to the set of processed items
                        processedItems.add(item.gort_id + item.item_id);

                        // Find all batches for the current item
                        const itemBatchData = orderDetailsResult.rows
                            .filter(batch => batch.gort_id === item.gort_id && batch.item_id === item.item_id && batch.item_sellable_quantity !== 0)
                            .map(({ 
                                item_id, 
                                item_batch_number, 
                                item_sellable_quantity, 
                                item_exp_date, 
                                item_batch_free_quantity, 
                                item_batch_unit_price, 
                                item_batch_purchase_rate,
                                item_batch_discount_percentage,
                                item_batch_discount_amount,
                                item_batch_tax_amount,
                                item_batch_tax_percentage,
                                item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate,
                                to_bin_id,
                                to_bin_location
                            }) => {
                                // Parse values to ensure they are numbers
                                const purchaseRate = parseFloat(item_batch_purchase_rate) || 0; // Default to 0 if undefined or null
                                const discountPercentage = parseFloat(item_batch_discount_percentage) || 0;
                                const taxPercentage = parseFloat(item_batch_tax_percentage) || 0;
                                const sellableQuantity = parseInt(item_sellable_quantity) || 0;
                            
                                // Perform calculations
                                const discountedRate = purchaseRate - (discountPercentage / 100) * purchaseRate;
                                const taxAmount = discountedRate * (taxPercentage / 100);
                                const finalPurchaseRate = discountedRate + taxAmount;
                                const totalTaxAmount = sellableQuantity *taxAmount
                                const totalPurchaseRate = sellableQuantity * finalPurchaseRate;
                            
                                // Return updated object
                                return {
                                    item_id,
                                    item_batch_number,
                                    item_sellable_quantity,
                                    item_exp_date:formatDate(item_exp_date),
                                    item_batch_free_quantity,
                                    item_batch_unit_price,
                                    item_batch_purchase_rate,
                                    item_batch_discount_percentage,
                                    item_batch_discount_amount,
                                    item_batch_tax_amount: parseFloat(totalTaxAmount.toFixed(2)), // Ensure rounded value
                                    item_batch_tax_percentage,
                                    item_batch_final_purchase_rate: parseFloat(finalPurchaseRate.toFixed(2)),
                                    item_batch_total_purchase_rate: parseFloat(totalPurchaseRate.toFixed(2)),
                                    to_bin_id,
                                    to_bin_location
                                };
                            });

                            const { itemSellableQuantitySum, itemBatchFreeQuantitySum, itemBatchTotalTaxRateSum, itemTotalAmount } = itemBatchData.reduce((totals, batch) => {
                                totals.itemSellableQuantitySum += parseInt(batch.item_sellable_quantity) || 0;
                                totals.itemBatchFreeQuantitySum += parseInt(batch.item_batch_free_quantity) || 0;
                                totals.itemBatchTotalTaxRateSum += batch.item_batch_tax_amount || 0;
                                totals.itemTotalAmount += batch.item_batch_total_purchase_rate || 0;  // Same as itemBatchTotalPurchaseRateSum
                                return totals;
                            }, {
                                itemSellableQuantitySum: 0,
                                itemBatchFreeQuantitySum: 0,
                                itemBatchTotalTaxRateSum: 0,
                                itemTotalAmount: 0
                            });
                    

                        // Add the formatted item to the accumulator
                        acc.push({ ...item,
                            item_quantity:itemSellableQuantitySum,
                            item_free_quantity:itemBatchFreeQuantitySum,
                            item_total_amount:itemTotalAmount,
                            item_tax_amount:itemBatchTotalTaxRateSum.toFixed(2),
                            item_cgst:(itemBatchTotalTaxRateSum/2).toFixed(2),
                            item_sgst: (itemBatchTotalTaxRateSum/2).toFixed(2),
                             itemBatchData });
                    }
                    return acc;
                }, []);

                console.log(formattedResponse);


                resultArray.push(formattedResponse)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        //console.log(resultArray,"ddd", resultArray['orderData'])


        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);

            return res.status(200).send(generateResponse(true, "items fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.status(400).send(generateResponse(false, "items not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getGopOrderById(req: any, res: any) {
    try {
        const { gort_id } = req.query

        if (gort_id) {

            const orderDetailsResult = await purchaseOrderService.getGopOrderById(gort_id)

            if (orderDetailsResult.length > 0) {




                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getGopOrderByIdHTML(req: any, res: any) {
    try {
        const { gort_id } = req.query

        if (gort_id) {

            const orderDetailsResult = await purchaseOrderService.getGopOrderById(gort_id)
            const storeDetails=await purchaseOrderService.getStoreDetails();
            const taxDetails=await purchaseOrderService.TaxInfoGRN(gort_id);

            if (orderDetailsResult.length > 0 && storeDetails.length >0) {
                const html=(await GRN(orderDetailsResult,storeDetails,taxDetails)).toString();
                if(html){
                    return res.send(generateResponse(true, "converted to html", 200,html));
                }
                else{
                    return res.send(generateResponse(false, "converted to html", 400, null));
                }
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getPurchaseOrderInvoiceitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await purchaseOrderService.getPurchaseInvoiceVendorDetails(queryParams[0].poit_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await purchaseOrderService.getPurchaseOrderInvoiceitemsList(queryParams[i])
            const getinvoiceORReturnitemBatchData = await purchaseOrderService.getReturnInvoiceitemBatchData(queryParams[i])
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                let item = orderDetailsResult.rows
                if (getinvoiceORReturnitemBatchData.returnorder.length > 0) {
                    let invoiceItems = getinvoiceORReturnitemBatchData.returnorder

                    for (let i = 0; i < invoiceItems.length; i++) {
                        for (let j = 0; j < item.length; j++) {
                            if (
                                invoiceItems[i].item_id === item[j].item_id &&
                                invoiceItems[i].poit_id === item[j].poit_id &&
                                invoiceItems[i].item_batch_number === item[j].item_batch_number
                            ) {
                                item[j].item_sellable_quantity -= invoiceItems[i].item_sellable_quantity;
                                console.log(item[j].item_batch_quantity, item[j], "invoice");
                            }
                        }
                    }
                }
                // Convert grouped items to an array
                const processedItems = new Set(); // Initialize a Set to keep track of processed items

                const formattedResponse = orderDetailsResult.rows.reduce((acc, item) => {
                    // Check if the item has already been processed
                    if (!processedItems.has(item.poit_id + item.item_id)) {
                        // Add the item to the set of processed items
                        processedItems.add(item.poit_id + item.item_id);

                        // Find all batches for the current item
                        const itemBatchData = orderDetailsResult.rows
                            .filter(batch => batch.poit_id === item.poit_id && batch.item_id === item.item_id)
                            .map(({ 
                                item_id, 
                                item_batch_number, 
                                item_sellable_quantity, 
                                item_exp_date, 
                                item_batch_free_quantity, 
                                item_batch_unit_price, 
                                item_batch_purchase_rate,
                                item_batch_discount_percentage,
                                item_batch_discount_amount,
                                item_batch_tax_amount,
                                item_batch_tax_percentage,
                                item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate,
                                to_bin_id,
                                to_bin_location
                            }) => {
                                // Parse values to ensure they are numbers
                                const purchaseRate = parseFloat(item_batch_purchase_rate) || 0; // Default to 0 if undefined or null
                                const discountPercentage = parseFloat(item_batch_discount_percentage) || 0;
                                const taxPercentage = parseFloat(item_batch_tax_percentage) || 0;
                                const sellableQuantity = parseFloat(item_sellable_quantity) || 0;
                            
                                // Perform calculations
                                const discountedRate = purchaseRate - (discountPercentage / 100) * purchaseRate;
                                const taxAmount = discountedRate * (taxPercentage / 100);
                                const finalPurchaseRate = discountedRate + taxAmount;
                                const totalTaxAmount = sellableQuantity *taxAmount
                                const totalPurchaseRate = sellableQuantity * finalPurchaseRate;
                            
                                // Return updated object
                                return {
                                    item_id,
                                    item_batch_number,
                                    item_sellable_quantity,
                                    item_exp_date:formatDate(item_exp_date),
                                    item_batch_free_quantity,
                                    item_batch_unit_price,
                                    item_batch_purchase_rate,
                                    item_batch_discount_percentage,
                                    item_batch_discount_amount,
                                    item_batch_tax_amount: parseFloat(totalTaxAmount.toFixed(2)), // Ensure rounded value
                                    item_batch_tax_percentage,
                                    item_batch_final_purchase_rate: parseFloat(finalPurchaseRate.toFixed(2)),
                                    item_batch_total_purchase_rate: parseFloat(totalPurchaseRate.toFixed(2)),
                                    to_bin_id,
                                    to_bin_location
                                };
                            });

                            const { itemSellableQuantitySum, itemBatchFreeQuantitySum, itemBatchTotalTaxRateSum, itemTotalAmount } = itemBatchData.reduce((totals, batch) => {
                                totals.itemSellableQuantitySum += parseInt(batch.item_sellable_quantity) || 0;
                                totals.itemBatchFreeQuantitySum += parseInt(batch.item_batch_free_quantity) || 0;
                                totals.itemBatchTotalTaxRateSum += batch.item_batch_tax_amount || 0;
                                totals.itemTotalAmount += batch.item_batch_total_purchase_rate || 0;  // Same as itemBatchTotalPurchaseRateSum
                                return totals;
                            }, {
                                itemSellableQuantitySum: 0,
                                itemBatchFreeQuantitySum: 0,
                                itemBatchTotalTaxRateSum: 0,
                                itemTotalAmount: 0
                            });
                    

                        // Add the formatted item to the accumulator
                        acc.push({ ...item,
                            item_quantity:itemSellableQuantitySum,
                            item_free_quantity:itemBatchFreeQuantitySum,
                            item_total_amount:itemTotalAmount,
                            item_tax_amount:itemBatchTotalTaxRateSum.toFixed(2),
                            item_cgst:(itemBatchTotalTaxRateSum/2).toFixed(2),
                            item_sgst: (itemBatchTotalTaxRateSum/2).toFixed(2),
                             itemBatchData });
                    }
                    return acc;
                }, []);

                console.log(formattedResponse);


                resultArray.push(formattedResponse)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addPurchaseOrderInvoice(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getPurchaseInvoiceNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        orderData.poit_invoice_number = getNextInvoiceNumber

        if (orderData && itemData) {
            const addOrder = await purchaseOrderService.addPurchaseOrderInvoice(orderData, itemData, itemBatchData)
            if (addOrder) {

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function updatePurchaseOrderInvoice(req: any, res: any) {

    try {
        const orderData = req.body
        let poit_order_statuss = orderData.poit_order_status
        const updateSalesOrder = await purchaseOrderService.updatePurchaseOrderInvoice(orderData)
        console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {
            const orderDetailsResult = await purchaseOrderService.getPurchaseOrderInvoiceById(orderData.poit_id)

            if (orderDetailsResult.length > 0) {
                   if(poit_order_statuss == 'draft'){
                purchaseOrderService.updateGOPItemData(orderDetailsResult[0].itemData)
                   }
                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, { orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData })
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }

    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseOrderInvoiceList(req: any, res: any) {
    try {

        const getOrderList = await purchaseOrderService.getPurchaseOrderInvoiceList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales invoice ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseOrderInvoiceById(req: any, res: any) {
    try {
        const { poit_id } = req.query

        if (poit_id) {

            const orderDetailsResult = await purchaseOrderService.getPurchaseOrderInvoiceById(poit_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {

                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseOrderInvoiceByIdHTML(req: any, res: any) {
    try {
        const { poit_id } = req.query

        if (poit_id) {

            const orderDetailsResult = await purchaseOrderService.getPurchaseOrderInvoiceById(poit_id)
            const storeDetails=await purchaseOrderService.getStoreDetails();
            const taxDetails=await purchaseOrderService.TaxInfo(poit_id);
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {
                const html=await GRN(orderDetailsResult,storeDetails,taxDetails,"POI");
                if(html){
                    return res.send(generateResponse(true, "Invoice fetched successfully", 200,html));
                }
                else{
                    console.log("hehe");
                    return res.send(generateResponse(false, "Invoice not found", 400, null));
                }
            } else {
                console.log("hehe1");
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function addPurhcaseReturnInvoice(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getPurchaseReturnNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        orderData.prt_invoice_number = getNextInvoiceNumber

        if (orderData && itemData) {
            const addOrder = await purchaseOrderService.addPurchaseReturnInvoice(orderData, itemData, itemBatchData)
            if (addOrder) {

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}
export async function updatePurchaseReturnInvoice(req: any, res: any) {

    try {
        const orderData = req.body

        const updateSalesOrder = await purchaseOrderService.updatePurchaseReturnInvoice(orderData)
        console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {
            const orderDetailsResult = await purchaseOrderService.getPurchaseReturnInvoiceById(orderData.prt_id)
            console.log(orderDetailsResult, "bbbbbbbbb");


            if (orderDetailsResult.length > 0) {

                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, { orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData })
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }

    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseReturnInvoiceList(req: any, res: any) {
    try {

        const getOrderList = await purchaseOrderService.getPurchaseReturnInvoiceList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales invoice ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseReturnInvoiceById(req: any, res: any) {
    try {
        const { prt_id } = req.query

        if (prt_id) {

            const orderDetailsResult = await purchaseOrderService.getPurchaseReturnInvoiceById(prt_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {
                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));

            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }

        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseReturnitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getVendorDetails = await purchaseOrderService.getPurchaseReturnVendorDetails(queryParams[0].prt_id)



        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await purchaseOrderService.getPurchaseReturnitemsList(queryParams[i])

            const getinvoiceORReturnitemBatchData = await purchaseOrderService.getReturnitemBatchData(queryParams[i])
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                let item = orderDetailsResult.rows
                if (getinvoiceORReturnitemBatchData.returnorder.length > 0) {
                    let invoiceItems = getinvoiceORReturnitemBatchData.returnorder

                    for (let i = 0; i < invoiceItems.length; i++) {
                        for (let j = 0; j < item.length; j++) {
                            if (
                                invoiceItems[i].item_id === item[j].item_id &&
                                invoiceItems[i].prt_id === item[j].prt_id &&
                                invoiceItems[i].item_batch_number === item[j].item_batch_number
                            ) {
                                item[j].item_sellable_quantity -= invoiceItems[i].item_sellable_quantity;
                                console.log(item[j].item_batch_quantity, item[j], "invoice");
                            }
                        }
                    }
                }

                // Convert grouped items to an array
                const processedItems = new Set(); // Initialize a Set to keep track of processed items

                const formattedResponse = orderDetailsResult.rows.reduce((acc, item) => {
                    // Check if the item has already been processed
                    if (!processedItems.has(item.prt_id + item.item_id)) {
                        // Add the item to the set of processed items
                        processedItems.add(item.prt_id + item.item_id);

                        // Find all batches for the current item
                        const itemBatchData = orderDetailsResult.rows
                            .filter(batch => batch.prt_id === item.prt_id && batch.item_id === item.item_id && batch.item_sellable_quantity != 0)
                            .map(({ 
                                item_id, 
                                item_batch_number, 
                                item_sellable_quantity, 
                                item_exp_date, 
                                item_batch_free_quantity, 
                                item_batch_unit_price, 
                                item_batch_purchase_rate,
                                item_batch_discount_percentage,
                                item_batch_discount_amount,
                                item_batch_tax_amount,
                                item_batch_tax_percentage,
                                item_batch_final_purchase_rate,
                                item_batch_total_purchase_rate,
                                to_bin_id,
                                to_bin_location
                            }) => {
                                // Parse values to ensure they are numbers
                                const purchaseRate = parseFloat(item_batch_purchase_rate) || 0; // Default to 0 if undefined or null
                                const discountPercentage = parseFloat(item_batch_discount_percentage) || 0;
                                const taxPercentage = parseFloat(item_batch_tax_percentage) || 0;
                                const sellableQuantity = parseFloat(item_sellable_quantity) || 0;
                            
                                // Perform calculations
                                const discountedRate = purchaseRate - (discountPercentage / 100) * purchaseRate;
                                const taxAmount = discountedRate * (taxPercentage / 100);
                                const finalPurchaseRate = discountedRate + taxAmount;
                                const totalTaxAmount = sellableQuantity *taxAmount
                                const totalPurchaseRate = sellableQuantity * finalPurchaseRate;
                            
                                // Return updated object
                                return {
                                    item_id,
                                    item_batch_number,
                                    item_sellable_quantity,
                                    item_exp_date:formatDate(item_exp_date),
                                    item_batch_free_quantity,
                                    item_batch_unit_price,
                                    item_batch_purchase_rate,
                                    item_batch_discount_percentage,
                                    item_batch_discount_amount,
                                    item_batch_tax_amount: parseFloat(totalTaxAmount.toFixed(2)), // Ensure rounded value
                                    item_batch_tax_percentage,
                                    item_batch_final_purchase_rate: parseFloat(finalPurchaseRate.toFixed(2)),
                                    item_batch_total_purchase_rate: parseFloat(totalPurchaseRate.toFixed(2)),
                                    to_bin_id,
                                    to_bin_location
                                };
                            });

                            const { itemSellableQuantitySum, itemBatchFreeQuantitySum, itemBatchTotalTaxRateSum, itemTotalAmount } = itemBatchData.reduce((totals, batch) => {
                                totals.itemSellableQuantitySum += parseInt(batch.item_sellable_quantity) || 0;
                                totals.itemBatchFreeQuantitySum += parseInt(batch.item_batch_free_quantity) || 0;
                                totals.itemBatchTotalTaxRateSum += batch.item_batch_tax_amount || 0;
                                totals.itemTotalAmount += batch.item_batch_total_purchase_rate || 0;  // Same as itemBatchTotalPurchaseRateSum
                                return totals;
                            }, {
                                itemSellableQuantitySum: 0,
                                itemBatchFreeQuantitySum: 0,
                                itemBatchTotalTaxRateSum: 0,
                                itemTotalAmount: 0
                            });
                    

                        // Add the formatted item to the accumulator
                        acc.push({ ...item,
                            item_quantity:itemSellableQuantitySum,
                            item_free_quantity:itemBatchFreeQuantitySum,
                            item_total_amount:itemTotalAmount,
                            item_tax_amount:itemBatchTotalTaxRateSum.toFixed(2),
                            item_cgst:(itemBatchTotalTaxRateSum/2).toFixed(2),
                            item_sgst: (itemBatchTotalTaxRateSum/2).toFixed(2),
                             itemBatchData });
                    }
                    return acc;
                }, []);

                console.log(formattedResponse);


                resultArray.push(formattedResponse)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getVendorDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function addPurchaseCreditNote(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, itemBatchData: itemBatchData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getPurchaseCreditNoteNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        orderData.pct_invoice_number = getNextInvoiceNumber

        if (orderData && itemData) {
            const addOrder = await purchaseOrderService.addPurchaseCreditNote(orderData, itemData, itemBatchData)
            if (addOrder) {

                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "order placing unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}
export async function updatePurchaseCreditNote(req: any, res: any) {

    try {
        const orderData = req.body

        const updateSalesOrder = await purchaseOrderService.updatePurchaseCreditNote(orderData)
        console.log(updateSalesOrder.rows, "ddddd")
        if (updateSalesOrder.rows.length > 0) {
            const orderDetailsResult = await purchaseOrderService.getPurchaseCreditNoteById(orderData.pct_id)

            if (orderDetailsResult.length > 0) {

                return res.status(200).send(
                    generateResponse(true, "order updated succesfully", 200, { orderData: orderDetailsResult[0].orderData, itemData: orderDetailsResult[0].itemData })
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order update unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "order update unsuccesfully", 400, null)
            )
        }

    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseCreditNoteList(req: any, res: any) {
    try {

        const getOrderList = await purchaseOrderService.getPurchaseCreditNoteList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "sales invoice ordeer fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "sales order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getPurchaseCreditNoteById(req: any, res: any) {
    try {
        const { pct_id } = req.query
        console.log(req.query, "ffffffffff")

        if (pct_id) {
            const orderDetailsResult = await purchaseOrderService.getPurchaseCreditNoteById(pct_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0) {
                return res.send(generateResponse(true, "Invoice fetched successfully", 200, orderDetailsResult));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }

        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function voidPurchaseOrder(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const pot_id = req.body.pot_id;

        let pot_order_status = 'closed'
        const [getOrderById, getdocumentsListofPurchaseOrder] = await Promise.all([purchaseOrderService.getPurchaseOrderById(pot_id), purchaseOrderService.getdocumentsListofPurchaseOrder(pot_id)])
        if (getdocumentsListofPurchaseOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the purchase order", 200, getdocumentsListofPurchaseOrder.rows)
            )
        } else {

            const insertCancelOrder = await purchaseOrderService.insertCancelPurchaseOrder(getOrderById[0].orderData, getOrderById[0].itemData)
            const updateSalesOrder = await purchaseOrderService.updatePurchaseOrderStatus(pot_order_status, pot_id)

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {
                await client.query('COMMIT');



                // Send the response with the updated orderData and itemResults
                return res.status(200).send(
                    generateResponse(true, "order updated successfully", 200, updateSalesOrder)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order updated unsuccesfully", 400, null)
                )
            }
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidGOPOrder(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const gort_id = req.body.gort_id;

        let gort_order_status = 'closed'
        const [getOrderById, getdocumentsListofDeliveryOrder] = await Promise.all([purchaseOrderService.getGopOrderById(gort_id), purchaseOrderService.getdocumentsListGOP(gort_id)])
        if (getdocumentsListofDeliveryOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the goods order reciept", 200, getdocumentsListofDeliveryOrder.rows)
            )
        } else {

            const insertCancelOrder = await purchaseOrderService.insertCancelGopOrder(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder, resetQuantity] = await Promise.all([purchaseOrderService.updateGOPOrderStatus(gort_order_status, gort_id), purchaseOrderService.resetGOPOpenQuantity(getOrderById[0].itemData)])

            // Fetch existing items for the order

            if (updateSalesOrder.rows.length > 0) {
                const deleteinvoiceDoccuments = await purchaseOrderService.deleteGOPDocumentlist(gort_id)
                await client.query('COMMIT');


                // Send the response with the updated orderData and itemResults
                return res.status(200).send(
                    generateResponse(true, "order updated successfully", 200, updateSalesOrder)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order updated unsuccesfully", 400, null)
                )
            }
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidInvoice(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const poit_id = req.body.poit_id;

        let poit_order_status = 'closed'
        const [getOrderById, getdocumentsListofDeliveryOrder] = await Promise.all([purchaseOrderService.getPurchaseOrderInvoiceById(poit_id), purchaseOrderService.getdocumentsListofPurchaseInvoice(poit_id)])
        console.log(getdocumentsListofDeliveryOrder.rows)
        if (getdocumentsListofDeliveryOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the pruchase invoice", 200, getdocumentsListofDeliveryOrder.rows)
            )
        } else {

            const insertCancelOrder = await purchaseOrderService.cancelPurchaseOrderInvoice(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder, resetQuantity] = await Promise.all([purchaseOrderService.updateInvoiceOrderStatus(poit_order_status, poit_id), purchaseOrderService.resetInvoiceOpenQuantity(getOrderById[0].itemData)])

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {
                const deleteinvoiceDoccuments = await purchaseOrderService.deleteInvoiceDocumentlist(poit_id)
                await client.query('COMMIT');


                return res.status(200).send(
                    generateResponse(true, "order updated successfully", 200, null)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order updated unsuccesfully", 400, null)
                )
            }
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidPurchaseCreditNote(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const pct_id = req.body.pct_id;

        let pct_order_status = 'closed'
        const getOrderById = await purchaseOrderService.getPurchaseCreditNoteById(pct_id)
        console.log(getOrderById)
        if (getOrderById.length > 0) {

            const insertCancelOrder = await purchaseOrderService.insertCancelCreditNote(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder, resetQuantity] = await Promise.all([purchaseOrderService.updateCreditNoteStatus(pct_order_status, pct_id), purchaseOrderService.resetCreditOpenQuantity(getOrderById[0].itemData)])

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {

                const deleteCreditNote = await purchaseOrderService.deleteCreditNoteDocumentlist(pct_id)
                await client.query('COMMIT');
                return res.status(200).send(
                    generateResponse(true, "order void successfully", 200, null)
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "order void unsuccesfully", 400, null)
                )
            }
        } else {

            return res.status(400).send(
                generateResponse(false, "order void unsuccesfully", 400, null)
            )
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function voidPurhcaseReturnInvoice(req: any, res: any) {
    try {
        await client.query('BEGIN');
        // Destructure orderData and itemData from the request body
        const prt_id = req.body.prt_id;

        let prt_order_status = 'closed'
        const [getOrderById, getdocumentsListofDeliveryOrder] = await Promise.all([purchaseOrderService.getPurchaseReturnInvoiceById(prt_id), purchaseOrderService.getdocumentsListofPurchaseReturn(prt_id)])
        console.log(getdocumentsListofDeliveryOrder.rows, getOrderById[0].orderData)
        if (getdocumentsListofDeliveryOrder.rows.length > 0) {
            return res.status(400).send(
                generateResponse(true, "cancel these document to void the return order", 200, getdocumentsListofDeliveryOrder.rows)
            )
        } else if (getOrderById.length > 0) {


            const insertCancelOrder = await purchaseOrderService.insertCancelurchaseReturnInvoice(getOrderById[0].orderData, getOrderById[0].itemData)
            const [updateSalesOrder, ResetQuantity] = await Promise.all([purchaseOrderService.updateReturnOrderStatus(prt_order_status, prt_id), purchaseOrderService.resetPurchaseReturnQuantity(getOrderById[0].itemData)])

            // Fetch existing items for the order


            if (updateSalesOrder.rows.length > 0) {
                const deleteinvoiceDoccuments = await purchaseOrderService.deleteReturnInvoiceDocumentlist(prt_id)
                await client.query('COMMIT');


                return res.status(200).send(
                    generateResponse(true, "order updated successfully", 200, null)
                )
            } else {
                await client.query('ROLLBACK');
                return res.status(400).send(
                    generateResponse(false, "order updated unsuccesfully", 400, null)
                )
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "invoice not found", 400, null)
            )
        }

    } catch (err) {
        await client.query('ROLLBACK');
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}



export async function getPurchaseInvoiceListSearch(req: any, res: any) {
    try {

        console.log()
        const [getInvoiceListResult, getOpenBalance] = await Promise.all([purchaseOrderService.getPurchaseInvoiceListSearch(req.query), purchaseOrderService.getOpenBalanceOfCMR(req.query.value)])
        console.log(getInvoiceListResult.rows)
        if (getInvoiceListResult.rows.length > 0) {
            return res.status(200).send(generateResponse(true, "Invoice fetched successfully", 200, { getInvoiceResult: getInvoiceListResult.rows, cmrOpenBalance: getOpenBalance.rows[0] }));
        } else {
            return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
        }

    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function addPurchasebulkOrder(req: any, res: any) {

    try {
        const { itemData: itemData } = req.body
        // console.log(orderData)
        const store_id = itemData.store_id
        let resultArray = []


        const newItemData = await Promise.all(itemData.map(async (item: any) => {
            const getTaxRate = await discountService.getTaxAmount(item.item_id);

            if (getTaxRate.rows.length > 0) {
                const cgstRate = parseFloat(getTaxRate.rows[0].rate) / 2 || 0;
                const sgstRate = parseFloat(getTaxRate.rows[0].rate) / 2 || 0;
                const taxPercentage = cgstRate + sgstRate;
                const discountAmount = 0; // Replace with actual discount logic
                const discountedAmount = (item.item_unit_price * item.item_quantity) - discountAmount;
                const taxAmount = discountedAmount - (discountedAmount * (100 / (100 + taxPercentage)));

                // Update item with calculated tax values
                item.item_tax_amount = parseFloat(taxAmount.toFixed(2));
                item.item_total_tax_percentage = parseFloat(taxPercentage.toFixed(2));
                item.item_gst = parseFloat(taxAmount.toFixed(2)) / 2
                item.item_sgst = parseFloat(taxAmount.toFixed(2)) / 2
            }

            return item;
        }));


        console.log(newItemData, "adtertax", JSON.stringify(newItemData, null, 2))


        const ordersArray: any = [];

        newItemData.forEach((item: any) => {
            // Find the existing order for the cmr_id, if it exists
            let order = ordersArray.find((order: { orderData: { cmr_id: any; }; }) => order.orderData.cmr_id === item.cmr_id);

            if (!order) {
                // If no order exists for this cmr_id, create a new one
                const currentTime = new Date().toISOString();
                order = {
                    orderData: {
                        cmr_phone_number: null,
                        cmr_code: item.cmr_code,
                        cmr_name: item.cmr_name,
                        pot_order_date: currentTime,
                        pot_document_date: currentTime,
                        pot_delivery_date: currentTime,
                        store_id: "STR0001",
                        pot_total_gst: 0,
                        pot_total_discount: 0,
                        pot_transaction_id: "",
                        pot_payment_method: null,
                        pot_billing_address: "",
                        pot_total_amount: 0,
                        remarks: "",
                        cmr_id: item.cmr_id,
                        pot_sub_total: 0
                    },
                    itemData: []
                };
                // Add the new order to the ordersArray
                ordersArray.push(order);
            }

            // Add item to itemData for the current cmr_id
            order.itemData.push({
                item_id: item.item_id,
                item_code: item.item_code,
                item_generic_name: item.item_generic_name,
                item_name: item.item_name,
                item_pack_size: item.item_pack_size,
                item_unit_price: item.item_unit_price,
                item_uom: item.item_uom,
                item_quantity: item.item_quantity,
                item_discount_amount: 0,
                item_discount_percentage: 0,
                item_tax_amount: item.item_tax_amount,
                item_total_tax_percentage: item.item_total_tax_percentage,
                item_total_amount: item.item_total_amount,
                item_gst: item.item_gst,
                item_sgst: item.item_sgst,
            });

            // Sum up the values for pot_total_gst, pot_total_discount, and pot_total_amount
            order.orderData.pot_total_gst += item.item_tax_amount;
            order.orderData.pot_total_discount = 0;
            order.orderData.pot_total_amount += parseFloat(item.item_total_amount);
            //  order.orderData.pot_sub_total =   order.orderData.pot_total_amount - order.orderData.pot_total_gst  
        });


        console.log(typeof (ordersArray), "dfghgr", JSON.stringify(ordersArray, null, 2));
        for (const order of ordersArray) {
            // const getNextInvoiceNumber =  await nextInvoicenumber.getPurchaseOrderNextInvoiceNumber()
            // console.log(getNextInvoiceNumber,"ertytrert");

            // if (!getNextInvoiceNumber) {
            //     return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
            // }

            // order.orderData.pot_invoice_number = getNextInvoiceNumber

            console.log(order.orderData, order.itemData)
            console.log('add order', JSON.stringify(order.orderData, null, 2), JSON.stringify(order.itemData, null, 2));
            if (order.orderData && order.itemData) {
                const addOrder = await purchaseOrderService.addPurchaseOrder(order.orderData, order.itemData)
                console.log(addOrder, "after adding orders")
                if (addOrder) {

                    resultArray.push(addOrder.order)


                }
            }
        }

        if (resultArray.length > 0) {


            return res.status(200).send(
                generateResponse(true, "order placed succesfully", 200, null)
            )


        } else {
            return res.status(400).send(
                generateResponse(false, "order placing unsuccesfully", 400, null)
            )

        }

    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function getUnSyncPurchaseOrder(){
    try{
      
      const [getUnSyncPurchaseOrder,getposid] = await Promise.all([purchaseOrderService.getUnSyncPurchaseOrder(),getposId()])
      console.log(getposid.rows)
      const pos_id = getposid.rows[0].pos_id
      if (getUnSyncPurchaseOrder.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncPurchaseOrder.rows) {
                  const orderId = item.pot_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                        orderData: {
                            pot_id: item.pot_id,
                            store_id: item.store_id,
                            cmr_id:item.cmr_id,
                            cmr_phone_number: item.cmr_phone_number,
                            pot_invoice_number:item.pot_invoice_number,
                            pot_total_gst: item.pot_total_gst,
                            pot_total_discount: item.pot_total_discount,
                            pot_payment_status: item.pot_payment_status,
                            pot_transaction_id: item.pot_transaction_id,
                            pot_order_status: item.pot_order_status,
                            pot_payment_method: item.pot_payment_method,
                            pot_billing_address: item.pot_billing_address,
                            pot_total_amount: item.pot_total_amount,
                            pot_delivery_date: item.pot_delivery_date,
                            pot_document_date: item.pot_document_date,
                            cmr_code: item.cmr_code,
                            cmr_name: item.cmr_name,
                            created_date: item.created_date,
                            update_date: item.update_date,
                            pos_id:pos_id
                        },
                        itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                
            
                    groupedOrders[orderId].itemData.push({
                        pot_id: item.pot_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_to_be_received:item.item_to_be_received,
                        item_invoice_open_quantity:item.item_invoice_open_quantity,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_uom:item.item_uom,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                    });
                  }
          
                
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
              
                    
                
                  
  
               //  console.log(JSON.stringify(order, null, 2), 'Processing Order after rrrrr');
  
                const syncedResult = await purchaseOrderService.syncPurchaseOrder(order.orderData,newItemsData,);
              }
            }
    }catch(error){
  
    }
 }

 export async function getUnSyncedGRN(){
    try{

        const [getUnSyncedStockTransfer,getposid] = await Promise.all([purchaseOrderService.getUnSyncedGRN(),getposId()])
        console.log(getposid.rows)
        const pos_id = getposid.rows[0].pos_id
      if (getUnSyncedStockTransfer.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedStockTransfer.rows) {
                  const orderId = item.gort_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                      orderData: {
                        gort_id: item.gort_id,
                        store_id: item.store_id,
                        cmr_id: item.cmr_id,
                        cmr_phone_number: item.cmr_phone_number,
                        remarks: item.remarks,
                        gort_total_gst: item.gort_total_gst,
                        gort_invoice_number:item.gort_invoice_number,
                        gort_total_discount: item.gort_total_discount,
                        gort_payment_status: item.gort_payment_status,
                        gort_transaction_id: item.gort_transaction_id,
                        gort_order_status: item.gort_order_status,
                        gort_payment_method: item.gort_payment_method,
                        gort_billing_address: item.gort_billing_address,
                        gort_total_amount: item.gort_total_amount,
                        gort_sub_total:item.gort_sub_total,
                        gort_delivery_date: item.gort_delivery_date,
                        gort_document_date: item.gort_document_date,
                        cmr_code: item.cmr_code,
                        cmr_name: item.cmr_name,
                        created_date: item.created_date,
                        update_date: item.update_date,
                        pos_id:pos_id
                      },
                      itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        gort_id: item.gort_id,
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                        item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                        item_exp_date: formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_tax_amount:item.item_batch_tax_amount,
                        item_batch_tax_percentage:item.item_batch_tax_percentage,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                        to_bin_id :item.to_bin_id,
                        to_bin_location:item.to_bin_location
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        gort_id: item.gort_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        pot_id:item.pot_id,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_received_quantity:item.item_received_quantity,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_return_open_quantity:item.item_return_open_quantity,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_to_be_received:item.item_to_be_received,
                        item_total_amount: item.item_total_amount,
                        item_uom:item.item_uom,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                      itemBatchData: [
                        {
                            gort_id: item.gort_id,
                            item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                        item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                        item_exp_date: formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_tax_amount:item.item_batch_tax_amount,
                        item_batch_tax_percentage:item.item_batch_tax_percentage,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                        to_bin_id :item.to_bin_id,
                        to_bin_location:item.to_bin_location
                        },
                      ],
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
              //  console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await purchaseOrderService.syncGRN(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }



export async function getUnPurchaseInvoice(){
    try{
        const [getUnSyncedStockTransfer,getposid] = await Promise.all([purchaseOrderService.getUnPurchaseInvoice(),getposId()])
        console.log(getposid.rows)
        const pos_id = getposid.rows[0].pos_id
      
      if (getUnSyncedStockTransfer.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedStockTransfer.rows) {
                  const orderId = item.poit_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                      orderData: {
                        poit_id: item.poit_id,
                        store_id: item.store_id,
                        cmr_id: item.cmr_id,
                        cmr_phone_number: item.cmr_phone_number,
                        remarks: item.remarks,
                        poit_total_gst: item.poit_total_gst,
                        poit_invoice_number:item.poit_invoice_number,
                        poit_total_discount: item.poit_total_discount,
                        poit_payment_status: item.poit_payment_status,
                        poit_transaction_id: item.poit_transaction_id,
                        poit_order_status: item.poit_order_status,
                        poit_payment_method: item.poit_payment_method,
                        poit_sub_total:item.poit_sub_total,
                        poit_billing_address: item.poit_billing_address,
                        poit_total_amount: item.poit_total_amount,
                        poit_delivery_date: item.poit_delivery_date,
                        poit_document_date: item.poit_document_date,
                        cmr_code: item.cmr_code,
                        cmr_name: item.cmr_name,
                        created_date: item.created_date,
                        update_date: item.update_date,
                        pos_id:pos_id
                      },
                      itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        poit_id: item.poit_id,
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                        item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                        item_exp_date:formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_tax_amount:item.item_batch_tax_amount,
                        item_batch_tax_percentage:item.item_batch_tax_percentage,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                        to_bin_id :item.to_bin_id,
                        to_bin_location:item.to_bin_location
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        poit_id: item.poit_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        gort_id:item.gort_id,
                        pot_id:item.pot_id,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_credit_quanity_remaining:item.item_credit_quanity_remaining,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_uom:item.item_uom,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                      itemBatchData: [
                        {
                            poit_id: item.poit_id,
                            item_id: item.item_id,
                            item_batch_number: item.item_batch_number,
                            item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                            item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                            item_exp_date: formatDate(item.item_exp_date),
                            item_mfg_date: item.item_mfg_date,
                            item_batch_free_quantity:item.item_batch_free_quantity,
                            item_batch_unit_price:item.item_batch_unit_price,
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_discount_percentage:item.item_batch_discount_percentage,
                            item_batch_discount_amount:item.item_batch_discount_amount,
                            item_batch_tax_amount:item.item_batch_tax_amount,
                            item_batch_tax_percentage:item.item_batch_tax_percentage,
                            item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                            item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                            to_bin_id :item.to_bin_id,
                            to_bin_location:item.to_bin_location
                        },
                      ],
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
            //    console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await purchaseOrderService.syncPurchaseInvoice(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }


  export async function getUnPurchaseReturn(){
    try{
      const getUnSyncedStockTransfer = await purchaseOrderService.getUnPurchaseReturn()
      if (getUnSyncedStockTransfer.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedStockTransfer.rows) {
                  const orderId = item.prt_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                      orderData: {
                        prt_id: item.prt_id,
                        store_id: item.store_id,
                        cmr_phone_number: item.cmr_phone_number,
                        remarks: item.remarks,
                         prt_total_gst: item. prt_total_gst,
                         prt_invoice_number:item.prt_invoice_number,
                         prt_total_discount: item. prt_total_discount,
                         prt_payment_status: item. prt_payment_status,
                         prt_transaction_id: item. prt_transaction_id,
                         prt_order_status: item. prt_order_status,
                         prt_payment_method: item. prt_payment_method,
                         prt_billing_address: item. prt_billing_address,
                         prt_total_amount: item. prt_total_amount,
                         prt_sub_total:item.prt_sub_total,
                         prt_delivery_date: item. prt_delivery_date,
                         prt_document_date: item. prt_document_date,
                        cmr_code: item.cmr_code,
                        cmr_name: item.cmr_name,
                        cmr_id: item.cmr_id,
                        created_date: item.created_date,
                        update_date: item.update_date,
                      },
                      itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        prt_id: item.prt_id,
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                        item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                        item_exp_date: formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_tax_amount:item.item_batch_tax_amount,
                        item_batch_tax_percentage:item.item_batch_tax_percentage,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                        to_bin_id :item.to_bin_id,
                        to_bin_location:item.to_bin_location
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        prt_id: item.prt_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        gort_id:item.gort_id,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_credit_quanity_remaining:item.item_credit_quanity_remaining,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_uom_id:item.item_id,
                        item_uom:item.item_uom,

                      itemBatchData: [
                        {
                            prt_id: item.prt_id,
                            item_id: item.item_id,
                            item_batch_number: item.item_batch_number,
                            item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                            item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                            item_exp_date:formatDate(item.item_exp_date),
                            item_mfg_date: item.item_mfg_date,
                            item_batch_free_quantity:item.item_batch_free_quantity,
                            item_batch_unit_price:item.item_batch_unit_price,
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_discount_percentage:item.item_batch_discount_percentage,
                            item_batch_discount_amount:item.item_batch_discount_amount,
                            item_batch_tax_amount:item.item_batch_tax_amount,
                            item_batch_tax_percentage:item.item_batch_tax_percentage,
                            item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                            item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                            to_bin_id :item.to_bin_id,
                            to_bin_location:item.to_bin_location

                        },
                      ],
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
             //   console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await purchaseOrderService.syncPurchaseReturn(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }

  export async function getUnPurchaseCreditNote(){
    try{
      const getUnSyncedStockTransfer = await purchaseOrderService.getUnPurchaseCreditNote()
      if (getUnSyncedStockTransfer.rows.length > 0) {
     //   console.log(getUnSyncedStockTransfer.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncedStockTransfer.rows) {
                  const orderId = item.pct_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                      orderData: {
                      
                         pct_invoice_number:item.pct_invoice_number,
                         pct_id: item.pct_id,
                         store_id: item.store_id,
                         cmr_phone_number: item.cmr_phone_number,
                         remarks: item.remarks,
                         pct_total_gst: item.pct_total_gst,
                         pct_total_discount: item.pct_total_discount,
                         pct_payment_status: item.pct_payment_status,
                         pct_transaction_id: item.pct_transaction_id,
                         pct_order_status: item.pct_order_status,
                         pct_payment_method: item.pct_payment_method,
                         pct_billing_address: item.pct_billing_address,
                         pct_total_amount: item.pct_total_amount,
                         pct_sub_total:item.pct_sub_total,
                         pct_delivery_date: item.pct_delivery_date,
                         pct_document_date: item.pct_document_date,
                         cmr_code: item.cmr_code,
                         cmr_name: item.cmr_name,
                         cmr_id: item.cmr_id,
                         created_date: item.created_date,
                         update_date: item.update_date,
                      },
                      itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                  if (existingItem) {
                    existingItem.itemBatchData.push({
                        pct_id: item.pct_id,
                        item_id: item.item_id,
                        item_batch_number: item.item_batch_number,
                        item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                        item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                        item_exp_date: formatDate(item.item_exp_date),
                        item_mfg_date: item.item_mfg_date,
                        item_batch_free_quantity:item.item_batch_free_quantity,
                        item_batch_unit_price:item.item_batch_unit_price,
                        item_batch_purchase_rate:item.item_batch_purchase_rate,
                        item_batch_discount_percentage:item.item_batch_discount_percentage,
                        item_batch_discount_amount:item.item_batch_discount_amount,
                        item_batch_tax_amount:item.item_batch_tax_amount,
                        item_batch_tax_percentage:item.item_batch_tax_percentage,
                        item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                        item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                        to_bin_id :item.to_bin_id,
                        to_bin_location:item.to_bin_location
                    });
                  } else {
                    groupedOrders[orderId].itemData.push({
                        pct_id: item.pct_id,
                        item_id: item.item_id,
                        poit_id:item.poit_id,
                        prt_id:item.prt_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_rack_location: item.item_rack_location,
                        item_unit_price: item.item_unit_price,
                        item_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_uom_id:item.item_id,
                        item_uom:item.item_uom,
                      itemBatchData: [
                        {
                            pct_id: item.pct_id,
                            item_id: item.item_id,
                            item_batch_number: item.item_batch_number,
                            item_sellable_quantity:  Number(item.item_sellable_quantity).toFixed(0),
                            item_non_sellable_quantity: Number(item.item_non_sellable_quantity).toFixed(0) ,
                            item_exp_date: formatDate(item.item_exp_date),
                            item_mfg_date: item.item_mfg_date,
                            item_batch_free_quantity:item.item_batch_free_quantity,
                            item_batch_unit_price:item.item_batch_unit_price,
                            item_batch_purchase_rate:item.item_batch_purchase_rate,
                            item_batch_discount_percentage:item.item_batch_discount_percentage,
                            item_batch_discount_amount:item.item_batch_discount_amount,
                            item_batch_tax_amount:item.item_batch_tax_amount,
                            item_batch_tax_percentage:item.item_batch_tax_percentage,
                            item_batch_final_purchase_rate:item.item_batch_final_purchase_rate,
                            item_batch_total_purchase_rate:item.item_batch_total_purchase_rate,
                            to_bin_id :item.to_bin_id,
                            to_bin_location:item.to_bin_location
                        },
                      ],
                    });
                  }
          
                }
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                  const { itemBatchData } = order.itemData
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                    const { itemBatchData, item_batch_quantity, item_exp_date, ...rest } = item;
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(rest).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
                const extractedBatchData :any= []
                order.itemData.forEach((item: { itemBatchData: any[]; }) => {
                    // Check if itemBatchData exists and is an array
                    
                    if (Array.isArray(item.itemBatchData)) {
                      // Push each itemBatchData object into the extractedBatchData array
                      item.itemBatchData.forEach(batchData => {
                        extractedBatchData.push(batchData);
                      });
                    }
                  });
    
                
    
                
                    const formatDateString = (dateString: string | number | Date) => {
                        const date = new Date(dateString);
                        return date.toISOString().split('T')[0]; // format as YYYY-MM-DD
                    };
    
                    const newBatchItemsData = extractedBatchData.map((item: any) => {
                        // Filter out properties with null values
                        const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                            if (value !== null) {
                                acc[key] = value;
                            }
                            return acc;
                        }, {} as { [key: string]: any });
    
                        // Return the new item object with additional properties
                        return {
                            ...filteredItem,
                            item_exp_date: formatDateString(item.item_exp_date),
                          
                        };
                    });
                    
                
                  
  
              //  console.log(order.orderData, JSON.stringify(newItemsData, null, 2),JSON.stringify(newBatchItemsData, null, 2), 'Processing Order after rrrrr');
  
                 const syncedResult = await purchaseOrderService.syncPurchaseCreditNote(order.orderData,newItemsData, newBatchItemsData);
              }
            }
    }catch(error){
  
    }
  }

export async function importpurchasecsv(req:any,res:any) {
    try{
    let  importobj = req.body.data
let itemsData = []
    if(importobj.length>0){
        for(let items of importobj ){
      
            console.log(items,"csv",importobj.length)
            let item_search = items.item_name
            let item_unit_price = items.item_unit_price
           let item_quantity =  items.item_quantity
           let item_sheet_uom 
           let item_sheet_uom_id

            console.log(item_search)
            const query = `
            SELECT
            itt.*,
            iit.*,
            itp.*
            FROM
            items_table as itt
            LEFT JOIN 
                item_invetory_table iit  ON iit.item_id = itt.item_id
            LEFT JOIN 
                item_purchasing_table itp ON itt.item_id = itp.item_id   
            WHERE
            itt.item_name ILIKE '%${item_search}%' ;
          `;
    
    
            
                const result = await client.query(query);
                console.log(query,"result", result.rows)
                // console.log(result)
                if (result.rows.length > 0) {
                    
                
                        let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(result.rows[0].item_uom)
                    if(getItemGroup.rows.length>0){
                       
                        items.uom_dropdown= getItemGroup.rows
                        items.item_base_uom = getItemGroup.rows[0].base_uom.name
                        items.item_uom_id = getItemGroup.rows[0].base_uom.uom_id
                        for(let uom of getItemGroup.rows){
                            console.log(items.item_sheet_uom === uom.alt_uom,item_search,items.item_sheet_uom,uom.alt_uom, typeof(items.item_sheet_uom),typeof(uom.alt_uom))
                            if(items.item_sheet_uom === uom.alt_uom){
                                item_sheet_uom = uom.alt_uom
                                item_sheet_uom_id =  uom.item_id
                                break 
                            }else{
                                item_sheet_uom = null
                                item_sheet_uom_id = null
                            }
                        }
                         
                  }
                
        }
        let moreSuggestedItemsArray:any = []
        if (result.rows.length > 0) {
            for (let moreSuggestedItems of result.rows) {
                let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(moreSuggestedItems.item_uom)
            if(getItemGroup.rows.length>0){
                let item_sheet_uom_more_items
                let item_sheet_uom_id_more_items
                for(let uom of getItemGroup.rows){
                    if(items.item_sheet_uom === uom.alt_uom){
                        item_sheet_uom_more_items = uom.alt_uom
                        item_sheet_uom_id_more_items =  uom.item_id
                        break
                    }else{
                        item_sheet_uom_more_items = null
                        item_sheet_uom_id_more_items = null
                    }
                }
                let uom_dropdown= getItemGroup.rows
                let item_base_uom = getItemGroup.rows[0].base_uom.name
                let item_uom_id = getItemGroup.rows[0].base_uom.uom_id
                let item_pur_purchasing_uom_name = moreSuggestedItems.item_pur_purchasing_uom_name
                let item_pur_purchasing_uom_name_id = moreSuggestedItems.item_pur_purchasing_uom_name_id
                let item_id = moreSuggestedItems.item_id
                let item_name =  moreSuggestedItems.item_name
                let item_code =  moreSuggestedItems.item_code
                console.log()
                let item_total_amount = item_unit_price * item_quantity
                let item_quantitys = item_quantity
                let gettaxmoreSuggested = await getItemTax( item_id,item_total_amount)
                         
                let item_tax_amount:any = gettaxmoreSuggested?.item_tax_amount
                let item_sgst = (gettaxmoreSuggested?.item_tax_amount ?? 0) > 0 ? (gettaxmoreSuggested?.item_tax_amount ?? 0) / 2 : 0;
                let item_cgst =  item_sgst

                let item_total_amount_aftertax = item_total_amount
             let    moreItemsObj = {
                 uom_dropdown:uom_dropdown,
                 item_base_uom:item_base_uom,
                 item_name:item_name,
                 item_code :item_code,
                 item_id : item_id,
                 item_unit_price : item_unit_price,
                 item_total_amount : parseFloat(item_total_amount_aftertax.toFixed(2)),
                 item_quantity :item_quantitys,
                 item_tax_amount:item_tax_amount,
                 item_sheet_uom :item_sheet_uom_more_items,
                 item_sheet_uom_id :item_sheet_uom_id_more_items,
                 item_sgst:item_sgst,
                 item_cgst:item_cgst,
                 item_uom_id :item_uom_id,
                 item_pur_purchasing_uom_name:item_pur_purchasing_uom_name,
                 item_pur_purchasing_uom_name_id:item_pur_purchasing_uom_name_id
                }
                moreSuggestedItemsArray.push(moreItemsObj)
          }
        }
}
console.log(result.rows.length>0,)
       if(result.rows.length>0){
if(moreSuggestedItemsArray.length>0){
        let item_name_suggested = moreSuggestedItemsArray[0].item_name
        let item_id = moreSuggestedItemsArray[0].item_id
        let item_code = moreSuggestedItemsArray[0].item_code
        let item_pur_purchasing_uom_name = moreSuggestedItemsArray[0].item_pur_purchasing_uom_name
        let item_pur_purchasing_uom_name_id = moreSuggestedItemsArray[0].item_pur_purchasing_uom_name_id
        let item_total_amount = item_unit_price * item_quantity
        let item_quantitys = item_quantity
        let gettax = await getItemTax(item_id,item_total_amount)
        let item_tax_amount :any= gettax?.item_tax_amount
        let item_sgst = (gettax?.item_tax_amount ?? 0) > 0 ? (gettax?.item_tax_amount ?? 0) / 2 : 0;
        let item_cgst =  item_sgst
        let item_total_amountafterTax = item_total_amount 
        let moreSuggestedItemsArray1 = moreSuggestedItemsArray
       
        let itemobj = {
            item_name_suggested :item_name_suggested,
            item_name:item_search,
            item_id : item_id,
            item_code:item_code,
            item_unit_price:item_unit_price,
            item_quantity:item_quantity,
            item_tax_amount:item_tax_amount,
            item_sgst:item_sgst,
            item_cgst:item_cgst,
            item_sheet_uom :moreSuggestedItemsArray[0].item_sheet_uom,
            item_sheet_uom_id :moreSuggestedItemsArray[0].item_sheet_uom_id,
            item_total_amount:parseFloat(item_total_amountafterTax.toFixed(2)),
            moreSuggestedItemsArray:moreSuggestedItemsArray1,
            uom_dropdown :moreSuggestedItemsArray[0].uom_dropdown,
            item_base_uom:moreSuggestedItemsArray[0].item_base_uom,
            item_uom_id :moreSuggestedItemsArray[0].item_uom_id,
            item_pur_purchasing_uom_name:moreSuggestedItemsArray[0].item_pur_purchasing_uom_name,
            item_pur_purchasing_uom_name_id:moreSuggestedItemsArray[0].item_pur_purchasing_uom_name_id


        }
        itemsData.push(itemobj)
    } 
    }else{
console.log("ddddddddddddddddddddddddddddddddddddddd")
        let obj = {
            item_name_suggested :null,
            item_name:item_search,
            item_id : null,
            item_code:null,
            item_quantity: items.item_quantity,
            item_unit_price:item_unit_price,
            item_tax_amount:null,
            item_sgst:null,
            item_cgst:null,
            item_total_amount:null,
            moreSuggestedItemsArray:null,
            uom_dropdown :null,
            item_base_uom:null,
            item_pur_purchasing_uom_name:null,
            item_pur_purchasing_uom_id:null,
            item_sheet_uom :null,
            item_sheet_uom_id :null,
        }

        itemsData.push(obj)
} 

        }
       

} 
if(itemsData.length>0){
    return res.status(200).send(generateResponse(true, "items fetched successfully", 200, itemsData));
}else{
    return res.status(400).send(generateResponse(false, "item fetching unsucessfull", 400, null));
}



    }catch(error){
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }

    
} 




export async function getItemtaxForPurchase(req: any, res: any) {
    try {
        const { item_id, totalAmountOfItem } = req.query
        let price_list_id 
        let resultObj
        let discount_percentage :any = 0
        let  discountAmount = 0
        let cmr_group_id 
        
       
        const taxResult = await discountService.getTaxAmount(item_id)
      
        if (taxResult.rows.length > 0) {
            var cgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
            var sgstRate = parseFloat(taxResult.rows[0].rate)/2 || 0;
         //   var igstRate = parseInt(taxResult.rows[0] || 0;
            var taxPercentage = cgstRate + sgstRate 

            var discountedAmount = totalAmountOfItem
            var taxAmount = totalAmountOfItem * (taxPercentage/100)

             resultObj = {
               
                item_tax_amount: parseFloat(taxAmount.toFixed(2)),
                item_total_tax_percentage: parseFloat(taxPercentage.toFixed(2)),
                cgstRate: parseFloat(cgstRate.toFixed(2)),
                sgstRate: parseFloat(sgstRate.toFixed(2))
              //  igstRate: parseInt(igstRate.toFixed(2))
            }
            console.log(resultObj)



    
            return res.status(200).send(
                generateResponse(true, "tax is applicable", 200,resultObj)
            )

        } 

        
        resultObj = {
            item_tax_amount: 0,
            item_total_tax_percentage: 0,
            cgstRate: 0,
            sgstRate: 0
          //  igstRate: parseInt(igstRate.toFixed(2))
        }

            

            return res.status(400).send(
                generateResponse(false, "tax is not found ",400,resultObj )
            )
        
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }


}


export async function getUnSyncPurchaseOrderIncompany(){
    try{
        console.log("eeeeeeeeeeeeeeeeeeeeee")
      const [getUnSyncPurchaseOrder,getposid] = await Promise.all([purchaseOrderService.getUnSyncPurchaseOrderIncompany(),getposId()])
      console.log(getposid.rows)
      const pos_id = getposid.rows[0].pos_id
    let cmr_id =getposid.rows[0].cmr_id
      if (getUnSyncPurchaseOrder.rows.length > 0) {
        console.log(getUnSyncPurchaseOrder.rows)
        const groupedOrders:any = {};
  
              // Group orders by sot_id
              for (let item of getUnSyncPurchaseOrder.rows) {
                  const orderId = item.pot_id;
  
                  if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                        orderData: {
                            pot_id: item.pot_id,
                            store_id: item.store_id,
                            cmr_phone_number: item.cmr_phone_number,
                            sott_total_gst: item.pot_total_gst,
                            sott_total_discount: item.pot_total_discount,
                            sott_payment_status: item.pot_payment_status,
                            sott_transaction_id: item.pot_transaction_id,
                            sott_order_status: "pending",
                            sott_invoice_number : item.pot_invoice_number,
                            sott_payment_method: item.pot_payment_method,
                            sott_billing_address: item.pot_billing_address,
                            sott_total_amount: item.pot_total_amount,
                            sott_delivery_date: item.created_date,
                            sott_document_date: item.created_date,
                            created_date: item.created_date,
                            update_date: item.update_date,
                            pos_id:pos_id,
                            cmr_id:cmr_id
                        },
                        itemData: [],
                      // Initialize payment data to avoid undefined errors
                    };
                  }
               
          
                  // Check if the item already exists in itemData
                  const existingItem = groupedOrders[orderId].itemData.find(
                    (i: { item_id: any }) => i.item_id === item.item_id
                  );
          
                
            
                    groupedOrders[orderId].itemData.push({
                        pot_id: item.pot_id,
                        item_id: item.item_id,
                        item_code: item.item_code,
                        item_generic_name: item.item_generic_name,
                        item_name: item.item_name,
                        item_pack_size: item.item_pack_size,
                        item_unit_price: item.item_unit_price,
                        item_requested_quantity:item.item_quantity,
                        item_schedule: item.item_schedule,
                        item_discount_amount: item.item_discount_amount,
                        item_discount_percentage: item.item_discount_percentage,
                        item_tax_amount: item.item_tax_amount,
                        item_total_tax_percentage: item.item_total_tax_percentage,
                        item_total_amount: item.item_total_amount,
                        item_uom:item.item_uom,
                        item_gst  :item.item_gst,
                        item_sgst:item.item_sgst,
                        item_cgst :item.item_cgst,
                        item_igst :item.item_igst,
                        item_uom_id :item.item_uom_id,
                        item_maximum_purchasing:item.item_maximum_purchasing,
                        item_minimun_purchasing:item.item_maximum_purchasing,
                        item_return_availability:item.item_return_availability,
                        item_hsn:item.item_hsn,
                        item_manufacturer_id:item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name,
                        pos_id:pos_id
                    });
                  }
          
                
          
                  // Push payment data if it doesn't already exist
                 
              
  
              // Now you can process each grouped order
              for (let orderId in groupedOrders) {
                  const order = groupedOrders[orderId];
               //   console.log(order.stocktransferData, JSON.stringify(order.itemData, null, 2), 'Processing Order');
                
                  const newItemsData = order.itemData.map((item: any) => {
                    // Destructure item to extract specific properties and the rest
                
                //console.log(itemBatchData)
                    // Filter out properties with null values
                    const filteredItem = Object.entries(item).reduce((acc, [key, value]) => {
                        if (value !== null) {
                            acc[key] = value;
                        }
                        return acc;
                    }, {} as { [key: string]: any });
                
                    // Return the new item object with additional properties
                    return {
                        ...filteredItem,
                       
                    
                    };
                });
               
                //console.log(newItemsData, 'rrrrr')
              
              
                    
                
                  
  
                console.log(JSON.stringify(order, null, 2), 'Processing  ittteeeeeeeeeeeeeeeee Order after rrrrr');
  
                const syncedResult = await purchaseOrderService.syncPurchaseOrderInterCompany(order.orderData,newItemsData,);
              }
            }
    }catch(error){
  
    }
 }



 export async function grnSync(data:any,socketid:any){
    try{
      if(data.body.transaction_type === 'GRNSYNC'){
     //   console.log("3e434")
     console.log(data,"wererfgfvefgfsdcvferfgbgfd")
     let grnSync:any
     grnSync  = await    purchaseOrderService.grnSync(data.body.orderData, data.body.itemData, data.body.itemBatchData)
      
      if (grnSync) {
        console.log(grnSync.gort_id,"wer")
        socket.emit('grn_sync-acknowledgment', {
            gort_id:grnSync.gort_id,
            sync: true,
            transaction_type :'syncGRN',
            pos_id:grnSync.pos_id
          })

        }
      }
    }catch(error){
      console.log(error)
  
    }
  }



  export async function InvoiceSYNC(data:any,socketid:any){
    try{
      if(data.body.transaction_type === 'InvoiceYNC'){
     //   console.log("3e434")
     console.log(data,"wererfgfvefgfsdcvferfgbgfd")
     let grnSync:any
     grnSync  = await    purchaseOrderService.invoiceSync(data.body.orderData, data.body.itemData, data.body.itemBatchData)
      
      if (grnSync) {
        console.log(grnSync.poit_id,"wer")
        socket.emit('invoice_sync-acknowledgment', {
            poit_id:grnSync.poit_id,
            sync: true,
            transaction_type :'syncinvoice',
            pos_id:grnSync.pos_id
          })

        }
      }
    }catch(error){
      console.log(error)
  
    }
  }
  export async function getPurchaseCreditNoteByIdHTML(req: any, res: any) {
    try {
        const { pct_id } = req.query
        console.log(req.query, "ffffffffff")

        if (pct_id) {
            const orderDetailsResult = await purchaseOrderService.getPurchaseCreditNoteById(pct_id)
            const storeDetails=await purchaseOrderService.getStoreDetails();
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.length > 0 && storeDetails.length>0) {
                const html=await DebitNote(orderDetailsResult,storeDetails);
                if(html){
                    return res.send(generateResponse(true, "Invoice fetched successfully", 200, html));
                }
                else{
                    return res.send(generateResponse(false, "Invoice not found", 400, null));
                }
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }

        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}
