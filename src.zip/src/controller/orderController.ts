
//import Razorpay = require('razorpay');
import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as productService from '../service/productService'
import * as orderService from '../service/orderService'
import * as customerService from '../service/customerService'
import * as financialLedgerService from '../service/financialLedgerService'
import Razorpay from 'razorpay'
import axios from 'axios';
import * as nextInvoicenumber from '../service/documentNumberingSeries'
import * as  permissionhelper from '../permissionHelper/permissionHelper'
import orderValidation from '../validateModels/orderValidation'
import returnOrderValidation from '../validateModels/returnOrderVadiation';
import socket from '../sync/syncScript';
import { getposId } from '../service/storeService';
import pdf from "html-pdf";
import { Invoice,ReturnInvoice } from '../helper/pdfhelper';
import * as userService from '../service/userService'
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import * as dotenv from 'dotenv';
import transporter from '../util/nodemailer'
import path from 'path';
import fs from 'fs';
import * as html_to_pdf from 'html-pdf-node';
//import { getSocket } from '../sync/syncScript';
function formatDate(date:any) {
    if (!date) return null; // Handle null or undefined dates
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
   const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
interface Item {
    item_id: string;
    item_code: string;
    item_open_quantity: number;
    item_generic_name: string;
    item_name: string;
    item_pack_size: number;
    item_batch_number: string;
    item_quantity: number;
    item_exp_date: string;
    item_mfg_date: string;
    item_rack_location: string;
    item_unit_price: number;
    item_schedule: string;
    item_discount_amount: number;
    item_discount_percentage: number;
    item_tax_amount: number;
    
                                item_total_tax_percentage:number;
                                item_total_amount: number;
                                item_price_wiithout_tax: number,
                                item_gst: number,
                                item_sgst: number,
                                item_cgst: number,
                                item_igst: number,
                                item_uom: number,
                                total_sellable_quantity:number,
                                item_total_qaunitiy: number,
    // Add any other fields you may have
}

interface ItemSum extends Item {
    item_total_quantity: number;
    item_cgst :number;
    item_sgst:number;
}

export async function addOrder(req: any, res: any) {

    try {
        const checkperm = await permissionhelper.permissionHelper('invoice', 'create', req.user_id)
        if (checkperm) {
            const { orderData: orderData, itemData: itemData, paymentData: paymentData } = req.body
            const { error, value } = orderValidation.validate(req.body);

            if (error) {
                return res.status(400).send(
                    generateResponse(false, `order placing unsuccesfully ${error.message}`, 400, error)
                )
            } else {
                console.log('Validation succeeded:', value);


                // console.log(orderData)
                const store_id = orderData.store_id
                orderData.is_draft_order = false
                orderData.sot_payment_status = 'paid'
                // Fetch next invoice number

                const getNextInvoiceNumber = await nextInvoicenumber.getInvoiceBillingNextNumber()
                console.log(getNextInvoiceNumber);

                if (!nextInvoicenumber) {
                    return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
                }
                const cmr_phone_number = orderData.cmr_phone_number
                orderData.sot_invoice_number = getNextInvoiceNumber

                const findCustomer = await customerService.findCustomerByPhoneNumber(cmr_phone_number)
                let cmr_id
                let customerObj

                if (findCustomer.rows.length === 0) {
                    const getCustomerNextSequenceCode = await customerService.getCustomerNextSequenceCode()
                    customerObj = {
                        cmr_id: ulid(),
                        cmr_active_status: true,
                        cmr_code: getCustomerNextSequenceCode.rows[0].cmr_number,
                        cmr_phone_number: cmr_phone_number,
                        price_list_id: '01HS5HJYWZ5DG2CW4EHX2W7A8V'
                    }
                    let noglAccount = {
                        account_id: customerObj.cmr_id,
                        account_code: customerObj.cmr_code,
                        is_gl_account: false
                    }
                    const addChartsOfAccounts = financialLedgerService.addChartsOfAccounts(noglAccount)

                    const result = await customerService.addCustomerData(customerObj)
                    orderData.cmr_id = customerObj.cmr_id


                } else {
                    orderData.cmr_id = findCustomer.rows[0].cmr_id
                }

                if (orderData && itemData) {
                    const addOrder = await orderService.addOrder(orderData, itemData, paymentData)
                    if (addOrder) {
                        // const smspath = `https://smsnotify.one/SMSApi/send?userid=davaindia&password=Dava@123&sendMethod=quick&mobile=${cmr_phone_number}&msg=Thank%20you,%20for%20connecting%20with%20Davaindia%20Generic%20Pharmacy,%20your%20login%20One%20Time%20Password%20(OTP)%20is%20Ajay%20Pandey.%20davaindia%20generic%20pharmacy.&senderid=DAVAIN&msgType=text&format=text`
                        // const sendSMS = axios.post(`${smspath}` ).then(function (response) {

                        //     console.log(response, "sms");
                        //   })
                        //   .catch(function (error) {

                        //     console.log(error,"sms");
                        //   })

                        // add sync to CPOS here
                        //  syncOrder(orderData, itemData, paymentData)

                        return res.status(200).send(
                            generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, items: addOrder.item })
                        )

                    } else {
                        return res.status(400).send(
                            generateResponse(false, "order placing unsuccesfully", 400, null)
                        )

                    }
                } else {
                    return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
                }
            }

        } else {
            return res.status(400).send(
                generateResponse(false, "user permission denied", 400, null)
            );
        }

    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


// async function syncOrder(orderData: any, itemData: any,paymentData:any) {
//     try {
//         const req = {
//          body: {
//             "orderData": orderData,
//             "itemData": itemData,
//             "paymentData":paymentData,
//             "transaction_type":"order"
//         }
//     }
//         socket.emit('sync', req)

//     } catch (error) {
//         console.error('Error:', error);
//     }
// }

export async function addDrafOrder(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, paymentData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id
        orderData.is_draft_order = true
        orderData.sot_payment_status = 'pending'

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getInvoiceBillingNextNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
        const cmr_phone_number = orderData.cmr_phone_number
        orderData.sot_invoice_number = getNextInvoiceNumber

        const findCustomer = await customerService.findCustomerByPhoneNumber(cmr_phone_number)
        let cmr_id
        let customerObj
        if (findCustomer.rows.length === 0) {
            const getCustomerNextSequenceCode = await customerService.getCustomerNextSequenceCode()
            customerObj = {
                cmr_id: ulid(),
                cmr_active_status: true,
                cmr_code: getCustomerNextSequenceCode.rows[0].cmr_number,
                cmr_phone_number: cmr_phone_number,
                price_list_id: '01HS5HJYWZ5DG2CW4EHX2W7A8V'
            }
            let noglAccount = {
                account_id: customerObj.cmr_id,
                account_code: customerObj.cmr_code,
                is_gl_account: false
            }
            const addChartsOfAccounts = financialLedgerService.addChartsOfAccounts(noglAccount)

            const result = await customerService.addCustomerData(customerObj)
            orderData.cmr_id = customerObj.cmr_id


        } else {
            orderData.cmr_id = findCustomer.rows[0].cmr_id
        }

        if (orderData && itemData) {
            console.log(orderData,"sssssssssssssssssssss")
            const addOrder = await orderService.addOrder(orderData, itemData, paymentData)
            if (addOrder)
                return res.status(200).send(
                    generateResponse(true, "order placed succesfully", 200, { orderData: addOrder.order, items: addOrder.item })
                )

        } else {
            return res.status(400).send(
                generateResponse(false, "order placing unsuccesfully", 400, null)
            )

        }
    }

    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function updateDrafOrder(req: any, res: any) {
    try {
        // Destructure orderData and itemData from the request body
        const { orderData, itemData, paymentData } = req.body;
        console.log(orderData)
        if (!orderData.is_draft_order) {
            orderData.sot_payment_status = 'paid'
        }

        // Extract the sot_id from orderData
        const sot_id = orderData.sot_id;


        // Start a database transaction
        await client.query('BEGIN');


        // Update sales_order
        const updateSalesOrder = await orderService.updateDraftOrderData(orderData, sot_id, paymentData)

        // Fetch existing items for the order
        const existingItemsResult = await orderService.existingItemsResult(sot_id)

        const existingItems = existingItemsResult.rows;

        // Handle items
        const itemResults: any = [];

        // // Iterate through existing items to check for updates or removals
        // for (const existingItem of existingItems) {
        //     // Check if the existing item is in the updated itemData
        //     const updatedItem = itemData.find((item: { item_id: any; item_batch_number:any,item_rack_location:any}) => item.item_id === existingItem.item_id && item.item_batch_number === existingItem.item_batch_number && item.item_rack_location === existingItem.item_rack_location);
        //     console.log(updatedItem,"dddddddinloop")
        //     if (updatedItem) {

        //         // Item exists, construct the SET clause for updating the item
        //       //  const updateItemResult = await orderService.updatedItem(updatedItem, sot_id)
        //        // itemResults.push(updateItemResult.rows);

        //     } else {
        //         // Item does not exist in the updated itemData, construct the query to remove it
        //         console.log(existingItem,"deletefromed ")
        //       ///  const removeItemResult = await orderService.removeItem(sot_id, existingItem.item_id)
        //       //  itemResults.push(removeItemResult.rows);
        //     }
        // }

        // // Check for new items to be added
        // const newItems = itemData.filter((item: { item_id: any; item_batch_number:any,item_rack_location:any}) => !existingItems.find(existingItem => existingItem.item_id === item.item_id  && item.item_batch_number === existingItem.item_batch_number && item.item_rack_location === existingItem.item_rack_location));

        // // Iterate through new items 
        // for (const newItem of newItems) {
        //     // Construct the field names for the INSERT query
        //     console.log(newItem,"newItems")
        //  //   const addItemResult = await orderService.addItem(newItem)

        //  // itemResults.push(addItemResult.rows);
        // }

        const updatedItems = itemData.filter((item: any) =>
            existingItems.some((existingItem: any) =>
                item.item_id === existingItem.item_id && item.item_batch_number === existingItem.item_batch_number && item.item_rack_location === existingItem.item_rack_location)
        );

        const removedItems = existingItems.filter((existingItem: any) =>
            !itemData.some((item: any) =>
                item.item_id === existingItem.item_id && item.item_batch_number === existingItem.item_batch_number && item.item_rack_location === existingItem.item_rack_location)
        );

        // Handle new items to be added
        const newItems = itemData.filter((item: any) =>
            !existingItems.some((existingItem: any) =>
                item.item_id === existingItem.item_id && item.item_batch_number === existingItem.item_batch_number && item.item_rack_location === existingItem.item_rack_location)
        );
        console.log('Updated Items:', updatedItems, 'Removed Items:', removedItems, 'New Items:', newItems)
        // Batch updating, removing, and adding items (improve with bulk queries if possible)
        const [updatedItem, removedItem, newItem] = await Promise.all([
            ...updatedItems.map(async (updatedItem: any) => {
                return orderService.updatedItem(updatedItem, sot_id);
            }),
            ...removedItems.map(async (removedItem: any) => {
                return orderService.removeItem(sot_id, removedItem.item_id);
            }),
            ...newItems.map(async (newItem: any) => {
                return orderService.addItem(newItem);
            })
        ]);

        await orderService.updateStoreInventor(orderData, itemData)
        // Commit the transaction
        await client.query('COMMIT');

        // Send the response with the updated orderData and itemResults
        return res.status(200).send(
            generateResponse(true, "Draft order updated successfully", 200, { orderData: updateSalesOrder.rows, items: itemResults })
        )

    } catch (err) {
        // Rollback the transaction in case of an error
        await client.query('ROLLBACK');

        // Log the error and send a 500 Internal Server Error response
        console.error(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export async function getOrderList(req: any, res: any) {
    try {

        const getOrderList = await orderService.getOrderList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "Invoice fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function repeatPastOrder(req: any, res: any) {
    try {
        const { cmr_phone_number } = req.query
        if (cmr_phone_number) {
            const orderDetailsResult = await orderService.repeatPastOrder(cmr_phone_number)
            if (orderDetailsResult.rows.length > 0) {
                console.log('Order details:', orderDetailsResult.rows);
               
                const uniqueItems = new Map()
                const filterOrderData = orderDetailsResult.rows.filter(item => {
                    if (!uniqueItems.has(item.item_id)) {
                        uniqueItems.set(item.item_id, true)
                        return true
                    }
                    return false

                })

                for(let item of filterOrderData){
                    const itemAvailableQuantity = await productService.getAvilableQunatity(item.item_id)
                    item.total_sellable_quantity = itemAvailableQuantity[0].total_sellable_quantity
                }
                return res.send(generateResponse(true, "order fetched successfully", 200, filterOrderData));
            } else {
                return res.send(generateResponse(false, "order not found", 400, null));
            }
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function payment(req: any, res: any) {
    //console.log(req)

    function generateInvoiceNumber() {
        // Get the current timestamp in milliseconds as a BigInt
        const timestamp = BigInt(new Date().getTime());
        // Generat;e a random number between 100000n and 999999n
        const random = BigInt(Math.floor(Math.random() * 900000) + 100000);
        // Concatenate the timestamp and random number
        const invoiceNumber = BigInt(timestamp.toString() + random.toString());
        // Take the first 11 digits (in case the timestamp is more than 11 digits)
        return invoiceNumber.toString().slice(0, 11);
    }

    const invoiceNumber = generateInvoiceNumber()
    var instance = new Razorpay({ key_id: 'rzp_test_SyZOx5U6wEl9gg', key_secret: 'ErEgCxmWM0Ur27exJ14PL90s' })
    try {
        var options = {
            amount: parseFloat(req.body.amount) * 100, // amount in the smallest currency unit
            currency: "INR",
            receipt: invoiceNumber
        };
        console.log(options)
        instance.orders.create(options, async function (err: any, order: any) {
            if (err) {
                console.log(err, "ffffff")
                res.status(400).json({ message: "payment unsuccesfull", result: err })
            }

            console.log(order)
            // Order_Table.update({ SOT_Payment_Id: order.id }, { where: { SOT_Id: SOT_Id } }).then(() => {
            //     return res.status(201).json({ message: "payment initiated ", order });

            // }).catch(err => {
            //     throw new Error(err)
            // })
            return res.status(201).json({ message: "payment initiated ", order });


        });
    } catch (error) {
        console.log(error)
        res.status(400).json({ message: error })
    }
}
// exports.paymentUpdate = async (req, res) => {
//     try {
//         console.log(req.body)
//         const { order_id, razorpay_payment_id } = req.body
//         console.log(order_id, razorpay_payment_id)
//         const result = await Order_Table.update({ SOT_Payment_Status: "Paid", SOT_transaction_Id: razorpay_payment_id }, { where: { SOT_Payment_Id: order_id } })
//         console.log(result)
//         if (result) {
//             res.status(200).json({ message: "payment succesfull" })
//         }
//     } catch (error) {
//         res.status(400).json({ message: error })
//     }
// }

// exports.deleteOrder = async (req, res) => {
//     try {
//         const { SOT_Id } = req.body
//         console.log(SOT_Id)
//         console.log(req)

//         if (SOT_Id) {
//             const result = await Order_Table.destroy({ where: { SOT_Id } })
//             if (result) {
//                 await Order_Items_List.destroy({ where: { SOT_Id } })

//                 res.status(200).json({ message: "delete succesfull", result })
//             } else {
//                 res.status(400).json({ message: "delete unsuccesfull", result })
//             }
//         }
//     } catch (err) {
//         res.status(400).json({ message: err })
//     }
// }


// export async function addOrder (req :Request, res:Response ): Promise<void>
// exports.verify = async (req, res) => {
//     try {
//         const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
//             req.body;
//         const sign = razorpay_order_id + "|" + razorpay_payment_id;
//         const expectedSign = crypto
//             .createHmac("sha256", process.env.KEY_SECRET)
//             .update(sign.toString())
//             .digest("hex");

//         if (razorpay_signature === expectedSign) {
//             return res.status(200).json({ message: "Payment verified successfully" });
//         } else {
//             return res.status(400).json({ message: "Invalid signature sent!" });
//         }
//     } catch (error) {
//         res.status(500).json({ message: "Internal Server Error!" });
//         console.log(error);
//     }
// }

// export async function addOrder (req :Request, res:Response ): Promise<void>
// exports.getOrderbyInvoice = async (req, res) => {
//     try {
//         const search = req.query.SOT_Invoice_number
//         console.log(typeof (search), "search")
//         const order = await Order_Table.findAll({
//             where: {
//                 SOT_Invoice_number: { [Op.iLike]: `%${search}%` },

//             },



//         })
//         console.log(order, "order")
//         if (order) {
//             res.status(200).json({ message: "update succesfull", order })
//         } else {
//             res.status(400).json({ message: "update unsuccesfull", result })
//         }
//     } catch (error) {
//         res.status(400).json({ message: error })
//     }
// }

//ItemsBatch

export async function getDoctor(req: any, res: any) {

    try {

        const queryCount = `SELECT doctor_table.dr_name, doctor_table.dr_name FROM doctor_table;
        ;`


        const getDoctor = await client.query(queryCount)


        if (getDoctor.rows.length > 0) {

            return res.send(
                generateResponse(true, "doctor fetched succesfully", 200, getDoctor.rows))
        } else {
            return res.send(
                generateResponse(false, "doctor not found", 400, null))
        }

    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null))
    }
}


export async function getOrderById(req: any, res: any) {
    try {
        const { sot_id } = req.query

        if (sot_id) {

            const orderDetailsResult = await orderService.getOrderById(sot_id)
            console.log(orderDetailsResult)
            if (orderDetailsResult.length > 0) {
                console.log(orderDetailsResult, "ssssss")
                const groupedItems = orderDetailsResult.reduce((acc, item) => {
                    const key = item.sot_id;
                    if (!acc[key]) {
                        acc[key] = {
                            orderData: {
                                sot_id: item.sot_id,
                                store_id: item.store_id,
                                cmr_phone_number: item.cmr_phone_number,
                                sot_total_gst: item.sot_total_gst,
                                sot_total_discount: item.sot_total_discount,
                                sot_payment_status: item.sot_payment_status,
                                sot_transaction_id: item.sot_transaction_id,
                                is_draft_order: item.is_draft_order,
                                sot_payment_method: item.sot_payment_method,
                                sot_billing_address: item.sot_billing_address,
                                sot_total_amount: item.sot_total_amount,
                                sot_invoice_number: item.sot_invoice_number,
                                doctor_name: item.doctor_name,
                                cmr_first_name: item.cmr_first_name,
                                cmr_last_name: item.cmr_last_name,
                                cmr_rewards: item.cmr_rewards,
                                created_date: item.created_date,
                                update_date: item.update_date,
                                sot_return_status: item.sot_return_status,
                                sot_remarks: item.sot_remarks
                            },
                            itemData: [],
                            paymentData: [],
                        };
                    }

                    // Check if the item record already exists
                    const itemExists = acc[key].itemData.some(
                        (existingItem: any) => existingItem.item_batch_number === item.item_batch_number
                            && existingItem.item_rack_location === item.item_rack_location

                    );




                    if (!itemExists) {
                        acc[key].itemData.push({
                            item_id: item.item_id,
                            item_code: item.item_code,
                            item_open_quantity: item.item_open_quantity,
                            item_generic_name: item.item_generic_name,
                            item_name: item.item_name,
                            item_pack_size: item.item_pack_size,
                            item_batch_number: item.item_batch_number,
                            item_quantity: item.item_quantity,
                            item_exp_date: item.item_exp_date,
                            item_mfg_date: item.item_mfg_date,
                            item_rack_location: item.item_rack_location,
                            item_unit_price: item.item_unit_price,
                            item_schedule: item.item_schedule,
                            item_discount_amount: item.item_discount_amount,
                            item_discount_percentage: item.item_discount_percentage,
                            item_tax_amount: item.item_tax_amount,
                            item_total_tax_percentage: item.item_total_tax_percentage,
                            item_total_amount: item.item_total_amount,
                            item_price_wiithout_tax: item.item_price_wiithout_tax,
                            item_gst: item.item_gst,
                            item_sgst: item.item_sgst,
                            item_cgst: item.item_cgst,
                            item_igst: item.item_igst,
                            item_uom: item.item_uom,
                            total_sellable_quantity: item.total_sellable_quantity,
                            item_total_qaunitiy: item.item_quantity,
                            item_free_quantity:item.item_free_quantity,
                            item_manufacturer_id:item.item_manufacturer_id,
                            item_manufacturer_name:item.item_manufacturer_name,
                            item_hsn:item.item_hsn


                        });
                    }

                    const paymentRecord = {
                        payment_mode_name: item.payment_mode_name,
                        payment_amount: item.payment_amount,
                    };

                    // Check if the payment record already exists
                    const paymentExists = acc[key].paymentData.some(
                        (payment: any) =>
                            payment.payment_mode_name === paymentRecord.payment_mode_name &&
                            payment.payment_amount === paymentRecord.payment_amount
                    );

                    if (!paymentExists) {
                        acc[key].paymentData.push(paymentRecord);
                    }

                    return acc;
                }, {});

                // Convert grouped items to an array
                const resultArray: any = Object.values(groupedItems);

                


                //console.log(resultArray,"ddd", resultArray['orderData'])
                const is_draft_order = resultArray[0].orderData.is_draft_order

                if (is_draft_order) {

                    const dividedItems:any = [];


                    const sumQuantitiesWithDetails = (itemArray: Item[]): ItemSum[] => {
                        const itemSums: { [key: string]: ItemSum } = itemArray.reduce((acc, item) => {
                            if (!acc[item.item_id]) {
                                // Initialize if not exists
                                acc[item.item_id] = { ...item, item_total_quantity: 0 };
                            }
                            // Sum the quantities
                            acc[item.item_id].item_total_quantity += item.item_quantity;
                            return acc;
                        }, {} as { [key: string]: ItemSum });

                        // Convert the result to an array
                        return Object.values(itemSums).map(({ item_total_quantity, ...rest }) => ({
                            ...rest,
                            item_total_quantity
                        }));



                        // const batchNumber = getBatchNumber!.fulfilledBatches
                        // // item.item_batch_number = batchNumber[0].batchNumber
                        // // item.item_exp_date = batchNumber[0]?.expiryDate
                        
                    }
                    const totalQuantities = sumQuantitiesWithDetails(orderDetailsResult)
                 //   console.log(totalQuantities,'totalQuantities')

                    for (let item of totalQuantities) {
                     let transaction_type = 'invoice_billing'
                     let cmr_phone_number
                        const getBatchNumber = await productService.checkBatchNumberV1(item.item_id, item.item_total_quantity,cmr_phone_number)
                      //  console.log(getBatchNumber, "sdfdfdf")
                        // Loop through each batch and create a new item object based on batch data
                        for (const batch of getBatchNumber!.fulfilledBatches) {
                            const taxamountpercem = item.item_total_tax_percentage
                            const taxPercentage = parseInt(item.item_total_tax_percentage.toString());

                           // const taxcalcuation = (tax/100)*item.item_unit_price
                         //   console.log(taxcalcuation,"ffffffff")
                         console.log(taxPercentage,"eeee",batch.quantity ,item.item_unit_price, typeof(taxPercentage) )
                         let item_total_amount = item.item_unit_price*batch.quantity 

                         let item_tax_amount = item_total_amount-( item_total_amount*(100/(100+taxPercentage)))
                
                         let item_price_wiithout_tax = item_total_amount - item_tax_amount

                         console.log(item_total_amount,item_tax_amount,item_price_wiithout_tax)
                            const itemObject = {
                                ...item,
                                item_batch_number: batch.batchNumber,
                                item_quantity: batch.quantity,
                                item_total_amount:parseFloat((item.item_unit_price * batch.quantity).toFixed(2)),
                                item_sgst: parseFloat((item_tax_amount/2).toFixed(2)),
                                item_cgst: parseFloat((item_tax_amount/2).toFixed(2)),
                                item_exp_date: batch.expiryDate,
                                item_tax_amount:parseFloat((item_tax_amount).toFixed(2)), 
                                item_rack_location: batch.item_rack_location,
                                item_price_wiithout_tax :parseFloat((item_price_wiithout_tax).toFixed(2)),
                                to_bin_id: batch.to_bin_id,
                                
                                itemBatchList : getBatchNumber.batchlist
                            };
                            dividedItems.push(itemObject);

                         
                        }

                    }
                   console.log(dividedItems,"dividedItems")
                    const groupedItems = dividedItems.reduce((acc:any, item:any) => {
                        const key = item.sot_id;
                        if (!acc[key]) {
                            acc[key] = {
                                orderData: {
                                    sot_id: item.sot_id,
                                    store_id: item.store_id,
                                    cmr_phone_number: item.cmr_phone_number,
                                    sot_total_gst: item.sot_total_gst,
                                    sot_total_discount: item.sot_total_discount,
                                    sot_payment_status: item.sot_payment_status,
                                    sot_transaction_id: item.sot_transaction_id,
                                    is_draft_order: item.is_draft_order,
                                    sot_payment_method: item.sot_payment_method,
                                    sot_billing_address: item.sot_billing_address,
                                    sot_total_amount: item.sot_total_amount,
                                    sot_invoice_number: item.sot_invoice_number,
                                    doctor_name: item.doctor_name,
                                    cmr_first_name: item.cmr_first_name,
                                    cmr_last_name: item.cmr_last_name,
                                    cmr_rewards: item.cmr_rewards,
                                    created_date: item.created_date,
                                    update_date: item.update_date,
                                    sot_return_status: item.sot_return_status,
                                    sot_remarks: item.sot_remarks
                                },
                                itemData: [],
                                paymentData: [],
                            };
                        }
    
                        // Check if the item record already exists
                        const itemExists = acc[key].itemData.some(
                            (existingItem: any) => existingItem.item_batch_number === item.item_batch_number
                                && existingItem.item_rack_location === item.item_rack_location
    
                        );
    
    
    
    
                        if (!itemExists) {
                            acc[key].itemData.push({
                                item_id: item.item_id,
                                item_code: item.item_code,
                                item_open_quantity: item.item_open_quantity,
                                item_generic_name: item.item_generic_name,
                                item_name: item.item_name,
                                item_pack_size: item.item_pack_size,
                                item_batch_number: item.item_batch_number,
                                item_quantity: item.item_quantity,
                                item_exp_date: item.item_exp_date,
                                item_mfg_date: item.item_mfg_date,
                                item_rack_location: item.item_rack_location,
                                item_unit_price: item.item_unit_price,
                                item_schedule: item.item_schedule,
                                item_discount_amount: item.item_discount_amount,
                                item_discount_percentage: item.item_discount_percentage,
                                item_tax_amount: item.item_tax_amount,
                                item_total_tax_percentage: item.item_total_tax_percentage,
                                item_total_amount: item.item_total_amount,
                                item_price_wiithout_tax: item.item_price_wiithout_tax,
                                item_gst: item.item_gst,
                                item_sgst: item.item_sgst,
                                item_cgst: item.item_cgst,
                                item_igst: item.item_igst,
                                item_uom: item.item_uom,
                                total_sellable_quantity: item.total_sellable_quantity,
                                item_total_qaunitiy: item.item_quantity,
                                item_free_quantity:item.item_free_quantity,
                                item_manufacturer_id:item.item_manufacturer_id,
                            item_manufacturer_name:item.item_manufacturer_name,
                            item_hsn:item.item_hsn,
    
    
                            });
                        }
    
                        const paymentRecord = {
                            payment_mode_name: item.payment_mode_name,
                            payment_amount: item.payment_amount,
                        };
    
                        // Check if the payment record already exists
                        const paymentExists = acc[key].paymentData.some(
                            (payment: any) =>
                                payment.payment_mode_name === paymentRecord.payment_mode_name &&
                                payment.payment_amount === paymentRecord.payment_amount
                        );
    
                        if (!paymentExists) {
                            acc[key].paymentData.push(paymentRecord);
                        }
    
                        return acc;
                    }, {});
    
                    // Convert grouped items to an array
                    const resultArray: any = Object.values(groupedItems);
                  //  console.log(JSON.stringify(resultArray, null, 2));
                    return res.status(200).send(generateResponse(true, "Invoice fetched successfully", 200, resultArray));
                }



                    return res.status(200).send(generateResponse(true, "Invoice fetched successfully", 200, resultArray));
                } else {
                    return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
                }



            } else {
                return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
            }
        
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getOrderByIdApp(req: any, res: any) {
    try {
        const { sot_id } = req.query

        if (sot_id) {

            const orderDetailsResult = await orderService.getOrderById(sot_id)
            console.log(orderDetailsResult)
            if (orderDetailsResult.length > 0) {
                console.log(orderDetailsResult, "ssssss")
                const groupedItems = orderDetailsResult.reduce((acc, item) => {
                    const key = item.sot_id;
                    if (!acc[key]) {
                        acc[key] = {
                            orderData: {
                                sot_id: item.sot_id,
                                store_id: item.store_id,
                                cmr_phone_number: item.cmr_phone_number,
                                sot_total_gst: item.sot_total_gst,
                                sot_total_discount: item.sot_total_discount,
                                sot_payment_status: item.sot_payment_status,
                                sot_transaction_id: item.sot_transaction_id,
                                is_draft_order: item.is_draft_order,
                                sot_payment_method: item.sot_payment_method,
                                sot_billing_address: item.sot_billing_address,
                                sot_total_amount: item.sot_total_amount,
                                sot_invoice_number: item.sot_invoice_number,
                                doctor_name: item.doctor_name,
                                cmr_first_name: item.cmr_first_name,
                                cmr_last_name: item.cmr_last_name,
                                cmr_rewards: item.cmr_rewards,
                                created_date: item.created_date,
                                update_date: item.update_date,
                            },
                            itemData: [],
                            paymentData: [],
                        };
                    }

                    const existingItem = acc[key].itemData.find((i: any) => i.item_id === item.item_id);
                    if (existingItem) {
                        const batchExists = existingItem.itemBatchData.some(
                            (batch: any) => batch.item_batch_number === item.item_batch_number
                        );

                        if (!batchExists) {
                            existingItem.itemBatchData.push({
                                item_batch_number: item.item_batch_number,
                                item_id: item.item_id,
                                item_quantity: item.item_quantity,
                                item_exp_date: item.item_exp_date,
                                item_rack_location: item.item_rack_location

                            });
                            existingItem.item_quantity += parseFloat(item.item_quantity);
                            existingItem.item_total_amount += parseFloat(item.item_total_amount);
                            existingItem.item_discount_amount += parseFloat(item.item_discount_amount);
                            existingItem.item_discount_percentage += parseFloat(item.item_discount_percentage);
                            existingItem.item_tax_amount += parseFloat(item.item_tax_amount);
                            existingItem.item_total_tax_percentage += parseFloat(item.item_total_tax_percentage);
                            existingItem.item_gst += parseFloat(item.item_gst);
                            existingItem.item_sgst += parseFloat(item.item_sgst);
                            existingItem.item_igst += parseFloat(item.item_igst);
                            existingItem.item_cgst += parseFloat(item.item_cgst);
                        }


                    } else {
                        acc[key].itemData.push({
                            item_id: item.item_id,
                            item_code: item.item_code,
                            item_generic_name: item.item_generic_name,
                            item_name: item.item_name,
                            item_pack_size: item.item_pack_size,
                            item_batch_number: item.item_batch_number,
                            item_quantity: item.item_quantity,
                            item_exp_date: item.item_exp_date,
                            item_mfg_date: item.item_mfg_date,
                            item_rack_location: item.item_rack_location,
                            item_unit_price: item.item_unit_price,
                            item_schedule: item.item_schedule,
                            item_uom: item.item_uom,
                            item_discount_amount: parseFloat(item.item_discount_amount),
                            item_discount_percentage: parseFloat(item.item_discount_percentage),
                            item_tax_amount: parseFloat(item.item_tax_amount),
                            item_total_tax_percentage: parseFloat(item.item_total_tax_percentage),
                            item_total_amount: parseFloat(item.item_total_amount),
                            item_gst: parseFloat(item.item_gst),
                            item_sgst: parseFloat(item.item_sgst),
                            item_cgst: parseFloat(item.item_cgst),
                            item_igst: parseFloat(item.item_igst),
                            item_price_wiithout_tax: item.item_price_wiithout_tax,
                            item_free_quantity:item.item_free_quantity,

                            itemBatchData: [{
                                item_batch_number: item.item_batch_number,
                                item_id: item.item_id,
                                item_quantity: item.item_quantity,
                                item_exp_date: item.item_exp_date,
                                item_rack_location: item.item_rack_location
                            }]
                        });
                    }

                    const paymentRecord = {
                        payment_mode_name: item.payment_mode_name,
                        payment_amount: item.payment_amount
                    };

                    // Check if the payment record already exists
                    const paymentExists = acc[key].paymentData.some(
                        (payment: any) =>
                            payment.payment_mode_name === paymentRecord.payment_mode_name &&
                            payment.payment_amount === paymentRecord.payment_amount
                    );

                    if (!paymentExists) {
                        acc[key].paymentData.push(paymentRecord);
                    }

                    return acc;
                }, {});

                // Convert grouped items to an array
                const resultArray = Object.values(groupedItems);

                console.log(resultArray);

                //console.log(resultArray,"ddd", resultArray['orderData'])


                return res.send(generateResponse(true, "Invoice fetched successfully", 200, resultArray));
            } else {
                return res.send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function deleteDraftOrder(req: any, res: any) {
    try {
        // Start a transaction
        const { sot_id } = req.body;
        console.log(sot_id)


        const deleteDraftOrder = await orderService.deleteDraftOrder(sot_id)


        if (deleteDraftOrder.rows.length == 0) {
            return res.send(
                generateResponse(true, "Order deleted successfully", 200, {
                    orderData: deleteDraftOrder.rows[0],
                })
            );
        } else {
            return res.send(
                generateResponse(false, "Order deletion unsuccessful - Order not found", 404, null)
            );
        }
    } catch (err) {
        console.log(err);
        return res.send(generateResponse(false, err.message, 400, null));
    }
}

export async function getPastOrder(req: any, res: any) {
    try {

        if (req.query) {

            const orderDetailsResult = await orderService.getPastOrder(req.query)

            if (orderDetailsResult.orderDetailsResult.rows.length > 0) {
                for(let item of orderDetailsResult.orderDetailsResult.rows ){
                        const itemAvailableQuantity = await productService.getAvilableQunatity(item.item_id)
                        if(itemAvailableQuantity.length>0){
                        item.total_sellable_quantity = itemAvailableQuantity[0].total_sellable_quantity
                        }else{
                            item.total_sellable_quantity = 0
                        }
                    
                }
                const ordersArray = orderDetailsResult.orderDetailsResult.rows.reduce((acc, item) => {
                    const existingOrder = acc.find((order: any) => order.orderData.sot_id === item.sot_id);

                    if (existingOrder) {
                        existingOrder.itemData.push({
                            sot_id: item.sot_id,
                            cmr_first_name: item.cmr_first_name,
                            cmr_last_name: item.cmr_last_name,
                            cmr_phone_number: item.cmr_phone_number,
                            item_id: item.item_id,
                            item_code: item.item_code,
                            item_generic_name: item.item_generic_name,
                            item_name: item.item_name,
                            item_pack_size: item.item_pack_size,
                            item_batch_number: item.item_batch_number,
                            item_quantity: item.item_quantity,
                            item_uom:item.item_uom,
                            item_exp_date: item.item_exp_date,
                            item_mfg_date: item.item_mfg_date,
                            item_rack_location: item.item_rack_location,
                            item_unit_price: item.item_unit_price,
                            item_schedule: item.item_schedule,
                            item_discount_amount: item.item_discount_amount,
                            item_discount_percentage: item.item_discount_percentage,
                            item_tax_amount: item.item_tax_amount,
                            item_total_tax_percentage: item.item_total_tax_percentage,
                            item_total_amount: item.item_total_amount,
                            total_sellable_quantity:item.total_sellable_quantity,
                            item_hsn:item.item_hsn,
                            item_manufacturer_id:item.item_manufacturer_id,
                            item_manufacturer_name:item.item_manufacturer_name,
    
                            created_date: item.created_date,
                            update_date: item.update_date,
                        });
                    } else {
                        acc.push({
                            orderData: {
                                sot_id: item.sot_id,
                                store_id: item.store_id,
                                cmr_phone_number: item.cmr_phone_number,
                                sot_total_gst: item.sot_total_gst,
                                sot_total_discount: item.sot_total_discount,
                                sot_payment_status: item.sot_payment_status,
                                sot_transaction_id: item.sot_transaction_id,
                                is_draft_order: item.is_draft_order,
                                sot_payment_method: item.sot_payment_method,
                                sot_billing_address: item.sot_billing_address,
                                sot_total_amount: item.sot_total_amount,
                                sot_invoice_number: item.sot_invoice_number,
                                doctor_name: item.doctor_name,
                                cmr_first_name: item.cmr_first_name,
                                cmr_last_name: item.cmr_last_name,
                                cmr_rewards: item.cmr_rewards,
                                created_date: item.created_date,
                                update_date: item.update_date,
                            },
                            itemData: [
                                {
                                    sot_id: item.sot_id,
                                    cmr_first_name: item.cmr_first_name,
                                    cmr_last_name: item.cmr_last_name,
                                    cmr_phone_number: item.cmr_phone_number,
                                    item_id: item.item_id,
                                    item_code: item.item_code,
                                    item_generic_name: item.item_generic_name,
                                    item_name: item.item_name,
                                    item_pack_size: item.item_pack_size,
                                    item_batch_number: item.item_batch_number,
                                    item_quantity: item.item_quantity,
                                    item_exp_date: item.item_exp_date,
                                    item_mfg_date: item.item_mfg_date,
                                    item_uom:item.item_uom,
                                    item_rack_location: item.item_rack_location,
                                    item_unit_price: item.item_unit_price,
                                    item_schedule: item.item_schedule,
                                    item_discount_amount: item.item_discount_amount,
                                    item_discount_percentage: item.item_discount_percentage,
                                    item_tax_amount: item.item_tax_amount,
                                    item_total_tax_percentage: item.item_total_tax_percentage,
                                    item_total_amount: item.item_total_amount,
                                    total_sellable_quantity:item.total_sellable_quantity,
                                    item_manufacturer_id:item.item_manufacturer_id,
                                    item_manufacturer_name:item.item_manufacturer_name,
                                    item_hsn:item.item_hsn,
                                    created_date: item.created_date,
                                    update_date: item.update_date,
                                },
                            ],
                        });
                    }

                    return acc;
                }, []);

                // Combine all itemData arrays into a single array
                const allItemsData = ordersArray.reduce((acc: any, order: any) => [...acc, ...order.itemData], []);

                return res.send(
                    generateResponse(true, "Fetched order list successfully", 200, {
                        totalCount: orderDetailsResult.totalCount.rows[0].count,
                        allItemsData: allItemsData,
                    })
                );
            } else {
                return res.send(
                    generateResponse(false, "Fetching order list unsuccessful", 400, null)
                );
            }
        }
    }
    catch (err) {
        console.log(err);
        return res.send(generateResponse(false, err.message, 500, null));
    }
}




export async function getDashboardGraph1(req: any, res: any) {
    try {

        if (req.query) {

            const getDashboardGraph1 = await orderService.getDashboardGraph1(req.query)

            if (getDashboardGraph1.length > 0) {


                return res.send(
                    generateResponse(true, "graph1 fetch  list successfully", 200, getDashboardGraph1)
                );
            } else {
                return res.send(
                    generateResponse(false, "Fetching order list unsuccessful", 400, null)
                );
            }
        }
    }
    catch (err) {
        console.log(err);
        return res.send(generateResponse(false, err.message, 500, null));
    }
}


export async function getInvoiceitemsList(req: any, res: any) {
    try {
        const { query } = req.query
        console.log(typeof (query))
        const resultArray: any = []
        const queryParams = JSON.parse(query)


        console.log(queryParams)

        const getCustomerDetails = await orderService.getInvoiceCustomerDetails(queryParams[0].sot_id)

        for (let i = 0; i <= queryParams.length - 1; i++) {
            console.log(queryParams[i])
            const orderDetailsResult = await orderService.getInvoiceItemsList(queryParams[i])
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                // Convert grouped items to an array
                resultArray.push(orderDetailsResult.rows)
                //console.log(resultArray,"ddd", resultArray['orderData'])
            }
        }
        if (resultArray.length > 0) {
            const flattenedArray = resultArray.flatMap((array: any) => array);

            return res.send(generateResponse(true, "Invoice fetched successfully", 200, { itemData: flattenedArray, vendorDetails: getCustomerDetails }));
        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }




    } catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}



export async function addInvoiceCreditNote(req: any, res: any) {

    try {
        const { orderData: orderData, itemData: itemData, paymentData } = req.body
        // console.log(orderData)
        const store_id = orderData.store_id
        const { error, value } = returnOrderValidation.validate(req.body);

        if (error) {
            return res.status(400).send(
                generateResponse(false, "order placing unsuccesfully", 400, error)
            )
        } else {
            console.log('Validation succeeded:', value);

            // Fetch next invoice number

            const getNextInvoiceNumber = await nextInvoicenumber.getReturnInvoiceNextInvoiceNumber()
            console.log(getNextInvoiceNumber);

            if (!getNextInvoiceNumber) {
                return res.status(400).send(generateResponse(false, "Failed to generate next invoice number", 400, null));
            }
            orderData.icn_invoice_number = getNextInvoiceNumber;

            if (orderData && itemData) {
                const addOrder = await orderService.addInoviceCreditNote(orderData, itemData, paymentData)
                if (addOrder) {

                    return res.status(200).send(
                        generateResponse(true, "invoice crdit note  placed succesfully", 200, { orderData: addOrder.order, itemData: addOrder.item })
                    )

                } else {
                    return res.status(400).send(
                        generateResponse(false, "invoice credit note placing unsuccesfully", 400, null)
                    )

                }
            } else {
                return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
            }
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export async function getCreditNoteOrderList(req: any, res: any) {
    try {

        const getOrderList = await orderService.getCredNoteOrderList(req.query)

        if (getOrderList) {
            return res.status(200).send(generateResponse(true, "credit note invoice fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "credit note invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getCreditNoteOrderById(req: any, res: any) {
    try {
        const { icn_id } = req.query

        if (icn_id) {

            const orderDetailsResult = await orderService.getCreditNoteOrderById(icn_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                console.log(orderDetailsResult.rows, "ssssss")
                const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                    const key = item.icn_id;
                    if (!acc[key]) {
                        acc[key] = {
                            orderData: {
                                icn_id: item.icn_id,
                                store_id: item.store_id,
                                cmr_phone_number: item.cmr_phone_number,
                                icn_total_gst: item.icn_total_gst,
                                icn_total_discount: item.icn_total_discount,
                                icn_payment_status: item.icn_payment_status,
                                icn_transaction_id: item.icn_transaction_id,
                                is_draft_order: item.is_draft_order,
                                icn_payment_method: item.icn_payment_method,
                                icn_billing_address: item.icn_billing_address,
                                icn_total_amount: item.icn_total_amount,
                                icn_invoice_number: item.icn_invoice_number,
                                doctor_name: item.doctor_name,
                                cmr_first_name: item.cmr_first_name,
                                cmr_last_name: item.cmr_last_name,
                                cmr_rewards: item.cmr_rewards,
                                created_date: item.created_date,
                                update_date: item.update_date,
                                icn_remarks:item.icn_remarks
                            },
                            itemData: [],
                            paymentData: [],
                        };
                    }

                    // Check if the item record already exists
                    const itemExists = acc[key].itemData.some(
                        (existingItem: any) => existingItem.item_batch_number === item.item_batch_number && existingItem.sot_id === item.sot_id
                    );

                    if (!itemExists) {
                        acc[key].itemData.push({
                            item_id: item.item_id,
                            item_code: item.item_code,
                            item_generic_name: item.item_generic_name,
                            item_name: item.item_name,
                            item_pack_size: item.item_pack_size,
                            item_batch_number: item.item_batch_number,
                            item_quantity: item.item_quantity,
                            item_exp_date: item.item_exp_date,
                            item_mfg_date: item.item_mfg_date,
                            item_rack_location: item.item_rack_location,
                            item_open_quantity: item.item_open_quantity,
                            item_unit_price: item.item_unit_price,
                            item_schedule: item.item_schedule,
                            item_discount_amount: item.item_discount_amount,
                            item_discount_percentage: item.item_discount_percentage,
                            item_tax_amount: item.item_tax_amount,
                            item_total_tax_percentage: item.item_total_tax_percentage,
                            item_total_amount: item.item_total_amount,
                            item_price_wiithout_tax: item.item_price_wiithout_tax,
                            item_uom: item.item_uom,
                            item_gst: item.item_gst,
                            item_sgst: item.item_sgst,
                            item_cgst: item.item_cgst,
                            item_igst: item.item_igst,
                            linked_invoice_number:item.sot_invoice_number,
                            item_free_quantity:item.item_free_quantity,
                            item_manufacturer_id:item.item_manufacturer_id,
                            item_manufacturer_name:item.item_manufacturer_name,
                            item_hsn:item.item_hsn
                        });
                    }

                    const paymentRecord = {
                        payment_mode_name: item.payment_mode_name,
                        payment_amount: item.payment_amount,
                    };

                    // Check if the payment record already exists
                    const paymentExists = acc[key].paymentData.some(
                        (payment: any) =>
                            payment.payment_mode_name === paymentRecord.payment_mode_name &&
                            payment.payment_amount === paymentRecord.payment_amount
                    );

                    if (!paymentExists) {
                        acc[key].paymentData.push(paymentRecord);
                    }

                    return acc;
                }, {});

                // Convert grouped items to an array
                const resultArray: any = Object.values(groupedItems);

                console.log(resultArray);

                //console.log(resultArray,"ddd", resultArray['orderData'])

                return res.status(200).send(generateResponse(true, "Invoice fetched successfully", 200, resultArray));
            } else {
                return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
            }



        } else {
            return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

async function getUnOrderById(orderDetailsResult: any) {
    try {
        console.log(orderDetailsResult, '124234')
        const orderDetailsArray = Array.isArray(orderDetailsResult) ? orderDetailsResult : [orderDetailsResult];
        const groupedItems = orderDetailsArray.reduce((acc: any, item: any) => {
            const key = item.sot_id;
            if (!acc[key]) {
                acc[key] = {
                    orderData: {
                        sot_id: item.sot_id,
                        store_id: item.store_id,
                        cmr_phone_number: item.cmr_phone_number,
                        sot_total_gst: item.sot_total_gst,
                        sot_total_discount: item.sot_total_discount,
                        sot_payment_status: item.sot_payment_status,
                        sot_transaction_id: item.sot_transaction_id,
                        is_draft_order: item.is_draft_order,
                        sot_payment_method: item.sot_payment_method,
                        sot_billing_address: item.sot_billing_address,
                        sot_total_amount: item.sot_total_amount,
                        sot_invoice_number: item.sot_invoice_number,
                        doctor_name: item.doctor_name,
                        sot_return_status: item.sot_return_status,
                        sot_remarks: item.sot_remarks,
                        sot_sub_total: item.sot_sub_total
                    },
                    itemData: [],
                    paymentData: [],
                };
            }

            // Check if the item record already exists
            const itemExists = acc[key].itemData.some(
                (existingItem: any) => existingItem.item_batch_number === item.item_batch_number
            );

            if (!itemExists) {
                acc[key].itemData.push({
                    item_id: item.item_id,
                    item_code: item.item_code,
                    item_open_quantity: item.item_open_quantity,
                    item_generic_name: item.item_generic_name,
                    item_name: item.item_name,
                    item_pack_size: item.item_pack_size,
                    item_batch_number: item.item_batch_number,
                    item_quantity: item.item_quantity,
                    item_exp_date: item.item_exp_date,
                    item_mfg_date: item.item_mfg_date,
                    item_rack_location: item.item_rack_location,
                    item_unit_price: item.item_unit_price,
                    item_schedule: item.item_schedule,
                    item_discount_amount: item.item_discount_amount,
                    item_discount_percentage: item.item_discount_percentage,
                    item_tax_amount: item.item_tax_amount,
                    item_total_tax_percentage: item.item_total_tax_percentage,
                    item_total_amount: item.item_total_amount,
                    item_price_wiithout_tax: item.item_price_wiithout_tax,
                    item_gst: item.item_gst,
                    item_sgst: item.item_sgst,
                    item_cgst: item.item_cgst,
                    item_igst: item.item_igst,
                    item_uom: item.item_uom,
                    total_sellable_quantity: item.total_sellable_quantity,
                    item_total_qaunitiy: item.item_quantity,
                    item_free_quantity:item.item_free_quantity,
                    sot_id: item.sot_id,
                    item_manufacturer_id:item.item_manufacturer_id,
                    item_manufacturer_name:item.item_manufacturer_name,
                    item_hsn:item.item_hsn

                });
            }

            const paymentRecord = {
                payment_mode_name: item.payment_mode_name,
                payment_amount: item.payment_amount,
                sot_id: item.sot_id,
            };

            // Check if the payment record already exists
            const paymentExists = acc[key].paymentData.some(
                (payment: any) =>
                    payment.payment_mode_name === paymentRecord.payment_mode_name &&
                    payment.payment_amount === paymentRecord.payment_amount
            );

            if (!paymentExists) {
                acc[key].paymentData.push(paymentRecord);
            }

            return acc;
        }, {});

        // Convert grouped items to an array
        const resultArray: any = Object.values(groupedItems);

        //console.log(resultArray);

        //console.log(resultArray,"ddd", resultArray['orderData'])


        return resultArray




    } catch (error) {
        console.log(error)

    }
}

// export async function getUnSynOrder() {
//     try {
//        const getUnSyncedOrder = await orderService.getUnSynOrder()

//        if(getUnSyncedOrder.rows.length>0){
//         for(let order of getUnSyncedOrder.rows ){

//             let getOrder = await getUnOrderById(order)
//             console.log(getOrder[0].orderData,getOrder[0].itemData,getOrder[0].paymentData ,'wwwwwwwwwwwwwww')
//         // const syncedResult = await    orderService.syncOrder(getOrder[0].orderData,getOrder[0].itemData,getOrder[0].paymentData)
//         }
//        }




//     } catch (error) {
//         console.log(error)

//     }
// }

export async function getUnSynOrder() {
    try {
        const [getUnSyncedOrder,posId] = await Promise.all([orderService.getUnSynOrder(),getposId()]);
        const pos_id = posId.rows[0].pos_id
        if (getUnSyncedOrder.rows.length > 0) {
            const groupedOrders: any = {};

            // Group orders by sot_id
            for (let order of getUnSyncedOrder.rows) {
                const orderId = order.sot_id;
                const replaceNullWithZero = (obj: Record<string, any>) => {
                    return Object.fromEntries(
                        Object.entries(obj).map(([key, value]) => [key, value ?? 0])
                    );
                };
                function formatDate(date:any) {
                    if (!date) return null; // Handle null or undefined dates
                    const d = new Date(date);
                    const year = d.getFullYear();
                    const month = String(d.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
                    const day = String(d.getDate()).padStart(2, '0');
                    return `${year}-${month}-${day}`;
                  }
                  
            
                if (!groupedOrders[orderId]) {
                    groupedOrders[orderId] = {
                        orderData: {
                            sot_id: order.sot_id,
                            store_id: order.store_id,
                            cmr_phone_number: order.cmr_phone_number,
                            sot_total_gst: order.sot_total_gst,
                            sot_total_discount: order.sot_total_discount,
                            sot_payment_status: order.sot_payment_status,
                            sot_transaction_id: order.sot_transaction_id,
                            is_draft_order: order.is_draft_order,
                            sot_payment_method: order.sot_payment_method,
                            sot_billing_address: order.sot_billing_address,
                            sot_total_amount: order.sot_total_amount,
                            sot_invoice_number: order.sot_invoice_number,
                            doctor_name: order.doctor_name,
                            sot_return_status: order.sot_return_status,
                            sot_remarks: order.sot_remarks,
                            sot_sub_total: order.sot_sub_total,
                            update_date: order.update_date,
                            created_date: order.created_date,
                            pos_id:pos_id
                        },
                        itemData: [],
                        paymentData: [],
                    };
                }

                // Push item data if it doesn't already exist
                const itemExists = groupedOrders[orderId].itemData.some(
                    (existingItem: any) => existingItem.item_batch_number === order.item_batch_number
                        && existingItem.item_rack_location === order.item_rack_location
                );

                if (!itemExists) {
                    groupedOrders[orderId].itemData.push({
                        item_id: order.item_id,
                        item_code: order.item_code,
                        item_generic_name: order.item_generic_name,
                        item_name: order.item_name,
                        item_pack_size: order.item_pack_size,
                        item_batch_number: order.item_batch_number,
                        item_quantity: order.item_quantity,
                        item_exp_date: formatDate(order.item_exp_date),
                        item_rack_location: order.item_rack_location,
                        item_unit_price: order.item_unit_price,
                        item_schedule: order.item_schedule,
                        item_discount_amount: order.item_discount_amount,
                        item_discount_percentage: order.item_discount_percentage,
                        item_tax_amount: order.item_tax_amount,
                        item_total_tax_percentage: order.item_total_tax_percentage,
                        item_total_amount: order.item_total_amount,
                        item_price_wiithout_tax: order.item_price_wiithout_tax?? 0,
                        item_gst: order.item_gst,
                        item_sgst: order.item_sgst,
                        item_cgst: order.item_cgst,
                        item_uom: order.item_uom,
                        item_free_quantity:order.item_free_quantity,
                        sot_id: order.sot_id,
                        item_manufacturer_id:order.item_manufacturer_id,
                        item_manufacturer_name:order.item_manufacturer_name,
                        item_hsn:order.item_hsn
                    });

                    

                }

                // Push payment data if it doesn't already exist
                const paymentRecord = {
                    payment_mode_name: order.payment_mode_name,
                    payment_amount: order.payment_amount,
                    sot_id: order.sot_id,
                };

                const paymentExists = groupedOrders[orderId].paymentData.some(
                    (payment: any) => payment.payment_mode_name === paymentRecord.payment_mode_name &&
                        payment.payment_amount === paymentRecord.payment_amount
                );

                if (!paymentExists) {
                    groupedOrders[orderId].paymentData.push(paymentRecord);
                }
            }

            // Now you can process each grouped order
            for (let orderId in groupedOrders) {
                const order = groupedOrders[orderId];

               console.log(order.orderData, order.itemData, order.paymentData, 'Processing Order');
                const syncedResult = await orderService.syncOrder(order.orderData, order.itemData, order.paymentData);
            }
        }
    } catch (error) {
        console.error('Error syncing orders:', error);
    }
}

export async function  invoiceShare(req: any, res: any) {
try{
              let getdetails 
              let orderData
    if(req.body.transaction_type=='Billing'){
           getdetails = await getOrder(req.body.transaction_id)
           orderData  = getdetails?.resultArray
    }

    if(req.body.transaction_type=='invoice_credit_note'){
        getdetails = await getSalesReturnInvoiceForShare(req.body.transaction_id)
        orderData  = getdetails?.resultArray
 }


  const storeDetailsResult= await orderService.getStoreDetails();
  const pdfOptions = {
    format: 'A4',
    orientation: 'landscape',
    margin: {
        top: '10mm',
        right: '10mm',
        bottom: '10mm',
        left: '10mm',
    },
};


const pdfBuffer: Buffer = await html_to_pdf.generatePdf({ content:  getdetails?.htmlContent }, pdfOptions) as unknown as Buffer;
if (!pdfBuffer || !(pdfBuffer instanceof Buffer)) {
    throw new Error("Failed to generate a valid PDF buffer.");
}

const pdfPath = path.join(process.cwd(), `Invoice_${orderData[0].orderData.sot_invoice_number}.pdf`);
fs.writeFileSync(pdfPath, pdfBuffer);



 



const mailOptions = {
    to: req.body.email_address,
    from: 'info@zotanextech.com',
    attachments: [
        {
            filename: `Invoice_${orderData[0].orderData.sot_invoice_number}.pdf`,
            content: pdfBuffer, // Ensure pdfBuffer is valid
            contentType: 'application/pdf',
        },
    ],
    subject: `Invoice #${orderData[0].orderData.sot_invoice_number}`,
    html: `
    <p>Dear ${orderData[0].orderData.cmr_first_name},</p>
    <p>Thank you for choosing ${storeDetailsResult[0]?.company } Your recent transaction is ready.</p>
    <p><strong>Summary of Your Transaction:</strong></p>
    <p>
        <strong>Invoice Number:</strong> ${orderData[0].orderData.sot_invoice_number}<br>
        <strong>Date:</strong> ${orderData[0].orderData.created_date}<br>
        <strong>Total Amount:</strong> ₹${orderData[0].orderData.sot_total_amount}
    </p>
    <p>We have attached a PDF copy of your invoice for your reference.</p>
    <p>If you have any questions, feel free to contact us.</p>
    <p>Warm regards,<br>${storeDetailsResult[0]?.company } </p>
    `,
};



      console.log(mailOptions)

      transporter.sendMail(mailOptions, (err, response) => {
        if (err) {
          console.error('Error sending email:', err);
          return res.status(500).send(generateResponse(false,'Error sending email',400,null));
        }
        res.status(200).send(generateResponse(true,'Password reset email sent successfully',200,null));
      });
      try {
        fs.unlinkSync(pdfPath);
        console.log('PDF file deleted successfully.');
    } catch (deleteError) {
        console.error('Error deleting PDF file:', deleteError);
    }

           

        return res.send(
            generateResponse(true, "send  succesfully", 200,null)
        )
    
}catch(error){
    console.log(error)
    return res.send(
        generateResponse(false, "something went wrong ", 400,null)
    )
                
}
    
     
    }
 export async function getOrderByIdAsPdf(req: any, res: any) {
        try {
            const { sot_id } = req.query
    
            if (sot_id) {
    
                const orderDetailsResult = await orderService.getOrderById(sot_id)
                console.log(orderDetailsResult)
                const storeDetailsResult= await orderService.getStoreDetails();
                console.log(storeDetailsResult[0].store_id);
                if (orderDetailsResult.length > 0 && storeDetailsResult && storeDetailsResult.length > 0) {
                    console.log(orderDetailsResult, "ssssss")
                    const groupedItems = orderDetailsResult.reduce((acc, item) => {
                        const key = item.sot_id;
                        if (!acc[key]) {
                            acc[key] = {
                                orderData: {
                                    sot_id: item.sot_id,
                                    store_id: item.store_id,
                                    cmr_phone_number: item.cmr_phone_number,
                                    sot_total_gst: item.sot_total_gst,
                                    sot_total_discount: item.sot_total_discount,
                                    sot_payment_status: item.sot_payment_status,
                                    sot_transaction_id: item.sot_transaction_id,
                                    is_draft_order: item.is_draft_order,
                                    sot_payment_method: item.sot_payment_method,
                                    sot_billing_address: item.sot_billing_address,
                                    sot_total_amount: item.sot_total_amount,
                                    sot_invoice_number: item.sot_invoice_number,
                                    doctor_name: item.doctor_name,
                                    cmr_first_name: item.cmr_first_name,
                                    cmr_last_name: item.cmr_last_name,
                                    cmr_rewards: item.cmr_rewards,
                                    created_date: formatDate(item.created_date),
                                    update_date: formatDate(item.created_date),
                                    sot_return_status: item.sot_return_status,
                                    sot_remarks: item.sot_remarks,
                                    cmr_state: item.cmr_state,
                                    cmr_pan:item.cmr_pan,
                                    cmr_area:item.cmr_address,
                                    cmr_gst:item.cmr_gstin,
                                    cmr_company:item.cmr_company,
                                    invoice_number:item.sot_invoice_number
                                },
                                itemData: [],
                                paymentData: [],
                            };
                        }
    
                        // Check if the item record already exists
                        const itemExists = acc[key].itemData.some(
                            (existingItem: any) => existingItem.item_batch_number === item.item_batch_number
                                && existingItem.item_rack_location === item.item_rack_location
    
                        );
    
    
    
    
                        if (!itemExists) {
                            acc[key].itemData.push({
                                item_id: item.item_id,
                                item_code: item.item_code,
                                item_open_quantity: item.item_open_quantity,
                                item_generic_name: item.item_generic_name,
                                item_name: item.item_name,
                                item_pack_size: item.item_pack_size,
                                item_batch_number: item.item_batch_number,
                                item_quantity: item.item_quantity,
                                item_exp_date: formatDate(item.item_exp_date),
                                item_mfg_date: item.item_mfg_date,
                                item_rack_location: item.item_rack_location,
                                item_unit_price: item.item_unit_price,
                                item_schedule: item.item_schedule,
                                item_discount_amount: item.item_discount_amount,
                                item_discount_percentage: item.item_discount_percentage,
                                item_tax_amount: item.item_tax_amount,
                                item_total_tax_percentage: item.item_total_tax_percentage,
                                item_total_amount: item.item_total_amount,
                                item_price_wiithout_tax: item.item_price_wiithout_tax,
                                item_gst: item.item_gst,
                                item_sgst: item.item_sgst,
                                item_cgst: item.item_cgst,
                                item_igst: item.item_igst,
                                item_uom: item.item_uom,
                                total_sellable_quantity: item.total_sellable_quantity,
                                item_total_qaunitiy: item.item_quantity,
                                item_free_quantity:item.item_free_quantity,
                                item_manufacturer_id:item.item_manufacturer_id,
                                item_manufacturer_name:item.item_manufacturer_name,
                                item_mfg:item.item_manufacturer_name,
                                item_hsn:item.item_hsn
                            });
                        }
    
                        const paymentRecord = {
                            payment_mode_name: item.payment_mode_name,
                            payment_amount: item.payment_amount,
                        };
    
                        // Check if the payment record already exists
                        const paymentExists = acc[key].paymentData.some(
                            (payment: any) =>
                                payment.payment_mode_name === paymentRecord.payment_mode_name &&
                                payment.payment_amount === paymentRecord.payment_amount
                        );
    
                        if (!paymentExists) {
                            acc[key].paymentData.push(paymentRecord);
                        }
    
                        return acc;
                    }, {});
    
                    // Convert grouped items to an array
                    const resultArray: any = Object.values(groupedItems);
    
    
                    //console.log(resultArray,"ddd", resultArray['orderData'])
                    const is_draft_order = resultArray[0].orderData.is_draft_order
    
                    
                        const htmlContent  = Invoice(resultArray,storeDetailsResult);
                     //    pdf.create(htmlContent,{
                        //     format: 'A4',
                        //     orientation: 'landscape', 
                        //     border: {
                        //       top: '10mm',
                        //       right: '10mm',
                        //       bottom: '10mm',
                        //       left: '10mm',
                        //     },
                        //   }).toBuffer(async (err:any, buffer:any) => {
                        //     if (err) {
                        //       console.error('Error creating PDF:', err);
                        //       return res.status(400).send(generateResponse(false, "Something went wrong", 400, null));
                        //     }
                        //     const filename = resultArray[0].orderData.sot_invoice_number + ".pdf";
                        //     res.set({
                        //       'Content-Type': 'application/pdf',
                        //       'Content-Disposition': `attachment; filename=${filename}`,
                        //     });

                        //     const base64Pdf = buffer.toString('base64');

    // API Request to Send the PDF via WhatsApp
    // const whatsappApiResponse = await axios.post(
    //   'https://theultimate.io/WAApi/send',
    //   {
    //     to: `7338578203`, // Recipient WhatsApp number
    //     type: 'media',
    //     mediaType: 'document',
    //     media: base64Pdf, // Sending the file as Base64
    //     filename, // File name for the recipient
    //     caption: `Invoice: ${filename}`,
    //   },
    //   {
    //     headers: {
    //       Authorization: '6b3971f0c1109d1271c484b03ce8d75294218904',
    //       'Content-Type': 'application/json',
    //     },
    //   }
    // );


  //  console.log(whatsappApiResponse.data,"eeeeeeeeeeeeeeee")

                        
   // Convert PDF buffer to Base64
  res.set('Content-Type', 'application/json'); // Set response type to JSON
  return res.status(200).send(generateResponse(true, "Invoice nfound", 200, htmlContent));
  res.send({
    success: true,
    html: htmlContent, // Send HTML content
    // pdf: base64Pdf,    // Send PDF content in Base64
 //   filename: resultArray[0].orderData.sot_invoice_number + ".pdf", // Optional filename
  });

   ///                       });
                        
                    } else {
                        return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
                    }
    
    
    
                } else {
                    return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
                }
            
        } catch (error) {
            console.log(error)
            return res.status(400).send(generateResponse(false, error.message, 400, null));
        }
    }

 export async function getOrder(sot_id:any) {
        try {
            
    
            const storeDetailsResult= await orderService.getStoreDetails();
    
                const orderDetailsResult = await orderService.getOrderById(sot_id)
                console.log(orderDetailsResult)
                if (orderDetailsResult.length > 0) {
                    console.log(orderDetailsResult, "ssssss")
                    const groupedItems = orderDetailsResult.reduce((acc, item) => {
                        const key = item.sot_id;
                        if (!acc[key]) {
                            acc[key] = {
                                orderData: {
                                    sot_id: item.sot_id,
                                    store_id: item.store_id,
                                    cmr_phone_number: item.cmr_phone_number,
                                    sot_total_gst: item.sot_total_gst,
                                    sot_total_discount: item.sot_total_discount,
                                    sot_payment_status: item.sot_payment_status,
                                    sot_transaction_id: item.sot_transaction_id,
                                    is_draft_order: item.is_draft_order,
                                    sot_payment_method: item.sot_payment_method,
                                    sot_billing_address: item.sot_billing_address,
                                    sot_total_amount: item.sot_total_amount,
                                    sot_invoice_number: item.sot_invoice_number,
                                    doctor_name: item.doctor_name,
                                    cmr_first_name: item.cmr_first_name,
                                    cmr_last_name: item.cmr_last_name,
                                    cmr_rewards: item.cmr_rewards,
                                    created_date:formatDate(item.created_date),
                                    update_date: formatDate(item.created_date),
                                    sot_return_status: item.sot_return_status,
                                    sot_remarks: item.sot_remarks,
                                    cmr_state: item.cmr_state,
                                    cmr_pan:item.cmr_pan,
                                    cmr_area:item.cmr_address,
                                    invoice_number:item.sot_invoice_number
                                },
                                itemData: [],
                                paymentData: [],
                            };
                        }
    
                        // Check if the item record already exists
                        const itemExists = acc[key].itemData.some(
                            (existingItem: any) => existingItem.item_batch_number === item.item_batch_number
                                && existingItem.item_rack_location === item.item_rack_location
    
                        );
    
    
    
    
                        if (!itemExists) {
                            acc[key].itemData.push({
                                item_id: item.item_id,
                                item_code: item.item_code,
                                item_open_quantity: item.item_open_quantity,
                                item_generic_name: item.item_generic_name,
                                item_name: item.item_name,
                                item_pack_size: item.item_pack_size,
                                item_batch_number: item.item_batch_number,
                                item_quantity: item.item_quantity,
                                item_exp_date:formatDate(item.item_exp_date),
                                item_mfg_date: item.item_mfg_date,
                                item_rack_location: item.item_rack_location,
                                item_unit_price: item.item_unit_price,
                                item_schedule: item.item_schedule,
                                item_discount_amount: item.item_discount_amount,
                                item_discount_percentage: item.item_discount_percentage,
                                item_tax_amount: item.item_tax_amount,
                                item_total_tax_percentage: item.item_total_tax_percentage,
                                item_total_amount: item.item_total_amount,
                                item_price_wiithout_tax: item.item_price_wiithout_tax,
                                item_gst: item.item_gst,
                                item_sgst: item.item_sgst,
                                item_cgst: item.item_cgst,
                                item_igst: item.item_igst,
                                item_uom: item.item_uom,
                                total_sellable_quantity: item.total_sellable_quantity,
                                item_total_qaunitiy: item.item_quantity,
                                item_free_quantity:item.item_free_quantity,
                                item_manufacturer_id:item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name
    
    
                            });
                        }
    
                        const paymentRecord = {
                            payment_mode_name: item.payment_mode_name,
                            payment_amount: item.payment_amount,
                        };
    
                        // Check if the payment record already exists
                        const paymentExists = acc[key].paymentData.some(
                            (payment: any) =>
                                payment.payment_mode_name === paymentRecord.payment_mode_name &&
                                payment.payment_amount === paymentRecord.payment_amount
                        );
    
                        if (!paymentExists) {
                            acc[key].paymentData.push(paymentRecord);
                        }
    
                        return acc;
                    }, {});
    
                    // Convert grouped items to an array
                    const resultArray: any = Object.values(groupedItems);
    
                    
    
    
                    //console.log(resultArray,"ddd", resultArray['orderData'])
                    const is_draft_order = resultArray[0].orderData.is_draft_order
    
                    
                        const htmlContent  = Invoice(resultArray,storeDetailsResult);
                        return {htmlContent:htmlContent,resultArray:resultArray}
                     //    pdf.create(htmlContent,{
                        //     format: 'A4',
                        //     orientation: 'landscape', 
                        //     border: {
                        //       top: '10mm',
                        //       right: '10mm',
                        //       bottom: '10mm',
                        //       left: '10mm',
                        //     },
                        //   }).toBuffer(async (err:any, buffer:any) => {
                        //     if (err) {
                        //       console.error('Error creating PDF:', err);
                        //       return res.status(400).send(generateResponse(false, "Something went wrong", 400, null));
                        //     }
                        //     const filename = resultArray[0].orderData.sot_invoice_number + ".pdf";
                        //     res.set({
                        //       'Content-Type': 'application/pdf',
                        //       'Content-Disposition': `attachment; filename=${filename}`,
                        //     });

                        //     const base64Pdf = buffer.toString('base64');

    // API Request to Send the PDF via WhatsApp
    // const whatsappApiResponse = await axios.post(
    //   'https://theultimate.io/WAApi/send',
    //   {
    //     to: `7338578203`, // Recipient WhatsApp number
    //     type: 'media',
    //     mediaType: 'document',
    //     media: base64Pdf, // Sending the file as Base64
    //     filename, // File name for the recipient
    //     caption: `Invoice: ${filename}`,
    //   },
    //   {
    //     headers: {
    //       Authorization: '6b3971f0c1109d1271c484b03ce8d75294218904',
    //       'Content-Type': 'application/json',
    //     },
    //   }
    // );


  //  console.log(whatsappApiResponse.data,"eeeeeeeeeeeeeeee")

                        
   // Convert PDF buffer to Base64
//   res.set('Content-Type', 'application/json'); // Set response type to JSON

//   res.send({
//     success: true,
//     html: htmlContent, // Send HTML content
//     // pdf: base64Pdf,    // Send PDF content in Base64
//  //   filename: resultArray[0].orderData.sot_invoice_number + ".pdf", // Optional filename
//   });

   ///                       });
                        
                //     } else {
                //         return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
                //     }
    
    
    
                // } else {
                //     return res.status(400).send(generateResponse(false, "Invoice not found", 400, null));
                // }
            
            }
        } catch (error) {
            console.log(error)
          //  return res.status(400).send(generateResponse(false, error.message, 400, null));
        }
    }
    


export async function getUnSynReturnOrder() {
        try {
            const [getUnSyncedOrder,posId] = await Promise.all([orderService.getUnSynReturnOrder(),getposId()]);
            const pos_id = posId.rows[0].pos_id
            if (getUnSyncedOrder.rows.length > 0) {
                const groupedOrders: any = {};
    
                // Group orders by sot_id
                for (let item of getUnSyncedOrder.rows) {
                    const orderId = item.icn_id;
    
                    if (!groupedOrders[orderId]) {
                        groupedOrders[orderId] = {
                            orderData: {
                                icn_id: item.icn_id,
                                store_id: item.store_id,
                                cmr_phone_number: item.cmr_phone_number,
                                icn_total_gst: item.icn_total_gst,
                                icn_total_discount: item.icn_total_discount,
                                icn_payment_status: item.icn_payment_status,
                                icn_transaction_id: item.icn_transaction_id,
                                icn_payment_method: item.icn_payment_method,
                                icn_billing_address: item.icn_billing_address,
                                icn_total_amount: item.icn_total_amount,
                                icn_invoice_number: item.icn_invoice_number,
                                doctor_name: item.doctor_name,
                                cmr_first_name: item.cmr_first_name,
                                cmr_last_name: item.cmr_last_name,
                                cmr_rewards: item.cmr_rewards,
                                created_date: item.created_date,
                                update_date: item.update_date,
                                icn_remarks:item.icn_remarks,
                                pos_id:pos_id
                            },
                            itemData: [],
                            paymentData: [],
                        };
                    }
    
                    // Push item data if it doesn't already exist
                    const itemExists = groupedOrders[orderId].itemData.some(
                        (existingItem: any) => existingItem.item_batch_number === item.item_batch_number && existingItem.sot_id === item.sot_id
                    );

                    if (!itemExists) {
                        groupedOrders[orderId].itemData.push({
                            item_id: item.item_id,
                            icn_id: item.icn_id,
                            item_code: item.item_code,
                            item_generic_name: item.item_generic_name,
                            item_name: item.item_name,
                            item_batch_number: item.item_batch_number,
                            item_quantity: item.item_quantity,
                            item_exp_date: item.item_exp_date,
                            item_rack_location: item.item_rack_location,
                            item_open_quantity: item.item_open_quantity,
                            item_unit_price: item.item_unit_price,
                            item_schedule: item.item_schedule,
                            item_discount_amount: item.item_discount_amount,
                            item_discount_percentage: item.item_discount_percentage,
                            item_tax_amount: item.item_tax_amount,
                            item_total_amount: item.item_total_amount,
                            item_price_wiithout_tax: item.item_price_wiithout_tax,
                            item_uom: item.item_uom,
                            item_gst: item.item_gst,
                            item_sgst: item.item_sgst,
                            item_cgst: item.item_cgst,
                            linked_invoice_number:item.sot_invoice_number,
                            item_free_quantity:item.item_free_quantity,
                            sot_id:item.sot_id,
                            item_manufacturer_id:item.item_manufacturer_id,
                        item_manufacturer_name:item.item_manufacturer_name
                        });
                    }
    
                    // Push payment data if it doesn't already exist
                    const paymentRecord = {
                        payment_mode_name: item.payment_mode_name,
                        payment_amount: item.payment_amount,
                        icn_id: item.icn_id,
                    };
    
                    const paymentExists = groupedOrders[orderId].paymentData.some(
                        (payment: any) => payment.payment_mode_name === paymentRecord.payment_mode_name &&
                            payment.payment_amount === paymentRecord.payment_amount
                    );
    
                    if (!paymentExists) {
                        groupedOrders[orderId].paymentData.push(paymentRecord);
                    }
                }
    
                // Now you can process each grouped order
                for (let orderId in groupedOrders) {
                    const order = groupedOrders[orderId];
                //   console.log(order.orderData, order.itemData, order.paymentData, 'Processing Order');
                    const syncedResult = await orderService.syncReturnOrder(order.orderData, order.itemData, order.paymentData);
                }
            }
        } catch (error) {
            console.error('Error syncing orders:', error);
        }
    }    


export async function getSalesReturnInvoiceByIdHTML(req: any, res: any) {
    try {
        const { icn_id } = req.query

        if (icn_id) {
            
            const orderDetailsResult = await orderService.getCreditNoteOrderById(icn_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                console.log(orderDetailsResult.rows, "ssssss")
                const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                    const key = item.icn_id;
                    if (!acc[key]) {
                        acc[key] = {
                            orderData: {
                                icn_id: item.icn_id,
                                store_id: item.store_id,
                                cmr_phone_number: item.cmr_phone_number,
                                icn_total_gst: item.icn_total_gst,
                                icn_total_discount: item.icn_total_discount,
                                icn_payment_status: item.icn_payment_status,
                                icn_transaction_id: item.icn_transaction_id,
                                is_draft_order: item.is_draft_order,
                                icn_payment_method: item.icn_payment_method,
                                icn_billing_address: item.icn_billing_address,
                                icn_total_amount: item.icn_total_amount,
                                icn_invoice_number: item.icn_invoice_number,
                                doctor_name: item.doctor_name,
                                cmr_first_name: item.cmr_first_name,
                                cmr_last_name: item.cmr_last_name,
                                cmr_rewards: item.cmr_rewards,
                                created_date: item.created_date,
                                update_date: item.update_date,
                                icn_remarks:item.icn_remarks,
                                invoice_number:item.icn_invoice_number,
                            },
                            itemData: [],
                            paymentData: [],
                        };
                    }

                    // Check if the item record already exists
                    const itemExists = acc[key].itemData.some(
                        (existingItem: any) => existingItem.item_batch_number === item.item_batch_number && existingItem.sot_id === item.sot_id
                    );

                    if (!itemExists) {
                        acc[key].itemData.push({
                            item_id: item.item_id,
                            item_code: item.item_code,
                            item_generic_name: item.item_generic_name,
                            item_name: item.item_name,
                            item_pack_size: item.item_pack_size,
                            item_batch_number: item.item_batch_number,
                            item_quantity: item.item_quantity,
                            item_exp_date:formatDate( item.item_exp_date),
                            item_mfg_date: item.item_mfg_date,
                            item_rack_location: item.item_rack_location,
                            item_open_quantity: item.item_open_quantity,
                            item_unit_price: item.item_unit_price,
                            item_schedule: item.item_schedule,
                            item_discount_amount: item.item_discount_amount,
                            item_discount_percentage: item.item_discount_percentage,
                            item_tax_amount: item.item_tax_amount,
                            item_total_tax_percentage: item.item_total_tax_percentage,
                            item_total_amount: item.item_total_amount,
                            item_price_wiithout_tax: item.item_price_wiithout_tax,
                            item_uom: item.item_uom,
                            item_gst: item.item_gst,
                            item_sgst: item.item_sgst,
                            item_cgst: item.item_cgst,
                            item_igst: item.item_igst,
                            linked_invoice_number:item.sot_invoice_number,
                            item_free_quantity:item.item_free_quantity,
                            item_manufacturer_id:item.item_manufacturer_id,
                            item_manufacturer_name:item.item_manufacturer_name,
                            item_hsn:item.item_hsn,
                            sot_invoice_number:item.sot_invoice_number
                        });
                    }

                    const paymentRecord = {
                        payment_mode_name: item.payment_mode_name,
                        payment_amount: item.payment_amount,
                    };
                    const paymentExists = acc[key].paymentData.some(
                        (payment: any) =>
                            payment.payment_mode_name === paymentRecord.payment_mode_name &&
                            payment.payment_amount === paymentRecord.payment_amount
                    );

                    if (!paymentExists) {
                        acc[key].paymentData.push(paymentRecord);
                    }

                    return acc;
                }, {});

                // Convert grouped items to an array
                const resultArray: any = Object.values(groupedItems);
            const storeDetailsResult= await orderService.getStoreDetails();
            const html=await ReturnInvoice(resultArray,storeDetailsResult);
            if(html){
                return res.send(generateResponse(true, "Invoice fetched successfully", 200, html));
            }
                else{
                    return res.send(generateResponse(false, "Invoice not found", 400, null));
            }

        } else {
            return res.send(generateResponse(false, "Invoice not found", 400, null));
        }
    } }catch (error) {
        console.log(error)
        return res.send(generateResponse(false, error.message, 400, null));
    }
}



export async function getSalesReturnInvoiceForShare(icn_id:any) {
    try {
    

        if (icn_id) {
            
            const orderDetailsResult = await orderService.getCreditNoteOrderById(icn_id)
            console.log(orderDetailsResult.rows)
            if (orderDetailsResult.rows.length > 0) {
                console.log(orderDetailsResult.rows, "ssssss")
                const groupedItems = orderDetailsResult.rows.reduce((acc, item) => {
                    const key = item.icn_id;
                    if (!acc[key]) {
                        acc[key] = {
                            orderData: {
                                icn_id: item.icn_id,
                                store_id: item.store_id,
                                cmr_phone_number: item.cmr_phone_number,
                                sot_total_gst: item.icn_total_gst,
                                sot_total_discount: item.icn_total_discount,
                                sot_payment_status: item.icn_payment_status,
                                sot_transaction_id: item.icn_transaction_id,
                                sot_draft_order: item.is_draft_order,
                                sot_payment_method: item.icn_payment_method,
                                sot_billing_address: item.icn_billing_address,
                                sot_total_amount: item.icn_total_amount,
                                sot_invoice_number: item.icn_invoice_number,
                                doctor_name: item.doctor_name,
                                cmr_first_name: item.cmr_first_name,
                                cmr_last_name: item.cmr_last_name,
                                cmr_rewards: item.cmr_rewards,
                                created_date:formatDate(item.created_date),
                                update_date: formatDate(item.created_date),
                                icn_remarks:item.icn_remarks,
                                invoice_number:item.icn_invoice_number,
                              //  sot_invoice_number:item.sot_invoice_number
                            },
                            itemData: [],
                            paymentData: [],
                        };
                    }

                    // Check if the item record already exists
                    const itemExists = acc[key].itemData.some(
                        (existingItem: any) => existingItem.item_batch_number === item.item_batch_number && existingItem.sot_id === item.sot_id
                    );

                    if (!itemExists) {
                        acc[key].itemData.push({
                            item_id: item.item_id,
                            item_code: item.item_code,
                            item_generic_name: item.item_generic_name,
                            item_name: item.item_name,
                            item_pack_size: item.item_pack_size,
                            item_batch_number: item.item_batch_number,
                            item_quantity: item.item_quantity,
                            item_exp_date: formatDate(item.item_exp_date),
                            item_mfg_date: item.item_mfg_date,
                            item_rack_location: item.item_rack_location,
                            item_open_quantity: item.item_open_quantity,
                            item_unit_price: item.item_unit_price,
                            item_schedule: item.item_schedule,
                            item_discount_amount: item.item_discount_amount,
                            item_discount_percentage: item.item_discount_percentage,
                            item_tax_amount: item.item_tax_amount,
                            item_total_tax_percentage: item.item_total_tax_percentage,
                            item_total_amount: item.item_total_amount,
                            item_price_wiithout_tax: item.item_price_wiithout_tax,
                            item_uom: item.item_uom,
                            item_gst: item.item_gst,
                            item_sgst: item.item_sgst,
                            item_cgst: item.item_cgst,
                            item_igst: item.item_igst,
                            linked_invoice_number:item.sot_invoice_number,
                            item_free_quantity:item.item_free_quantity,
                            item_manufacturer_id:item.item_manufacturer_id,
                            item_manufacturer_name:item.item_manufacturer_name,
                            item_hsn:item.item_hsn
                        });
                    }

                    const paymentRecord = {
                        payment_mode_name: item.payment_mode_name,
                        payment_amount: item.payment_amount,
                    };
                    const paymentExists = acc[key].paymentData.some(
                        (payment: any) =>
                            payment.payment_mode_name === paymentRecord.payment_mode_name &&
                            payment.payment_amount === paymentRecord.payment_amount
                    );

                    if (!paymentExists) {
                        acc[key].paymentData.push(paymentRecord);
                    }

                    return acc;
                }, {});

                // Convert grouped items to an array
                const resultArray: any = Object.values(groupedItems);
            const storeDetailsResult= await orderService.getStoreDetails();
            const html=await ReturnInvoice(resultArray,storeDetailsResult);
            return {htmlContent:html,resultArray:resultArray}
        //     if(html){
        //         return res.send(generateResponse(true, "Invoice fetched successfully", 200, html));
        //     }
        //         else{
        //             return res.send(generateResponse(false, "Invoice not found", 400, null));
        //     }

        // } else {
        //     return res.send(generateResponse(false, "Invoice not found", 400, null));
        // }
}
 }   }catch (error) {
        console.log(error)

    }
}
 