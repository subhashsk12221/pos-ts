import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as nextInvoicenumber  from '../service/documentNumberingSeries'
import * as paymentInSerivce from '../service/paymentInService'


export async function addPaymentIN(req: any, res: any) {

    try {
        const { paymentData: paymentData, invoicePaymentData: invoicePaymentData, paymentModeData:paymentModeData } = req.body
        // console.log(orderData)
        const store_id = paymentData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getPurchaseCreditNoteNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
    
        paymentData.pit_invoice_number = getNextInvoiceNumber;


        if (paymentData && invoicePaymentData && paymentModeData ) {
            const addOrder = await paymentInSerivce.addPaymentIn(paymentData,invoicePaymentData,paymentModeData)
            if (addOrder) {
               
                return res.status(200).send(
                    generateResponse(true, "payment done succesfully", 200, null))
                

            } else {
                return res.status(400).send(
                    generateResponse(false, "payment done unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}



export async function addPaymentOut(req: any, res: any) {

    try {
        const { paymentData: paymentData, invoicePaymentData: invoicePaymentData, paymentModeData:paymentModeData } = req.body
        // console.log(orderData)
        const store_id = paymentData.store_id

        // Fetch next invoice number

        const getNextInvoiceNumber = await nextInvoicenumber.getPurchaseReturnNextInvoiceNumber()
        console.log(getNextInvoiceNumber);

        if (!getNextInvoiceNumber) {
            return res.send(generateResponse(false, "Failed to generate next invoice number", 400, null));
        }
    
        paymentData.pot_invoice_number = getNextInvoiceNumber;


        if (paymentData && invoicePaymentData && paymentModeData ) {
            const addOrder = await paymentInSerivce.addPaymentOut(paymentData,invoicePaymentData,paymentModeData)
            if (addOrder) {
               
                return res.status(200).send(
                    generateResponse(true, "payment done succesfully", 200,null)
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "payment done unsuccesfully", 400, null)
                )

            }
        } else {
            return res.status(400).send(generateResponse(false, "something went wrong", 400, null));
        }
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}



export async function getGlAccount(req: any, res: any) {

    try {


       
            const getaccount = await paymentInSerivce.getGlAccount()
            if (getaccount.rows.length>0) {
               
                return res.status(200).send(
                    generateResponse(true, "gl accounts fetched succesfully", 200,getaccount.rows)
                )

            } else {
                return res.status(400).send(
                    generateResponse(false, "gl accounts fetching unsuccesfully", 400, null)
                )

            }
        
    }
    catch (err) {
        console.log(err)
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}



export async function getAllPaymentIn(req: any, res: any) {
    try {

        const getOrderList = await paymentInSerivce.getAllPaymentIn(req.query)

        if (getOrderList) {
             

            return res.status(200).send(generateResponse(true, "payment in order fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "payment order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}



export async function paymentInGetbyId(req: any, res: any) {
    try {

        const getOrderList = await paymentInSerivce.paymentInGetbyId(req.query.pit_id)

        if (getOrderList.rows.length>0) {

            const groupedItems = getOrderList.rows.reduce((acc, item) => {
                const key = item.pit_id;
                
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                           pot_id: item.pit_id,
                            cmr_id: item.cmr_id,
                            cmr_name: item.cmr_name,
                            cmr_code: item.cmr_code,
                            pit_posting_date: item.pit_posting_date,
                            pit_invoice_number: item.pit_invoice_number,
                            pit_order_status: item.pit_order_status,
                            pit_due_date: item.pit_due_date,
                            pit_doc_date: item.pit_doc_date,
                            pit_remarks: item.pit_remarks,
                            pit_total_amount: item.pit_total_amount,
                            pit_current_payment: item.pit_current_payment,
                            pit_add_to_account_amount: item.pit_add_to_account_amount,
                            pit_open_balance: item.pit_open_balance,
                            payment_journal_remarks: item.payment_journal_remarks,
                            pit_applied_amount: item.pit_applied_amount,
                            pit_cmr_amount_paid: item.pit_cmr_amount_paid,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        invoiceData: [],
                        paymentData: [],
                        invoiceIdsSet: new Set() // Set to track unique invoice IDs
                    };
                }
            
                // Push invoice data only if the invoice ID is not already in the set
                if (!acc[key].invoiceIdsSet.has(item.soit_id)) {
                    acc[key].invoiceData.push({
                        soit_id: item.soit_id,
                        soit_invoice_number: item.soit_invoice_number,
                        pit_id: item.pit_id,
                        pdt_due_days: item.pdt_due_days,
                        pdt_balance_due: item.pdt_balance_due,
                        pdt_total_amount: item.pdt_total_amount,
                        pdt_current_payment: item.pdt_current_payment,
                        pdt_doc_date: item.pdt_doc_date,
                        pdt_due_date: item.pdt_due_date,
                    });
                    acc[key].invoiceIdsSet.add(item.soit_id); // Add invoice ID to the set
                }
            
                // Push payment data as it is (assuming no duplicates issue here)
                acc[key].paymentData.push({
                    pmt_id: item.pmt_id,
                    pmt_mode_name: item.pmt_mode_name,
                    account_id: item.account_id,
                    account_code: item.account_code,
                    account_name: item.account_name,
                    pmt_total_amount: item.pmt_total_amount,
                    bank_reference_number: item.bank_reference_number,
                    date_of_transfer: item.date_of_transfer,
                    payment_id: item.payment_id,
                    card_number: item.card_number,
                    expiry_date: item.expiry_date,
                    cheque_number: item.cheque_number,
                    date_of_cheque: item.date_of_cheque,
                    upi_referernce: item.upi_referernce,
                });
            
                return acc;
            }, {});
            
            // Remove the invoiceIdsSet from the final result
            for (const key in groupedItems) {
                delete groupedItems[key].invoiceIdsSet;
            }
            
            console.log(groupedItems);
            
            
            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            
            return res.status(200).send(generateResponse(true, "payment in order fetched successfully", 200,resultArray[0]))
               
        } else {
            return res.status(400).send(generateResponse(false, "payment order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}



export async function getAllPaymentOut(req: any, res: any) {
    try {

        const getOrderList = await paymentInSerivce.getAllPaymentOut(req.query)

        if (getOrderList) {
             

            return res.status(200).send(generateResponse(true, "payment in order fetched successfully", 200, {
                totalCount: getOrderList.totalRowsCount,
                orderList: getOrderList.orderList
            }));
        } else {
            return res.status(400).send(generateResponse(false, "payment order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}



export async function paymentOutGetbyId(req: any, res: any) {
    try {

        const getOrderList = await paymentInSerivce.paymentOutGetbyId(req.query.pot_id)
        console.log(getOrderList.rows)
        if (getOrderList.rows.length>0) {
 
            const groupedItems = getOrderList.rows.reduce((acc, item) => {
                const key = item.pot_id;
                
                if (!acc[key]) {
                    acc[key] = {
                        orderData: {
                           pot_id: item.pot_id,
                            cmr_id: item.cmr_id,
                            cmr_name: item.cmr_name,
                            cmr_code: item.cmr_code,
                           pot_posting_date: item.pot_posting_date,
                           pot_invoice_number: item.pot_invoice_number,
                           pot_order_status: item.pot_order_status,
                           pot_due_date: item.pot_due_date,
                           pot_doc_date: item.pot_doc_date,
                           pot_remarks: item.pit_remarks,
                           pot_total_amount: item.pit_total_amount,
                           pot_current_payment: item.pot_current_payment,
                           pot_add_to_account_amount: item.pot_add_to_account_amount,
                           pot_open_balance: item.pot_open_balance,
                            payment_journal_remarks: item.payment_journal_remarks,
                           pot_applied_amount: item.pot_applied_amount,
                           pot_cmr_amount_paid: item.pot_cmr_amount_paid,
                            created_date: item.created_date,
                            update_date: item.update_date,
                        },
                        invoiceData: [],
                        paymentData: [],
                        invoiceIdsSet: new Set() // Set to track unique invoice IDs
                    };
                }
            
                // Push invoice data only if the invoice ID is not already in the set
                if (!acc[key].invoiceIdsSet.has(item.soit_id)) {
                    acc[key].invoiceData.push({
                        soit_id: item.soit_id,
                        soit_invoice_number: item.soit_invoice_number,
                       pot_id: item.pot_id,
                        podt_due_days: item. podt_due_days,
                         podt_balance_due: item. podt_balance_due,
                         podt_total_amount: item. podt_total_amount,
                         podt_current_payment: item. podt_current_payment,
                         podt_doc_date: item. podt_doc_date,
                         podt_due_date: item. podt_due_date,
                    });
                    acc[key].invoiceIdsSet.add(item.soit_id); // Add invoice ID to the set
                }
            
                // Push payment data as it is (assuming no duplicates issue here)
                acc[key].paymentData.push({
                    pmt_id: item.pmt_id,
                    pmt_mode_name: item.pmt_mode_name,
                    account_id: item.account_id,
                    account_code: item.account_code,
                    account_name: item.account_name,
                    pmt_total_amount: item.pmt_total_amount,
                    bank_reference_number: item.bank_reference_number,
                    date_of_transfer: item.date_of_transfer,
                    payment_id: item.payment_id,
                    card_number: item.card_number,
                    expiry_date: item.expiry_date,
                    cheque_number: item.cheque_number,
                    date_of_cheque: item.date_of_cheque,
                    upi_referernce: item.upi_referernce,
                });
            
                return acc;
            }, {});
            // Convert grouped items to an array
            const resultArray: any = Object.values(groupedItems);
            return res.status(200).send(generateResponse(true, "payment in order fetched successfully", 200,resultArray[0]))
               
        } else {
            return res.status(400).send(generateResponse(false, "payment order fetching unsucessfull", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}