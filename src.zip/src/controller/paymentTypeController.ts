import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as paymentTypeService from '../service/paymentTypeService'


export async function addPymentType(req: any, res: any) {
  try {
    const paymentData = req.body;
    paymentData.payment_type_id = ulid();
    if (paymentData) {
      const result = await paymentTypeService.addPaymentTypeService(paymentData);
      if (result) {
        return res.send(
          generateResponse(true, "Pyment Type added successfully", 200, result)
        );
      } else {
        return res.send(
          generateResponse(false, "Pyment Type adding unsuccessful", 400, null)
        );
      }
    }
  } catch (error) {
    const err = error as Error;
    return res.send(generateResponse(false, err.message, 400, null));
  }
}


export async function getPymentTypeById(req: any, res: any) {
  try {
    const paymentTypeDetails = await paymentTypeService.getPaymentTypeByIdService(
       
    );
    return res.send(
      generateResponse(true, "payment Type Details fetched successfully", 200, paymentTypeDetails)
    );
  } catch (error) {
    const err = error as Error;
    return res.send(generateResponse(false, err.message, 400, null));
  }
}



export async function editPymentType(req: any, res: any) {
  try {
    const paymentTypeData = req.body;
    if (!paymentTypeData.payment_type_id) {
      return res.send(generateResponse(false, "Pyment Type Not Found", 400, null));
    }
    const result = await paymentTypeService.editPaymentTypeService(paymentTypeData.payment_type_id,paymentTypeData);
    if (result) {
      return res.send(
        generateResponse(true, "Pyment Type Edited successfully", 200, result)
      );
    } else {
      return res.send(
        generateResponse(false, "Unable to Edit Pyment Type", 400, null)
      );
    }
  } catch (error) {
    const err = error as Error;
    return res.send(generateResponse(false, err.message, 400, null));
  }
}