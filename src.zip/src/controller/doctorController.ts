import { ulid } from "ulid";
import { generateResponse } from "../util/genRes";
import * as doctorService from "../service/doctorService";

export async function addDoctor(req: any, res: any) {
  try {
    const doctorData = req.body;
    doctorData.dr_id = ulid();
    if (doctorData) {
      const result = await doctorService.addDoctorService(doctorData);
      if (result) {
        return res.send(
          generateResponse(true, "Doctor added successfully", 200, result)
        );
      } else {
        return res.send(
          generateResponse(false, "Doctor adding unsuccessful", 400, null)
        );
      }
    }
  } catch (error) {
    console.log(error, "errr");
    return res.send(generateResponse(false, error.message, 400, null));
  }
}

export async function updateDoctor(req: any, res: any) {
  try {
    const { dr_id } = req.body;
    if (dr_id) {
      const updateDoctor = await doctorService.updateDoctorService(
        dr_id,
        req.body
      );
      if (updateDoctor.rows.length > 0) {
        return res
          .status(200)
          .send(
            generateResponse(
              true,
              "Doctor updated succesfully",
              200,
              updateDoctor.rows[0]
            )
          );
      } else {
        return res
          .status(400)
          .send(
            generateResponse(true, "doctor update unsuccesfully", 400, null)
          );
      }
    }
  } catch (error) {
    return res
      .status(400)
      .send(generateResponse(false, error.message, 400, null));
  }
}

export async function getDoctorById(req: any, res: any) {

    try {
        const { dr_id } = req.query
        if (dr_id) {
            const getDoctor = await doctorService.getDoctorByIdService(dr_id)
            if (getDoctor.rows.length > 0) {
                return res.status(200).send(
                    generateResponse(true, "Doctor fetched succesfully ", 200, getDoctor.rows[0]))
            } else {
                return res.status(400).send(
                    generateResponse(false, "Doctor not found", 400, null))
            }
        }
    }
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function deleteDoctor(req: any, res: any) {

    try {
        const { dr_id } = req.body

        if (dr_id) {
            const deleteDoctor = await doctorService.deleteDoctorService(dr_id)
            if (deleteDoctor.rows.length == 0) {
                return res.status(200).send(
                    generateResponse(true, "Doctor deleted successfully", 200, deleteDoctor.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "Doctor not found", 400, null))
            }
        }
    }
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getDoctorList(req: any, res: any) {
    try {

         if(req.query){
           const getDoctorList = await doctorService.getDoctorListService(req.query)

        if (getDoctorList.doctorList.length>0) {

            return res.send(generateResponse(true, "Doctor list with total order value fetched successfully", 200, {
                totalCount: getDoctorList.totalRowsCount,
                DoctorList: getDoctorList.doctorList
            }));
        } else {
            return res.send(generateResponse(true, "no customers found", 400, null));
        }
    }
 } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


