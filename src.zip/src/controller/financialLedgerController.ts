import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as financialLedgerService from '../service/financialLedgerService'


export async function   addChartsOfAccounts (req:any,res:any){
    try{
            const accountsData = req.body
             
            if(accountsData){
                accountsData.account_id = ulid()


                const addStoreAddress = await financialLedgerService.addChartsOfAccounts(accountsData)
                if(addStoreAddress.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "personal details added successfully", 200, addStoreAddress.rows[0])
                    );
                }else{
                    return res.status(400).send(
                        generateResponse(false, "store details adding unsuccessfull", 400,null)
                    );
                }
            
            }
    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
} 


export async function updateChartsOfAccounts(req: any, res: any) {

    try {
        const { account_id } = req.body
        
        if(account_id){
            const updateGeneralDetails = await financialLedgerService.updateChartsOfAccounts(account_id,req.body)

        if (updateGeneralDetails.rows.length>0){
            return res.status(200).send(
                generateResponse(true, "updated item general details succesfully", 200, updateGeneralDetails.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "updated item general details unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}
export async function deletChartsAccount(req: any, res: any) {
    try {
        // Start a transaction
        const { account_id } = req.body;
        console.log(account_id)

       
        const deletChartsAccount = await financialLedgerService.deletechartsAccount(account_id)


       if(deletChartsAccount.rows.length==0){
            return res.send(
                generateResponse(true, "account deleted successfully", 200, {
                    orderData: deletChartsAccount.rows[0],
                })
            );
        } else {
            return res.send(
                generateResponse(false, "account deletion unsuccessful - account not found", 404, null)
            );
        }
    } catch (err) {
        console.log(err);
        return res.send(generateResponse(false, err.message, 400, null));
    }
}

export async function getChartsOfAccounts(req: any, res: any) {
    try {

        const getCustomerGroupData = await financialLedgerService.getChartsOfAccounts()

        if (getCustomerGroupData) {

            return res.status(200).send(
                generateResponse(true, "fetched customergroup succesfully", 200, getCustomerGroupData)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "fetched customergroup unsuccesfull", 400, null)
            )
        }
    } catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updateGeneralAccountAllocation(req: any, res: any) {

    try {
        const tab = req.body.tab
        delete req.body.tab
  
       let updateaccount :any
          if(tab=== 'general_tab'){
            updateaccount  = await financialLedgerService.updateGeneralAccountAllocation(req.body)
          } else if (tab==='sale_tab'){
            updateaccount  = await financialLedgerService.updateSaleAccountAllocation(req.body)
          }else if (tab=== 'purchase_tab'){
            updateaccount  = await financialLedgerService.updatePurchaseAccountAllocation(req.body)
          }else if (tab=== 'inventory_tab'){
            updateaccount = await financialLedgerService.updateInventoryAccountAllocation(req.body)
          }

        if (updateaccount.rows.length > 0) {
            return res.status(200).send(
                generateResponse(true, "account updated succesfully", 200, updateaccount.rows[0])
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "customer update unsuccesfully", 400, null)
            )
        }
    }

    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function   addFinancialYear (req:any,res:any){
    try{
            const accountsData = req.body
             
            if(accountsData){
                accountsData.gcct_id = ulid()


                const addStoreAddress = await financialLedgerService.addFinancialYear(accountsData)
                if(addStoreAddress.rows.length>0){
                    return res.status(200).send(
                        generateResponse(true, "personal details added successfully", 200, addStoreAddress.rows[0])
                    );
                }else{
                    return res.status(400).send(
                        generateResponse(false, "store details adding unsuccessfull", 400,null)
                    );
                }
            
            }
    }catch(error){
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getGeneralAccount(req: any, res: any) {

    try {
    
         const getGeneralAccount = await financialLedgerService.getGeneralAccount(req.query)
            if (getGeneralAccount.rows.length > 0) {
                console.log('Customers found:', getGeneralAccount.rows);
                return res.status(200).send(
                    generateResponse(true, "accounts fetched succesfully ", 200, getGeneralAccount.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "accounts not found", 400, null))
            }
        }
    
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getColumnofAccountType(req: any, res: any) {

    try {
    
         const getGeneralAccount = await financialLedgerService.getColumnofAccountType()
            if (getGeneralAccount.rows.length > 0) {
                console.log('Customers found:', getGeneralAccount.rows);
                return res.status(200).send(
                    generateResponse(true, "accounts fetched succesfully ", 200, getGeneralAccount.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "accounts not found", 400, null))
            }
        }
    
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}



export async function getjournEntry(req: any, res: any) {

    try {
    
         const getGeneralAccount = await financialLedgerService.getjournEntry(req.query)
            if (getGeneralAccount.rows.length > 0) {
                console.log('Customers found:', getGeneralAccount.rows);
                const groupedItems = getGeneralAccount.rows.reduce((acc, item) => {
                    const key = item.transcation_id;
                    if (!acc[key]) {
                        acc[key] = {
                            journalEntryData: {
                                transcation_id: item.transcation_id,
                                journal_entry_no: item.journal_entry_no,
                                origin_id: item.origin_id,
                                origin_type: item.origin_type,
                                remarks: item.jrt_remarks,
                                batch_num: item.batch_num,
                                due_date: item.due_date,
                                document_date: item.document_date,
                                created_date: item.created_date,
                                update_date: item.update_date,
                            },
                            accountsData: [],
                        };
                    }
                    acc[key].accountsData.push({
                        account_id: item.account_id,
                        account_name:item.account_name,
                        account_code:item.account_code,
                        debit_amount: item.debit_amount,
                        credit_amount: item.credit_amount,
                        remarks: item.jert_remarks,
                    });
                    return acc;
                }, {});

                // Convert grouped items to an array
                const resultArray: any = Object.values(groupedItems);
                return res.status(200).send(
                    generateResponse(true, "accounts fetched succesfully ", 200, resultArray))
            } else {
                return res.status(400).send(
                    generateResponse(false, "accounts not found", 400, null))
            }
        }
    
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}




export async function getGeneralAccountsOfYears(req: any, res: any) {
    try {
        const tab = req.query.tab;
        let getGeneralAccount: any;

        if (tab === 'general_tab') {
            getGeneralAccount = await financialLedgerService.getGeneralAccountsOfYears(req.query);
        } else if (tab === 'sale_tab') {
            getGeneralAccount = await financialLedgerService.getSaletabOfYear(req.query);
        } else if (tab === 'purchase_tab') {
            getGeneralAccount = await financialLedgerService.getPurchaseTabOfYear(req.query);
        }else if (tab === 'inventory_tab') {
            getGeneralAccount = await financialLedgerService.getInventoryTabOfYear(req.query);
        }

        if (getGeneralAccount.rows.length > 0) {
            // Get the keys of the first row
            const keys = Object.keys(getGeneralAccount.rows[0]);

            // Filter out the 'gcct_id' property
            const propertyKeys = keys.filter(key => key !== 'gcct_id');

            // Map over the property keys and create an array of promises
            const promiseArray = propertyKeys.map(async key => {
                // Check if the value is not null
               console.log(typeof(getGeneralAccount.rows[0][key]))
                if (getGeneralAccount.rows[0][key] !== 'null') {
                    // Call the asynchronous function to get the account name
                    console.log(getGeneralAccount.rows[0][key],"eeeeeeeeeee")
                    const accountName = await financialLedgerService.getaccountName(getGeneralAccount.rows[0][key]);
                     console.log(accountName.rows,"dddddddddddd")
                    // Construct the response object with gcct_id, property, and accountName
                    return {
                        gcct_id: getGeneralAccount.rows[0].gcct_id,
                        [key]: getGeneralAccount.rows[0][key],
                        account_name: accountName.rows[0]?.account_name || null,
                        account_code: accountName.rows[0]?.account_code || null
                        // Assuming 'accountName' is the key to store the account name
                    };
                } else {
                    // Construct the response object with gcct_id and the current property
                    return {
                        gcct_id: getGeneralAccount.rows[0].gcct_id,
                        [key]: getGeneralAccount.rows[0][key],
                        account_name: null,
                        account_code: null
                    };
                }
            });

            // Resolve all promises and await their results
            const response = await Promise.all(promiseArray);

            console.log('Accounts found:', response);
            return res.status(200).send(generateResponse(true, "Accounts fetched successfully", 200, response));
        } else {
            return res.status(400).send(generateResponse(false, "Accounts not found", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}



export async function getYearList(req: any, res: any) {

    try {
    
         const getYearList = await financialLedgerService.getYearList()
            if (getYearList.rows.length > 0) {
                console.log('Customers found:', getYearList.rows);
                return res.status(200).send(
                    generateResponse(true, "accounts fetched succesfully ", 200, getYearList.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "accounts not found", 400, null))
            }
        }
    
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function searchJournalEntry(req: any, res: any) {

    try {
    
         const getGeneralAccount = await financialLedgerService.getJournalEntryList(req.query)
            if (getGeneralAccount) {

                return res.status(200).send(
                    generateResponse(true, "accounts fetched succesfully ", 200,  {
                        totalCount: getGeneralAccount.totalRowsCount,
                        journalentryList: getGeneralAccount.entryList
                    }))
            } else {
                return res.status(400).send(
                    generateResponse(false, "accounts not found", 400, null))
            }
        }
    
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}