import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as customerService from '../service/customerService'
import * as  permissionhelper  from '../permissionHelper/permissionHelper'
import * as financialLedgerService from '../service/financialLedgerService'
import  customerAddValidation from '../validateModels/customerValidation'
import axios from 'axios';
//import socket from '../server';
import socket from '../sync/syncScript';



export async function addStoreCustomer(req: any, res: any) {
    try {
         
        const checkperm = await permissionhelper.permissionHelper('customer','create',req.user_id)

         console.log(checkperm)   
         if(checkperm) {     
            // const { error, value } = customerAddValidation.validate(req.body);
            // if (error) {
            //     return res.status(400).json({ error: error.details[0].message });
            // }
         
        const customerData = req.body;
        const { cmr_phone_number } = customerData
        const findCustomer: any = await customerService.findCustomerByPhoneNumber(cmr_phone_number)
        if (findCustomer.rows.length === 0) {
            const getCustomerNextSequenceCode = await customerService.getCustomerNextSequenceCode()
            customerData.cmr_id = ulid();
            customerData.cmr_code = getCustomerNextSequenceCode.rows[0].cmr_number;
            customerData.cmr_active_status = true
            customerData.price_list_id = '01HS5HJYWZ5DG2CW4EHX2W7A8V'
            const addCustomerData = await customerService.addCustomerData(customerData)
            syncCustomerData(customerData, 'add');
            let   noglAccount = {
                account_id :customerData.cmr_id,
                account_code:customerData.cmr_code,
                account_name  :customerData.cmr_first_name,
                is_gl_account:false
               }
               const addChartsOfAccountsoFCustomer = financialLedgerService.addChartsOfAccounts(noglAccount) 
            if (addCustomerData.rows.length > 0) {
                return res.status(200).send(
                    generateResponse(true, "customer added successfully", 200, addCustomerData.rows[0])
                );
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer adding unsuccessful", 400, null)
                );
            }
        } else {
            return res.status(400).send(
                generateResponse(false, "customer already exists", 400, null)
            );
        }
    }else{
        return res.status(400).send(
            generateResponse(false, "user permission denied", 400, null)
        );
    }
    } catch (error) {
        console.log(error, "error");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}



// call api endpoint to sync the customer data
export async function syncCustomerData(customerData: any, type: string) {
    // create request body from customerData
    const req = {
        body: {
            "customerData": customerData,
            "type": type,
            "transaction_type":"customer"
        }
    };
    try {
        socket.emit('sync', req)
    } catch (error) {
        console.log('Error while syncing data', error);
    }
}


export async function updateStoreCustomer(req: any, res: any) {

    try {
        const { cmr_id } = req.body
        if(cmr_id){
        const updateCustomer = await customerService.updateCustomer(cmr_id, req.body)
        if (updateCustomer.rows.length > 0) {
            syncCustomerData(req.body, 'update');
            return res.status(200).send(
                generateResponse(true, "customer updated succesfully", 200, updateCustomer.rows[0])
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "customer update unsuccesfully", 400, null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getCustomerById(req: any, res: any) {

    try {
        const { cmr_id } = req.query
        if (cmr_id) {
            const getCustomer = await customerService.getCustomerById(cmr_id)
            if (getCustomer.rows.length > 0) {
                console.log('Customers found:', getCustomer.rows);
                return res.status(200).send(
                    generateResponse(true, "customer fetched succesfully ", 200, getCustomer.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer not found", 400, null))
            }
        }
    }
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function searchCustomerByPhoneNumber(req: any, res: any) {

    try {

        const { cmr_phone_number } = req.query
        if (cmr_phone_number) {
         const searchCustomerByPhoneNumber = await customerService.searchCustomerByPhoneNumber(cmr_phone_number)
            if (searchCustomerByPhoneNumber.rows.length > 0) {
                console.log('Customers found:', searchCustomerByPhoneNumber.rows);
                return res.status(200).send(
                    generateResponse(true, "customer fetched succesfully ", 200, searchCustomerByPhoneNumber.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer not found", 400, null))
            }
        }
    }
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}
export async function getStoreCustomerById(req: any, res: any) {

    try {

        const { cmr_id } = req.query
        console.log(cmr_id)

        if (cmr_id) {
            const result = await customerService.getStoreCustomerById(cmr_id)
            console.log(result)
            if (result.rows.length > 0) {
                console.log('Customers found:', result.rows);
                return res.status(200).send(
                    generateResponse(true, "customer fetched succesfully ", 200, result.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer not found", 400, null))
            }
        }
    }
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}
export async function deleteStoreCustomer(req: any, res: any) {

    try {
        const { cmr_id } = req.body

        if (cmr_id) {
            const deleteCustomer = await customerService.deleteCustomer(cmr_id)
            if (deleteCustomer.rows.length == 0) {
                console.log('Customers found:', deleteCustomer.rows);
                return res.status(200).send(
                    generateResponse(true, "customer deleted successfully", 200, deleteCustomer.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer not found", 400, null))
            }
        }
    }
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getCustomerList(req: any, res: any) {
    try {
       
         if(req.query){
           const getCustomerList = await customerService.getCustomerList(req.query)
         
        if (getCustomerList.customerList.length>0) {

            return res.send(generateResponse(true, "customer list with total order value fetched successfully", 200, {
                totalCount: getCustomerList.totalRowsCount,
                customerList: getCustomerList.customerList
            }));
        } else {
            return res.send(generateResponse(true, "no customers found", 400, null));
        }
    }
 } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, error.message, 400, null));
    }
}



export async function getCustomerByType(req: any, res: any) {

    try {
    
         const searchCustomerByPhoneNumber = await customerService.getCustomerByType(req.query)
            if (searchCustomerByPhoneNumber.rows.length > 0) {
                console.log('Customers found:', searchCustomerByPhoneNumber.rows);
                return res.status(200).send(
                    generateResponse(true, "customer fetched succesfully ", 200, searchCustomerByPhoneNumber.rows))
            } else {
                return res.status(400).send(
                    generateResponse(false, "customer not found", 400, null))
            }
        }
    
    catch (error) {
        console.log(error)
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}





