import * as dashboardService from "../service/dashboardService";
import { generateResponse } from "../util/genRes";

export async function getSalesReport(req: any, res: any) {
  try {
    const { period, from, to } = req.query;

    if (period === "custom_date" && (!from || !to)) {
      return res
        .status(400)
        .send(
          generateResponse(
            false,
            "Both 'from' and 'to' dates are required for custom date range",
            400,
            null
          )
        );
    }

    const salesReport = await dashboardService.getSalesReportService(
      period,
      from,
      to
    );

    if (salesReport) {
      return res
        .status(200)
        .send(
          generateResponse(
            true,
            "Sales Report fetched successfully",
            200,
            salesReport
          )
        );
    } else {
      return res
        .status(400)
        .send(generateResponse(false, "Sales Report not found", 400, null));
    }
  } catch (error) {
    return res
      .status(500) // Changed to 500 for server errors
      .send(generateResponse(false, error.message, 500, null));
  }
}

export async function getTopSellingProducts(req: any, res: any) {
  try {
    const { period, type, from, to } = req.query;

    if (period === "custom_date" && (!from || !to)) {
      return res
        .status(400)
        .send(
          generateResponse(
            false,
            "Both 'from' and 'to' dates are required for custom date range",
            400,
            null
          )
        );
    }

    const topSellingProducts = await dashboardService.getTopSellingProducts(
      period,
      type,
      from,
      to
    );

    if (topSellingProducts) {
      return res
        .status(200)
        .send(
          generateResponse(
            true,
            "Top-selling products fetched successfully",
            200,
            topSellingProducts
          )
        );
    } else {
      return res
        .status(400)
        .send(
          generateResponse(false, "Top-selling products not found", 400, null)
        );
    }
  } catch (error) {
    return res
      .status(500) // Changed to 500 for server errors
      .send(generateResponse(false, error.message, 500, null));
  }
}


export async function getLowStockProducts(req: any, res: any) {
  try {
    // No threshold needed, just fetch items sorted by quantity
    const lowStockProducts = await dashboardService.getLowStockProducts();
    if (lowStockProducts.length > 0) {
      return res
        .status(200)
        .send(
          generateResponse(
            true,
            "Low stock products fetched successfully",
            200,
            lowStockProducts
          )
        );
    } else {
      return res
        .status(404)
        .send(
          generateResponse(false, "No low stock products found", 404, null)
        );
    }
  } catch (error) {
    return res
      .status(500)
      .send(generateResponse(false, error.message, 500, null));
  }
}

export async function getExpiringSoonProducts(req: any, res: any) {
  try {
    const expiringSoonProducts =
      await dashboardService.getExpiringSoonProducts();
    if (expiringSoonProducts.length > 0) {
      return res
        .status(200)
        .send(
          generateResponse(
            true,
            "Expiring soon products fetched successfully",
            200,
            expiringSoonProducts
          )
        );
    } else {
      return res
        .status(404)
        .send(
          generateResponse(false, "No expiring soon products found", 404, null)
        );
    }
  } catch (error) {
    return res
      .status(500)
      .send(generateResponse(false, error.message, 500, null));
  }
}

export async function getNewCustomersReport(req: any, res: any) {
  try {
    const { period, from, to } = req.query;

    if (period === "custom_date" && (!from || !to)) {
      return res
        .status(400)
        .send(
          generateResponse(
            false,
            "Both 'from' and 'to' dates are required for custom date range",
            400,
            null
          )
        );
    }

    const newCustomersReport = await dashboardService.getNewCustomersReportService(
      period,
      from,
      to
    );

    if (newCustomersReport) {
      return res
        .status(200)
        .send(
          generateResponse(
            true,
            "New Customers Report fetched successfully",
            200,
            newCustomersReport
          )
        );
    } else {
      return res
        .status(400)
        .send(
          generateResponse(false, "New Customers Report not found", 400, null)
        );
    }
  } catch (error) {
    return res
      .status(500) // Changed to 500 for server errors
      .send(generateResponse(false, error.message, 500, null));
  }
}

