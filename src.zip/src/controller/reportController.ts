import { getQueryPlan } from "../helper/helper";
import client from "../util/database";
import { generateResponse } from "../util/genRes";
function getCurrentDate() {
    const dateObj = new Date();
    const year = dateObj.getFullYear();
    const month = String(dateObj.getMonth() + 1).padStart(2, '0'); // January is 0!
    const day = String(dateObj.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

export const generateSalesSummaryReport = async (req: any, res: any) => {
    try {
        const { filter_by } = req.body;


        let whereClause = [];
        let groupByClause = ['so.created_date'];

        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        } else if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        whereClause.push(`so.is_draft_order = FALSE`);

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';
        const groupByClauseString = `GROUP BY ${groupByClause.join(', ')}`;

        const query = `
              SELECT 
                TO_CHAR(so.created_date, 'MON YYYY') AS month,
                COUNT(DISTINCT so.sot_id) AS total_invoice,
                COALESCE(SUM(oi.item_quantity), 0) AS total_items,
                COALESCE(SUM(so.sot_total_amount), 0) AS total_amount,
                COALESCE(SUM(oi.item_tax_amount), 0) AS total_tax,
                COALESCE(SUM(so.sot_total_discount), 0) AS total_discount,
                COALESCE(SUM(so.sot_total_amount) - SUM(so.sot_total_discount), 0) AS total_net_amount,
                COALESCE(ROUND(SUM(so.sot_total_amount) - SUM(so.sot_total_discount), 2), 0) AS total_round_off_amount
            FROM 
                sales_order so
            LEFT JOIN 
                order_items_list oi ON so.sot_id = oi.sot_id
            ${whereClauseString}
            ${groupByClauseString}
            ORDER BY 
                TO_CHAR(so.created_date, 'YYYYMM');
        `;

        const plan = await getQueryPlan(query);
        console.log("query is", query);
        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows, plan })
        );

    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};

/**Sales Order Reports */

export const generateOverallSalesReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        // Helper function to wrap columns based on their data type
        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
        }

        // Add filters
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_week') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(WEEK FROM so.created_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
        }
        if (filter_by === 'today') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(DAY FROM so.created_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
        }

        if (from && to) {
            whereClause.push(`so.created_date >= '${from}' AND so.created_date < '${to}'::date + interval '1 day'`);
        } else if (from) {
            whereClause.push(`so.created_date >= '${from}'`);
        } else if (to) {
            whereClause.push(`so.created_date <= '${to}'`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        whereClause.push('so.is_draft_order = false')
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        // Build the final query
        // const query = `
        //     SELECT ${selectClause.join(', ')}
        //     FROM sales_order so
        //     ${joinClause.join(' ')}
        //     ${whereClauseString}
        //     ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        // `;

        // console.log("query is", query);

        // const result = await client.query(query);

        const query = `
       SELECT so.created_date, 
       oi.item_code, oi.item_name, oi.item_quantity, oi.item_unit_price, oi.item_total_amount, 
       oi.item_price_wiithout_tax,
       oi.item_discount_amount, oi.item_tax_amount, 
       so.sot_invoice_number, so.sot_total_amount, so.sot_total_discount, so.sot_total_gst, 
       icnil.item_total_amount AS returned_item_total_amount, icnil.item_quantity AS returned_item_quantity, 
       icnil.item_discount_amount AS return_item_discount_amount, icnil.item_tax_amount AS returned_item_tax_amount, 
       icnil.created_date AS returned_created_date, icn.icn_id, icn.icn_invoice_number
       FROM sales_order so
        LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id
      LEFT JOIN invoice_credit_note_item_list icnil ON oi.sot_id = icnil.sot_id AND oi.item_id = icnil.item_id
      LEFT JOIN invoice_credit_note AS icn ON icnil.icn_id = icn.icn_id
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY oi.item_code, so.created_date, oi.item_name, oi.item_quantity, oi.item_unit_price, 
         oi.item_total_amount, oi.item_price_wiithout_tax, oi.item_discount_amount, 
         oi.item_tax_amount, so.sot_invoice_number, so.sot_total_amount, 
         so.sot_total_discount, so.sot_total_gst, icnil.item_total_amount, 
         icnil.item_quantity, icnil.item_discount_amount, icnil.item_tax_amount, 
         icnil.created_date, icn.icn_id, icn.icn_invoice_number,${groupByClause.join(', ')}` : ''};
        `;

        // const query =  `
        //     SELECT 
        //         so.created_date, 
        //         oi.item_code, 
        //         oi.item_name, 
        //         oi.item_quantity, 
        //         oi.item_unit_price, 
        //         oi.item_total_amount, 
        //         oi.item_price_wiithout_tax, 
        //         oi.item_discount_amount, 
        //         oi.item_tax_amount, 
        //         so.sot_invoice_number, 
        //         so.sot_total_amount, 
        //         so.sot_total_discount, 
        //         so.sot_total_gst, 
        //         NULL AS returned_item_total_amount, 
        //         NULL AS returned_item_quantity, 
        //         NULL AS return_item_discount_amount, 
        //         NULL AS returned_item_tax_amount, 
        //         NULL AS returned_created_date, 
        //         NULL AS icn_id, 
        //         NULL AS icn_invoice_number
        //     FROM sales_order so
        //     LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id

        //     UNION ALL

        //     SELECT 
        //         icnil.created_date AS created_date, 
        //         icnil.item_code, 
        //         icnil.item_name, 
        //         icnil.item_quantity AS item_quantity, 

        //         icnil.item_discount_amount AS item_discount_amount, 
        //         icnil.item_tax_amount AS item_tax_amount, 

        //         icnil.item_total_amount AS returned_item_total_amount, 
        //         icnil.item_quantity AS returned_item_quantity, 
        //         icnil.item_discount_amount AS return_item_discount_amount, 
        //         icnil.item_tax_amount AS returned_item_tax_amount, 
        //         icnil.created_date AS returned_created_date, 
        //         icn.icn_id AS icn_id, 
        //         icn.icn_invoice_number AS icn_invoice_number
        //     FROM invoice_credit_note_item_list icnil
        //     LEFT JOIN invoice_credit_note icn ON icnil.icn_id = icn.icn_id
        //     ${whereClauseString}
        //     ${groupByClause.length > 0 ? `GROUP BY item_code, item_name, ${groupByClause.join(', ')}` : ''};
        // `;

        console.log("query is", query);

        const result = await client.query(query);

        //     console.log(result.rows, "resulttttt")

        // Process result to add negative value objects for returned items
        const processedResult = result.rows.flatMap((row: any) => {
            const originalItem = {
                created_date: row.created_date,
                item_code: row.item_code,
                item_name: row.item_name,
                item_quantity: row.item_quantity,
                item_unit_price: row.item_unit_price,
                item_price_without_tax: row.item_price_wiithout_tax,
                sot_invoice_number: row.sot_invoice_number,
                sot_total_amount: row.item_total_amount,
                sot_total_discount: row.item_discount_amount,
                sot_total_gst: row.item_tax_amount,

            };

            if (row.returned_item_total_amount) {
                const returnedItem = {
                    created_date: row.returned_created_date,
                    item_code: row.item_code,
                    item_name: row.item_name + ' (Returned)',
                    item_quantity: '-' + row.returned_item_quantity,
                    item_unit_price: row.item_unit_price,
                    item_price_without_tax: row.item_price_wiithout_tax,
                    sot_invoice_number: row.icn_invoice_number,
                    sot_total_amount: '-' + row.returned_item_total_amount,  // Negative value
                    sot_total_discount: row.return_item_discount_amount,
                    sot_total_gst: row.returned_item_tax_amount  // Negative GST
                };
                return [originalItem, returnedItem];
            } else {
                return [originalItem];
            }
        });
        // const uniqueInvoices = processedResult.reduce((acc, current) => {
        //     if (!acc.find(item => item.sot_invoice_number === current.sot_invoice_number)) {
        //       acc.push(current);
        //     }
        //     return acc;
        //   }, []);
        const uniqueData = processedResult.filter((item, index, array) => {
            // Check if this is the first occurrence of this sot_invoice_number
            return array.findIndex(obj => obj.sot_invoice_number === item.sot_invoice_number) === index;
        });

        uniqueData.sort((a, b) => b.created_date - a.created_date);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: uniqueData })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};

export const generateOverallSalesReportv1 = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to,save,name } = req.body;
        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
       // const groupByOptions = group_by.split(',');
       // const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
      //  let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        // Helper function to wrap columns based on their data type


        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));

        // Add columns to select clause with appropriate aggregate functions

        // Add filters
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_week') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(WEEK FROM trn.transaction_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
        }
        if (filter_by === 'today') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(DAY FROM trn.transaction_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
        }

        if (from && to) {
           // whereClauseforGroup.push(`created_date >= $1 AND created_date < ($2::date + interval '1 day')`);
            whereClause.push(`trn.transaction_date >= '${from}' AND trn.transaction_date < '${to}'::date + interval '1 day'`);
        } else if (from) {
            whereClause.push(`trn.transaction_date >= '${from}'`);
        } else if (to) {
            whereClause.push(`trn.transaction_date <= '${to}'`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value, from, to } = filter;
            const fromRange = parseInt(from)
            const toRange = parseInt(to)
            let conditionString;
            if (column && condition) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    case 'range':
                        conditionString = `${column} BETWEEN ${fromRange} AND ${toRange}`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

    //    whereClause.push('so.is_draft_order = false')
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        let  sales_report_query = `WITH all_transactions AS (
    SELECT
        soi.item_id,
        soi.item_name,
	    so.cmr_phone_number,
	    soi.item_discount_percentage,
	    soi.item_discount_amount,
	    soi.item_sgst,
	    soi.item_tax_amount,
	    soi.item_total_amount , 
	    soi.item_gst,
	    soi.item_unit_price,
        soi.item_price_wiithout_tax,
	    soi.item_uom,
	    soi.item_batch_number,
	    soi.item_cgst,
        so.created_date AS transaction_date,
        'Billing' AS transaction_type,
        soi.item_quantity AS quantity,
        soi.item_unit_price AS unit_cost,
        so.sot_invoice_number AS invoice_number,
		 '-' as linked_document
    FROM
        order_items_list soi
    JOIN
        sales_order so ON soi.sot_id = so.sot_id
	Where so.is_draft_order = false

    UNION ALL

    SELECT
        il.item_id,
        il.item_name,
	    icn.cmr_phone_number,
	    il.item_discount_percentage,
	    -il.item_discount_amount,
	    -il.item_sgst,
	    -il.item_tax_amount,
	    -il.item_total_amount, 
         il.item_gst,
         -il.item_unit_price,
        il.item_price_wiithout_tax ,
	    il.item_uom,
	    il.item_batch_number,
	    -il.item_cgst,
        icn.created_date AS transaction_date,
        'invoice_credit_note' AS transaction_type,
        -il.item_quantity AS quantity,
        il.item_unit_price AS unit_cost,
        icn.icn_invoice_number AS invoice_number,
		 so.sot_invoice_number as linked_document
	     
    FROM
        invoice_credit_note_item_list il
    JOIN
        invoice_credit_note icn ON icn.icn_id = il.icn_id
   LEFT JOIN sales_order as so ON so.sot_id = il.sot_id 
	
)`
if(group_by){
    if(group_by==='item_category'){
    sales_report_query += `SELECT
    ig.name as item_category,
    SUM(trn.quantity) as "Total Quantity",
    SUM(trn.item_total_amount) as "Total Sales"
FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_category as ig on ig.id = it.item_category
${whereClauseString}
GROUP BY it.item_category, ig.id
 ;
`
}
     
if(group_by==='item_group'){
    sales_report_query += `SELECT
    ig.name as item_group,
    SUM(trn.quantity) as "Total Quantity",
    SUM(trn.item_total_amount) as "Total Sales"

FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}
GROUP BY it.item_group	, ig.name
 ;
`
}

   if(group_by==='transaction_date'){
    sales_report_query += `SELECT
   trn.transaction_date,
    SUM(trn.quantity) as "Total Quantity",
    SUM(trn.item_total_amount) as "Total Sales",
 COUNT(trn.invoice_number) AS "Total Transactions"
FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}
GROUP BY    trn.transaction_date
 ;
`
   }

   if(group_by==='transaction_type'){
    sales_report_query += `SELECT
   trn.transaction_type,
    SUM(trn.quantity) as "Total Quantity",
    SUM(trn.item_total_amount) as "Total Sales"
FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}
GROUP BY    trn.transaction_type
 ;
`
   }

   if(group_by==='cmr_first_name'){
    sales_report_query += `SELECT
    cd.cmr_first_name,
    SUM(trn.quantity) as "Total Quantity",
    SUM(trn.item_total_amount) as "Total Sales",
    COUNT(trn.invoice_number) AS "Total Transactions"
FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}
GROUP BY cd.cmr_first_name
 ;
`
   }

   if(group_by==='item_name'){
    sales_report_query += `SELECT
    it.item_name,
    SUM(trn.quantity) as "Total Quantity",
    SUM(trn.item_total_amount) as "Total Sales",
    COUNT(trn.invoice_number) AS "Total Transactions"
FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}
GROUP BY  it.item_name
 ;
`
   }

   if(group_by==='item_hsn'){
    sales_report_query += `SELECT
     it.item_hsn,
    SUM(trn.item_total_amount) as "Total Sales",
    SUM(trn.item_tax_amount) as "Total Tax"
FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}
GROUP BY  it.item_hsn
 ;
`
   }
   

    }else{ 
        sales_report_query += `SELECT
    trn.transaction_date,
    trn.invoice_number,
    trn.linked_document as "linked invoice number",
    cd.cmr_code,
    cd.cmr_first_name,
	it.item_code,
    it.item_name,
    ig.name as item_group,
    it.item_category,
    it.item_hsn,
	trn.item_batch_number,
    ity.name as item_type,
    trn.quantity,
    trn.item_uom,
    trn.item_unit_price as MRP,
    trn.item_price_wiithout_tax as unit_price,
    trn.item_discount_percentage,
    trn.item_discount_amount,
    trn.item_gst,
    trn.item_tax_amount,
    ROUND((trn.item_total_amount/trn.quantity), 2) AS "Final Price",
    trn.item_total_amount,
    trn.transaction_type

FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}	
ORDER BY
    trn.transaction_date DESC ;
`
}


        console.log("query is", sales_report_query);
        if(save=="true"){
            if (!name || typeof name !== 'string' || name.trim() === "" || name.length > 255) {
                return res.status(400).send(generateResponse(false, "Enter valid name", 400, ""));
            }
            else if(filters.length ==0 && group_by && from && to && filter_by){
                return res.status(400).send(generateResponse(false, "Select a valid filter", 400, null));
            }
            else{
                const savedQuery = 'INSERT INTO Favorite (name, query, selectedColumns) VALUES ($1, $2,$3)';
                const values = [name, sales_report_query,selectedColumns];
                try {
                    await client.query(savedQuery, values);
                } catch (err) {
                    console.log(err);
                    return res.status(400).send(generateResponse(false, err.message, 400, null));
                }
            }
        }
        const result = await client.query(sales_report_query);
        if(save=="true"){
            return res.status(200).send(generateResponse(true, "Added to Favorite", 200, { result: result.rows }));
        }
        else{
        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    }
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};

export const branchWiseSalesReport = async (req: any, res: any) => {
    try {

        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        // Helper function to wrap columns based on their data type
        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`);
        }

        // Add filters
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';


        const query = `
        SELECT ${selectClause.join(', ')}
        FROM sales_order so
        ${joinClause.join(' ')}
        ${whereClauseString}
        ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
    `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );

    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const productWiseSalesReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];


        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`);
        }



        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order so
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const doctorWiseSalesReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];


        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`);
        }



        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order so
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const paymentModeWiseSalesReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to,save,name } = req.body;
        let selectClause: any = [];
        let joinClause = [];
        let whereClause: any = [];
        let whereClauseforGroup = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        const params = [];
        
        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => {
            if (col === null) {
                console.log("Null value found in sales order columns");
                return false; // Skip null values
            }
            return col.startsWith('so.');
        });
        
        const customerCols = selectedColumns.filter((col: any) => {
            if (col === null) {
                console.log("Null value found in customer columns");
                return false; // Skip null values
            }
            return col.startsWith('c.');
        });
        
        const storeCols = selectedColumns.filter((col: any) => {
            if (col === null) {
                console.log("Null value found in store columns");
                return false; // Skip null values
            }
            return col.startsWith('si.');
        });
        
        const paymentCols = selectedColumns.filter((col: any) => {
            if (col === null) {
                console.log("Null value found in payment columns");
                return false; // Skip null values
            }
            return col.startsWith('bn.');
        });

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (paymentCols.length > 0) {
            if (group_by) {
                paymentCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...paymentCols);
            }
            joinClause.push(`LEFT JOIN billing_invoice_payment_modes bn ON bn.sot_id = so.sot_id`)

        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`);
        }


        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (filter_by === 'this_month') {
            whereClauseforGroup.push(`EXTRACT(YEAR FROM bn.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClauseforGroup.push(`EXTRACT(MONTH FROM bn.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClauseforGroup.push(`EXTRACT(YEAR FROM bn.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_week') {
            whereClauseforGroup.push(`EXTRACT(YEAR FROM bn.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClauseforGroup.push(`EXTRACT(WEEK FROM bn.created_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
        }
        if (filter_by === 'today') {
            whereClauseforGroup.push(`EXTRACT(YEAR FROM bn.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClauseforGroup.push(`EXTRACT(MONTH FROM bn.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClauseforGroup.push(`EXTRACT(DAY FROM bn.created_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
        }
          // Check if from and to dates are provided, and append the WHERE clause if they are
          if (from && to) {
            whereClauseforGroup.push(`bn.created_date >= $1 AND bn.created_date < ($2::date + interval '1 day')`);
            console.log(from,to)
            params.push(from, to);
        }
        
        filters.forEach((filter: any) => {
            const { column, condition, value, from, to } = filter;
            const fromRange = parseInt(from)
            const toRange = parseInt(to)
            let conditionString;
            if (column && condition) {
                console.log()
                switch (condition) {

                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    case 'range':
                        conditionString = `${column} BETWEEN ${fromRange} AND ${toRange}`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                console.log(conditionString)
                whereClause.push(conditionString);
                whereClauseforGroup.push(conditionString)
            }
        });

        if (group_by) {
            console.log(group_by,)
           


            //             const groupbyquery = `WITH PaymentSummary AS (
            //     SELECT 
            //         payment_mode_name AS "Payment Mode",
            //         COUNT(*) AS "Number of Transactions",
            //         SUM(payment_amount) AS "Total Sales (Amount)"
            //     FROM billing_invoice_payment_modes
            //     WHERE created_date BETWEEN '${from}' AND '${to}'  -- Use user-defined start and end dates
            //     GROUP BY payment_mode_name
            // ),
            // TotalSummary AS (
            //     SELECT 
            //         SUM("Number of Transactions") AS total_transactions,
            //         SUM("Total Sales (Amount)") AS total_sales
            //     FROM PaymentSummary
            // )
            // SELECT 
            //     ps."Payment Mode",
            //     ps."Number of Transactions",
            //     CONCAT('₹', ps."Total Sales (Amount)") AS "Total Sales (Amount)",
            //     ROUND((ps."Total Sales (Amount)" * 100.0 / ts.total_sales), 2) || '%' AS "% of Total Sales"
            // FROM 
            //     PaymentSummary ps,
            //     TotalSummary ts

            // UNION ALL

            // SELECT 
            //     'Total' AS "Payment Mode",
            //     ts.total_transactions AS "Number of Transactions",
            //     CONCAT('₹', ts.total_sales) AS "Total Sales (Amount)",
            //     '100%' AS "% of Total Sales"
            // FROM 
            //     TotalSummary ts

            // ` 
            // Base query without WHERE clause
            let groupbyquery = `
  WITH PaymentSummary AS (
    SELECT 
      payment_mode_name AS "Payment Mode",
      COUNT(*) AS "Number of Transactions",
      SUM(payment_amount) AS "Total Sales (Amount)"
    FROM billing_invoice_payment_modes as bn
`;

            // Check if from and to dates are provided, and append the WHERE clause if they are
            // if (from && to) {
            //     whereClauseforGroup.push(`created_date >= $1 AND created_date < ($2::date + interval '1 day')`);
            //     params.push(from, to);
            // }




            const whereClauseStringforGRoup = whereClauseforGroup.length > 0 ? `WHERE ${whereClauseforGroup.join(' AND ')}` : '';

            groupbyquery += whereClauseStringforGRoup
            groupbyquery += `
    GROUP BY bn.payment_mode_name
  ),
  TotalSummary AS (
    SELECT 
      SUM("Number of Transactions") AS total_transactions,
      SUM("Total Sales (Amount)") AS total_sales
    FROM PaymentSummary
  )
  SELECT 
    ps."Payment Mode",
    ps."Number of Transactions",
      ps."Total Sales (Amount)" AS "Total Sales (Amount)",
    ROUND((ps."Total Sales (Amount)" * 100.0 / ts.total_sales), 2) || '%' AS "% of Total Sales"
  FROM 
    PaymentSummary ps,
    TotalSummary ts

  UNION ALL

  SELECT 
    'Total' AS "Payment Mode",
    ts.total_transactions AS "Number of Transactions",
    ts.total_sales AS "Total Sales (Amount)",
    '100%' AS "% of Total Sales"
  FROM 
    TotalSummary ts
`;

            // Set up the parameters array based on whether from and to dates are provided
           

            // Execute the query with the database client


            console.log(groupbyquery, "dfffffgroupbyquery")
            if(save=="true"){
                if (!name || typeof name !== 'string' || name.trim() === "" || name.length > 255) {
                    return res.status(400).send(generateResponse(false, "Enter valid name", 400, ""));
                }
                else if(filters.length ==0 && group_by && from && to && filter_by){
                    return res.status(400).send(generateResponse(false, "Select a valid filter", 400, null));
                }
                else{
                    const savedQuery = 'INSERT INTO Favorite (name, query) VALUES ($1, $2)';
                    const values = [name, groupbyquery];
                    try {
                        await client.query(savedQuery, values);
                    } catch (err) {
                        console.log(err);
                        return res.status(400).send(generateResponse(false, err.message, 400, null));
                    }
                }
            }
            const result = await client.query(groupbyquery, params);
            if(save=="true"){
                return res.status(200).send(generateResponse(true, "Added to Favorite", 200, { result: result.rows }));
            }
            else{
            return res.status(200).send(
                generateResponse(true, "Fetched successfully", 200, { result: result.rows })
            );
            }
        } else {

            // if (filter_by === 'this_month') {

            //     whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            //     whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            // }
            // if (filter_by === 'this_year') {
            //     whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            // }
            // if (filter_by === 'this_week') {
            //     whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            //     whereClause.push(`EXTRACT(WEEK FROM so.created_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
            // }
            // if (filter_by === 'today') {
            //     whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            //     whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            //     whereClause.push(`EXTRACT(DAY FROM so.created_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
            // }


            // if (from && to) {
            //     whereClauseforGroup.push(`created_date >= $1 AND created_date < ($2::date + interval '1 day')`);
            //     params.push(from, to);
            // } else if (from) {
            //     whereClause.push(`so.created_date >= '${from}'`);
            // } else if (to) {
            //     whereClause.push(`so.created_date <= '${to}'`);
            // }
            // console.log(filters, "erert")
            // // filters.forEach((filter: any) => {
            // //     const { column, condition, value, from, to } = filter;
            // //     const fromRange = parseInt(from)
            // //     const toRange = parseInt(to)
            // //     let conditionString;
            // //     if (column && condition) {
            // //         console.log()
            // //         switch (condition) {

            // //             case 'greater_than':
            // //                 conditionString = `${column} > ${value}`;
            // //                 break;
            // //             case 'less_than':
            // //                 conditionString = `${column} < ${value}`;
            // //                 break;
            // //             case 'equal_to':
            // //                 conditionString = `${column} = '${value}'`;
            // //                 break;
            // //             case 'not_equal_to':
            // //                 conditionString = `${column} != '${value}'`;
            // //                 break;
            // //             case 'range':
            // //                 conditionString = `${column} BETWEEN ${fromRange} AND ${toRange}`;
            // //                 break;
            // //             default:
            // //                 throw new Error(`Unsupported condition: ${condition}`);
            // //         }
            // //         console.log(conditionString)
            // //         whereClause.push(conditionString);
            // //     }
            // // });

            // whereClause.push('so.is_draft_order = false')
            // const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';
            whereClauseforGroup.push('so.is_draft_order = false')
            const whereClauseStringforGRoup = whereClauseforGroup.length > 0 ? `WHERE ${whereClauseforGroup.join(' AND ')}` : '';



            const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order so
            ${joinClause.join(' ')}
            ${whereClauseStringforGRoup}
            ORDER BY bn.created_date DESC
        `;

            console.log("query is", query);
            if(save=="true"){
                if (!name || typeof name !== 'string' || name.trim() === "" || name.length > 255) {
                    return res.status(400).send(generateResponse(false, "Enter valid name", 400, ""));
                }
                else if(filters.length ==0 && group_by && from && to && filter_by){
                    return res.status(400).send(generateResponse(false, "Select a valid filter", 400, null));
                }
                else{
                    const savedQuery = 'INSERT INTO Favorite (name, query) VALUES ($1, $2)';
                    const values = [name, query];
                    try {
                        await client.query(savedQuery, values);
                    } catch (err) {
                        console.log(err);
                        return res.status(400).send(generateResponse(false, err.message, 400, null));
                    }
                }
            }

            const result = await client.query(query,params);
            if(save=="true"){
                return res.status(200).send(generateResponse(true, "Added to Favorite", 200, { result: result.rows }));
            }
            else{
            return res.status(200).send(
                generateResponse(true, "Fetched successfully", 200, { result: result.rows })
            );
        }
        }
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const partyWiseSalesReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];


        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`);
        }



        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order so
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

/**Financial & Revenue */
export const discountAnalysisReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`);
        }



        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order so
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


/**Sales Return  */
export const salesReturnReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];


        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        const wrapStodGroupColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            let originalCol = col;
            if (col === "sodt.so_item_quantity") {
                col = "sodt.item_quantity"
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount') || col === "sodt.item_quantity") {
                return `SUM(${col}) AS "${originalCol.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${originalCol.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${originalCol.split('.')[1]}"`;
        };

        const wrapStodColumn = (col: string) => {
            if (col === "sodt.so_item_quantity") {
                return `sodt.item_quantity AS ${col.split('.')[1]}`
            } else {
                return col
            }
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('sr.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('sri.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const sodtCols = selectedColumns.filter((col: any) => col.startsWith('sodt.'));
        // const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN sales_return_items_list sri ON sr.srt_id = sri.srt_id`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON sr.store_id = si.store_id`);
        }

        if (sodtCols.length > 0) {
            if (group_by) {
                sodtCols.forEach((col: any) => {
                    selectClause.push(wrapStodGroupColumn(col));
                });
            } else {
                sodtCols.forEach((col: any) => {
                    selectClause.push(wrapStodColumn(col));
                });
            }
            joinClause.push(`LEFT JOIN sale_order_delivery_items_list sodt ON sri.item_id = sodt.item_id AND sri.sodtt_id = sodt.sodtt_id`);
        }


        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM sr.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM sr.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM sr.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_return_table sr
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const getCustomerPurchaseFreqReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause: any = [];
        let whereClause = [];
        let havingClause: any = [];

        const groupByOptions = group_by ? group_by.split(',') : [];
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        const columnMappings: any = {
            'sott.cmr_code': 'sott.cmr_code',
            'sott.cmr_name': 'sott.cmr_name',
            'sott.sott_order_date': 'sott.sott_order_date',
            'sott.lastPurchaseDate': 'MAX(sott.sott_order_date)',
            'sott.daysSinceLastPurchase': 'CURRENT_DATE - MAX(sott.sott_order_date)',
            'sott.totalInvoiceCount': 'COUNT(sott.sott_id)',
            'sott.averagePurchaseValue': 'ROUND(AVG(sott.sott_total_amount), 2)',
            'sott.cmr_phone_number': 'sott.cmr_phone_number',
            'si.firm_name': 'si.firm_name',
            'sott.totalInvoiceAmount': 'SUM(sott.sott_total_amount)'
        };

        const additionalColumns = ['sott.lastPurchaseDate', 'sott.daysSinceLastPurchase', 'sott.totalInvoiceCount', 'sott.averagePurchaseValue', 'sott.totalInvoiceAmount']

        selectedColumns.forEach((col: string) => {
            if (columnMappings[col]) {
                selectClause.push(`${columnMappings[col]} AS "${col.split('.')[1] || col.split('.')[0]}"`);
            } else {
                throw new Error(`Unsupported column: ${col}`);
            }
        });

        // Construct join clauses
        if (selectedColumns.some((col: string) => col.startsWith('soi.'))) {
            joinClause.push(`LEFT JOIN sales_order_items_list soi ON sott.sott_id = soi.sott_id`);
        }
        if (selectedColumns.some((col: string) => col.startsWith('si.'))) {
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON sott.store_id = si.store_id`);
        }

        // Handle filters
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM sott.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM sott.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM sott.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (additionalColumns.includes(column)) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${columnMappings[column]} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${columnMappings[column]} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${columnMappings[column]} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${columnMappings[column]} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                havingClause.push(conditionString);
            } else if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';
        const havingClauseString = havingClause.length > 0 ? `HAVING ${havingClause.join(' AND ')}` : '';


        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order_transaction_table sott
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''}
            ${havingClauseString};
        `;

        console.log("query is", query);


        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};

export const customerPurchaseBehaviorReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];


        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('sott.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('soi.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN sales_order_invoice_items_list soi ON sott.soit_id = soi.soit_id`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON sott.store_id = si.store_id`);
        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON sott.cmr_id = c.cmr_id`);
        }



        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM sott.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM sott.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM sott.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order_invoice_table sott
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

/**Inventory and Stock */

export const getBounceReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to,name,save } = req.body;
        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        whereClause.push("purchase_order_invoice_table.poit_order_status != 'draft'");
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
          }
          if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
          }
          if (filter_by === 'this_week') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(WEEK FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
          }
          if (filter_by === 'today') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(DAY FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
          }
          
          if (from && to) {
            whereClause.push(`purchase_order_invoice_table.poit_order_date >= '${from}' AND purchase_order_invoice_table.poit_order_date < '${to}'::date + interval '1 day'`);
          } else if (from) {
            whereClause.push(`purchase_order_invoice_table.poit_order_date >= '${from}'`);
          } else if (to) {
            whereClause.push(`purchase_order_invoice_table.poit_order_date <= '${to}'`);
          }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });
        
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';
          const query=`SELECT
	purchase_order_invoice_items_list.item_name AS generic_name,
	purchase_order_invoice_items_list.item_code as item_code,
	purchase_order_transaction_table.pot_invoice_number as PO_no,
	TO_CHAR(purchase_order_transaction_table.pot_document_date, 'YYYY-MM-DD') as PO_date,
	purchase_order_items_list.item_quantity as PO_qty,
	purchase_order_invoice_table.poit_invoice_number AS PI_no,
    TO_CHAR(purchase_order_invoice_table.poit_document_date, 'YYYY-MM-DD') AS PI_date,  
    purchase_order_invoice_items_list.item_quantity AS PI_qty,
    CASE 
        WHEN (purchase_order_items_list.item_quantity-purchase_order_invoice_items_list.item_quantity) > 0 
        THEN (purchase_order_items_list.item_quantity-purchase_order_invoice_items_list.item_quantity)
        ELSE 0 
    END AS bounce_qty,
    CASE 
        WHEN (purchase_order_items_list.item_quantity-purchase_order_invoice_items_list.item_quantity) < 0 
        THEN (purchase_order_invoice_items_list.item_quantity-purchase_order_items_list.item_quantity) 
        ELSE 0 
    END AS excess_qty
FROM
    purchase_order_invoice_items_list 
LEFT JOIN
    purchase_order_invoice_table 
    ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
left join good_order_receipt_items_list
on good_order_receipt_items_list.gort_id=purchase_order_invoice_items_list.gort_id
and purchase_order_invoice_items_list.item_id=good_order_receipt_items_list.item_id
left join purchase_order_items_list
on good_order_receipt_items_list.pot_id=purchase_order_items_list.pot_id
and purchase_order_items_list.item_id=good_order_receipt_items_list.item_id
left join purchase_order_transaction_table
on purchase_order_items_list.pot_id=purchase_order_transaction_table.pot_id
    ${whereClauseString};
`
          console.log(query);
          
        console.log("query is", query);
        if(save=="true"){
            if (!name || typeof name !== 'string' || name.trim() === "" || name.length > 255) {
                return res.status(400).send(generateResponse(false, "Enter valid name", 400, ""));
            }
            else if(filters.length ==0 && group_by && from && to && filter_by){
                return res.status(400).send(generateResponse(false, "Select a valid filter", 400, null));
            }
            else{
                const savedQuery = 'INSERT INTO Favorite (name, query, selectedColumns) VALUES ($1, $2,$3)';
                const values = [name, query,selectedColumns];
                try {
                    await client.query(savedQuery, values);
                } catch (err) {
                    console.log(err);
                    return res.status(400).send(generateResponse(false, err.message, 400, null));
                }
            }
        }
        const result = await client.query(query);
        // Map of expected columns for each case
        const columnMapping: Record<string, string[]> = {
            purchase_date: [
                "generic_name", "item_code","po_no", "po_date","po_qty",
                "pi_no", "pi_date","pi_qty","bounce_qty","excess_qty"
            ],
            product_name: [
                "product_name", "total_quantity_purchased", "total_quantity_returned", 
                "net_purchase", "total_purchase_amount", "total_return_amount"
            ],
            vendor_name: [
                "vendor_name", "total_quantity_purchased", "total_quantity_returned", 
                "net_purchase", "total_purchase_amount", "total_return_amount"
            ],
            P_N_V: [
                "purchase_date", "product_name", "vendor_name", "total_quantity_purchased", 
                "total_quantity_returned", "net_purchase", "total_purchase_amount", 
                "total_return_amount"
            ],
            P_V_N: [
                "purchase_date", "vendor_name", "product_name", "total_quantity_purchased", 
                "total_quantity_returned", "net_purchase", "total_purchase_amount", 
                "total_return_amount"
            ],
            default: [
                "generic_name", "item_code","po_no", "po_date","po_qty",
                "pi_no", "pi_date","pi_qty","bounce_qty","excess_qty"
            ]
        };
        const columns = columnMapping[group_by] || columnMapping.default;
        const processedResult = result.rows.map((row: any) => {
            const processedRow: Record<string, any> = {};
            for (const column of columns) {
                processedRow[column] = row[column] || null;
            }
            return processedRow;
        });
        if(save=="true"){
            return res.status(200).send(generateResponse(true, "Added to Favorite", 200, { result: processedResult }));
        }
        else{
        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: processedResult })
        );
        }
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};

export const getSalesInventoryReport = async (req: any, res: any) => {
    try {
        const { start_date, selectedColumns, filter_by, filters, } = req.body;

        let selectClause: any = [];
        let whereClause: any = [];
        selectClause.push(...selectedColumns);
        let closeCol = "(os.opening_stock + COALESCE(t.sales_qty, 0) - COALESCE(t.sales_return_qty, 0) + COALESCE(t.purchase_qty, 0) - COALESCE(t.purchase_return_qty, 0)) AS closing_stock"
        let condClosingCol = "(os.opening_stock + COALESCE(t.sales_qty, 0) - COALESCE(t.sales_return_qty, 0) + COALESCE(t.purchase_qty, 0) - COALESCE(t.purchase_return_qty, 0))"

        if (selectClause.includes('os.closing_stock')) {
            const index = selectClause.indexOf('os.closing_stock');
            selectClause.splice(index, 1);
            selectClause.push(closeCol)
        }
        console.log(selectClause, "selectedColumns list clause");

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            let col = column
            if (column === "os.closing_stock") {
                col = condClosingCol
            }
            if (col && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${col} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${col} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${col} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${col} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const getReport = async (startDate: any, endDate: any) => {
            try {
                const query = `
                WITH opening_stock AS (
                    SELECT 
                        item_id,
                        item_code,
                        SUM(CASE 
                                WHEN transaction_date < $1 THEN item_quantity 
                                ELSE 0 
                            END) AS opening_stock
                    FROM (
                        SELECT item_id, item_code, item_quantity, soit_order_date AS transaction_date
                        FROM sales_order_invoice_items_list
                        INNER JOIN sales_order_invoice_table ON sales_order_invoice_table.soit_id = sales_order_invoice_items_list.soit_id
    
                        UNION ALL
    
                        SELECT item_id, item_code, -item_quantity, srt_document_date AS transaction_date
                        FROM sales_return_items_list
                        INNER JOIN sales_return_table ON sales_return_table.srt_id = sales_return_items_list.srt_id
    
                        UNION ALL
    
                        SELECT item_id, item_code, item_quantity, poit_order_date AS transaction_date
                        FROM purchase_order_invoice_items_list
                        INNER JOIN purchase_order_invoice_table ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
    
                        UNION ALL
    
                        SELECT item_id, item_code, -item_quantity, prt_document_date AS transaction_date
                        FROM purchase_return_items_list
                        INNER JOIN purchase_return_table ON purchase_return_table.prt_id = purchase_return_items_list.prt_id
                    ) AS transactions
                    GROUP BY item_id, item_code
                ),
                transactions AS (
                    SELECT
                        item_id,
                        item_code,
                        item_name,
                        item_unit_price,
                        item_exp_date,
                        item_batch_number,
                        SUM(CASE WHEN transaction_type = 'sale' AND transaction_date BETWEEN $1 AND $2 THEN item_quantity ELSE 0 END) AS sales_qty,
                        SUM(CASE WHEN transaction_type = 'sale_return' AND transaction_date BETWEEN $1 AND $2 THEN item_quantity ELSE 0 END) AS sales_return_qty,
                        SUM(CASE WHEN transaction_type = 'purchase' AND transaction_date BETWEEN $1 AND $2 THEN item_quantity ELSE 0 END) AS purchase_qty,
                        SUM(CASE WHEN transaction_type = 'purchase_return' AND transaction_date BETWEEN $1 AND $2 THEN item_quantity ELSE 0 END) AS purchase_return_qty,
                        MAX(CASE WHEN transaction_type = 'sale' THEN transaction_date END) AS last_sale_date,
                        MAX(CASE WHEN transaction_type = 'purchase' THEN transaction_date END) AS last_purchase_date,
                        SUM(CASE WHEN transaction_type = 'sale' THEN item_total_amount END) AS gross_amount
                    FROM (
                        SELECT item_id, item_code, 'sale' AS transaction_type, item_quantity, soit_order_date AS transaction_date, item_total_amount, item_exp_date, item_batch_number, item_name, item_unit_price
                        FROM sales_order_invoice_items_list
                        INNER JOIN sales_order_invoice_table ON sales_order_invoice_table.soit_id = sales_order_invoice_items_list.soit_id
    
                        UNION ALL
    
                        SELECT item_id, item_code, 'sale_return' AS transaction_type, item_quantity, srt_document_date AS transaction_date, item_total_amount, item_exp_date, item_batch_number, item_name, item_unit_price
                        FROM sales_return_items_list
                        INNER JOIN sales_return_table ON sales_return_table.srt_id = sales_return_items_list.srt_id
    
                        UNION ALL
    
                        SELECT item_id, item_code, 'purchase' AS transaction_type, item_quantity, poit_order_date AS transaction_date, item_total_amount, item_exp_date, item_batch_number, item_name, item_unit_price
                        FROM purchase_order_invoice_items_list
                        INNER JOIN purchase_order_invoice_table ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
    
                        UNION ALL
    
                        SELECT item_id, item_code, 'purchase_return' AS transaction_type, item_quantity, prt_document_date AS transaction_date, item_total_amount, item_exp_date, item_batch_number, item_name, item_unit_price
                        FROM purchase_return_items_list
                        INNER JOIN purchase_return_table ON purchase_return_table.prt_id = purchase_return_items_list.prt_id
                    ) AS all_transactions
                    GROUP BY item_id, item_code, item_exp_date, item_batch_number, item_name, item_unit_price
                )
                SELECT
                    ${selectClause.join(', ')}
                FROM
                    opening_stock os
                LEFT JOIN
                    transactions t ON os.item_id = t.item_id
                ${whereClauseString}
                ;
                    
            `;

                console.log(query);
                const result = await client.query(query, [startDate, endDate]);
                return result.rows;

            } catch (err) {
                console.error(err);
            }
        };

        const currentDate = getCurrentDate();
        const startDate = start_date || '2024-01-01';

        const report = await getReport(startDate, currentDate);
        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: report })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};

export const inventoryReport = async (req: any, res: any) => {
    try {

        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        let havingClause: any = [];

        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];


        // Helper function to wrap columns based on their data type
        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const storeInvCols = selectedColumns.filter((col: any) => col.startsWith('sit.'));
        const itemBatchCols = selectedColumns.filter((col: any) => col.startsWith('ibnt.'));
        const storeInvLocCols = selectedColumns.filter((col: any) => col.startsWith('siilt.'));
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('soi.'));


        // Add columns to select clause with appropriate aggregate functions
        if (storeInvCols.length > 0) {
            if (group_by) {
                storeInvCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeInvCols);
            }

        }

        if (itemBatchCols.length > 0) {
            if (group_by) {
                itemBatchCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...itemBatchCols);
            }
            joinClause.push(`LEFT JOIN items_batch_no_table ibnt ON sit.item_id = ibnt.item_id`);
        }

        if (storeInvLocCols.length > 0) {
            if (group_by) {
                storeInvLocCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeInvLocCols);
            }
            joinClause.push(`LEFT JOIN store_inventory_item_location_table siilt ON sit.item_id = siilt.item_id`);
        }

        if (salesOrderCols.length > 0) {
            if (selectedColumns.includes('soi.last_sale_date')) {
                selectClause.push(`MAX(soi.created_date) AS "last_sale_date"`);
            }
            if (selectedColumns.includes('soi.sales_qty')) {
                selectClause.push(`SUM(soi.item_quantity) AS "sales_qty"`);
            }
            joinClause.push(`LEFT JOIN sales_order_invoice_items_list soi ON sit.item_id = soi.item_id`);
        }



        // Add filters
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM sit.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM sit.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM sit.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        const additionalColumns = ["soi.sales_qty", "soi.last_sale_date"]

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            let col = column;
            if (column === "soi.sales_qty") {
                col = 'SUM(soi.item_quantity)'
            }
            if (column === "soi.last_sale_date") {
                col = 'MAX(soi.created_date)'
            }

            if (additionalColumns.includes(column)) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${col} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${col} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${col} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${col} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                havingClause.push(conditionString);
            } else {
                if (col && condition && value) {
                    switch (condition) {
                        case 'greater_than':
                            conditionString = `${col} > ${value}`;
                            break;
                        case 'less_than':
                            conditionString = `${col} < ${value}`;
                            break;
                        case 'equal_to':
                            conditionString = `${col} = '${value}'`;
                            break;
                        case 'not_equal_to':
                            conditionString = `${col} != '${value}'`;
                            break;
                        default:
                            throw new Error(`Unsupported condition: ${condition}`);
                    }
                    whereClause.push(conditionString);
                }
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';
        const havingClauseString = havingClause.length > 0 ? `HAVING ${havingClause.join(' AND ')}` : '';

        const query = `
        SELECT ${selectClause.join(', ')}
        FROM store_inventory_table sit
        ${joinClause.join(' ')}
        ${whereClauseString}
        ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''}
        ${havingClauseString};
    `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );

    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const scheduledHDrugReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('sott.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('soil.'));

        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN sales_order_items_list soil ON sott.sott_id = soil.sott_id`);
        }


        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM sott.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM sott.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM sott.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }


        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        whereClause.push(`soil.item_schedule = 'H'`)
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order_transaction_table sott
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const expiryLossReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            console.log(col, "batch.item_sellable_quantity");

            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        const invCols = selectedColumns.filter((col: any) => col.startsWith('inv.'));
        const batchCols = selectedColumns.filter((col: any) => col.startsWith('batch.'));
        if (selectedColumns.includes('prod.estimated_loss')) {
            selectClause.push('(batch.item_sellable_quantity * inv.item_unit_price) AS "estimated_loss"')
        }

        if (invCols.length > 0) {
            if (group_by) {
                invCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...invCols);
            }

        }
        if (batchCols.length > 0) {
            if (group_by) {
                batchCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...batchCols);
            }
            joinClause.push(`LEFT JOIN items_batch_no_table batch ON inv.item_id = batch.item_id`);
        }


        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM inv.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM inv.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM inv.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }


        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        whereClause.push(`batch.item_exp_date < CURRENT_DATE`)
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM store_inventory_table inv
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const getFastAndSlowMovingProductsReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));

        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }
        }

        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN sales_order_invoice_items_list oi ON so.soit_id = oi.soit_id`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_id = c.cmr_id`);
        }

        if (selectedColumns.includes('add.last_sale_date')) {
            selectClause.push('MAX(so.created_date) AS last_sale_date')
        }

        if (selectedColumns.includes('add.last_purchase_date') || selectedColumns.includes('add.purchase_qty')) {
            joinClause.push(`LEFT JOIN purchase_order_invoice_items_list pi ON oi.item_id = pi.item_id`);
            if (selectedColumns.includes('add.last_purchase_date')) {
                selectClause.push('MAX(pi.created_date) AS last_purchase_date')
            }
            if (selectedColumns.includes('add.purchase_qty')) {
                selectClause.push('SUM(pi.item_quantity) AS purchase_qty')
            }
        }

        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order_invoice_table so
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''}
            ORDER BY 
            "item_quantity" DESC;
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}

export const dailySalesReport = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];


        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('c.'));
        const storeCols = selectedColumns.filter((col: any) => col.startsWith('si.'));
        const invCreditCols = selectedColumns.filter((col: any) => col.startsWith('inv.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }

        if (customerCols.length > 0) {
            if (group_by) {
                customerCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...customerCols);
            }
            joinClause.push(`LEFT JOIN customer_details c ON so.cmr_phone_number = c.cmr_phone_number`);
        }

        if (storeCols.length > 0) {
            if (group_by) {
                storeCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...storeCols);
            }
            joinClause.push(`LEFT JOIN store_info_firm_details_table si ON so.store_id = si.store_id`);
        }

        if (invCreditCols.length > 0) {
            if (group_by) {
                invCreditCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...invCreditCols);
            }
            joinClause.push(`LEFT JOIN invoice_credit_note_item_list invi ON so.sot_id = invi.sot_id`);
            joinClause.push(`LEFT JOIN invoice_credit_note inv ON invi.icn_id = inv.icn_id`);
        }

        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }
        if (filter_by === 'today') {
            whereClause.push(`DATE(so.created_date) = CURRENT_DATE`);
        }
        if (filter_by === 'this_week') {
            whereClause.push(`DATE_TRUNC('week', so.created_date) = DATE_TRUNC('week', CURRENT_DATE)`);
        }
        if (!filter_by) {
            whereClause.push(`DATE(so.created_date) = CURRENT_DATE`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        whereClause.push(`so.is_draft_order = false`);

        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        const query = `
            SELECT ${selectClause.join(', ')}
            FROM sales_order so
            ${joinClause.join(' ')}
            ${whereClauseString}
            ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        `;

        console.log("query is", query);

        const result = await client.query(query);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: result.rows })
        );

    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}



// export const getGstr1 = async (req: any, res: any) => {
//     try {
//         const { selectedColumns, filter_by, filters, group_by, from, to } = req.body;

//         let selectClause: any = [];
//         let joinClause = [];
//         let whereClause = [];
//         const groupByOptions = group_by.split(',');
//         const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
//         let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

//         // Helper function to wrap columns based on their data type
//         const wrapColumn = (col: string) => {
//             if (groupByClause.includes(col)) {
//                 return col; // Group by column
//             }
//             if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
//                 return `SUM(${col}) AS "${col.split('.')[1]}"`;
//             }

//             if (col.includes('price') || col.includes('rate')) {
//                 return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
//             }
//             return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
//         };

//         // Separate columns based on their table prefixes
//         const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
//         const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
//         const customerCols = selectedColumns.filter((col: any) => col.startsWith('cd.'));

//         // Add columns to select clause with appropriate aggregate functions
//         if (salesOrderCols.length > 0) {
//             if (group_by) {
//                 salesOrderCols.forEach((col: any) => {
//                     selectClause.push(wrapColumn(col));
//                 });
//             } else {
//                 selectClause.push(...salesOrderCols);
//             }

//         }
//         if (orderItemsCols.length > 0) {
//             if (group_by) {
//                 orderItemsCols.forEach((col: any) => {
//                     selectClause.push(wrapColumn(col));
//                 });
//             } else {
//                 selectClause.push(...orderItemsCols);
//             }
//             joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
//         }

//         // Add filters
//         if (filter_by === 'this_month') {
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
//         }
//         if (filter_by === 'this_year') {
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//         }
//         if (filter_by === 'this_week') {
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(WEEK FROM so.created_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
//         }
//         if (filter_by === 'today') {
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(DAY FROM so.created_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
//         }
//         if (filter_by === 'first_quarter') {
//             // 1st Quarter: April to June
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 4 AND 6`);
//         }
//         if (filter_by === 'second_quarter') {
//             // 2nd Quarter: July to September
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 7 AND 9`);
//         }
//         if (filter_by === 'third_quarter') {
//             // 3rd Quarter: October to December
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 10 AND 12`);
//         }
//         if (filter_by === 'fourth_quarter') {
//             // 4th Quarter: January to March
//             whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
//             whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 1 AND 3`);
//         }

//         if (from && to) {
//             whereClause.push(`so.created_date >= '${from}' AND so.created_date < '${to}'::date + interval '1 day'`);
//         } else if (from) {
//             whereClause.push(`so.created_date >= '${from}'`);
//         } else if (to) {
//             whereClause.push(`so.created_date <= '${to}'`);
//         }

//         filters.forEach((filter: any) => {
//             const { column, condition, value } = filter;
//             let conditionString;
//             if (column && condition && value) {
//                 switch (condition) {
//                     case 'greater_than':
//                         conditionString = `${column} > ${value}`;
//                         break;
//                     case 'less_than':
//                         conditionString = `${column} < ${value}`;
//                         break;
//                     case 'equal_to':
//                         conditionString = `${column} = '${value}'`;
//                         break;
//                     case 'not_equal_to':
//                         conditionString = `${column} != '${value}'`;
//                         break;
//                     default:
//                         throw new Error(`Unsupported condition: ${condition}`);
//                 }
//                 whereClause.push(conditionString);
//             }
//         });

//         whereClause.push('so.is_draft_order = false')
//         const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

//    //     Build the final query
//         // const query = `
//         //     SELECT ${selectClause.join(', ')}
//         //     FROM sales_order so
//         //     ${joinClause.join(' ')}
//         //     ${whereClauseString}
//         //     ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
//         // `;

//         // console.log("query is", query);

//         // const result = await client.query(query);

//     //     const query = `
//     //    SELECT so.created_date, 
//     //    oi.item_code, oi.item_name, oi.item_quantity, oi.item_unit_price, oi.item_total_amount, 
//     //    oi.item_price_wiithout_tax, oi.item_sgst,oi.item_cgst,oi.item_igst, oi.item_total_tax_percentage,
//     //    oi.item_discount_amount, oi.item_tax_amount, 
//     //    so.sot_invoice_number, so.sot_total_amount, so.sot_total_discount, so.sot_total_gst, 
//     //    icnil.item_total_amount AS returned_item_total_amount, icnil.item_quantity AS returned_item_quantity, 
//     //    icnil.item_discount_amount AS return_item_discount_amount, icnil.item_tax_amount AS returned_item_tax_amount, 
//     //    icnil.item_price_wiithout_tax AS return_item_price_wiithout_tax, icnil.item_sgst AS return_item_sgst ,icnil.item_cgst AS return_item_cgst,icnil.item_igst AS return_item_igst,icnil.item_total_tax_percentage  AS return_item_total_tax_percentage,
//     //    icnil.item_gst AS return_gst, icnil.created_date AS returned_created_date, icn.icn_id, icn.icn_invoice_number, 
//     //    cd.cmr_first_name,cd.cmr_gstin,cd.cmr_state
//     //    FROM sales_order so
//     //    LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id
//     //    LEFT JOIN invoice_credit_note_item_list icnil ON oi.sot_id = icnil.sot_id AND oi.item_id = icnil.item_id
//     //    LEFT JOIN invoice_credit_note AS icn ON icnil.icn_id = icn.icn_id
//     //    LEFT JOIN customer_details  as cd on cd.cmr_phone_number = so.cmr_phone_number
//     //    ${whereClauseString}
//     //    ${groupByClause.length > 0 ? `GROUP BY oi.item_code, so.created_date, oi.item_name, oi.item_quantity, oi.item_unit_price, 
//     //      oi.item_total_amount, oi.item_price_wiithout_tax, oi.item_discount_amount, 
//     //      oi.item_tax_amount, so.sot_invoice_number, so.sot_total_amount, 
//     //      so.sot_total_discount, so.sot_total_gst, icnil.item_total_amount, 
//     //      icnil.item_quantity, icnil.item_discount_amount, icnil.item_tax_amount, 
//     //      icnil.created_date, icn.icn_id, icn.icn_invoice_number,${groupByClause.join(', ')}` : ''}
//     //      ;
//     //     `;
//     const sales_report_query = `WITH all_transactions AS (
//         SELECT
//             soi.item_id,
//             soi.item_name,
//             so.cmr_phone_number,
//             soi.item_discount_percentage,
//             soi.item_discount_amount,
//             soi.item_sgst,
//             soi.item_tax_amount,
//             soi.item_total_amount , 
//             soi.item_gst,
//             soi.item_unit_price,
//             soi.item_price_wiithout_tax,
//             soi.item_uom,
//             soi.item_batch_number,
//             soi.item_cgst,
//             so.created_date AS transaction_date,
//             'Billing' AS transaction_type,
//             soi.item_quantity AS quantity,
//             soi.item_unit_price AS unit_cost,
//             so.sot_invoice_number AS invoice_number,
//              '-' as linked_document
//         FROM
//             order_items_list soi
//         JOIN
//             sales_order so ON soi.sot_id = so.sot_id
//         Where so.is_draft_order = false
    
//         UNION ALL
    
//         SELECT
//             il.item_id,
//             il.item_name,
//             icn.cmr_phone_number,
//             il.item_discount_percentage,
//             -il.item_discount_amount,
//             -il.item_sgst,
//             -il.item_tax_amount,
//             -il.item_total_amount, 
//             il.item_price_wiithout_tax    ,
//             il.item_gst,
//             -il.item_unit_price,
//             il.item_uom,
//             il.item_batch_number,
//             -il.item_cgst,
//             icn.created_date AS transaction_date,
//             'invoice_credit_note' AS transaction_type,
//             -il.item_quantity AS quantity,
//             il.item_unit_price AS unit_cost,
//             icn.icn_invoice_number AS invoice_number,
//              so.sot_invoice_number as linked_document
             
//         FROM
//             invoice_credit_note_item_list il
//         JOIN
//             invoice_credit_note icn ON icn.icn_id = il.icn_id
//        LEFT JOIN sales_order as so ON so.sot_id = il.sot_id 
        
//     )
//     SELECT
//         trn.transaction_date,
//         trn.invoice_number,
//         trn.linked_document as "linked invoice number",
//         trn.transaction_type,
//         cd.cmr_code,
//         cd.cmr_first_name,
//         it.item_code,
//         it.item_name,
//         trn.quantity,
//         trn.item_unit_price as MRP,
//         trn.item_discount_percentage,
//         trn.item_discount_amount,
//         trn.item_gst,
//         trn.item_tax_amount,
//         trn.item_price_wiithout_tax as unit_price,
//         ROUND((trn.item_total_amount/trn.quantity), 2) AS "Final Price",
//         trn.item_total_amount,
//         trn.item_unit_price,
//         it.item_category,
//         it.item_hsn,
//         trn.item_uom,
//         trn.item_batch_number,
//         ity.name as item_type,
//         ig.name as item_group
    
//     FROM
//         all_transactions as trn
//     JOIN	items_table as it on trn.item_id = it.item_id
//     JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
//     LEFT JOIN item_type as ity on it.item_type = ity.id
//     LEFT JOIN item_group as ig on ig.id = it.item_group
//     ${whereClauseString}	
//     ORDER BY
//         trn.transaction_date DESC ;
//     `
//         console.log("query is", sales_report_query);

//         const result = await client.query(sales_report_query);

//         //     console.log(result.rows, "resulttttt")

//         // Process result to add negative value objects for returned items
//         // const processedResult = result.rows.flatMap((row: any) => {
//         //     const originalItem = {
//         //         created_date: row.created_date,
//         //         item_code: row.item_code,
//         //         item_name: row.item_name,
//         //         item_quantity: row.item_quantity,
//         //         item_unit_price: row.item_unit_price,
//         //         item_sgst: row.item_sgst,
//         //         item_cgst: row.item_cgst,
//         //         item_igst: row.item_igst,
//         //         item_discount_amount: row.item_discount_amount,
//         //         item_tax_amount: row.item_tax_amount,
//         //         item_price_without_tax: row.item_price_wiithout_tax,
//         //         sot_invoice_number: row.sot_invoice_number,
//         //         sot_total_amount: row.item_total_amount,
//         //         sot_total_discount: row.item_discount_amount,
//         //         sot_total_gst: row.item_tax_amount,
//         //         cmr_first_name: row.cmr_first_name,
//         //         cmr_gstin: row.cmr_gstin,
//         //         cmr_state: row.cmr_state,
//         //         item_total_tax_percentage: row.item_total_tax_percentage


//         //     };

//         //     if (row.returned_item_total_amount) {
//         //         const returnedItem = {
//         //             created_date: row.returned_created_date,
//         //             item_code: row.item_code,
//         //             item_name: row.item_name + '(Returned)',
//         //             item_quantity: '-' + row.returned_item_quantity,
//         //             item_unit_price: row.item_unit_price,
//         //             item_price_without_tax: row.return_item_price_wiithout_tax,
//         //             item_sgst: row.return_item_sgst,
//         //             item_cgst: row.return_item_cgst,
//         //             item_igst: row.return_item_igst,
//         //             item_discount_amount: row.return_item_discount_amount,
//         //             item_total_tax_percentage: row.return_gst,
//         //             item_tax_amount: row.return_item_tax_amount,
//         //             sot_invoice_number: row.icn_invoice_number,
//         //             sot_total_amount: '-' + row.returned_item_total_amount,  // Negative value
//         //             sot_total_discount: row.return_item_discount_amount,
//         //             sot_total_gst: row.returned_item_tax_amount,
//         //             cmr_first_name: row.cmr_first_name,
//         //             cmr_gstin: row.cmr_gstin,
//         //             cmr_state: row.cmr_state, // Negative GST
//         //         };
//         //         return [originalItem, returnedItem];
//         //     } else {
//         //         return [originalItem];
//         //     }
//         // });
//         // processedResult.sort((a, b) => b.created_date - a.created_date);



//         // return res.status(200).send(
//         //     generateResponse(true, "Fetched successfully", 200, { result: processedResult })
//         // );
//     } catch (err) {
//         console.log(err);
//         return res.status(400).send(generateResponse(false, err.message, 400, null));
//     }
// };
export const getGstr1 = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        // Helper function to wrap columns based on their data type
        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('cd.'));

        // Add columns to select clause with appropriate aggregate functions
        // if (salesOrderCols.length > 0) {
        //     if (group_by) {
        //         salesOrderCols.forEach((col: any) => {
        //             selectClause.push(wrapColumn(col));
        //         });
        //     } else {
        //         selectClause.push(...salesOrderCols);
        //     }

        // }
        // if (orderItemsCols.length > 0) {
        //     if (group_by) {
        //         orderItemsCols.forEach((col: any) => {
        //             selectClause.push(wrapColumn(col));
        //         });
        //     } else {
        //         selectClause.push(...orderItemsCols);
        //     }
        //     joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
        // }

        // Add filters
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date  ) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_week') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(WEEK FROM trn.transaction_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
        }
        if (filter_by === 'today') {
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(DAY FROM trn.transaction_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
        }
        if (filter_by === 'first_quarter') {
            // 1st Quarter: April to June
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) BETWEEN 4 AND 6`);
        }
        if (filter_by === 'second_quarter') {
            // 2nd Quarter: July to September
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) BETWEEN 7 AND 9`);
        }
        if (filter_by === 'third_quarter') {
            // 3rd Quarter: October to December
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) BETWEEN 10 AND 12`);
        }
        if (filter_by === 'fourth_quarter') {
            // 4th Quarter: January to March
            whereClause.push(`EXTRACT(YEAR FROM trn.transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM trn.transaction_date) BETWEEN 1 AND 3`);
        }

        if (from && to) {
            whereClause.push(`trn.transaction_date >= '${from}' AND trn.transaction_date < '${to}'::date + interval '1 day'`);
        } else if (from) {
            whereClause.push(`trn.transaction_date >= '${from}'`);
        } else if (to) {
            whereClause.push(`trn.transaction_date <= '${to}'`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

       // whereClause.push('so.is_draft_order = false')
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        // Build the final query

        // const query = `
        //     SELECT ${selectClause.join(', ')}
        //     FROM sales_order so
        //     ${joinClause.join(' ')}
        //     ${whereClauseString}
        //     ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        // `;

        // console.log("query is", query);

        // const result = await client.query(query);

    //     const query = `
    //    SELECT so.created_date, 
    //    oi.item_code, oi.item_name, oi.item_quantity, oi.item_unit_price, oi.item_total_amount, 
    //    oi.item_price_wiithout_tax, oi.item_sgst,oi.item_cgst,oi.item_igst, oi.item_total_tax_percentage,
    //    oi.item_discount_amount, oi.item_tax_amount, 
    //    so.sot_invoice_number, so.sot_total_amount, so.sot_total_discount, so.sot_total_gst, 
    //    icnil.item_total_amount AS returned_item_total_amount, icnil.item_quantity AS returned_item_quantity, 
    //    icnil.item_discount_amount AS return_item_discount_amount, icnil.item_tax_amount AS returned_item_tax_amount, 
    //    icnil.item_price_wiithout_tax AS return_item_price_wiithout_tax, icnil.item_sgst AS return_item_sgst ,icnil.item_cgst AS return_item_cgst,icnil.item_igst AS return_item_igst,icnil.item_total_tax_percentage  AS return_item_total_tax_percentage,
    //    icnil.item_gst AS return_gst, icnil.created_date AS returned_created_date, icn.icn_id, icn.icn_invoice_number, 
    //    cd.cmr_first_name,cd.cmr_gstin,cd.cmr_state
    //    FROM sales_order so
    //    LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id
    //    LEFT JOIN invoice_credit_note_item_list icnil ON oi.sot_id = icnil.sot_id AND oi.item_id = icnil.item_id
    //    LEFT JOIN invoice_credit_note AS icn ON icnil.icn_id = icn.icn_id
    //    LEFT JOIN customer_details  as cd on cd.cmr_phone_number = so.cmr_phone_number
    //    ${whereClauseString}
    //    ${groupByClause.length > 0 ? `GROUP BY oi.item_code, so.created_date, oi.item_name, oi.item_quantity, oi.item_unit_price, 
    //      oi.item_total_amount, oi.item_price_wiithout_tax, oi.item_discount_amount, 
    //      oi.item_tax_amount, so.sot_invoice_number, so.sot_total_amount, 
    //      so.sot_total_discount, so.sot_total_gst, icnil.item_total_amount, 
    //      icnil.item_quantity, icnil.item_discount_amount, icnil.item_tax_amount, 
    //      icnil.created_date, icn.icn_id, icn.icn_invoice_number,${groupByClause.join(', ')}` : ''}
    //      ;
    //     `;

    let  sales_report_query = `WITH all_transactions AS (
        SELECT
            soi.item_id,
            soi.item_name,
            so.cmr_phone_number,
            soi.item_discount_percentage,
            soi.item_discount_amount,
            soi.item_sgst,
            soi.item_tax_amount,
            soi.item_total_amount , 
            soi.item_gst,
            soi.item_unit_price,
            soi.item_price_wiithout_tax,
            soi.item_uom,
            soi.item_batch_number,
            soi.item_cgst,
            soi.item_igst,
            so.created_date AS transaction_date,
            'Billing' AS transaction_type,
            soi.item_quantity AS quantity,
            soi.item_unit_price AS unit_cost,
            so.sot_invoice_number AS invoice_number,
             '-' as linked_document
        FROM
            order_items_list soi
        JOIN
            sales_order so ON soi.sot_id = so.sot_id
        Where so.is_draft_order = false
    
        UNION ALL
    
        SELECT
            il.item_id,
            il.item_name,
            icn.cmr_phone_number,
            il.item_discount_percentage,
            -il.item_discount_amount,
            -il.item_sgst,
            -il.item_tax_amount,
            -il.item_total_amount, 
            il.item_gst,
            -il.item_unit_price,
            -il.item_price_wiithout_tax,
            il.item_uom,
            il.item_batch_number,
            -il.item_cgst,
             -il.item_igst,
            icn.created_date AS transaction_date,
            'invoice_credit_note' AS transaction_type,
            -il.item_quantity AS quantity,
            il.item_unit_price AS unit_cost,
            icn.icn_invoice_number AS invoice_number,
            so.sot_invoice_number as linked_document
             
        FROM
            invoice_credit_note_item_list il
        JOIN
            invoice_credit_note icn ON icn.icn_id = il.icn_id
       LEFT JOIN sales_order as so ON so.sot_id = il.sot_id 
        
    )`

    sales_report_query += `SELECT
    trn.transaction_date  AS created_date,
    trn.invoice_number as sot_invoice_number,
    trn.linked_document as "linked invoice number",
    cd.cmr_code,
    cd.cmr_first_name,
    cd.cmr_state as cmr_state,
    cd.cmr_gstin as cmr_gstin,
	it.item_code AS item_code,
    it.item_name AS item_name,
    ig.name as item_group,
    it.item_category,
    it.item_hsn as item_hsn,
    trn.item_gst as item_gst,
    trn.item_sgst as item_sgst,
    trn.item_cgst as item_cgst,
    trn.item_igst as item_igst ,
	trn.item_batch_number,
    ity.name as item_type,
    trn.quantity as item_quantity ,
    trn.item_uom,
    trn.item_unit_price as item_unit_price ,
    trn.item_price_wiithout_tax as item_price_wiithout_tax,
    trn.item_discount_percentage as item_discount_amount,
    trn.item_discount_amount as item_discount_amount,
    trn.item_gst as item_total_tax_percentage,
    trn.item_tax_amount as item_tax_amount,
    ROUND((trn.item_total_amount/trn.quantity), 2) AS "Final Price",
    trn.item_total_amount ,
    trn.transaction_type
FROM
    all_transactions as trn
JOIN	items_table as it on trn.item_id = it.item_id
JOIN customer_details as cd on cd.cmr_phone_number = trn.cmr_phone_number
LEFT JOIN item_type as ity on it.item_type = ity.id
LEFT JOIN item_group as ig on ig.id = it.item_group
${whereClauseString}	
ORDER BY
    trn.transaction_date DESC ;
`

console.log(sales_report_query,"eeeeee")
        const result = await client.query(sales_report_query);

        //     console.log(result.rows, "resulttttt")

        // Process result to add negative value objects for returned items
        const processedResult = result.rows.flatMap((row: any) => {
            console.log(row,"errrrrertertrt")
            const originalItem = {
                created_date: row.created_date,
                item_code: row.item_code,
                item_name: row.item_name,
                item_quantity: row.item_quantity,
                item_unit_price: row.item_unit_price,
                item_sgst: row.item_sgst,
                item_cgst: row.item_cgst,
                item_igst: row.item_igst,
                item_discount_amount: row.item_discount_amount,
                item_tax_amount: row.item_tax_amount,
                item_price_without_tax: row.item_price_wiithout_tax,
                sot_invoice_number: row.sot_invoice_number,
                sot_total_amount: row.item_total_amount,
                sot_total_discount: row.item_discount_amount,
                sot_total_gst: row.item_tax_amount,
                cmr_first_name: row.cmr_first_name,
                cmr_gstin: row.cmr_gstin,
                cmr_state: row.cmr_state,
                item_hsn_code:row.item_hsn,
                item_total_tax_percentage: row.item_gst
            };

                return [originalItem];
            
        });
    
        // const uniqueData = processedResult.filter((item, index, array) => {
        //     // Check if this is the first occurrence of this sot_invoice_number
        //     return array.findIndex(obj => obj.sot_invoice_number === item.sot_invoice_number) === index;
        // });

        processedResult.sort((a, b) => b.created_date - a.created_date);


        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: processedResult })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};


export const getGstr2 = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to } = req.body;

        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        // Helper function to wrap columns based on their data type
        const wrapColumn = (col: string) => {
            if (groupByClause.includes(col)) {
                return col; // Group by column
            }
            if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
                return `SUM(${col}) AS "${col.split('.')[1]}"`;
            }

            if (col.includes('price') || col.includes('rate')) {
                return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
            }
            return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        };

        // Separate columns based on their table prefixes
        const salesOrderCols = selectedColumns.filter((col: any) => col.startsWith('so.'));
        const orderItemsCols = selectedColumns.filter((col: any) => col.startsWith('oi.'));
        const customerCols = selectedColumns.filter((col: any) => col.startsWith('cd.'));

        // Add columns to select clause with appropriate aggregate functions
        if (salesOrderCols.length > 0) {
            if (group_by) {
                salesOrderCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...salesOrderCols);
            }

        }
        if (orderItemsCols.length > 0) {
            if (group_by) {
                orderItemsCols.forEach((col: any) => {
                    selectClause.push(wrapColumn(col));
                });
            } else {
                selectClause.push(...orderItemsCols);
            }
            joinClause.push(`LEFT JOIN order_items_list oi ON so.sot_id = oi.sot_id`);
        }

        // Add filters
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_week') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(WEEK FROM so.created_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
        }
        if (filter_by === 'today') {
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(DAY FROM so.created_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
        }
        if (filter_by === 'first_quarter') {
            // 1st Quarter: April to June
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 4 AND 6`);
        }
        if (filter_by === 'second_quarter') {
            // 2nd Quarter: July to September
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 7 AND 9`);
        }
        if (filter_by === 'third_quarter') {
            // 3rd Quarter: October to December
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 10 AND 12`);
        }
        if (filter_by === 'fourth_quarter') {
            // 4th Quarter: January to March
            whereClause.push(`EXTRACT(YEAR FROM so.created_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM so.created_date) BETWEEN 1 AND 3`);
        }

        if (from && to) {
            whereClause.push(`so.created_date >= '${from}' AND so.created_date < '${to}'::date + interval '1 day'`);
        } else if (from) {
            whereClause.push(`so.created_date >= '${from}'`);
        } else if (to) {
            whereClause.push(`so.created_date <= '${to}'`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });

        //  whereClause.push('so.is_draft_order = false')
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        // Build the final query
        // const query = `
        //     SELECT ${selectClause.join(', ')}
        //     FROM sales_order so
        //     ${joinClause.join(' ')}
        //     ${whereClauseString}
        //     ${groupByClause.length > 0 ? `GROUP BY ${groupByClause.join(', ')}` : ''};
        // `;

        // console.log("query is", query);

        // const result = await client.query(query);

        const query = `
       SELECT so.created_date, 
       oi.item_code, oi.item_name, oi.item_quantity, oi.item_unit_price, oi.item_total_amount, 
      ( oi.item_unit_price - (oi.item_unit_price * (oi.item_gst/100))) * oi.item_quantity  as   item_price_wiithout_tax, oi.item_sgst,oi.item_cgst,
       oi.item_discount_amount, oi.item_tax_amount,  oi.item_gst,
       so.poit_invoice_number, so.poit_total_amount, so.poit_total_discount, so.poit_total_gst, 
       icnil.item_total_amount AS returned_item_total_amount, icnil.item_quantity AS returned_item_quantity, 
       icnil.item_discount_amount AS return_item_discount_amount, icnil.item_tax_amount AS returned_item_tax_amount, 
       (icnil.item_unit_price -( icnil.item_unit_price * (icnil.item_gst/100))) * oi.item_quantity AS return_item_price_wiithout_tax, icnil.item_sgst AS return_item_sgst, icnil.item_gst AS return_item_gst ,icnil.item_cgst AS return_item_cgst,icnil.item_igst AS return_item_igst,icnil.item_total_tax_percentage  AS return_item_total_tax_percentage,
       icnil.created_date AS returned_created_date, icn.pct_id, icn.pct_invoice_number,  
       cd.cmr_first_name,cd.cmr_gstin,cd.cmr_state
       FROM purchase_order_invoice_table so
       LEFT JOIN purchase_order_invoice_items_list oi ON so.poit_id = oi.poit_id
       LEFT JOIN purchase_credit_items_list_table icnil ON oi.poit_id = icnil.poit_id AND oi.item_id = icnil.item_id
       LEFT JOIN purchase_credit_table AS icn ON icnil.pct_id = icn.pct_id
       LEFT JOIN customer_details  as cd on cd.cmr_id = so.cmr_id
       ${whereClauseString}
       ${groupByClause.length > 0 ? `GROUP BY oi.item_code, so.created_date, oi.item_name, oi.item_quantity, oi.item_unit_price, 
         oi.item_total_amount, oi.item_price_wiithout_tax, oi.item_discount_amount, 
         oi.item_tax_amount, so.pct_invoice_number, so.pct_total_amount, 
         so.pct_total_discount, so.pct_total_gst, icnil.item_total_amount, 
         icnil.item_quantity, icnil.item_discount_amount, icnil.item_tax_amount, 
         icnil.created_date, icn.pct_id, icn.pct_invoice_number,${groupByClause.join(', ')}` : ''};
        `;

        console
        console.log("query is", query);

        const result = await client.query(query);

        //     console.log(result.rows, "resulttttt")

        // Process result to add negative value objects for returned items
        const processedResult = result.rows.flatMap((row: any) => {
            const originalItem = {
                created_date: row.created_date,
                item_code: row.item_code,
                item_name: row.item_name,
                item_quantity: row.item_quantity,
                item_unit_price: row.item_unit_price,
                item_sgst: row.item_sgst,
                item_cgst: row.item_cgst,
                item_igst: row.item_igst,
                item_discount_amount: row.item_discount_amount,
                item_tax_amount: row.item_tax_amount,
                item_price_without_tax: parseFloat(row.item_price_wiithout_tax).toFixed(2),
                poit_invoice_number: row.poit_invoice_number,
                poit_total_amount: row.item_total_amount,
                poit_total_discount: row.item_discount_amount,
                poit_total_gst: row.item_tax_amount,
                cmr_first_name: row.cmr_first_name,
                cmr_gstin: row.cmr_gstin,
                cmr_state: row.cmr_state,
                item_total_tax_percentage: row.item_gst,






            };

            if (row.returned_item_total_amount) {
                const returnedItem = {
                    created_date: row.returned_created_date,
                    item_code: row.item_code,
                    item_name: row.item_name + '(Returned)',
                    item_quantity: '-' + row.returned_item_quantity,
                    item_unit_price: row.item_unit_price,
                    item_price_without_tax: parseFloat(row.return_item_price_wiithout_tax).toFixed(2),
                    item_sgst: row.return_item_sgst,
                    item_cgst: row.return_item_cgst,
                    item_igst: row.return_item_igst,
                    item_discount_amount: row.return_item_discount_amount,
                    item_total_tax_percentage: row.return_item_gst,
                    item_tax_amount: row.return_item_tax_amount,
                    poit_invoice_number: row.pct_invoice_number,
                    poit_total_amount: '-' + row.returned_item_total_amount,  // Negative value
                    poit_total_discount: row.return_item_discount_amount,
                    poit_total_gst: row.returned_item_tax_amount,
                    cmr_first_name: row.cmr_first_name,
                    cmr_gstin: row.cmr_gstin,
                    cmr_state: row.cmr_state, // Negative GST
                };
                return [originalItem, returnedItem];
            } else {
                return [originalItem];
            }
        });

        processedResult.sort((a, b) => b.created_date - a.created_date);

        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: processedResult })
        );
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};



export const stockSalesReport = async (req: any, res: any) => {
    try {
        let { selectedColumns, filter_by, filters, group_by, from, to,save,name  } = req.body;
        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        //  const groupByOptions = group_by.split(',');
        //  const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        //  let groupByClause = filteredGroupByOptions.length > 0 ? filteredGroupByOptions : [];

        // Helper function to wrap columns based on their data type
        // const wrapColumn = (col: string) => {
        //     if (groupByClause.includes(col)) {
        //         return col; // Group by column
        //     }
        //     if (col.includes('total') || col.includes('amount') || col.includes('quantity') || col.includes('gst') || col.includes('discount')) {
        //         return `SUM(${col}) AS "${col.split('.')[1]}"`;
        //     }

        //     if (col.includes('price') || col.includes('rate')) {
        //         return `SUM(CAST(${col} AS NUMERIC)) AS "${col.split('.')[1]}"`;
        //     }
        //     return `STRING_AGG(CAST(${col} AS TEXT), ', ') AS "${col.split('.')[1]}"`;
        // };


        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM transaction_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
        }
        if (filter_by === 'this_week') {
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(WEEK FROM transaction_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
        }
        if (filter_by === 'today') {
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM transaction_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(DAY FROM transaction_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
        }
        if (filter_by === 'first_quarter') {
            // 1st Quarter: April to June
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM transaction_date) BETWEEN 4 AND 6`);
        }
        if (filter_by === 'second_quarter') {
            // 2nd Quarter: July to September
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM transaction_date) BETWEEN 7 AND 9`);
        }
        if (filter_by === 'third_quarter') {
            // 3rd Quarter: October to December
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM transaction_date) BETWEEN 10 AND 12`);
        }
        if (filter_by === 'fourth_quarter') {
            // 4th Quarter: January to March
            whereClause.push(`EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM transaction_date) BETWEEN 1 AND 3`);
        }

        if (from && to) {
            whereClause.push(`transaction_date>= '${from}' AND transaction_date < '${to}'::date + interval '1 day'`);
        } else if (from) {
            whereClause.push(`transaction_date >= '${from}'`);
        } else if (to) {
            whereClause.push(`transaction_date <= '${to}'`);
        }

        filters.forEach((filter: any) => {
            const { column, condition, value, from, to } = filter;
            const fromRange = parseInt(from)
            const toRange = parseInt(to)
            let conditionString;
            if (column && condition) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    case 'range':
                        conditionString = `${column} BETWEEN ${fromRange} AND ${toRange}`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });



        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';

        let query = `
        WITH all_transactions AS (
    SELECT
        so.created_date AS transaction_date,
        'Billing' AS transaction_type,
        so.sot_invoice_number AS reference_number,
        soi.item_id,
        soi.item_name,
        0 AS quantity_in,
        soi.item_quantity AS quantity_out,
        soi.item_unit_price AS unit_cost,
        0 AS total_value_in,
        soi.item_quantity * soi.item_unit_price AS total_value_out
    FROM
        order_items_list soi
    JOIN
        sales_order so ON soi.sot_id = so.sot_id
	
    UNION ALL
    SELECT
        icn.created_date AS transaction_date,
        'Invoice Credit Note' AS transaction_type,
        icn.icn_invoice_number AS reference_number,
        il.item_id,
        il.item_name,
        il.item_quantity AS quantity_in,
        0 AS quantity_out,
        il.item_unit_price AS unit_cost,
        il.item_quantity * il.item_unit_price AS total_value_in,
        0 AS total_value_out
    FROM
        invoice_credit_note icn
    JOIN
        invoice_credit_note_item_list il ON icn.icn_id = il.icn_id
    UNION ALL
    SELECT
        sd.created_date AS transaction_date,
        'Sales Delivery' AS transaction_type,
        sd.sodtt_invoice_number AS reference_number,
        il.item_id,
        il.item_name,
        0 AS quantity_in,
        il.item_quantity * ug.base_quantity AS quantity_out,
        il.item_unit_price AS unit_cost,
        0 AS total_value_in,
        il.item_quantity * il.item_unit_price AS total_value_out
    FROM
        sales_order_delivery_transaction_table sd
    JOIN
        sale_order_delivery_items_list il ON sd.sodtt_id = il.sodtt_id
	JOIN uom_group_item as  ug on ug.item_id = il.item_uom_id
    UNION ALL
    SELECT
        st.created_date AS transaction_date,
        'Stock Out ' AS transaction_type,
        st.stock_transfer_doc_number AS reference_number,
        il.item_id,
        il.item_name,
        0 AS quantity_in,
        il.item_quantity * ug.base_quantity AS quantity_out,
        it.item_unit_price AS unit_cost,
        0 AS total_value_in,
       CAST(il.item_quantity * ug.base_quantity * it.item_unit_price AS NUMERIC)  AS total_value_out
    FROM
        inventory_transfer_table st
    JOIN
        inventory_transfer_rows_table il ON st.itt_id = il.itt_id
    JOIN items_table AS it ON il.item_id = it.item_id
	JOIN uom_group_item as  ug on ug.item_id = il.item_uom_id
	where st.stock_management_action = 'stock_out'
    UNION ALL
    SELECT
        pd.created_date AS transaction_date,
        'GRN' AS transaction_type,
        pd.gort_invoice_number AS reference_number,
        il.item_id,
        il.item_name,
        il.item_quantity * ug.base_quantity AS quantity_in,
        0 AS quantity_out,
        il.item_unit_price AS unit_cost,
        il.item_quantity * il.item_unit_price AS total_value_in,
        0 AS total_value_out
    FROM
        goods_order_receipt_table pd
    JOIN
        good_order_receipt_items_list il ON pd.gort_id = il.gort_id
	JOIN uom_group_item as  ug on ug.item_id = il.item_uom_id
    WHERE pd.gort_order_status != 'draft'
	UNION ALL
    SELECT
        pd.created_date AS transaction_date,
        'Purchase Return' AS transaction_type,
        pd.prt_invoice_number AS reference_number,
        il.item_id,
        il.item_name,
        il.item_quantity  * ug.base_quantity AS quantity_in,
        0 AS quantity_out,
        il.item_unit_price AS unit_cost,
        il.item_quantity * il.item_unit_price AS total_value_in,
        0 AS total_value_out
    FROM
        purchase_return_table pd
    JOIN
        purchase_return_items_list il ON pd.prt_id = il.prt_id
	JOIN uom_group_item as  ug on ug.item_id = il.item_uom_id
	 UNION ALL
    SELECT
        st.created_date AS transaction_date,
        'Stock In ' AS transaction_type,
        st.stock_transfer_doc_number AS reference_number,
        il.item_id,
        il.item_name,
	     il.item_quantity * ug.base_quantity AS quantity_in,
        0 AS quantity_out,
        it.item_unit_price AS unit_cost,
	    CAST(il.item_quantity * ug.base_quantity * it.item_unit_price AS NUMERIC)  AS total_value_in,
        0 AS total_value_out

    FROM
        inventory_transfer_table st
    JOIN
        inventory_transfer_rows_table il ON st.itt_id = il.itt_id
    JOIN items_table AS it ON il.item_id = it.item_id
	JOIN uom_group_item as  ug on ug.item_id = il.item_uom_id
	where st.stock_management_action = 'stock_in'

		 UNION ALL
     SELECT
        pd.created_date AS transaction_date,
        'Sales Return' AS transaction_type,
        pd.srt_invoice_number AS reference_number,
        il.item_id,
        il.item_name,
        il.item_quantity AS quantity_in,
        0 AS quantity_out,
        il.item_unit_price AS unit_cost,
        il.item_quantity * il.item_unit_price AS total_value_in,
        0 AS total_value_out
    FROM
        sales_return_table pd
    JOIN
        sales_return_items_list il ON pd.srt_id = il.srt_id
	JOIN uom_group_item as  ug on ug.item_id = il.item_uom_id
	
),
opening_balance AS (
    SELECT
        item_id,
        item_name,
        COALESCE(SUM(quantity_in - quantity_out), 0) AS opening_quantity,
        COALESCE(SUM((quantity_in - quantity_out) * unit_cost), 0) AS opening_value
    FROM
        all_transactions
    WHERE
        transaction_date < CURRENT_DATE -- Use a specific date if needed
    GROUP BY
        item_id, item_name
),
running_totals AS (
    SELECT
        t.transaction_date,
        t.transaction_type,
        t.reference_number,
        t.item_id,
        t.item_name,
        t.quantity_in,
        t.quantity_out,
        t.unit_cost,
        t.total_value_in,
        t.total_value_out,
        SUM(t.quantity_in - t.quantity_out) OVER (
            PARTITION BY t.item_id
            ORDER BY t.transaction_date
        ) AS closing_quantity -- Running total as closing balance
    FROM
        all_transactions t
),
final_with_opening_balance AS (
    SELECT
        rt.transaction_date,
        rt.transaction_type,
        rt.reference_number,
        rt.item_id,
        rt.item_name,
        LAG(rt.closing_quantity, 1, 0) OVER (
            PARTITION BY rt.item_id
            ORDER BY rt.transaction_date
        ) AS opening_quantity, -- Use LAG to calculate opening balance
        rt.quantity_in,
        rt.quantity_out,
        rt.closing_quantity, -- Running total as closing balance
        rt.unit_cost,
        rt.total_value_in,
        rt.total_value_out,
        rt.closing_quantity * rt.unit_cost AS closing_value
    FROM
        running_totals rt
)


              `

        if (group_by) {
            console.log(group_by, group_by.length, group_by.length > 1)
            let groupByColumns = group_by
            if (group_by.length > 1) {

            
                query += `SELECT
    DATE(transaction_date) AS "Date",
    item_name AS "Item Name",
    ROUND(SUM(opening_quantity), 2) AS "Opening Balance (Quantity)",
ROUND(SUM(quantity_in), 2) AS "Quantity In",
ROUND(SUM(quantity_out), 2) AS "Quantity Out",
ROUND(SUM(closing_quantity), 2) AS "Closing Balance (Quantity)",
ROUND(AVG(unit_cost), 2) AS "Unit Cost",  -- Assuming average unit cost is desired
ROUND(SUM(total_value_in), 2) AS "Total Value In",
ROUND(SUM(total_value_out), 2) AS "Total Value Out",
ROUND(SUM(closing_value), 2) AS "Closing Balance (Value)"

FROM
    final_with_opening_balance  ${whereClauseString} 
GROUP BY
    item_name,
     DATE(transaction_date)
  ORDER BY DATE(transaction_date) DESC       
`
            } else {
                query += `SELECT
        item_name AS "Item Name",
        ROUND(SUM(opening_quantity), 2) AS "Opening Balance (Quantity)",
    ROUND(SUM(quantity_in), 2) AS "Quantity In",
    ROUND(SUM(quantity_out), 2) AS "Quantity Out",
    ROUND(SUM(closing_quantity), 2) AS "Closing Balance (Quantity)",
    ROUND(AVG(unit_cost), 2) AS "Unit Cost",  -- Assuming average unit cost is desired
    ROUND(SUM(total_value_in), 2) AS "Total Value In",
    ROUND(SUM(total_value_out), 2) AS "Total Value Out",
    ROUND(SUM(closing_value), 2) AS "Closing Balance (Value)"
    
    FROM
        final_with_opening_balance  ${whereClauseString} 
    GROUP BY
        item_name
     ORDER BY item_name ASC


  
      
       
    `
            }
        } else {
            query += `SELECT
    transaction_date AS "Date",
    transaction_type AS "Transaction Type",
    reference_number AS "Reference/Invoice #",
    item_name AS "Item Name",
    opening_quantity AS "Opening Balance (Quantity)",
    quantity_in AS "Quantity In",
    quantity_out AS "Quantity Out",
    closing_quantity AS "Closing Balance (Quantity)",
    unit_cost AS "Unit Cost",
    total_value_in AS "Total Value In",
    total_value_out AS "Total Value Out",
    closing_value AS "Closing Balance (Value)"
FROM
    final_with_opening_balance   ${whereClauseString}
 ORDER BY  transaction_date DESC
     `
        }







        console.log(query, "query");
        if(save=="true"){
            if (!name || typeof name !== 'string' || name.trim() === "" || name.length > 255) {
                return res.status(400).send(generateResponse(false, "Enter valid name", 400, ""));
            }
            else if(filters.length ==0 && group_by && from && to && filter_by){
                return res.status(400).send(generateResponse(false, "Select a valid filter", 400, null));
            }
            else{
                const savedQuery = 'INSERT INTO Favorite (name, query) VALUES ($1, $2)';
                const values = [name, query];
                try {
                    await client.query(savedQuery, values);
                } catch (err) {
                    console.log(err);
                    return res.status(400).send(generateResponse(false, err.message, 400, null));
                }
            }
        }

        const result = await client.query(query);

        //     console.log(result.rows, "resulttttt")

        // Process result to add negative value objects for returned items

        if (result.rows.length > 0) {

            if(save=="true"){
                return res.status(200).send(generateResponse(true, "Added to Favorite", 200, { result: result.rows }));
            }
            else{
            return res.status(200).send(
                generateResponse(true, "Fetched successfully", 200, { result: result.rows })
            );
        }
        } else {
            return res.status(400).send(
                generateResponse(true, "Fetched unsuccessfully", 400, { result: result.rows })
            );
        }
    } catch (error) {
        console.log(error)
    }
}


export const getGstr3B = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to } = req.body;

        let G4A_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G4B_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G4C_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G5A_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G5B_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G6C_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G7A_1_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G7B_1_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G9A_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G9B_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G9C_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G10A_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G10B_result = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G11_I_A1 = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G11_I_A2 = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G11_I_B1 = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G11_I_B2 = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G11_II = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }

        let G6A = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }

        let G6B = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }

        let G9A = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }

        let G9B = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }

        let G9C = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }
        let G8C = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }

        let G8D = {
            igst: 0,
            cgst: 0,
            sgst: 0,
            taxable_value: 0
        }

        let A3_1results = [
            G4A_result, G4B_result, G4C_result, G5A_result, G5B_result,
            G6C_result, G7A_1_result, G7B_1_result, G9A_result, G9B_result,
            G9C_result, G10A_result, G10B_result, G11_I_A1, G11_I_A2,
            G11_I_B1, G11_I_B2, G11_II
        ];
        let B3_1results = [G6A, G6B, G9A, G9B, G9C
        ];
        // Initialize the final sum object
        let A3_1totalSum = { igst: 0, cgst: 0, sgst: 0, taxable_value: 0 };

        // Helper function to sum up all the objects

        //  nsole.log(totalSum,'dddddd')

        let ctotalSum = { igst: 0, cgst: 0, sgst: 0, taxable_value: 0 }

        let B3_1 = B3_1results.forEach(result => {
            ctotalSum.igst += result.igst;
            ctotalSum.cgst += result.cgst;
            ctotalSum.sgst += result.sgst;
            ctotalSum.taxable_value += result.taxable_value;
        });






        const G4A_query = `WITH order_and_invoice_totals AS (
    SELECT 
        SUM(item_sgst) AS sgst_sum,
        SUM(item_cgst) AS cgst_sum,
        SUM(item_igst) AS igst_sum,
        SUM(item_unit_price - (item_unit_price * (item_gst / 100))) AS tax_able_value_sum
    FROM (
        SELECT item_sgst, item_cgst, item_igst, item_unit_price, item_gst FROM order_items_list
        UNION ALL
        SELECT item_sgst, item_cgst, item_igst, item_unit_price, item_gst FROM sales_order_invoice_items_list
    ) combined_order_invoice
),
credit_and_note_totals AS (
    SELECT 
        SUM(item_sgst) AS sgst_sum,
        SUM(item_cgst) AS cgst_sum,
        SUM(item_igst) AS igst_sum,
        SUM(item_unit_price - (item_unit_price *(item_gst / 100))) AS tax_able_value_sum
    FROM (
        SELECT item_sgst, item_cgst, item_igst, item_unit_price, item_gst FROM sales_credit_items_list_table
        UNION ALL
        SELECT item_sgst, item_cgst, item_igst, item_unit_price, item_gst FROM invoice_credit_note_item_list
    ) combined_credit_note
)
SELECT
    oai.sgst_sum - cac.sgst_sum AS final_sgst,
    oai.cgst_sum - cac.cgst_sum AS final_cgst,
    oai.igst_sum - cac.igst_sum AS final_igst,
    oai.tax_able_value_sum - cac.tax_able_value_sum AS final_tax_able_value
FROM 
    order_and_invoice_totals oai,
    credit_and_note_totals cac;`

        const [G4A_query_result] = await Promise.all([client.query(G4A_query)])

        console.log(G4A_query_result)
        G4A_result.sgst = parseInt(G4A_query_result.rows[0].final_sgst)
        G4A_result.cgst = parseInt(G4A_query_result.rows[0].final_cgst)
        G4A_result.igst = parseInt(G4A_query_result.rows[0].final_igst)
        G4A_result.taxable_value = parseInt(G4A_query_result.rows[0].final_tax_able_value)

        let A3_1: any = A3_1results.forEach(result => {
            console.log(result, 'resultresultresult')
            A3_1totalSum.igst += result.igst;
            A3_1totalSum.cgst += result.cgst;
            A3_1totalSum.sgst += result.sgst;
            A3_1totalSum.taxable_value += result.taxable_value;
        })
        let object3_1a = {
            nature_of_supply: '(a) Outward taxable supplies (other than zero rated, nil rated andexempted)',
            taxable_value: A3_1totalSum.taxable_value,
            integrated_tax: A3_1totalSum.igst,
            state_tax: A3_1totalSum.sgst,
            central_tax: A3_1totalSum.cgst,
            cess_tax: 0
        }

        let object3_1b = {
            nature_of_supply: ' (b) Outward taxable supplies (zero rated)',
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0
        }

        let object3_1c = {
            nature_of_supply: ' (c) Other outward supplies Nil rated, exempted)',
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0
        }

        let object3_1d = {
            nature_of_supply: '  (d) Inward supplies (liable to reverse charge)',
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0
        }

        let object3_1e = {
            nature_of_supply: '(e) Non-GST outward supplies',
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0
        }

        let object3_1b1 = {
            nature_of_supply: `(i) Taxable supplies on which electronic commerce operator pays tax underSub-section 5 of Section 9To be furnished by the electronic commerce operator`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0
        }

        let object3_1b2 = {
            nature_of_supply: `(ii) Taxable supplies made by the registered person through electronic
 commerce operator, on which electronic commerce operator is required to
 pay tax under Sub-section 5 of Section 9
 To be furnished by the registered person making supplies through electronic
 commerce operator]`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0

        }

        let object3_2b1 = {
            nature_of_supply: ` Supplies made to Unregistered Persons commerce operator`,
            taxable_value: 0,
            integrated_tax: 0,
            place_of_supply: ''


        }

        let object3_2b2 = {
            nature_of_supply: `  Supplies made to Composition Taxable Persons`,
            taxable_value: 0,
            integrated_tax: 0,

            place_of_supply: ''
        }

        let object3_2b3 = {
            nature_of_supply: `Supplies made to UIN holders`,
            taxable_value: 0,
            integrated_tax: 0,
            place_of_supply: ''
        }

        let object4_1 = {
            details: `1 Import of Goods`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0,

        }

        let object4_2 = {
            details: `2 Import of Service`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0,

        }

        let object4_3 = {
            details: `3 Inward supplies liable to reverse charge ( other than 1 & 2 above)`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0,

        }

        let object4_4 = {
            details: ` 4 Inward supplies from ISD`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0,

        }

        let object4_5 = {
            details: ` 5 All other IT`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0,

        }

        let object5 = {
            nature_of_supply: ` Composition Scheme, Exempted, Nil Rated`,
            taxable_value: 0,
            integrated_tax: 0,
            state_tax: 0,
            central_tax: 0,
            cess_tax: 0,
        }
        const response3_1a = [object3_1a, object3_1b, object3_1c, object3_1d, object3_1e]
        const response3_2a = [object3_1b1, object3_1b2]
        const response3_3a = [object3_2b1, object3_2b2, object3_2b3]

        const response4 = [object4_1, object4_2, object4_3, object4_4, object4_5]
        const response5 = [object5]


        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, {
                detailsofOutwardSupplies3_1: response3_1a, detailsofOutwardSupplies3_2: response3_2a, detailsofOutwardSupplies3_3: response3_3a,
                detailsofOutwardSupplies4: response4, detailsofOutwardSupplies5: response5
            })
        );

    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
};

export const productPurchaseReturn = async (req: any, res: any) => {
    try {
        const { selectedColumns, filter_by, filters, group_by, from, to,name,save } = req.body;
        let selectClause: any = [];
        let joinClause = [];
        let whereClause = [];
        const groupByOptions = group_by.split(',');
        const filteredGroupByOptions = groupByOptions.filter((option: any) => option.trim() !== '');
        if (filter_by === 'this_month') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
          }
          if (filter_by === 'this_year') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
          }
          if (filter_by === 'this_week') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(WEEK FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(WEEK FROM CURRENT_DATE)`);
          }
          if (filter_by === 'today') {
            whereClause.push(`EXTRACT(YEAR FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(YEAR FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(MONTH FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(MONTH FROM CURRENT_DATE)`);
            whereClause.push(`EXTRACT(DAY FROM purchase_order_invoice_table.poit_order_date) = EXTRACT(DAY FROM CURRENT_DATE)`);
          }
          
          if (from && to) {
            whereClause.push(`purchase_order_invoice_table.poit_order_date >= '${from}' AND purchase_order_invoice_table.poit_order_date < '${to}'::date + interval '1 day'`);
          } else if (from) {
            whereClause.push(`purchase_order_invoice_table.poit_order_date >= '${from}'`);
          } else if (to) {
            whereClause.push(`purchase_order_invoice_table.poit_order_date <= '${to}'`);
          }

        filters.forEach((filter: any) => {
            const { column, condition, value } = filter;
            let conditionString;
            if (column && condition && value) {
                switch (condition) {
                    case 'greater_than':
                        conditionString = `${column} > ${value}`;
                        break;
                    case 'less_than':
                        conditionString = `${column} < ${value}`;
                        break;
                    case 'equal_to':
                        conditionString = `${column} = '${value}'`;
                        break;
                    case 'not_equal_to':
                        conditionString = `${column} != '${value}'`;
                        break;
                    default:
                        throw new Error(`Unsupported condition: ${condition}`);
                }
                whereClause.push(conditionString);
            }
        });
        const whereClauseString = whereClause.length > 0 ? `WHERE ${whereClause.join(' AND ')}` : '';
        const query: string = (() => {
            switch (group_by) {
                case "purchase_date":
                  return `
                    SELECT
                      TO_CHAR(purchase_order_invoice_table.poit_order_date, 'YYYY-MM-DD') AS purchase_date,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) as total_quantity,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)) as total_returned,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0) - COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)) as net_purchase,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_batch_unit_price, 0) * COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) as total_purchase_amount,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0) * COALESCE(purchase_return_items_batches_list.item_batch_unit_price, 0)) as total_return_amount
                    FROM
                      purchase_order_invoice_table
                    LEFT JOIN purchase_order_invoice_items_list 
                      ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
                    LEFT JOIN purchase_order_invoice_items_batches_list 
                      ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id 
                      AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
                    LEFT JOIN purchase_return_items_batches_list 
                      ON purchase_order_invoice_items_batches_list.item_id = purchase_return_items_batches_list.item_id 
                      AND purchase_order_invoice_items_batches_list.item_batch_number = purchase_return_items_batches_list.item_batch_number
                    ${whereClauseString}
                    GROUP BY purchase_order_invoice_table.poit_order_date
                    ORDER BY 
                      TO_CHAR(purchase_order_invoice_table.poit_order_date, 'YYYYMM');
                  `;
                
                case "product_name":
                  return `
                    SELECT
                      purchase_order_invoice_items_list.item_name AS product_name,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_purchased,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_returned,
                      COALESCE(SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) - SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)), 0) AS net_purchase,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_batch_final_purchase_rate, 0) * COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) as total_purchase_amount,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0) * COALESCE(purchase_return_items_batches_list.item_batch_purchase_rate, 0)) as total_return_amount
                    FROM
                      purchase_order_invoice_table
                    LEFT JOIN purchase_order_invoice_items_list 
                      ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
                    LEFT JOIN purchase_order_invoice_items_batches_list 
                      ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id 
                      AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
                    LEFT JOIN purchase_return_items_batches_list 
                      ON purchase_order_invoice_items_batches_list.item_id = purchase_return_items_batches_list.item_id 
                      AND purchase_order_invoice_items_batches_list.item_batch_number = purchase_return_items_batches_list.item_batch_number
                    ${whereClauseString}
                    GROUP BY purchase_order_invoice_items_list.item_name;
                  `;
                
                case "vendor_name":
                  return `
                    SELECT
                      purchase_order_invoice_table.cmr_name AS vendor_name,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_purchased,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_returned,
                      COALESCE(SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) - SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)), 0) AS net_purchase,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_batch_final_purchase_rate, 0) * COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) as total_purchase_amount,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0) * COALESCE(purchase_return_items_batches_list.item_batch_purchase_rate, 0)) as total_return_amount
                    FROM
                      purchase_order_invoice_table
                    LEFT JOIN purchase_order_invoice_items_list 
                      ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
                    LEFT JOIN purchase_order_invoice_items_batches_list 
                      ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id 
                      AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
                    LEFT JOIN purchase_return_items_batches_list 
                      ON purchase_order_invoice_items_batches_list.item_id = purchase_return_items_batches_list.item_id 
                      AND purchase_order_invoice_items_batches_list.item_batch_number = purchase_return_items_batches_list.item_batch_number
                    ${whereClauseString}
                    GROUP BY purchase_order_invoice_table.cmr_name;
                  `;
                
                case "P_N_V":
                  return `
                    SELECT
                      TO_CHAR(purchase_order_invoice_table.poit_order_date, 'YYYY-MM-DD') AS purchase_date,
                      purchase_order_invoice_items_list.item_name as product_name,
                      purchase_order_invoice_table.cmr_name AS vendor_name,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_purchased,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_returned,
                      COALESCE(SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) 
                               - SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)), 0) AS net_purchase,
                      SUM(COALESCE(purchase_order_invoice_items_batches_list.item_batch_final_purchase_rate, 0) 
                           * COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) AS total_purchase_amount,
                      SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0) 
                           * COALESCE(purchase_return_items_batches_list.item_batch_purchase_rate, 0)) AS total_return_amount
                    FROM
                      purchase_order_invoice_table
                    LEFT JOIN purchase_order_invoice_items_list 
                      ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
                    LEFT JOIN purchase_order_invoice_items_batches_list 
                      ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id 
                      AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
                    LEFT JOIN purchase_return_items_batches_list 
                      ON purchase_order_invoice_items_batches_list.item_id = purchase_return_items_batches_list.item_id 
                      AND purchase_order_invoice_items_batches_list.item_batch_number = purchase_return_items_batches_list.item_batch_number
                    ${whereClauseString}
                    GROUP BY
                      purchase_order_invoice_table.poit_order_date,
                      purchase_order_invoice_items_list.item_name,
                      purchase_order_invoice_table.cmr_name;
                  `;

                case "P_V_N":
                    return `
                      SELECT
                        TO_CHAR(purchase_order_invoice_table.poit_order_date, 'YYYY-MM-DD') AS purchase_date,
                        purchase_order_invoice_items_list.item_name as product_name,
                        purchase_order_invoice_table.cmr_name AS vendor_name,
                        SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_purchased,
                        SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)) AS total_quantity_returned,
                        COALESCE(SUM(COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) 
                                 - SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0)), 0) AS net_purchase,
                        SUM(COALESCE(purchase_order_invoice_items_batches_list.item_batch_final_purchase_rate, 0) 
                             * COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0)) AS total_purchase_amount,
                        SUM(COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0) 
                             * COALESCE(purchase_return_items_batches_list.item_batch_purchase_rate, 0)) AS total_return_amount
                      FROM
                        purchase_order_invoice_table
                      LEFT JOIN purchase_order_invoice_items_list 
                        ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
                      LEFT JOIN purchase_order_invoice_items_batches_list 
                        ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id 
                        AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
                      LEFT JOIN purchase_return_items_batches_list 
                        ON purchase_order_invoice_items_batches_list.item_id = purchase_return_items_batches_list.item_id 
                        AND purchase_order_invoice_items_batches_list.item_batch_number = purchase_return_items_batches_list.item_batch_number
                      ${whereClauseString}
                      GROUP BY
                        purchase_order_invoice_table.poit_order_date,
                        purchase_order_invoice_table.cmr_name;
                        purchase_order_invoice_items_list.item_name,
                    `;
                
                default:
                  return `
                  SELECT TO_CHAR(purchase_order_invoice_table.poit_document_date, 'YYYY-MM-DD') AS purchase_date,
                  purchase_order_invoice_items_list.item_code AS product_code,
                  purchase_order_invoice_items_list.item_name AS product_name,
                  purchase_order_invoice_table.cmr_name AS vendor_name,
                  purchase_order_invoice_items_batches_list.item_batch_number AS batch_number,
                  COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0) AS quantity_purchased,
                  COALESCE(purchase_order_invoice_items_batches_list.item_batch_free_quantity, 0) AS free_quantity,
                  COALESCE(purchase_order_invoice_items_batches_list.item_batch_final_purchase_rate, 0) AS purchase_rate,
                  COALESCE(purchase_order_invoice_items_batches_list.item_batch_total_purchase_rate,0) AS purchase_amount,
                  TO_CHAR(purchase_return_items_list.created_date, 'YYYY-MM-DD') AS return_date,
                  COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0) AS quantity_returned,
                  COALESCE(purchase_return_items_batches_list.item_batch_total_purchase_rate, 0) AS return_amount,
                  COALESCE(purchase_order_invoice_items_batches_list.item_sellable_quantity, 0) - COALESCE(purchase_return_items_batches_list.item_sellable_quantity, 0) AS net_purchase,
                  (COALESCE(purchase_order_invoice_items_batches_list.item_batch_total_purchase_rate, 0) - COALESCE(purchase_return_items_batches_list.item_batch_total_purchase_rate, 0)) AS net_purchase_amount
                  FROM
                  purchase_order_invoice_table
                  LEFT JOIN purchase_order_invoice_items_list
                  ON purchase_order_invoice_table.poit_id = purchase_order_invoice_items_list.poit_id
                  LEFT JOIN purchase_order_invoice_items_batches_list
                  ON purchase_order_invoice_items_list.poit_id = purchase_order_invoice_items_batches_list.poit_id
                  AND purchase_order_invoice_items_list.item_id = purchase_order_invoice_items_batches_list.item_id
                  LEFT JOIN purchase_return_items_list
                  on purchase_order_invoice_items_list.gort_id=purchase_return_items_list.gort_id
                  LEFT JOIN purchase_return_items_batches_list
                  ON purchase_order_invoice_items_batches_list.item_id = purchase_return_items_list.item_id
                  AND purchase_order_invoice_items_batches_list.item_batch_number = purchase_return_items_list.item_batch_number

                    ${whereClauseString}
                    ORDER BY 
                      TO_CHAR(purchase_order_invoice_table.poit_order_date, 'YYYYMM');
                  `;
              }                                      
          })();
          
          console.log(query);
          
        console.log("query is", query);
        if(save=="true"){
            if (!name || typeof name !== 'string' || name.trim() === "" || name.length > 255) {
                return res.status(400).send(generateResponse(false, "Enter valid name", 400, ""));
            }
            else if(filters.length ==0 && group_by && from && to && filter_by){
                return res.status(400).send(generateResponse(false, "Select a valid filter", 400, null));
            }
            else{
                const savedQuery = 'INSERT INTO Favorite (name, query, selectedColumns) VALUES ($1, $2,$3)';
                const values = [name, query,selectedColumns];
                try {
                    await client.query(savedQuery, values);
                } catch (err) {
                    console.log(err);
                    return res.status(400).send(generateResponse(false, err.message, 400, null));
                }
            }
        }
        const result = await client.query(query);
    
        // Map of expected columns for each case
        const columnMapping: Record<string, string[]> = {
            purchase_date: [
                "purchase_date", "total_quantity", "total_returned", "net_purchase", 
                "total_purchase_amount", "total_return_amount"
            ],
            product_name: [
                "product_name", "total_quantity_purchased", "total_quantity_returned", 
                "net_purchase", "total_purchase_amount", "total_return_amount"
            ],
            vendor_name: [
                "vendor_name", "total_quantity_purchased", "total_quantity_returned", 
                "net_purchase", "total_purchase_amount", "total_return_amount"
            ],
            P_N_V: [
                "purchase_date", "product_name", "vendor_name", "total_quantity_purchased", 
                "total_quantity_returned", "net_purchase", "total_purchase_amount", 
                "total_return_amount"
            ],
            P_V_N: [
                "purchase_date", "vendor_name", "product_name", "total_quantity_purchased", 
                "total_quantity_returned", "net_purchase", "total_purchase_amount", 
                "total_return_amount"
            ],
            default: [
                "purchase_date", "product_code", "product_name", "vendor_name", 
                "batch_number", "quantity_purchased", "free_quantity", "purchase_rate", 
                "purchase_amount", "quanity_returned", "return_amount", "net_purchase", 
                "net_purchase_amount"
            ]
        };
        const columns = columnMapping[group_by] || columnMapping.default;
        const processedResult = result.rows.map((row: any) => {
            const processedRow: Record<string, any> = {};
            for (const column of columns) {
                processedRow[column] = row[column] || null;
            }
            return processedRow;
        });
        if(save=="true"){
            return res.status(200).send(generateResponse(true, "Added to Favorite", 200, { result: processedResult }));
        }
        else{
        return res.status(200).send(
            generateResponse(true, "Fetched successfully", 200, { result: processedResult })
        );
        }
    } catch (err) {
        console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
    }
}


export const GetSavedReports = async (req: any, res: any) => {
  const query = "SELECT name FROM Favorite"; 
  try {
    const result = await client.query(query);
    if (result.rows.length > 0) {
        const namesArray = result.rows.map((row: any) => row.name);
        console.log("query is", query);
        return res.status(200).send(generateResponse(true, "Fetched successfully", 200, { result: namesArray }));
      } else {
        return res.status(400).send(generateResponse(false, "No saved reports found", 400, null));
    }
  } catch (err) {
    console.log(err);
        return res.status(400).send(generateResponse(false, err.message, 400, null));
  }
};

export const GetSavedReportData=async(req:any,res:any)=>{
    const {name}=req.body;
    const queryGet = "SELECT query,selectedColumns FROM Favorite WHERE name = $1";
    try {
        const result = await client.query(queryGet, [name]);
        if (result.rows.length > 0) {
            const query = result.rows[0].query;
            const selectedColumns = result.rows[0].selectedcolumns;
            const result1 = await client.query(query);
            const processedResult = result1.rows.map((row: any) => {
                const processedRow: Record<string, any> = {};
                for (const column of Object.keys(row)) {
                    if(selectedColumns.includes(column)){
                    processedRow[column] = row[column];
                    }
                }
            
                return processedRow;
            });
            return res.status(200).send(
                generateResponse(true, "Fetched successfully", 200, { result: processedResult })
            );
          } else {
            return res.status(400).send(generateResponse(false, "No Matching Report Found", 400, null));
          }
      } catch (err) {
        console.log(err);
            return res.status(400).send(generateResponse(false, err.message, 400, null));
      }

}