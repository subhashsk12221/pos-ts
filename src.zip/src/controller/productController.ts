import client from '../util/database';
import { ulid } from 'ulid';
import { generateResponse } from '../util/genRes';
import * as productService from '../service/productService'
import * as discountService from '../service/discountService'
import axios from 'axios';
import * as UOMGroipService from '../administrativesettings/src/service/uomService'

export async function addProduct(req: any, res: any) {

    try {

        const productData = req.body

        productData.item_id = ulid()

        //   console.log(result,"result")
        if (productData) {
            const columns = Object.keys(productData);
            const values = Object.values(productData);

            // Construct the parameterized query
            const query = `INSERT INTO products_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
            console.log(query)

            // Execute the query with parameterized values
            const result = await client.query(query, values);
            if (result) {
                return res.send(
                    generateResponse(true, "product added succesfully", 200, result.rows[0])
                )
            } else {
                return res.send(
                    generateResponse(false, "product adding unsuccesfully", 400, result)
                )
            }



        }

    } catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } finally {
        // release the pool when done

    }
}

export async function updateProduct(req: any, res: any) {

    try {
        const { item_id } = req.body

        const columnValuePairs = Object.entries(req.body)
            .map(([columnName, value], index) => `${columnName} = $${index + 1}`)
            .join(', ');
        // Extracting values from the updatedFields object
        const values = Object.values(req.body);

        const query = `
    UPDATE products_table
    SET ${columnValuePairs}
    WHERE item_id = $${Object.keys(req.body).length + 1}
    RETURNING *;`;
        console.log(values)
        const result = await client.query(query, [...values, item_id]);
        console.log(result.rows, "ddddd")
        if (result.rows.length > 0) {
            return res.send(
                generateResponse(true, "product updated succesfully", 200, result.rows[0])
            )
        } else {
            return res.send(
                generateResponse(false, "product update unsuccesfully", 400, result.rows[0])
            )
        }
    }
    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getProduct(req: any, res: any) {

    try {
        const { field, value } = req.query
        console.log(req.query)
    //     const query = `
    //     SELECT
    //     items_table.*
    //     FROM
    //     items_table
    //     WHERE
    //     LEFT(${field}, 10) ILIKE $1 ;
    //   `;
//     const query = `
//     SELECT
//         items_table.*,
//          COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
//     FROM
//         items_table
//     LEFT JOIN
//         items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
//     LEFT JOIN
//           store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id= items_batch_no_table.item_id
//      LEFT JOIN
//     sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id 
//     WHERE
//         REPLACE(LOWER(${field}), ' ', '') ILIKE '%' || REPLACE(LOWER($1), ' ', '') || '%'
//         AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
//         AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false OR sublevel_bins.bin_no_id IS NULL)
//     GROUP BY
//         items_table.item_id;
// `;

let whereClause = 'WHERE 1=1'; // Start with WHERE 1=1 to simplify appending conditions
let orderByClause = '';



// Add item group filter to the WHERE clause


// Add sorting to the ORDER BY clause

// Add search condition for the specified column
const searchCondition = field
    ? `AND (LOWER(${field}) ILIKE LOWER('%${value}%')) AND items_table.is_active = true`
    : '';

// First query to get the items
const totalOrderValueQuery = `
    SELECT items_table.*,
     mt.name as item_manufacturer_name,
     mt.id as item_manufacturer_id
     FROM items_table
     LEFT JOIN  manufacturer mt ON items_table.item_manufacturer = mt.id 
    
    
    ${whereClause} ${searchCondition}
    ${orderByClause};
`;

// Execute the first query
const getItemsList = await client.query(totalOrderValueQuery);

if (getItemsList.rows.length > 0) {

        for (let item of getItemsList.rows) {
            let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
         if(getItemGroup.rows.length>0){
            console.log(getItemGroup.rows)
            item.uom_dropdown= getItemGroup.rows
             item.item_uom = getItemGroup.rows[0].base_uom.name
      }
    }
    
    // Extract item_ids from the result
    const itemIds = getItemsList.rows.map((item: any) => `'${item.item_id}'`).join(', ');

    // Second query to get the total_sellable_quantity for the fetched items
    const sellableQuantityQuery = `
        SELECT
            items_table.item_id,
            COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
        FROM
            items_table
        LEFT JOIN
            items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
        LEFT JOIN
            store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
        LEFT JOIN
            sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
        WHERE
            items_table.item_id IN (${itemIds})
            AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
            AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
        GROUP BY
            items_table.item_id;
    `;

    // Execute the second query
    const sellableQuantities = await client.query(sellableQuantityQuery);

    // Map sellable quantities to item IDs
    const quantitiesMap = new Map(sellableQuantities.rows.map((row: any) => [row.item_id, row.total_sellable_quantity]));

    // Merge sellable quantities with the original item data
    let finalItemsList = getItemsList.rows.map((item: any) => ({
        ...item,
        total_sellable_quantity: quantitiesMap.get(item.item_id) || 0
    }));


        // console.log(query, field, value)
        // if (field && value) {
        //     const result = await client.query(query, [`%${value}%`]);
            // console.log(result)
            if (finalItemsList.length > 0) {
                console.log('Customers found:', finalItemsList);
            //     for (let item of finalItemsList) {
            //         let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
            //     if(getItemGroup.rows.length>0){
            //         console.log(getItemGroup.rows)
            //         item.uom_dropdown= getItemGroup.rows
            //          item.item_uom = getItemGroup.rows[0].base_uom.name
            //   }
            // }
        
                return res.send(
                    generateResponse(true, "product fetched succesfully", 200, finalItemsList))
            } else {
                return res.send(
                    generateResponse(false, "product not found", 400, null))
            }
        }
    }

    catch (error) {
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


// export async function getproductlist(req: any, res: any) {
//     try {
//         const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, itemgroup, searchColumn, searchValue } = req.query;

//         if (!pageNumber || !pageSize) {
//             return res.send(generateResponse(false, "pageNumber and pageSize are required", 400, null));
//         }



//         const offset = (pageNumber - 1) * pageSize;
//         const limit = pageSize;

//         let whereClause = '';
//         let orderByClause = '';

//         // Add date range filter to the WHERE clause
//         if (fromDate && toDate) {
//             whereClause += ` AND created_date >= '${fromDate}' AND created_date < '${toDate}'::date + interval '1 day'`;
//         }

//         // Add payment status filter to the WHERE clause
//         if (itemgroup) {
//             const itemGroups = Array.isArray(itemgroup) ? itemgroup : [itemgroup];
          
//             if (itemGroups.length > 0) {

//                 console.log(itemGroups)
//                 const itemGroupFilter = itemgroup.split(',').map((group: any) => `'${group}'`).join(', ');
                
//                 // Add the IN clause to the whereClause
//                 whereClause += ` AND item_group IN (${itemGroupFilter})`;
//             }
//             console.log(whereClause,"ddddd")

//         }


       
//         // Add sorting to the ORDER BY clause
//         if (sortBy && sortOrder) {

//             // Sort by a column in the customer_details table
//             orderByClause = `ORDER BY ${sortBy} ${sortOrder}`;

//         } else {
//             // Default sorting by created_date in descending order if no sorting parameters provided
//             orderByClause = 'ORDER BY created_date DESC';
//         }

//         // Add search condition for the specified column
//         const searchCondition = searchColumn
//             ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
//             : '';


// //         const totalOrderValueQuery = `
// //     SELECT *
// //     FROM
// //     items_table
// //     WHERE
// //         1=1 ${whereClause} ${searchCondition}
   
// //     ${orderByClause} OFFSET $1 LIMIT $2;
// // `;
// // const totalOrderValueQuery = `
// // SELECT
// //     items_table.*,
// //     COALESCE(SUM(items_batch_no_table.item_sellable_quantity), 0) AS total_sellable_quantity
// // FROM
// //     items_table
// // LEFT JOIN
// //     items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
// // WHERE
// //     1=1 ${whereClause} ${searchCondition}
// //     AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
// // GROUP BY
// //     items_table.item_id
// // ${orderByClause}
// // OFFSET $1 LIMIT $2;
// // `;

// const totalOrderValueQuery = `
// SELECT
//     items_table.*,
//     COALESCE(SUM(items_batch_no_table.item_sellable_quantity), 0) AS total_sellable_quantity
// FROM
//     items_table
// LEFT JOIN
//     items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
// LEFT JOIN
//     store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number
// LEFT JOIN
//     sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
// WHERE
   
//         (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
//         AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false)
//     ${whereClause}
//     ${searchCondition}
// GROUP BY
//     items_table.item_id
// ${orderByClause}
// OFFSET $1 LIMIT $2;
// `;


//         const queryCount = `
//             SELECT COUNT(*) 
//             FROM items_table  
//             WHERE 1=1 ${whereClause} ${searchCondition};
//         `;
//         console.log(totalOrderValueQuery)
//         console.log(queryCount)
//         const totalCount = await client.query(queryCount);
//         const getItemsList = await client.query(totalOrderValueQuery, [offset, limit]);

//         if (getItemsList.rows.length > 0) {
//             console.log('Customers found:', getItemsList.rows);
//             return res.send(generateResponse(true, "items list fetched successfully", 200, {
//                 totalCount: totalCount.rows[0].count,
//                 getItemsList: getItemsList.rows
//             }));
//         } else {


//             return res.send(generateResponse(false, "No items found", 400, null));
//         }
//     } catch (error) {
//         console.log(error);
//         return res.send(generateResponse(false, error.message, 400, null));
//     }
// }

// export async function getproductlist(req: any, res: any) {
//     try {
//         const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, itemgroup, searchColumn, searchValue } = req.query;

//         if (!pageNumber || !pageSize) {
//             return res.send(generateResponse(false, "pageNumber and pageSize are required", 400, null));
//         }

//         const offset = (pageNumber - 1) * pageSize;
//         const limit = pageSize;

//         let whereClause = 'WHERE 1=1'; // Start with WHERE 1=1 to simplify appending conditions
//         let orderByClause = '';

//         // Add date range filter to the WHERE clause
//         if (fromDate && toDate) {
//             whereClause += ` AND created_date >= '${fromDate}' AND created_date < '${toDate}'::date + interval '1 day'`;
//         }

//         // Add item group filter to the WHERE clause
//         if (itemgroup) {
//             const itemGroups = itemgroup.split(',').map((group: any) => `'${group}'`).join(', ');
//             whereClause += ` AND item_group IN (${itemGroups})`;
//         }

//         // Add sorting to the ORDER BY clause
//         if (sortBy && sortOrder) {
//             orderByClause = `ORDER BY ${sortBy} ${sortOrder}`;
//         } else {
//             orderByClause = 'ORDER BY created_date DESC';
//         }

//         // Add search condition for the specified column
//         const searchCondition = searchColumn
//             ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
//             : '';

//         const totalOrderValueQuery = `
//         SELECT
//             items_table.*,
//             COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
//         FROM
//             items_table
//         LEFT JOIN
//             items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
//         LEFT JOIN
//             store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id= items_batch_no_table.item_id
//         LEFT JOIN
//             sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
//         ${whereClause}
//             AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
//             AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false OR sublevel_bins.bin_no_id IS NULL)
//         ${searchCondition}
//         GROUP BY
//             items_table.item_id
//         ${orderByClause}
//         OFFSET $1 LIMIT $2;
//         `;

//         // const queryCount = `
//         //     SELECT COUNT(*) 
//         //     FROM items_table  
//         //     ${whereClause} ${searchCondition};
//         // `;

//         const queryCount = `
//             SELECT COUNT(DISTINCT items_table.item_id) 
//             FROM 
//                 items_table
//             LEFT JOIN
//                 items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
//             LEFT JOIN
//                 store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number 
//                 AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
//             LEFT JOIN
//                 sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
//             ${whereClause}
//                 AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
//                 AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false OR sublevel_bins.bin_no_id IS NULL)
//             ${searchCondition};
//         `;


//         console.log(totalOrderValueQuery);
//         console.log(queryCount);
//         const totalCount = await client.query(queryCount);
//         const getItemsList = await client.query(totalOrderValueQuery, [offset, limit]);

//         if (getItemsList.rows.length > 0) {
//             console.log('Items found:', getItemsList.rows);
//             return res.send(generateResponse(true, "Items list fetched successfully", 200, {
//                 totalCount: totalCount.rows[0].count,
//                 getItemsList: getItemsList.rows
//             }));
//         } else {
//             return res.send(generateResponse(false, "No items found", 400, null));
//         }
//     } catch (error) {
//         console.log(error);
//         return res.send(generateResponse(false, error.message, 400, null));
//     }
// }

// export async function getproductlist(req: any, res: any) {
//     try {
//         const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, itemgroup, searchColumn, searchValue , filterValue} = req.query;

//         if (!pageNumber || !pageSize) {
//             return res.send(generateResponse(false, "pageNumber and pageSize are required", 400, null));
//         }

//         const offset = (pageNumber - 1) * pageSize;
//         const limit = pageSize;

//         let whereClause = 'WHERE 1=1'; // Start with WHERE 1=1 to simplify appending conditions
//         let orderByClause = '';

//         // Add date range filter to the WHERE clause
//         if (fromDate && toDate) {
//             whereClause += ` AND created_date >= '${fromDate}' AND created_date < '${toDate}'::date + interval '1 day'`;
//         }

//         // Add item group filter to the WHERE clause
//         if (itemgroup) {
//             const itemGroups = Array.isArray(itemgroup) ? itemgroup : [itemgroup];
//             if (itemGroups.length > 0) {
//                 const itemGroupFilter = itemgroup.split(',').map((group: any) => `'${group}'`).join(', ');
//                 whereClause += ` AND item_group IN (${itemGroupFilter})`;
//             }
//         }

//         // Add sorting to the ORDER BY clause
//         if (sortBy && sortOrder) {
//             orderByClause = `ORDER BY ${sortBy} ${sortOrder}`;
//         } else {
//             orderByClause = 'ORDER BY created_date DESC';
//         }

//         // Add search condition for the specified column
//         const searchCondition = searchColumn
//             ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
//             : '';

//         // First query to get the items
//         const totalOrderValueQuery = `
//             SELECT *
//             FROM items_table
//             ${whereClause} ${searchCondition}
//             ${orderByClause}
//             OFFSET $1 LIMIT $2;
//         `;

//         // Execute the first query
//         const getItemsList = await client.query(totalOrderValueQuery, [offset, limit]);

//         if (getItemsList.rows.length > 0) {
//             // Extract item_ids from the result
//             const itemIds = getItemsList.rows.map((item: any) => `'${item.item_id}'`).join(', ');

//             // Second query to get the total_sellable_quantity for the fetched items
//             const sellableQuantityQuery = `
//                 SELECT
//                     items_table.item_id,
//                     COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
//                 FROM
//                     items_table
//                 LEFT JOIN
//                     items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
//                 LEFT JOIN
//                     store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
//                 LEFT JOIN
//                     sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
//                 WHERE
//                     items_table.item_id IN (${itemIds})
//                     AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
//                     AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false OR sublevel_bins.bin_no_id IS NULL)
//                 GROUP BY
//                     items_table.item_id;
//             `;

//             // Execute the second query
//             const sellableQuantities = await client.query(sellableQuantityQuery);

//             // Map sellable quantities to item IDs
//             const quantitiesMap = new Map(sellableQuantities.rows.map((row: any) => [row.item_id, row.total_sellable_quantity]));

//             // Merge sellable quantities with the original item data
//             let finalItemsList = getItemsList.rows.map((item: any) => ({
//                 ...item,
//                 total_sellable_quantity: quantitiesMap.get(item.item_id) || 0
//             }));

//             if (filterValue) {
//                 if (filterValue === 'no_stock') {
//                     finalItemsList = finalItemsList.filter(item => item.total_sellable_quantity === 0);
//                 } else if (filterValue === 'low_stock') {
//                     finalItemsList = finalItemsList.filter(item => item.total_sellable_quantity > 0 && item.total_sellable_quantity <= 5);
//                 }
//             }

//             // Query to count the total number of items
//             const queryCount = `
//                 SELECT COUNT(*)
//                 FROM items_table
//                 ${whereClause} ${searchCondition};
//             `;

//             const totalCount = await client.query(queryCount);

//             return res.send(generateResponse(true, "Items list fetched successfully", 200, {
//                 totalCount: totalCount.rows[0].count,
//                 getItemsList: finalItemsList
//             }));
//         } else {
//             return res.send(generateResponse(false, "No items found", 400, null));
//         }
//     } catch (error) {
//         console.log(error);
//         return res.send(generateResponse(false, error.message, 400, null));
//     }
// }

export async function getproductlist(req: any, res: any) {
    try {
        const { pageNumber, pageSize, sortBy, sortOrder, fromDate, toDate, itemgroup, searchColumn, searchValue, filterValue } = req.query;

        if (!pageNumber || !pageSize) {
            return res.send(generateResponse(false, "pageNumber and pageSize are required", 400, null));
        }

        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;

        let whereClause = 'WHERE 1=1'; // Start with WHERE 1=1 to simplify appending conditions
        let orderByClause = '';

        // Add date range filter to the WHERE clause
        if (fromDate && toDate) {
            whereClause += ` AND created_date >= '${fromDate}' AND created_date < '${toDate}'::date + interval '1 day'`;
        }

        // Add item group filter to the WHERE clause
        if (itemgroup) {
            const itemGroups = Array.isArray(itemgroup) ? itemgroup : [itemgroup];
            if (itemGroups.length > 0) {
                const itemGroupFilter = itemgroup.split(',').map((group: any) => `'${group}'`).join(', ');
                whereClause += ` AND item_group IN (${itemGroupFilter})`;
            }
        }

        // Add sorting to the ORDER BY clause
        if (sortBy && sortOrder) {
            orderByClause = `ORDER BY ${sortBy} ${sortOrder}`;
        } else {
            orderByClause = 'ORDER BY created_date DESC';
        }

        // Add search condition for the specified column
        const searchCondition = searchColumn
            ? `AND (LOWER(${searchColumn}) ILIKE LOWER('%${searchValue}%'))`
            : '';

        // First query to get the items
        const totalOrderValueQuery = `
            SELECT *
            FROM items_table
            ${whereClause} ${searchCondition}
            ${orderByClause};
        `;

        // Execute the first query
        const getItemsList = await client.query(totalOrderValueQuery);

        if (getItemsList.rows.length > 0) {
            // Extract item_ids from the result
            const itemIds = getItemsList.rows.map((item: any) => `'${item.item_id}'`).join(', ');

            // Second query to get the total_sellable_quantity for the fetched items
            const sellableQuantityQuery = `
                SELECT
                    items_table.item_id,
                    COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
                FROM
                    items_table
                LEFT JOIN
                    items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
                LEFT JOIN
                    sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
                WHERE
                    items_table.item_id IN (${itemIds})
                    AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
                    AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
                GROUP BY
                    items_table.item_id;
            `;

            // Execute the second query
            const sellableQuantities = await client.query(sellableQuantityQuery);

            // Map sellable quantities to item IDs
            const quantitiesMap = new Map(sellableQuantities.rows.map((row: any) => [row.item_id, row.total_sellable_quantity]));

            // Merge sellable quantities with the original item data
            let finalItemsList = getItemsList.rows.map((item: any) => ({
                ...item,
                total_sellable_quantity: quantitiesMap.get(item.item_id) || 0
            }));

            // Apply stock filter if provided
            if (filterValue) {
                if (filterValue === 'no_stock') {
                    finalItemsList = finalItemsList.filter(item => item.total_sellable_quantity === 0);
                } else if (filterValue === 'low_stock') {
                    finalItemsList = finalItemsList.filter(item => item.total_sellable_quantity > 0 && item.total_sellable_quantity <= 5);
                }
            }

            // Now apply pagination to the filtered list
            const totalCount = finalItemsList.length;
            finalItemsList = finalItemsList.slice(offset, offset + limit);

            return res.send(generateResponse(true, "Items list fetched successfully", 200, {
                totalCount: totalCount,
                getItemsList: finalItemsList
            }));
        } else {
            return res.send(generateResponse(false, "No items found", 400, null));
        }
    } catch (error) {
        console.log(error);
        return res.send(generateResponse(false, error.message, 400, null));
    }
}



export async function additemBatchNumber(req: any, res: any) {

    try {

        const {itemBatchData:itemBatchData} = req.body

        const itemColumns = Object.keys(itemBatchData[0]);
        
        const itemValuesArray = itemBatchData.map((item: any) =>
            Object.values(item)
        );
      
        const valuesStrings = itemValuesArray.map((innerArray: any) =>
            `(${innerArray.map((value: any) => `'${value}'`).join(', ')})`
        );

        console.log(valuesStrings)


        const resultString = valuesStrings.join(', ');
     
        const query = `INSERT INTO items_batch_no_table (${itemColumns.join(', ')}) VALUES ${resultString} RETURNING *;`;

            const result = await client.query(query);
            if (result.rows.length > 0) {
                return res.send(
                    generateResponse(true, "itembatchnumber added succesfully", 200, result.rows)
                )
            } else {
                return res.send(
                    generateResponse(false, "itembatchnumber adding unsuccesfully", 400, result)
                )
            }

        

    } catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getStockItems(req: any, res: any) {

    try {

        const { item_id, item_quantity } = req.query

        //   console.log(result,"result")
        if (item_id) {
            const query = `
            SELECT
                *
            FROM
                items_batch_no_table
            WHERE
                item_id = $1
            ORDER BY
                item_exp_date ASC
            LIMIT 1;
        `;

            // Execute the query with parameterized values
            const getItemQuantity = await client.query(query, [item_id]);

            if (getItemQuantity.rows.length > 0) {
                const sellableQuantity = parseInt(getItemQuantity.rows[0].item_sellable_quantity, 10);
                const requestedQuantity = parseInt(item_quantity, 10);
                let inStock
                if (!isNaN(sellableQuantity) && !isNaN(requestedQuantity)) {
                    inStock = sellableQuantity >= requestedQuantity;

                }         // Check if the available quantity is greater than or equal to the requested quantity

                if (inStock) {
                    return res.status(200).send(
                        generateResponse(true, "item is instock", 200, {
                            inStock: inStock,
                            itemDetails: getItemQuantity.rows[0],
                        })
                    )
                } else {
                    return res.status(400).send(
                        generateResponse(false, "item is out of stock", 400, { inStock: inStock , itemDetails: getItemQuantity.rows[0]})
                    )
                }

            } else {
            return res.status(400).send(
                generateResponse(false, "item is not found", 400, {itemDetails:{item_sellable_quantity:0}})
            )

        }
    }
}

    catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    }
}


export async function getStockItemsV1(req: any, res: any) {
    try {
        const { item_id, item_quantity, cmr_phone_number} = req.query;

        if (item_id) {

          const getBatchNumber = await productService.checkBatchNumberV1(item_id,item_quantity,cmr_phone_number)
          console.log(getBatchNumber)
        if(item_quantity>getBatchNumber.totalSellableQuantity){
            return res.status(400).send(
                generateResponse(false, "item is not found", 400, { itemDetails: { item_sellable_quantity: getBatchNumber.totalSellableQuantity } })
            );
        } else if (getBatchNumber)
                return res.status(200).send(
                    generateResponse(true, "item is in stock", 200, {
                        itemDetails: getBatchNumber.fulfilledBatches,
                        itemBatchList:getBatchNumber.batchlist
                    })
                );
            } else {
                return res.status(400).send(
                    generateResponse(false, "item is not found", 400, { itemDetails: { item_sellable_quantity: 0 } })
                );
            }
        } catch (error) {
        console.log(error, "errr");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}


export async function getSalesStockItemsV1(req: any, res: any) {
    try {
        let { item_id, item_quantity,base_quantity} = req.query;
            
        if (item_id) {
            
          const getBatchNumber = await productService.checkSalesBatchNumberV1(item_id,item_quantity,base_quantity)
          console.log(getBatchNumber)
        if(item_quantity>getBatchNumber.totalSellableQuantity){
            return res.status(400).send(
                generateResponse(false, "item is not found", 400, { itemDetails: { item_sellable_quantity: getBatchNumber.totalSellableQuantity } })
            );
        } else if (getBatchNumber)
                return res.status(200).send(
                    generateResponse(true, "item is in stock", 200, {
                        itemDetails: getBatchNumber.fulfilledBatches,
                        itemBatchList:getBatchNumber.batchlist
                    })
                );
            } else {
                return res.status(400).send(
                    generateResponse(false, "item is not found", 400, { itemDetails: { item_sellable_quantity: 0 } })
                );
            }
        } catch (error) {
        console.log(error, "errr");
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function addAlternativeItem(req: any, res: any) {

    try {

        const alternativeProductData = req.body
        alternativeProductData.alternative_id = ulid()
        //   console.log(result,"result")
        if (alternativeProductData) {
            const columns = Object.keys(alternativeProductData);
            const values = Object.values(alternativeProductData);

            // Construct the parameterized query
            const query = `INSERT INTO alternative_items_table (${columns.join(', ')})VALUES (${values.map((_, i) => `$${i + 1}`).join(', ')})RETURNING *;`;
            console.log(query)

            // Execute the query with parameterized values
            const result = await client.query(query, values);
            if (result) {
                return res.send(
                    generateResponse(true, "alternative item added succesfully", 200, result.rows[0])
                )
            } else {
                return res.send(
                    generateResponse(false, "alternative adding unsuccesfully", 400, result)
                )
            }

        }

    } catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    } finally {
        // release the pool when done

    }
}


export async function getAlternativeItem(req: any, res: any) {

    try {

        const {item_id,pageNumber, pageSize,} = req.query
        if (!pageNumber || !pageSize) {
            return res.send(generateResponse(false, "pageNumber and pageSize are required", 400, null));
        }



        const offset = (pageNumber - 1) * pageSize;
        const limit = pageSize;


        //   console.log(result,"result")
        if (item_id) {
            const totalCountQuery = `
        SELECT COUNT(DISTINCT a.alternative_item_id) AS total_count
        FROM alternative_items_table a
        WHERE a.main_item_id = $1;
    `;

    const query = `
      SELECT
            p.*,
            COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
        FROM
            alternative_items_table a
        JOIN
        items_table p ON a.alternative_item_id = p.item_id
        LEFT JOIN 
            items_batch_no_table ibn ON p.item_id = ibn.item_id
        LEFT JOIN
                    store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = ibn.item_batch_number AND store_inventory_item_location_table.item_id = ibn.item_id
        LEFT JOIN
                    sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
         WHERE
         a.main_item_id = $1
         AND (ibn.item_exp_date IS NULL OR ibn.item_exp_date > CURRENT_DATE)
         AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
         GROUP BY
            p.item_id
         ORDER BY
            total_sellable_quantity DESC
        LIMIT $2
        OFFSET $3;
    `;
    const findMainItem  = `SELECT 
    item_name AS main_item FROM items_table WHERE item_id = $1`
    // Execute the main query with parameterized values for pagination
    const getAlternativeProducts = await client.query(query, [item_id, limit, offset]);
    if (getAlternativeProducts.rows.length > 0) {

        for (let item of getAlternativeProducts.rows) {
            let getItemGroup = await UOMGroipService.getUomGroupItemsDropdown(item.item_uom)
         if(getItemGroup.rows.length>0){
            console.log(getItemGroup.rows)
            item.uom_dropdown= getItemGroup.rows
             item.item_uom = getItemGroup.rows[0].base_uom.name
      }
    }
    const getMainItem = await client.query(findMainItem,[item_id])
   
            const totalCountResult = await client.query(totalCountQuery, [item_id]);
            const totalCount = totalCountResult.rows[0].total_count;
        
        
              console.log(getAlternativeProducts.rows)
            if (getAlternativeProducts.rows.length > 0) {
               
                
                    return res.status(200).send(
                        generateResponse(true, "alternative are found", 200, {
                            totalCount:totalCount,
                            alternativeProducts: getAlternativeProducts.rows,
                            main_item_name:getMainItem.rows[0].main_item
                        })
                    )
                } else {
                    return res.status(400).send(
                        generateResponse(false, "alternative are not found", 400,null)
                    )
                }

            } else {
            return res.status(400).send(
                generateResponse(false, "alternative are not found", 400,null)
            )

        }
    }

    }
    catch (error) {
        console.log(error, "errr")
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function listofAlternativeItem(req: any, res: any){
    try{
    const getAllitems = await productService.listofAlternativeItem(req.query)
    if (getAllitems.items) {
        return res.status(200).send(
            generateResponse(true, "items fetched succesfully", 200,{
                itemList:getAllitems.items,
                totalCount :getAllitems.totalCountRows
            } )
        )
    } else {
        return res.status(400).send(
            generateResponse(false, "items fetching unsuccesfull", 400, null)
        )
    }
}
catch (error) {
    return res.status(400).send(generateResponse(false, error.message, 400, null));
}
}

export async function addGeneralDetails(req: any, res: any) {

    try {

        const itemObj = req.body

        itemObj.item_id = ulid()
        
        function generateRandomString() {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let result = '';

            for (let i = 0; i < 5; i++) {
                const randomIndex = Math.floor(Math.random() * chars.length);
                result += chars.charAt(randomIndex);
            }

            return result;
        }

        // Function to generate an item code with a random string
        function generateRandomItemCode(prefix = 'IT', length = 4) {
            const randomString = generateRandomString();
            return `${prefix}${randomString}`;
        }

        // Example usage
     //   const randomItemCode = generateRandomItemCode();
        itemObj.item_code = Math.floor(Math.random() * (1000000 - 1000 + 1)) + 1000
        //   console.log(result,"result")
        if (itemObj) {
                 
            const  getbasepricelist = await  discountService.getPricelistById('01HS5HJYWZ5DG2CW4EHX2W7A8V')

            const addItemGeneralDetails = await  productService.addItemGeneralDetails(itemObj)
          if(addItemGeneralDetails.rows.length>0){
          //  syncitemrData(itemObj,'add')
          const multipliedItems = addItemGeneralDetails.rows.map((item: { item_id: any; item_unit_price: any; item_selling_price: number; }) => {
            return {
                item_id: item.item_id,
                item_base_price: item.item_unit_price,
                price_list_id: getbasepricelist.rows[0].price_list_id,
                item_selling_price: item.item_unit_price * getbasepricelist.rows[0].default_factor // Assuming pricelistObj.multiplying_factor contains the multiplying factor of the new price list
            };
        });
        console.log(multipliedItems, "sdddd")
        const additems = await discountService.addItemsToBasePriceList(multipliedItems)
                return res.send(
                    generateResponse(true, "item added succesfully", 200, addItemGeneralDetails.rows[0])
                )
            } else {
                return res.send(
                    generateResponse(false, "item adding unsuccesfully", 400,null)
                )
            }



        }

    } catch (error) {
   
        console.log(error, "Error");

        return res.send(generateResponse(false, error.message, 400, null));
    } 
}

export async function syncitemrData(itemData: any, type: string) {
    // create request body from customerData
    const req = {
        body: {
            "itemData": itemData,
            "type": type
        }
    };
    try {
        let res = await axios.post('https://huox3n6kad.execute-api.us-east-1.amazonaws.com/dev/itemData', req.body);
        console.log('Response from sync API:', res.data);
    } catch (error) {
        console.log('Error while syncing data', error);
    }
}

export async function updateGeneralDetails(req: any, res: any) {

    try {
        const { item_id } = req.body
        
        if(item_id){
            const updateGeneralDetails = await productService.updateGeneralDetails(item_id,req.body)

        if (updateGeneralDetails.rows.length>0){
            return res.status(200).send(
                generateResponse(true, "updated item general details succesfully", 200, updateGeneralDetails.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "updated item general details unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updatePurchasingDetails(req: any, res: any) {

    try {
        const { itemGeneralData:itemGeneralData, itemPurchasingData:itemPurchasingData } = req.body
        console.log(req.body)
        
        if(itemPurchasingData){
            const {item_id} = itemPurchasingData
            if(itemGeneralData){
                const updateGeneralDetails =  productService.updateGeneralDetails(item_id,itemGeneralData)
            }

            const updatePurchasingDetails = await productService.updatePurchasingDetails(item_id,itemPurchasingData)
        
        if (updatePurchasingDetails.rows.length>0) {
            return res.status(200).send(
                generateResponse(true, "adding item purchasing details succesfully", 200, updatePurchasingDetails.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "adding item purchasing details unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updateSalesDetails(req: any, res: any) {

    try {
        const { itemGeneralData:itemGeneralData, itemSalesData:itemSalesData } = req.body
      
        
        if(itemSalesData){
            const {item_id} = itemSalesData
            if(itemGeneralData){
                const updateGeneralDetails =  productService.updateGeneralDetails(item_id,itemGeneralData)
            }
            const updateSaleData = await productService.updateSalesDetails(item_id,itemSalesData)

        

        if (updateSaleData.rows.length>0) {
            return res.status(200).send(
                generateResponse(true, "added item sales details succesfully", 200, updateSaleData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "adding item sales details  unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updateInventoryDetails(req: any, res: any) {

    try {

        const { itemGeneralData:itemGeneralData, itemInventoryData:itemInventoryData } = req.body

                
        if(itemInventoryData){
            const {item_id} = itemInventoryData
            if(itemGeneralData){
                const updateGeneralDetails =  productService.updateGeneralDetails(item_id,itemGeneralData)
            }
            const updateInventoryData = await productService.updateInventoryDetails(item_id,itemInventoryData)


        if (updateInventoryData.rows.length>0) {
            return res.status(200).send(
                generateResponse(true, "added item inventory  detials succesfully", 200,updateInventoryData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "adding item restriction condition unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updatePlanningDetails(req: any, res: any) {

    try {
        const { itemGeneralData:itemGeneralData, itemPlanningData:itemPlanningData } = req.body
 
        if(itemPlanningData){
            const {item_id} = itemPlanningData
            if(itemGeneralData){
                const updateGeneralDetails =  productService.updateGeneralDetails(item_id,itemGeneralData)
            }
            const updatePlanningData = await productService.updatePlanningDetails(item_id,itemPlanningData)


        if (updatePlanningData.rows.length>0) {
            return res.status(200).send(
                generateResponse(true, "added item planning details succesfully", 200, updatePlanningData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "adding item planning details unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updateRestrictionDetails(req: any, res: any) {

    try {
        const { itemGeneralData:itemGeneralData, itemRestrictionData:itemRestrictionData } = req.body

                
        if(itemRestrictionData){
            const {item_id} = itemRestrictionData
            if(itemGeneralData){
                const updateGeneralDetails =  productService.updateGeneralDetails(item_id,itemGeneralData)
            }
            const updateRestrictionData = await productService.updateRestrictionDetails(item_id,itemRestrictionData)

        if (updateRestrictionData.rows.length>0) {
            return res.status(200).send(
                generateResponse(true, "updated item restriction condition succesfully", 200, updateRestrictionData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "update item restriction condition unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function updateItemRemarks(req: any, res: any) {

    try {
        const { itemGeneralData:itemGeneralData, itemRemarksData:itemRemarksData } = req.body
   
        if(itemRemarksData){
            const {item_id} = itemRemarksData
            if(itemGeneralData){
                const updateGeneralDetails =  productService.updateGeneralDetails(item_id,itemGeneralData)
            }
            
            const updateRestrictionData = await productService.updateItemRemarks(item_id,itemRemarksData)

        if (updateRestrictionData.rows.length>0) {
            return res.status(200).send(
                generateResponse(true, "updated item remarks succesfully", 200, updateRestrictionData.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "update item remarks unsuccesfully", 400,null)
            )
        }
    }
}
    catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

// export async function getItemById(req: any, res: any) {

//     try {
//         const { item_id } = req.query
//         console.log(req.query)
//         if (item_id) {
//             const query = `
//             SELECT
//                 items_table.*,
//                 item_purchasing_table.*,
//                 item_sales_table.*,
//                 item_invetory_table.*,
//                 item_planning_table.*,
//                 item_restriction_table.*,
//                 item_remarks_table.*,
//                 item_barcode_table.*
                
//             FROM
//                 items_table
//             LEFT JOIN
//                 item_purchasing_table ON items_table.item_id = item_purchasing_table.item_id
//             LEFT JOIN
//                 item_sales_table ON items_table.item_id = item_sales_table.item_id
//             LEFT JOIN
//             item_invetory_table ON items_table.item_id = item_invetory_table.item_id
//             LEFT JOIN
//                 item_planning_table ON items_table.item_id = item_planning_table.item_id
//             LEFT JOIN
//                 item_restriction_table ON items_table.item_id = item_restriction_table.item_id
//             LEFT JOIN
//                 item_remarks_table ON items_table.item_id = item_remarks_table.item_id
//             LEFT JOIN
//             item_barcode_table ON items_table.item_id = item_barcode_table.item_id
//             WHERE
//                 items_table.item_id = $1;
//         `;
//         console
//         const result = await client.query(query, [item_id]);



            
//             if (result.rows.length > 0) {
//                 console.log('Customers found:', result.rows);
//                 return res.status(200).send(
//                     generateResponse(true, "item fetched succesfully", 200, result.rows))
//             } else {
//                 return res.status(400).send(
//                     generateResponse(false, "item not found", 400, null))
//             }
//         }
//     }
//     catch (error) {
//         console.log(error)
//         return res.status(400).send(generateResponse(false, error.message, 400, null));
//     }
// }

export async function getItemById(req:any, res:any) {
    try {
        const { item_id } = req.query;
        console.log(req.query);
        if (item_id) {
            const query =
             `
            SELECT
                items_table.*,
                item_purchasing_table.*,
                item_sales_table.*,
                item_invetory_table.*,
                item_planning_table.*,
                item_restriction_table.*,
                item_remarks_table.*,
                item_barcode_table.*
                
            FROM
                items_table
            LEFT JOIN
                item_purchasing_table ON items_table.item_id = item_purchasing_table.item_id
            LEFT JOIN
                item_sales_table ON items_table.item_id = item_sales_table.item_id
            LEFT JOIN
            item_invetory_table ON items_table.item_id = item_invetory_table.item_id
            LEFT JOIN
                item_planning_table ON items_table.item_id = item_planning_table.item_id
            LEFT JOIN
                item_restriction_table ON items_table.item_id = item_restriction_table.item_id
            LEFT JOIN
                item_remarks_table ON items_table.item_id = item_remarks_table.item_id
            LEFT JOIN
            item_barcode_table ON items_table.item_id = item_barcode_table.item_id
            WHERE
                items_table.item_id = $1;
        `;
        const query1 =
        `
       SELECT
           items_table.*
           FROM
           items_table
           WHERE
           items_table.item_id = $1;
           
           `
           let resultRow
        const result1 = await client.query(query1, [item_id]);
        console.log(result1.rows,"weeeeeeeee")
        if (result1.rows.length > 0) {
            // Assuming both result1 and result have only one row each
            const result1Row = result1.rows[0];
            const result = await client.query(query, [item_id]);
        
            if (result.rows.length > 0) {
           let resultRow = result.rows[0];
        
                // Assign columns from result1 to result
                for (let key in result1Row) {
                    if (result1Row.hasOwnProperty(key)) {
                        resultRow[key] = result1Row[key];
                    }
                }
        
                console.log(result.rows, "Updated result with result1 values");
            }
        
           // const result = await client.query(query, [item_id]);
            if (result.rows.length > 0) {
                console.log('Customers found:', result.rows);
                return res.status(200).send(generateResponse(true, "item fetched succesfully", 200, result.rows));
            }
            else {
                return res.status(400).send(generateResponse(false, "item not found", 400, null));
            }
        }
    }
    }
    catch (error) {
        console.log(error);
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function deleteItem(req: any, res: any) {

    try {
        await client.query('BEGIN'); // Start a transaction
        const { item_id} = req.body
        const query = `
        DELETE FROM items_table
        WHERE item_id = $1 ;`;
 if(item_id){
   
             
    const purchasingQuery = `
    DELETE FROM item_purchasing_table WHERE item_id = $1 ;
    `;

    const salesQuery = `
    DELETE FROM item_sales_table WHERE item_id = $1 ;
    `;
    
    const inventoryQuery = `
    DELETE FROM item_invetory_table WHERE item_id = $1 ;
    `;

    const planningQuery = `
    DELETE FROM item_planning_table WHERE item_id = $1 ;
    `;

    const restrictionQuery = `
    DELETE FROM item_restriction_table WHERE item_id = $1 ;
    `;

    const remarksQuery = `
    DELETE FROM item_remarks_table WHERE item_id = $1 ;
    `;
    
   
    // Use Promise.all to parallelize the execution of the two queries
  const [result] =   await Promise.all([
        client.query(purchasingQuery, [item_id]),
        client.query(salesQuery, [item_id]),
        client.query(inventoryQuery, [item_id]),
        client.query(planningQuery, [item_id]),
        client.query(remarksQuery, [item_id]),
        client.query(restrictionQuery, [item_id]),
       
    ]);
   
            if (result.rows.length==0) {

                const query = `
                DELETE FROM items_table
                WHERE item_id = $1 ;`;
                    // Execute the query with parameterized values
                    const result = await client.query(query,[item_id]);

                await client.query('COMMIT'); // Commit the transaction


                return res.status(200).send(
                    generateResponse(true, "item deleted succesfully", 200, result.rows[0])
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "item deleted unsuccesfully", 400, result)
                )
            }
        }
    }

    catch (error) {
        await client.query('ROLLBACK'); // Rollback the transaction if an error occurs
        console.log(error, "Error");

        return res.send(generateResponse(false, error.message, 400, null));
    } 
}


export async function updateBarcode(req:any, res:any){
    try{

        const barcodeData = req.body
        console.log(req.body)
          if(barcodeData){
        const adduombarcode = await  productService.additemUomBarcode(barcodeData)


            if(adduombarcode.length>0){
                return res.status(200).send(
                    generateResponse(true, "barcode added succesfully", 200, adduombarcode))
            }else{
                return res.status(400).send(
                    generateResponse(false, "barcode adding unsuccesfully", 400,null))
            }
    

        }else{
            return res.status(400).send(
                generateResponse(false, "something went wrong", 400,null))
        }

}catch(error){
    console.log(error)
                   
        return res.send(generateResponse(false, error.message, 400, null));
    }
}

export async function getProductByBarcode(req:any, res:any){

    try{
 
    const barcode = req.query.item_barcode

    if(barcode){
        const findProductByBarcode = await productService.findProductByBarcode(barcode)
            console.log(findProductByBarcode.rows)
    
        if(findProductByBarcode.rows.length>0){
            const item_id = findProductByBarcode.rows[0].item_id
            const  item_quantity = 1
            const totalAmountOfItem = findProductByBarcode.rows[0].item_unit_price
            const item_uom = findProductByBarcode.rows[0].item_uom
            const queryobj = {
                item_id:item_id,
                 item_quantity:item_quantity,
                 totalAmountOfItem:totalAmountOfItem,
                  cmr_phone_number:null
            }
              // Second query to get the total_sellable_quantity for the fetched items
    const sellableQuantityQuery = `
    SELECT
        items_table.item_id,
        COALESCE(SUM(store_inventory_item_location_table.item_quantity), 0) AS total_sellable_quantity
    FROM
        items_table
    LEFT JOIN
        items_batch_no_table ON items_table.item_id = items_batch_no_table.item_id
    LEFT JOIN
        store_inventory_item_location_table ON store_inventory_item_location_table.item_batch_number = items_batch_no_table.item_batch_number AND store_inventory_item_location_table.item_id = items_batch_no_table.item_id
    LEFT JOIN
        sublevel_bins ON store_inventory_item_location_table.to_bin_id = sublevel_bins.bin_no_id
    WHERE
        items_table.item_id = $1 
        AND (items_batch_no_table.item_exp_date IS NULL OR items_batch_no_table.item_exp_date > CURRENT_DATE)
        AND (sublevel_bins.is_expired_bin_location = false AND sublevel_bins.is_non_sellable_bin_location = false )
    GROUP BY
        items_table.item_id;
`;
let cmr_phone_number

// Execute the second query
                      let transaction_type = 'invoice_billing'
           const[getBatchNumber,getdiscount, sellableQuantities,getItemGroup] =    
            await Promise.all([
            productService.checkBatchNumberV1(item_id,item_quantity,cmr_phone_number),
            discountService.getDiscountAndTaxAmount(queryobj),
            client.query(sellableQuantityQuery,[item_id]),
            UOMGroipService.getUomGroupItemsDropdown(item_uom)
        ])
           console.log(sellableQuantities.rows,"ddddddddd")
findProductByBarcode.rows[0].total_sellable_quantity = sellableQuantities.rows[0].total_sellable_quantity
if(getItemGroup.rows.length>0){
    console.log(getItemGroup.rows)
    findProductByBarcode.rows[0].uom_dropdown= getItemGroup.rows
    findProductByBarcode.rows[0].item_uom = getItemGroup.rows[0].base_uom.name
 }
 
           console.log(getdiscount,"getdiscount",totalAmountOfItem)
            if(item_quantity>getBatchNumber.totalSellableQuantity){
                return res.status(400).send(
                    generateResponse(false, "item is not found", 400, { itemDetails: { item_sellable_quantity: getBatchNumber.totalSellableQuantity } })
                );
            } else if (getBatchNumber)
                    return res.status(200).send(
                        generateResponse(true, "item is in stock", 200, {
                            item_information:findProductByBarcode.rows[0],
                            item_fullfilled_Batches: getBatchNumber.fulfilledBatches,
                            itemBatchList:getBatchNumber.batchlist,
                            discount_details:getdiscount
                        })
                    );
                } else {
                    return res.status(400).send(
                        generateResponse(false, "item is not found", 400, { itemDetails: { item_sellable_quantity: 0 } })
                    );
                }
        }
    
    }catch(error){
        console.log(error)      
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }



}


export async function getProductScheduleList(req:any, res:any){

    const  scheduleList = [
        {
            id:"01HKCTDNDJWAHD43GSX3W5P6FQ",
            schedule: "S"
             },

         {
            id:"01HKCTDNDJWAHD43GSX3W5P6W2",
            schedule: "H"
         },  
         {
            id:"01HKCTDNDJWAHD43GSX3W5P6W2",
            schedule: "AB"
         }      
    ]

    return res.send(
        generateResponse(true, "fetched product schedule list succesfully", 200,{scheduleList:scheduleList})
    )
}

export async function getProductBatchNumberAndLocation(req: any, res: any) {

    try {

        
       
         const getProductDetails = await productService.getProductBatchNumberAndLocation(req.query.item_id)


        if (getProductDetails.rows.length>0) {
            return res.status(200).send(
                generateResponse(true, "fetching item details succesfully", 200, getProductDetails.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "fetching item details  unsuccesfully", 400,null)
            )
        }
    } catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function getitemsUombarcode(req: any, res: any) {

    try {
         const getProductDetails = await productService.getitemsUombarcode(req.query)


        if (getProductDetails) {
            return res.status(200).send(
                generateResponse(true, "fetching item details succesfully", 200, getProductDetails)
            )
        } else {
            return res.status(400).send(
                generateResponse(true, "fetching item details  unsuccesfully", 400,null)
            )
        }
    } catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}




export async function getMinimumstockquntity(req: any, res: any) {

    try {
         const getMinimumstockquntity = await productService.getMinimumstockquntity(req.query)


        if (getMinimumstockquntity) {
            return res.status(200).send(
                generateResponse(true, "fetching item details succesfully", 200, getMinimumstockquntity.rows)
            )
        } else {
            return res.status(400).send(
                generateResponse(false, "fetching item details  unsuccesfully", 400,null)
            )
        }
    } catch (error) {
        return res.status(400).send(generateResponse(false, error.message, 400, null));
    }
}

export async function deleteAlternativeItem(req: any, res: any) {

    try {
        // Start a transaction
        const { alternative_id} = req.body
        const query = `
        DELETE FROM alternative_items_table
        WHERE alternative_id = '${alternative_id}' ;`;

   
     const result = await client.query(query);

     console.log(query,result.rows)
if(result.rows.length ==0){
                return res.status(200).send(
                    generateResponse(true, "item deleted succesfully", 200, result.rows[0])
                )
            } else {
                return res.status(400).send(
                    generateResponse(false, "item deleted unsuccesfully", 400, result)
                )
            }
        }catch (error) {
       // Rollback the transaction if an error occurs
        console.log(error, "Error");

        return res.send(generateResponse(false, error.message, 400, null));
    } 
}

export async function itemInfoSync(data:any) {

    try {
    
           const itemData = data.itemData
           
           if(itemData){
            const [ ]= await Promise.all([
                productService.itemTableSync(itemData.items_table), 
                productService.itempurchasingtableSync(itemData.item_purchasing_table),
                productService.iteminvetorytableSync(itemData.item_invetory_table) ,
                productService.itemsalestableSync(itemData.item_sales_table),
                productService.itemplanningtableSync(itemData.item_planning_table) ,
                productService.itemrestrictiontableSync(itemData.item_restriction_table) ,
                productService.itemremarkstableSync(itemData.item_remarks_table) ,
            ])
           
           
        }
    }
    
    catch (error) {
        console.log(error)
        
    }
  }