import * as itemDataSyncService from '../service/itemDataSetupSyncService'
export async function itemDataSetup(data:any) {

  try {
  
         const itemData = data.itemData
         
         if(itemData){
          const [ ]= await Promise.all([
            itemDataSyncService.uomSync(itemData.unitOfMeasure), 
            itemDataSyncService.uomGroupSync(itemData.uomGroup),
            itemDataSyncService.uomGroupItemSync(itemData.uomGroupItem) ,
            itemDataSyncService.itemTypeSync(itemData.itemType) ,
            itemDataSyncService.itemCategorySync(itemData.itemCategory) ,
            itemDataSyncService.taxTypeSync(itemData.taxType) ,
            itemDataSyncService.taxCombinationSync(itemData.taxCombination),
            itemDataSyncService.taxCombinationItemSync(itemData.taxCombinationItem),
            itemDataSyncService.manufacturerSync(itemData.manufacturer) ,
            itemDataSyncService.shippingTypeSync(itemData.shippingType) ,
            itemDataSyncService.itemGroupSync(itemData.itemGroup)
          ])

         }
         
      }
  
  catch (error) {
      console.log(error)
      
  }
}