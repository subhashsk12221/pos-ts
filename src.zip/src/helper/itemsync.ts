import WebSocket from 'ws';
import * as productService from '../service/productService'
const webSocketUrl = 'wss://c50uiq5z1h.execute-api.us-east-1.amazonaws.com/dev/';


export function initializeWebSocket() {
  const socket = new WebSocket(webSocketUrl);

  socket.onopen = () => {
    console.log('Connected to WebSocket');
    socket.send(JSON.stringify({ action: 'connect', token: 'your-auth-token' }));
  };

  socket.onmessage = (event: any) => {
    console.log('Received message:', event.data);
    if(event.data){
    const data = JSON.parse(event.data)
    console.log(data, data.data ,"www")
    productService.addItemGeneralDetails(data.data)
    }
    
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };

  socket.onclose = (event) => {
    console.log('WebSocket closed:', event);
    setTimeout(initializeWebSocket, 5000); // Reconnect after 5 seconds
  };
}


