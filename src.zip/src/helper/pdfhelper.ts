import { ToWords } from 'to-words';
const toWords = new ToWords({
  localeCode: 'en-IN',
  converterOptions: {
    currency: true,
    ignoreDecimal: false,
    ignoreZeroCurrency: false,
    doNotAddOnly: false,
    currencyOptions: {
      // can be used to override defaults for the selected locale
      name: 'Rupee',
      plural: 'Rupees',
      symbol: '₹',
      fractionalUnit: {
        name: 'Paisa',
        plural: 'Paise',
        symbol: '',
      },
    },
  },
});
function calculateTotals(data: any[]): { 
  subtotal: number; 
  totalTax: number; 
  totalDiscount: number; 
  netAmount: number 
} {
  return data.reduce(
    (totals, item) => {
      const itemPriceWithoutTax = parseFloat(item.item_price_wiithout_tax || 0);
      const itemTaxAmount = parseFloat(item.item_tax_amount || 0);
      const itemDiscountAmount = parseFloat(item.item_discount_amount || 0);
      const item_total_amount = parseFloat(item.item_total_amount || 0);

      return {
        subtotal: totals.subtotal + (isNaN(itemPriceWithoutTax) ? 0 : itemPriceWithoutTax),
        totalTax: totals.totalTax + (isNaN(itemTaxAmount) ? 0 : itemTaxAmount),
        totalDiscount: totals.totalDiscount + (isNaN(itemDiscountAmount) ? 0 : itemDiscountAmount),
        netAmount: totals.netAmount + (isNaN(item_total_amount) ? 0 : item_total_amount),
      };
    },
    { subtotal: 0, totalTax: 0, totalDiscount: 0, netAmount: 0 }
  );
}

function getDeliveryItemsHTML(items: any, linkedInvoice = false) {
  return items.map((item: any, index: any) => {
    return `
      <tr>
        <td>${index + 1}</p></td>
         ${linkedInvoice ? `<td><p>${item.linked_invoice_number || "-"}</p></td>` : ""}
        <td><p>${item.item_mfg_date ? item.item_mfg_date : '-'}</p></td>
        <td><p>${item.item_code ? item.item_code : '-'}</p></td>
        <td><p>${item.item_name ? item.item_name : '-'}</p></td>
        <td><p>${item.item_batch_number ? item.item_batch_number : '-'}</p></td>
        <td><p>${item.item_exp_date ? new Date(item.item_exp_date).toISOString().split('T')[0] : '-'}</p></td>
        <td colspan="2"><p>${item.item_pack_size ? item.item_pack_size : '-'}</p></td>
        <td><p>${item.item_quantity ? item.item_quantity : '-'}</p></td>
        <td colspan="2"><p>${item.item_unit_price ? item.item_unit_price : '-'}</p></td>
        <td><p>${item.item_total_tax_percentage || (item.item_gst || "-")}</p></td>
        <td><p>${item.item_tax_amount ? (item.item_tax_amount / 2).toFixed(2) : '-'}</p></td>
        <td><p>${item.item_tax_amount ? (item.item_tax_amount / 2).toFixed(2) : '-'}</p></td>
        <td><p>${item.item_discount_percentage ? item.item_discount_percentage : '-'}</p></td>
        <td><p>${item.item_total_amount ? item.item_total_amount : '-'}</p></td>
      </tr>
    `;
  }).join('');
}

function getDeliveryItemsHTML_1(items: any, linkedInvoice = false) {
  return items.map((item: any, index: any) => {
    return `
      <tr>
      <td colspan="1">${index + 1}</td>
      ${linkedInvoice ? `<td>${item.linked_invoice_number || "-"}</td>` : ""}
      <td colspan="1">${item.item_manufacturer_name ? item.item_manufacturer_name : '-'}</td>
      <td colspan="1">${item.item_hsn ? item.item_hsn : '-'}</td>
      <td colspan="3">${item.item_name ? item.item_name : '-'} </td>
      <td colspan="2">${item.item_batch_number ? item.item_batch_number : '-'}</td>
      <td colspan="1">${item.item_exp_date ? 
        new Date(item.item_exp_date).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' }).replace(/-/g, '/') 
        : '-'}</td>
      <td colspan="1" class="right">${item.item_pack_size ? item.item_pack_size : '-'}</td>
      <td colspan="1" class="right">${item.item_quantity ? item.item_quantity : '-'}</td>
      <td colspan="2" class="right">${item.item_unit_price ? item.item_unit_price : '-'}</td>
      <td colspan="1" class="right">${item.item_total_tax_percentage || (item.item_gst || "-")}</td>
      <td colspan="1" class="right">${item.item_tax_amount ? (item.item_tax_amount / 2).toFixed(2) : '-'}</td>
      <td colspan="1" class="right">${item.item_tax_amount ? (item.item_tax_amount / 2).toFixed(2) : '-'}</td>
      <td colspan="1" class="right">${item.item_discount_percentage ? item.item_discount_percentage : '-'}</td>
      <td colspan="2" class="right">${item.item_total_amount ? item.item_total_amount : '-'}</td>
    </tr>
    `;
  }).join('');
}



async function CNItems(array: any) {
  return array
    .map((item: any, index: any) =>
      item.itemBatchData?.map((batch: any, index_b: any) => `
        <tr>
          <td>${index_b + 1}</td>
          <td>${item.item_name || "-"}</td>
          <td>${item.item_pack_size || "-"}</td>
          <td>${item.item_hsn !== "null" && item.item_hsn ? item.item_hsn : "-"}</td>
          <td>${batch.item_batch_number || item.item_batch_number || "-"}</td>
          <td>${batch.item_exp_date 
            ? new Date(batch.item_exp_date).toISOString().split('T')[0] 
            : item.item_exp_date 
              ? new Date(item.item_exp_date).toISOString().split('T')[0] 
              : "-"
          }</td>
          <td>${batch.item_batch_quantity || item.item_batch_quantity || item.item_quantity || "-"}</td>
          <td>${batch.item_batch_unit_price || item.item_unit_price || "-"}</td>
          <td>${batch.item_batch_discount_amount || item.item_discount_amount || "-"}</td>
          <td>${batch.item_batch_total_purchase_rate && batch.item_batch_tax_amount
            ? (parseFloat(batch.item_batch_total_purchase_rate) - parseFloat(batch.item_batch_tax_amount)).toFixed(2)
            : item.item_tax_amount 
              ? (parseFloat(item.item_unit_price) - parseFloat(item.item_tax_amount)).toFixed(2)
              : "-"
          }</td>
          <td>${item.item_cgst || "0.00"}</td>
          <td>${item.item_sgst || "0.00"}</td>
          <td>${item.item_igst || "0.00"}</td>
          <td>${item.item_cess || "0.00"}</td>
        </tr>
      `)
    )
    .flat()
    .join('');
}


async function GrnItems(array: any) {
  return array
    .map((item: any, index: any) =>
      item.itemBatchData?.map((batch: any, index_b: any) => `
        <tr>
          <td>${index_b + 1}</td>
          <td>${item.item_code || "-"}</td>
          <td>${item.item_hsn !== "null" && item.item_hsn ? item.item_hsn : "-"}</td>
          <td>${item.item_name || "-"}</td>
          <td>${item.item_uom || "-"}</td>
          <td>${batch?.item_batch_number || "-"}</td>
          <td>${batch?.item_exp_date ? new Date(batch.item_exp_date).toISOString().split('T')[0] : "-"}</td>
          <td>${batch?.item_sellable_quantity || batch?.item_batch_quantity || "0"}</td>
          <td>${batch?.item_batch_purchase_rate || "0.00"}</td>
          <td>${batch?.item_batch_unit_price || "0.00"}</td>
          <td>${batch?.item_batch_discount_amount || "0.00"}</td>
          <td>${batch?.item_batch_total_sales_rate||(batch?.item_batch_total_purchase_rate && batch?.item_batch_tax_amount 
            ? (parseFloat(batch.item_batch_total_purchase_rate) - parseFloat(batch.item_batch_tax_amount)).toFixed(2)
            : "-")
          }</td>
          <td>${batch?.item_batch_tax_amount || "0.00"}</td>
          <td>${batch?.item_batch_total_purchase_rate || batch?.item_batch_total_sales_rate || "0.00"}</td>
        </tr>
      `)
    )
    .flat()
    .join('');
}

//grn,purchaase invoie
export async function GRN(resultArray: any, storeDetailsResult: any, taxdetails:any,name: string = "GRN") {
  const html = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      body {
        font-family: "Courier New", Courier, monospace;
      }
      table {
        border-collapse: collapse;
        width: 100%;
        margin: 0;
      }
      td {
        border: 1px solid black;
      }
    </style>
  </head>
  <body>
    <table>
      <tr>
        <td colspan="14" style="text-align: center;">
          <b>${name === "GRN" ? "Goods Recipient Note" : "Purchase Invoice"}</b>
        </td>
      </tr>
      <tr>
        <td colspan="7">
          From,<br/>
          <b>${storeDetailsResult[0]?.company || "-"}</b><br/>
          ${storeDetailsResult[0]?.company_address || "-"}
        </td>
        <td colspan="7">
          <table>
            <tr>
              <td>${name === "GRN" ?`GRN No: ${resultArray[0]?.orderData?.inv_no || "-"}`:`Bill No: ${resultArray[0]?.orderData?.inv_no || "-"}`}</td>
              <td>${name === "GRN"?"GRN Date":"Bill Date"}:${resultArray[0]?.orderData?.document_date ? new Date(resultArray[0]?.orderData?.document_date).toLocaleDateString('en-GB') : "-"}</td>
            </tr>
            <tr>
              <td colspan="2">
                To,<br/>
                <b>${resultArray[0]?.orderData?.cmr_name || "-"}<br/>
                StoreCode: ${resultArray[0]?.orderData?.store_id || "-"}</b><br/>
                Address: ${
                  name === "GRN"
                    ? resultArray[0]?.orderData?.gort_billing_address || "-"
                    : resultArray[0]?.orderData?.poit_billing_address || "-"
                }<br/>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td><b>#</b></td>
        <td><b>ProductCode</b></td>
        <td><b>HsnCode</b></td>
        <td><b>ProductName</b></td>
        <td><b>UomName</b></td>
        <td><b>BatchNo</b></td>
        <td><b>Exp</b></td>
        <td><b>Qty</b></td>
        <td><b>Rate</b></td>
        <td><b>MRP</b></td>
        <td><b>DiscAmt</b></td>
        <td><b>Subtotal</b></td>
        <td><b>TaxAmount</b></td>
        <td><b>TaxAmount</b></td>
      </tr>
      ${await GrnItems(resultArray[0]?.itemData || [])}
      <tr>
        <td colspan="11" rowspan="5">
         <table style="width: 50%;">
  <tr>
    <td><b>GST%</b></td>
    <td><b>Taxable</b></td>
    <td><b>SGST</b></td>
    <td><b>CGST</b></td>
    <td><b>IGST</b></td>
  </tr>
  ${taxdetails
    .map((item:any) => {
      console.log(item);
      const gst = item.item_gst || "-";
      const taxable = item.taxable || "-";
      const sgst = item.sgst || "-";
      const cgst = item.gst || "-";
      const igst = item.igst || "-";
      console.log("cgst"+cgst);
      return `
        <tr>
          <td>${gst}</td>
          <td>${taxable}</td>
          <td>${sgst}</td>
          <td>${cgst}</td>
          <td>${igst}</td>
        </tr>`;
    })
    .join('')}
</table>
        </td>
        <td colspan="2">GrossTotal:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.gort_sub_total || "-"
              : resultArray[0]?.orderData?.poit_sub_total || "-"
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">TaxAmount:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.gort_total_gst || "-"
              : resultArray[0]?.orderData?.poit_total_gst || "-"
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">Discount:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.gort_total_discount || "-"
              : (
                  resultArray[0]?.orderData?.poit_total_amount -
                  resultArray[0]?.orderData?.poit_sub_total -
                  resultArray[0]?.orderData?.poit_total_gst
                ).toFixed(2) || "-"
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">OtherCharge:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.gort_other_charges || "-"
              : resultArray[0]?.orderData?.poit_other_charges || "-"
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">TotalAmount:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.gort_total_amount || "-"
              : resultArray[0]?.orderData?.poit_total_amount || "-"
          }
        </td>
      </tr>
      <tr>
        <td colspan="14">Remarks:${resultArray[0]?.orderData?.remarks || "-"}</td>
      </tr>
      <tr>
        <td colspan="14" style="height: 100px;"></td>
      </tr>
      <tr>
        <td colspan="14" style="text-align: right;">
          for, ${resultArray[0]?.orderData?.cmr_name || "-"}<br/>
          AuthorisedSignature
        </td>
      </tr>
    </table>
  </body>
</html>`.trim();

  return html;
}

//billing
export function Invoice(resultArray: any, storeDetailsResult: any) {
  // Ensure all values are handled with defaults for null or undefined
  const totals =calculateTotals(resultArray[0].itemData);
  return `
    <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Invoice Table</title>
  <style>
    body {
      font-family: "Courier New", Courier, monospace;
    }
    table {
    width: 100%;
    border-collapse: collapse;
  }

      table,
      th,
      td {
          border: 1px solid gray;
          text-align: left;
          padding: 3px;
      }

      th {
          background-color: #f2f2f2;
      }

      .center {
          text-align: center;
      }

      p {
          margin: 0;
          padding: 0;
      }

      .center{
        text-align: center;
      }

      .inner,.inner td,.inner th{
        border: none;
      }
      .left{
        text-align: left;
      }
      .right{
        text-align: right;
      }
      .bottom{
        vertical-align: bottom;
      }
  </style>
</head>
<body>
<table>
<tr>
      <td colspan="6" rowspan="2" >
        <table class="inner">
          <tr>
            <td class="limited-width">
              <b>${storeDetailsResult[0]?.company || "-"}</b><br/>
              <b>Store Code: ${storeDetailsResult[0]?.store_code || "-"}</b><br/>
              ${storeDetailsResult[0]?.company_address || "-"}<br/>
              <b>Phone No:</b> ${storeDetailsResult[0]?.company_telephone1 || "-"}<br/>
              <b>FSSAI No:</b> ${storeDetailsResult[0]?.fssai_no || "-"}
          </td>          
            <td style="justify-content: flex-start;display: flex;">
              <img src="${storeDetailsResult[0]?.company_logo.replace(/ /g, '%20')}" alt="Store Logo"
                            style="width: 50px; height: auto;">
            </td>
          </tr>
        </table>
      </td>
      <td colspan="2" class="center">
        <b>
            CASH MEMO<br/>
            ORIGINAL<br/>
            GST INVOICE<br/>
        </b>
      </td>
      <td colspan="13">
        <b>GST No:</b> ${storeDetailsResult[0]?.company_gstn || "-"}<br/>
        <b>Pan No:</b> ${storeDetailsResult[0]?.company_pan || "-"}<br/>
        <b>DL.No:</b> ${storeDetailsResult[0]?.company_licence || "-"}<br/>
      </td>
    </tr>
        <tr>
        <td rowspan="2" colspan="6" class="bottom">
            <b>Mob no:</b> ${resultArray[0]?.orderData?.cmr_phone_number || "-"}
        </td>
        <td rowspan="2" colspan="6" class="bottom">
            <b>Area:</b> ${resultArray[0]?.orderData?.cmr_area || "-"}
        </td>
    </tr>
    <tr>
      <td colspan="6">
          <b>Customer Name:</b> ${resultArray[0]?.orderData?.cmr_first_name ? 
            (resultArray[0]?.orderData?.cmr_last_name ? 
              resultArray[0].orderData.cmr_first_name + " " + resultArray[0].orderData.cmr_last_name : 
              resultArray[0].orderData.cmr_first_name) : 
            "-"}
      </td>
    </tr>
    <tr>
      <td colspan="6">
          <b>Dr Name:</b> ${resultArray[0]?.orderData?.cmr_doctor_name || "-"}
      </td>
      <td colspan="6">
          <b>Gst No:</b> ${resultArray[0]?.orderData?.cmr_gst_number || "-"}
      </td>
      <td rowspan="2" colspan="6">
          <b>Address:</b> ${resultArray[0]?.orderData?.cmr_state || "-"}
      </td>
    </tr>
    <tr>
      <td colspan="3">
              <b>Inv No.:</b>${resultArray[0]?.orderData?.invoice_number || "-"}
      </td>
      <td colspan="3">
          <b>Inv Date.:</b>${new Date(resultArray[0]?.orderData?.update_date).toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(',', '/').replace(/ /g, '')}
      </td>
      <td colspan="6">
        <b>Pan No:</b> ${resultArray[0]?.orderData?.cmr_pan || "-"}
      </td>
    </tr>
    <tr>
      <td colspan="1"><b>S.no</b></td>
      <td colspan="1"><b>Mfg</b></td>
      <td colspan="1" class="center"><b>HSN</b></td>
      <td colspan="3"><b>Product name</b></td>
      <td colspan="2"><b>Batch no</b></td>
      <td colspan="1"><b>Exp</b></td>
      <td colspan="1"><b>Pack</b></td>
      <td colspan="1" class="center"><b>Qty</b></td>
      <td colspan="2" class="center"><b>MRP</b></td>
      <td colspan="1" class="center"><b>Gst</b><br/>
          <b>(%)</b>
      </td>
      <td colspan="1" class="center"><b>SGST<br/>
             (Amt)</b>
      </td>
      <td colspan="1" class="center"><b>CGST<br/>
             (Amt)</b> 
      </td>
      <td colspan="1" class="center"><b>DISC<br/>
              (%)</b>
      </td>
      <td colspan="3" class="center"><b>Amt</b></td>
    </tr>
    ${getDeliveryItemsHTML_1(resultArray[0]?.itemData || [])}
    <tr>
      <td rowspan="4" colspan="6">
      ${resultArray[0]?.orderData?.sot_remarks || "-"}
      </td>
      <td colspan="3" class="right">
          <b>Disc Amt:</b>
      </td>
      <td colspan="5" class="right">
      ${totals.totalDiscount.toFixed(2)}
      </td>
      <td colspan="2" class="right">
          <b>Gross:</b>
      </td>
      <td colspan="5" class="right">
      ${totals.subtotal.toFixed(2)}
      </td>
    </tr>
    <tr>
      <td colspan="3" class="right">
          <b>Other Charges:</b>
      </td>
      <td colspan="5" class="right">
          0.00
      </td>
      <td colspan="2" class="right">
          <b>Total Tax:</b>
      </td>
      <td colspan="3" class="right">
      ${totals.totalTax.toFixed(2)}
      </td>
  </tr>
    <tr>
      <td colspan="8"></td>
      <td colspan="2" class="right">
          <b>Disc Amt:</b>
      </td>
      <td colspan="3" class="right">
      ${totals.totalDiscount.toFixed(2)}
      </td>
    </tr>
    <tr>
      <td colspan="8"></td>
      <td colspan="2" class="right">
          <b>Round Off:</b>
      </td>
      <td colspan="3" class="right">
          ${Math.ceil(totals.netAmount)-totals.netAmount}
      </td>
    </tr>
    <tr>
      <td colspan="6">
          FOR: ${storeDetailsResult[0]?.company || "-"}
      </td>
      <td colspan="8">
      ${toWords.convert(Math.ceil(totals.netAmount))}
      </td>
      <td colspan="2" class="right"><b>Net:</b></td>
      <td colspan="3" class="right">${Math.ceil(totals.netAmount).toFixed(2)}</td>
    </tr>
    <tr>
      <td colspan="6" style="border-right: none;border-bottom: none;">
          <u>Terms & Conditions :</u><br> 
          - The medicine is dispensed as per prescription only.<br>
          -All prices of the medicines are inclusive of all Taxes.<br>
          Return Policy:<br>
          - Full strip only can be returned.<br>
          - Bill and prescription are necessary.<br>
          - Medicines requiring refrigeration cannot be returned.<br>
          - No return can be made on Sundays.<br>
          - Return must be made within 7 days of purchase<br>
      </td>
    </tr>
    <tr>
      <td colspan="21" style="text-align: right;border-top: none;">
        Pharmacist Signature
      </td>
    </tr>
  </table>
    
    
    </div>
</body>
</html>
  `;
}

//credit note
export async function CreditNote(resultArray: any, storeDetailsResult: any) {
  const orderData = resultArray[0]?.orderData || {};
  const storeData = storeDetailsResult[0] || {};

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Credit Note</title>
        <style>
            table {
                border-collapse: collapse;
                width: 100%;
                margin: 0;
            }
            td {
                border: 1px dashed black;
            }
            .nested td {
                border: 0;
            }
            .nested_1 td {
                border: 1px solid black;
            }
        </style>
    </head>
    <body>
        <table>
            <tr>
                <td colspan="14">
                    <table>
                        <tr>
                            <td style="border: 0; text-align: left;">
                                <iframe src="${storeData.company_logo.replace(/ /g, '%20') || ''}" 
                                    width="100" height="50" frameborder="0" scrolling="no" title="Store logo"></iframe>
                            </td>
                            <td style="border: 0; text-align: center;">
                                <b>${storeData.company || "-"}</b><br>
                                <b>Store code: ${storeData.store_code || "-"}</b><br>
                                ${storeData.company_address || "-"}<br>
                                GST No.: ${storeData.company_gstn || "-"}<br>
                                DL No.: ${storeData.company_licence || "-"}<br>
                                Contact: ${storeData.company_telephone1 || "-"}<br>
                                Email: ${storeData.company_email || "-"}<br>
                                <b>Sales Credit Note</b>
                            </td>
                            <td style="border: 0; text-align: right;">
                                <iframe src="https://zotanextech-my.sharepoint.com/personal/lravva_zotanextech_com/_layouts/15/embed.aspx?UniqueId=77454602-2f76-4ecf-8920-67006a569cf4"
                                    width="100" height="50" frameborder="0" scrolling="no" title="Zota Logo"></iframe>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="7">
                    <table class="nested">
                        <tr><td>Store Code:</td><td>${orderData.store_id || "-"}</td></tr>
                        <tr><td>Sales Invoice No:</td><td>${orderData.inv_no || "-"}</td></tr>
                        <tr><td>Patient Name:</td><td>${orderData.cmr_name || "-"}</td></tr>
                        <tr><td>Patient Mob:</td><td>${orderData.cmr_phone_number || "-"}</td></tr>
                    </table>
                </td>
                <td colspan="7">
                    <table class="nested">
                        <tr><td>Credit Note No:</td><td>${orderData.note_no || "-"}</td></tr>
                        <tr><td>Date:</td><td>${orderData.sct_document_date
                          ? new Date(orderData.sct_document_date).toLocaleDateString('en-GB')
                          : "-"}</td></tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td><b>#</b></td>
                <td><b>Product</b></td>
                <td><b>Pack Size</b></td>
                <td><b>Hsn Code</b></td>
                <td><b>Batch No</b></td>
                <td><b>Exp</b></td>
                <td><b>Qty</b></td>
                <td><b>MRP</b></td>
                <td><b>Disc Amt</b></td>
                <td><b>Amount</b></td>
                <td><b>CGST</b></td>
                <td><b>SGST</b></td>
                <td><b>IGST</b></td>
                <td><b>CESS</b></td>
            </tr>
            ${await CNItems(resultArray[0]?.itemData || [])}
            <tr>
                <td colspan="7" rowspan="8">
                    <table style="width: 50%;" class="nested_1">
                        <tr><td colspan="4">Tax Details</td></tr>
                        <tr>
                            <td><b>Tax Type</b></td>
                            <td><b>Amount</b></td>
                            <td><b>Tax %</b></td>
                            <td><b>Tax Total</b></td>
                        </tr>
                        <tr><td>CGST</td><td>${orderData.sct_sub_total || "0.00"}</td><td>-</td><td>${((orderData.sct_total_gst || 0) / 2).toFixed(2)}</td></tr>
                        <tr><td>SGST</td><td>${orderData.sct_sub_total || "0.00"}</td><td>-</td><td>${((orderData.sct_total_gst || 0) / 2).toFixed(2)}</td></tr>
                        <tr><td colspan="2"></td><td>Total:</td><td>${orderData.sct_total_gst || "0.00"}</td></tr>
                    </table>
                </td>
                <td colspan="4" style="text-align: right;">Total Amount:</td>
                <td colspan="3" style="text-align: right; font-weight: bold;">${orderData.sct_total_amount || "0.00"}</td>
            </tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">CGST:</td><td colspan="3" style="text-align: right;">${((orderData.sct_total_gst || 0) / 2).toFixed(2)}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">SGST:</td><td colspan="3" style="text-align: right;">${((orderData.sct_total_gst || 0) / 2).toFixed(2)}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">IGST:</td><td colspan="3" style="text-align: right;">${orderData.sct_total_IGST || "0.00"}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">CESS:</td><td colspan="3" style="text-align: right;">${orderData.sct_total_CESS || "0.00"}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">Disc. Amt:</td><td colspan="3" style="text-align: right;">${orderData.sct_total_discount || "0.00"}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">Round Off:</td><td colspan="3" style="text-align: right;">${(Math.ceil(orderData.sct_total_amount || 0) - (orderData.sct_total_amount || 0)).toFixed(2)}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">Net Amount:</td><td colspan="3" style="text-align: right;">${Math.ceil(orderData.sct_total_amount || 0)}</td></tr>
            <tr><td colspan="14" style="text-align: right; border-bottom: 0;">For, ${orderData.cmr_name || "-"}</td></tr>
            <tr><td colspan="14" style="border-bottom: 0; border-top: 0;"><br><br><br><br></td></tr>
            <tr><td colspan="14" style="text-align: right; border-top: 0;">Authorised Signature</td></tr>
        </table>
    </body>
    </html>
  `;
}

//debit note
export async function DebitNote(resultArray: any, storeDetailsResult: any) {
  const orderData = resultArray[0]?.orderData || {};
  const storeData = storeDetailsResult[0] || {};
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Credit Note</title>
        <style>
            table {
                border-collapse: collapse;
                width: 100%;
                margin: 0;
            }
            td {
                border: 1px dashed black;
            }
            .nested td {
                border: 0;
            }
            .nested_1 td {
                border: 1px solid black;
            }
        </style>
    </head>
    <body>
        <table>
            <tr>
                <td colspan="14">
                    <table>
                        <tr>
                            <td style="border: 0; text-align: left;">
                                <iframe src="${storeData.company_logo.replace(/ /g, '%20') || ''}" 
                                    width="100" height="50" frameborder="0" scrolling="no" title="Davaindia logo"></iframe>
                            </td>
                            <td style="border: 0; text-align: center;">
                                <b>${storeData.company || "-"}</b><br>
                                <b>Store code: ${storeData.store_id || "-"}</b><br>
                                ${storeData.company_address || "-"}<br>
                                GST No.:  ${storeData.company_gstn || "-"}<br>
                                DL No.: ${storeData.company_licence || "-"}<br>
                                Contact:  ${storeData.company_telephone1 || "-"}<br>
                                Email:  ${storeData.company_email || "-"}<br>
                                <b>Credit Note</b>
                            </td>
                            <td style="border: 0; text-align: right;">
                                <iframe src="https://zotanextech-my.sharepoint.com/personal/lravva_zotanextech_com/_layouts/15/embed.aspx?UniqueId=77454602-2f76-4ecf-8920-67006a569cf4"
                                    width="100" height="50" frameborder="0" scrolling="no" title="Zota Logo"></iframe>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="7">
                    <table class="nested">
                        <tr><td>Store Code:</td><td>${orderData.store_id || "-"}</td></tr>
                        <tr><td>Sales Invoice No:</td><td>${orderData.inv_no || "-"}</td></tr>
                        <tr><td>Patient Name:</td><td>${orderData.cmr_name || ""}</td></tr>
                        <tr><td>Patient Mob:</td><td>${orderData.cmr_phone_number || ""}</td></tr>
                    </table>
                </td>
                <td colspan="7">
                    <table class="nested">
                        <tr><td>Credit Note No:</td><td>${orderData.note_no || ""}</td></tr>
                        <tr><td>Date:</td><td>${orderData.pct_document_date ? new Date(orderData.sct_document_date).toLocaleDateString('en-GB')
                          : "-"}</td></tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td><b>#</b></td>
                <td><b>Product</b></td>
                <td><b>Pack Size</b></td>
                <td><b>Hsn Code</b></td>
                <td><b>Batch No</b></td>
                <td><b>Exp</b></td>
                <td><b>Qty</b></td>
                <td><b>MRP</b></td>
                <td><b>Disc Amt</b></td>
                <td><b>Amount</b></td>
                <td><b>CGST</b></td>
                <td><b>SGST</b></td>
                <td><b>IGST</b></td>
                <td><b>CESS</b></td>
            </tr>
            ${await CNItems(resultArray[0].itemData)}
            <tr>
                <td colspan="7" rowspan="8">
                    <table style="width: 50%;" class="nested_1">
                        <tr><td colspan="4">Tax Details</td></tr>
                        <tr>
                            <td><b>Tax Type</b></td>
                            <td><b>Amount</b></td>
                            <td><b>Tax %</b></td>
                            <td><b>Tax Total</b></td>
                        </tr>
                        <tr><td>CGST</td><td>${orderData.pct_sub_total || "0.00"}</td><td>-</td><td>${(orderData.pct_total_gst || 0) / 2}</td></tr>
                        <tr><td>SGST</td><td>${orderData.pct_sub_total || "0.00"}</td><td>-</td><td>${(orderData.pct_total_gst || 0) / 2}</td></tr>
                        <tr><td colspan="2"></td><td>Total:</td><td>${orderData.pct_total_gst || "0.00"}</td></tr>
                    </table>
                </td>
                <td colspan="4" style="text-align: right;">Total Amount:</td>
                <td colspan="3" style="text-align: right; font-weight: bold;">${orderData.pct_total_amount || "0.00"}</td>
            </tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">CGST:</td><td colspan="3" style="text-align: right;">${(orderData.pct_total_gst || 0) / 2}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">SGST:</td><td colspan="3" style="text-align: right;">${(orderData.pct_total_gst || 0) / 2}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">IGST:</td><td colspan="3" style="text-align: right;">${orderData.pct_total_IGST || "0.00"}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">CESS:</td><td colspan="3" style="text-align: right;">${orderData.pct_total_CESS || "0.00"}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">Disc. Amt:</td><td colspan="3" style="text-align: right;">${orderData.pct_total_discount || "0.00"}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">Round Off:</td><td colspan="3" style="text-align: right;">${Math.ceil(orderData.pct_total_amount || 0) - (orderData.pct_total_amount || 0)}</td></tr>
            <tr><td colspan="4" style="text-align: right; font-weight: bold;">Net Amount:</td><td colspan="3" style="text-align: right;">${Math.ceil(orderData.pct_total_amount || 0)}</td></tr>
            <tr><td colspan="14" style="text-align: right; border-bottom: 0;">For, ${orderData.cmr_name || "-"}</td></tr>
            <tr><td colspan="14" style="border-bottom: 0; border-top: 0;"><br><br><br><br></td></tr>
            <tr><td colspan="14" style="text-align: right; border-top: 0;">Authorised Signature</td></tr>
        </table>
    </body>
    </html>
  `;
}
//DN,Sales order invoice
export async function DN(resultArray: any, storeDetailsResult: any,taxdetails:any, name: string = "GRN") {
  const html = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      body {
        font-family: "Courier New", Courier, monospace;
      }
      table {
        border-collapse: collapse;
        width: 100%;
        margin: 0;
      }
      td {
        border: 1px solid black;
      }
    </style>
  </head>
  <body>
    <table>
      <tr>
        <td colspan="14" style="text-align: center;">
          <b>${name === "GRN" ? "Delivery Note" : "Sales Invoice"}</b>
        </td>
      </tr>
      <tr>
        <td colspan="7">
          From,<br/>
          <b>${storeDetailsResult[0]?.company || "-"}</b><br/>
          ${storeDetailsResult[0]?.company_address || "-"}
        </td>
        <td colspan="7">
          <table>
             <tr>
              <td>${name === "GRN" ?`GRN No: ${resultArray[0]?.orderData?.inv_no || "-"}`:`Bill No: ${resultArray[0]?.orderData?.inv_no || "-"}`}</td>
              <td>${name === "GRN"?"GRN Date":"Bill Date"}:${resultArray[0]?.orderData?.document_date ? new Date(resultArray[0]?.orderData?.document_date).toLocaleDateString('en-GB') : "-"}</td>
            </tr>
            <tr>
              <td colspan="2">
                To,<br/>
                <b>${resultArray[0]?.orderData?.cmr_name || "-"}<br/>
                StoreCode: ${resultArray[0]?.orderData?.store_id || "-"}</b><br/>
                Address: ${
                  name === "GRN"
                    ? resultArray[0]?.sodtt_billing_address || "-"
                    : resultArray[0]?.soit?.soit_billing_address || "-"
                }<br/>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td><b>#</b></td>
        <td><b>ProductCode</b></td>
        <td><b>HsnCode</b></td>
        <td><b>ProductName</b></td>
        <td><b>UomName</b></td>
        <td><b>BatchNo</b></td>
        <td><b>Exp</b></td>
        <td><b>Qty</b></td>
        <td><b>Rate</b></td>
        <td><b>MRP</b></td>
        <td><b>DiscAmt</b></td>
        <td><b>Subtotal</b></td>
        <td><b>TaxAmount</b></td>
        <td><b>Total Amount</b></td>
      </tr>
      ${await GrnItems(resultArray[0]?.itemData || [])}
      <tr>
        <td colspan="11" rowspan="5">
          <table style="width: 50%;">
            <tr>
              <td><b>GST%</b></td>
              <td><b>Taxable</b></td>
              <td><b>SGST</b></td>
              <td><b>CGST</b></td>
              <td><b>IGST</b></td>
            </tr>
  ${taxdetails
    .map((item:any) => {
      console.log(item);
      const gst = item.item_gst || "-";
      const taxable = item.taxable || "-";
      const sgst = item.sgst || "-";
      const cgst = item.gst || "-";
      const igst = item.igst || "-";
      console.log("cgst"+cgst);
      return `
        <tr>
          <td>${gst}</td>
          <td>${taxable}</td>
          <td>${sgst}</td>
          <td>${cgst}</td>
          <td>${igst}</td>
        </tr>`;
    })
    .join('')}
          </table>
        </td>
        <td colspan="2">GrossTotal:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.sodtt_sub_total || "0.00"
              : resultArray[0]?.orderData?.soit_sub_total || "0.00"
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">TaxAmount:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.sodtt_total_gst || "0.00"
              : resultArray[0]?.orderData?.soit_total_gst || "0.00"
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">Discount:</td>
        <td>
          ${
            name === "GRN"
              ? (resultArray[0]?.orderData?.sodtt_total_discount || 0)
              : (resultArray[0]?.orderData?.soit_total_discount || 0)
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">OtherCharge:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.sodtt_other_charges || "0.00"
              : resultArray[0]?.orderData?.soit_other_charges || "0.00"
          }
        </td>
      </tr>
      <tr>
        <td colspan="2">TotalAmount:</td>
        <td>
          ${
            name === "GRN"
              ? resultArray[0]?.orderData?.sodtt_total_amount || "0.00"
              : resultArray[0]?.orderData?.soit_total_amount || "0.00"
          }
        </td>
      </tr>
      <tr>
        <td colspan="14">Remarks: ${resultArray[0]?.orderData?.remarks || ""}</td>
      </tr>
      <tr>
        <td colspan="14" style="height: 100px;"></td>
      </tr>
      <tr>
        <td colspan="14" style="text-align: right;">
          for, ${resultArray[0]?.orderData?.cmr_name || "-"}<br/>
          Authorised Signature
        </td>
      </tr>
    </table>
  </body>
</html>`.trim();

  return html;
}

export async function ReturnInvoice(resultArray: any, storeDetailsResult: any) {
  // Ensure all values are handled with defaults for null or undefined
  const totals =calculateTotals(resultArray[0].itemData);
  return `
    <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Invoice Table</title>
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
      heigth:100%;
    }
    table, th, td {
      border: 1px solid black;
      text-align: left;
      padding: 3px;
    }
    th {
      background-color: #f2f2f2;
    }
    .center {
      text-align: center;
    }
    p {
      margin:0;
      padding:0;
    }
  </style>
</head>
<body>
  <div><table><tbody><tr><td rowspan="2" colspan="4" style="position: relative;"><img src="${storeDetailsResult[0]?.company_logo.replace(/ /g, '%20')}" alt="Store Logo" style="position: absolute; top: 10px; right: 10px; width: 50px; height: auto;">
  <p><b>${storeDetailsResult[0]?.company || "-"}</b></p>
  <p><b>Store code:</b> ${storeDetailsResult[0]?.store_id || "-"}</p>
  <p>${storeDetailsResult[0]?.company_address || "-"}</p>
  <p><b>Phone number:</b> ${storeDetailsResult[0]?.company_telephone1 || "-"}</p>
  <p><b>FSSAI NO:</b> ${storeDetailsResult[0]?.fssai_no || "-"}</p></td><td colspan="2" class="center"><b><p>CASH MEMO</p>
  
  <p>ORIGINAL</p>
  
  <p>RETURN INVOICE</p></b></td><td colspan="11"><p><b>GST No:</b>${storeDetailsResult[0]?.company_gstn || "-"}</p>
  
  <p><b>Pan No:</b>${storeDetailsResult[0]?.company_pan || "-"}</p>
  
  <p><b>Dl No:</b>${storeDetailsResult[0]?.company_licence || "-"}</p></td></tr>
  <tr><td rowspan="2" colspan="6"><p><b>Mob no:</b> ${resultArray[0]?.orderData?.cmr_phone_number || "-"}</p></td><td rowspan="2" colspan="7"><p><b>Area:</b> ${resultArray[0]?.orderData?.cmr_area || "-"}</p></td></tr>
  <tr><td colspan="4"><p><b>Customer name:</b>${resultArray[0]?.orderData?.cmr_first_name ? 
    (resultArray[0]?.orderData?.cmr_last_name ? 
      resultArray[0].orderData.cmr_first_name + " " + resultArray[0].orderData.cmr_last_name : 
      resultArray[0].orderData.cmr_first_name) : 
    "-"}</p></td></tr>
  <tr><td colspan="4"><p><b>Dr Name:</b> ${resultArray[0]?.orderData?.cmr_doctor_name || "-"}</p></td><td colspan="4"><p><b>Gst no:</b> ${resultArray[0]?.orderData?.cmr_gst_number || "-"}</p></td><td rowspan="2" colspan="9"><p><b>Address:</b> ${resultArray[0]?.orderData?.cmr_state || "-"}</p></td></tr>
  <tr><td colspan="3"><b><p>Return Inv No:</b> ${resultArray[0]?.orderData?.invoice_number || "-"}</p></td><td><p><b>Inv Date/Time:</b>${new Date(resultArray[0]?.orderData?.update_date).toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(',', '/').replace(/ /g, '')}</p>
  </td><td colspan="4"><p><b>Pan no:</b>${resultArray[0]?.orderData?.cmr_pan || "-"}</p></td></tr>
    <tr><b><td><p><b>S.no</b></p></td><td><p><b>Linked Invoice</b></p></td><td><p><b>Mfg</b></p></td><td><p><b>Item Code</b></p></td><td><p><b>Product name</b></p></td><td><p><b>Batch no</b></p></td><td><p><b>Exp</b></p></td><td colspan="2"><p><b>Pack</b></p></td><td><p><b>Qty</b></p></td><td colspan="2"><p><b>MRP</b></p></td><td><p><b>Gst</b></p><p><b>(%)</b></p></td><td><b><p>SGST</p><p>(Amt)</p></b></td><td><b><p>CGST</p><p>(Amt)</p></b></td><td><b><p>DISC</p><p>(%)</p></b></td><td><p><b>Amt</b></p></td></b></tr>
    ${getDeliveryItemsHTML(resultArray[0]?.itemData || [],true)}
    <tr><td rowspan="3" colspan="4"><p>Remarks: ${resultArray[0]?.orderData?.icn_remarks || "-"}</p></td><td colspan="2"><b><p>disc amt:</b></p></td><td colspan="4"><p>${totals.totalDiscount.toFixed(2)}</p></td><td colspan="3"><p>Gross:</p></td><td colspan="4"><p>${totals.subtotal.toFixed(2)}</p></td></tr>
    <tr><td colspan="2"><p><b>Other charges:</b></p></td><td colspan="4"><p>0.00</p></td><td colspan="3"><p><b>Total Tax:</b></p></td><td colspan="4"><p>${totals.totalTax.toFixed(2)}</p></td></tr>
    <tr><td colspan="6"></td><td colspan="3"><p><b>Disc:</b></p></td><td colspan="4"><p>${totals.totalDiscount.toFixed(2)}</p></td></tr>
    <tr><td colspan="4"><p><b>FOR: ${resultArray[0]?.orderData?.cmr_company ? 
      resultArray[0]?.orderData?.cmr_company : 
      (resultArray[0]?.orderData?.cmr_first_name || resultArray[0]?.orderData?.cmr_last_name ? 
        [resultArray[0]?.orderData?.cmr_first_name, resultArray[0]?.orderData?.cmr_last_name].filter(Boolean).join(" ") : 
        "-")}
    </b></p></td><td colspan="6"><p><b>${toWords.convert(totals.netAmount)}</b></p></td><td colspan="3"><b>Net:</b></td><td colspan="4">${totals.netAmount.toFixed(2)}</td></tr>
    <tr style="height: 100px;">
    <td colspan="14" style="border-right: none;">
      <p>
        Terms & Conditions:<br>
        - Items once purchased should not be returned<br>
      </p>
    </td>
    <td colspan="3" style="text-align: right; vertical-align: bottom;border-left: none;">
      <p>Authorized Signature</p>
    </td>
  </tr>

  </table>
    
    
    </div>
</body>
</html>
  `;
}
