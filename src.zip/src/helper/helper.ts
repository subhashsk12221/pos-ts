


import client from '../util/database';


export function roundValue(value: any, roundingMethod: any, roundingRule: any) {
    console.log(value, roundingMethod, roundingRule)
    switch (roundingMethod) {
        case "no_rounding":
            // No rounding required, return the original value
            return value;
        case "round_full_dec_amt":
            // Round to the nearest integer based on the rounding rule
            switch (roundingRule) {
                case "round_closest":
                    return Math.round(value);
                case "round_up":
                    return Math.ceil(value);
                case "round_down":
                    return Math.floor(value);
                default:
                    return value;
            }
        case "round_full_amt":
            // Round up to the next whole number based on the rounding rule
            switch (roundingRule) {
                case "round_closest":
                    return Math.round(value);
                case "round_up":
                    return Math.ceil(value);
                case "round_down":
                    return Math.floor(value);
                default:
                    return value;
            }
        case "round_full_tens_amt":
            // Round up to the next tens place based on the rounding rule
            switch (roundingRule) {
                case "round_closest":
                    return Math.round(value / 10) * 10;
                case "round_up":
                    return Math.ceil(value / 10) * 10;
                case "round_down":
                    return Math.floor(value / 10) * 10;
                default:
                    return value;
            }
        default:
            // Default case: No rounding
            return value;
    }
}

export async function getQueryPlan(query: any) {
    try {
        const explainQuery = `EXPLAIN ${query}`;
        const explainAnalyzeQuery = `EXPLAIN ANALYZE ${query}`;


        const explainResult = await client.query(explainQuery);
        const explainAnalyzeResult = await client.query(explainAnalyzeQuery);


        return {
            explain: explainResult.rows,
            explainAnalyze: explainAnalyzeResult.rows,
        };
    } catch (error) {
        throw new Error(error);
    }
}
